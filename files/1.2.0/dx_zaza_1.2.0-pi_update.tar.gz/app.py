import ipaddress
import json
from urllib.parse import urlparse
import os
import re
import socket
import threading
import time
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

from services.digital_voice_config_service import sanitize_digital_voice_config_for_api
from services.digital_voice_service import get_digital_voice_readiness, get_digital_voice_status
from services.dx_spots_service import get_dx_spots
from services.band_activity import BandActivity
from services.dx_cluster_stream import DXClusterStream
from services.weather_service import WeatherService
from services.qrz_service import QRZClient, QRZError
from services.network_service import connect_wifi_network, get_network_status, scan_wifi_networks
from services.iss_service import get_iss_info
from services.update_service import UpdateService, voice_busy_reason
from services.satellite_service import get_satellite_passes
from services.solar_service import get_band_conditions, get_solar_conditions
from services.geo_service import (cty_status, distance_bearing, is_valid_locator,
                                  latlon_to_locator, locator_to_latlon)
from services.space_service import get_aurora, get_satellites
from services.bluedv_service import control_bluedv, get_bluedv_status
from services.geo_service import _data_dir as geo_data_dir, locate as geo_locate
from services.platform_service import detect_platform, features as platform_features
from voice.api import create_voice_blueprint, pi_busy_check
from services.location_service import AutoLocation


BASE_DIR = Path(__file__).resolve().parent
DEFAULT_CONFIG = BASE_DIR / "config.example.json"
LOCAL_CONFIG = BASE_DIR / "config.local.json"
CALLSIGN_RE = re.compile(r"^[A-Z0-9/]{3,20}$")
SUPPORTED_LANGUAGES = {"en", "it"}
NETWORK_CHECK_HOST = os.environ.get("DX_ZAZA_NETWORK_CHECK_HOST", "example.com")
NETWORK_CHECK_TTL_SECONDS = 15
_network_check_cache = {"checked_at": 0.0, "online": False}


def resolve_webapp_dir():
    for name in ("dx_zaza_webapp", "dx_zaza_live_webapp"):
        candidate = BASE_DIR / name
        if (candidate / "index.html").exists():
            return candidate
    raise RuntimeError(
        "DX Zaza webapp not found. Expected dx_zaza_webapp or dx_zaza_live_webapp next to app.py."
    )


def resolve_config_path():
    env_config = os.environ.get("DX_ZAZA_CONFIG", "").strip()
    if env_config:
        env_path = Path(env_config).expanduser()
        if env_path.exists():
            return env_path
    if LOCAL_CONFIG.exists():
        return LOCAL_CONFIG
    return DEFAULT_CONFIG


def writable_config_path():
    env_config = os.environ.get("DX_ZAZA_CONFIG", "").strip()
    if env_config:
        return Path(env_config).expanduser()
    return LOCAL_CONFIG


WEBAPP_DIR = resolve_webapp_dir()
ACTIVE_CONFIG = resolve_config_path()
WRITABLE_CONFIG = writable_config_path()


def load_config():
    with DEFAULT_CONFIG.open("r", encoding="utf-8") as handle:
        config = json.load(handle)
    if ACTIVE_CONFIG.exists() and ACTIVE_CONFIG != DEFAULT_CONFIG:
        with ACTIVE_CONFIG.open("r", encoding="utf-8") as handle:
            local_config = json.load(handle)
        deep_merge(config, local_config)
    return config


def deep_merge(base, override):
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            deep_merge(base[key], value)
        else:
            base[key] = value
    return base


def mask_callsign(callsign):
    value = str(callsign or "").strip().upper()
    if not value:
        return ""
    if len(value) <= 3:
        return value[0] + "***"
    return value[:2] + "***" + value[-1]


def normalize_operator_callsign(value):
    callsign = str(value or "").strip().upper()
    if not callsign:
        raise ValueError("Operator callsign is required")
    if " " in callsign or not CALLSIGN_RE.fullmatch(callsign):
        raise ValueError("Use letters, numbers and slash only, with no spaces")
    if "//" in callsign or callsign.startswith("/") or callsign.endswith("/"):
        raise ValueError("Use a valid callsign format")
    return callsign


def is_valid_operator_callsign(value):
    try:
        normalize_operator_callsign(value)
        return True
    except ValueError:
        return False


def _cluster_recently_alive(seconds=180):
    """Spots arrived from the DX cluster a moment ago: the internet is clearly there."""
    stream = globals().get("dx_stream")
    try:
        return bool(stream and stream.last_spot and time.time() - stream.last_spot < seconds)
    except Exception:  # pragma: no cover
        return False


def network_online():
    now = time.monotonic()
    if now - _network_check_cache["checked_at"] < NETWORK_CHECK_TTL_SECONDS:
        return _network_check_cache["online"]
    try:
        socket.getaddrinfo(NETWORK_CHECK_HOST, 443, type=socket.SOCK_STREAM)
        online = True
    except OSError:
        # a short DNS hiccup must not blank the spot list while the cluster is working
        online = _cluster_recently_alive()
    _network_check_cache.update({"checked_at": now, "online": online})
    return online


def get_setup_state(active_config, online=None):
    operator = active_config.get("operator", {}) or {}
    operator_configured = is_valid_operator_callsign(operator.get("callsign"))
    network_is_online = network_online() if online is None else bool(online)
    reasons = []
    if not operator_configured:
        reasons.append("Configure Operator Callsign to enable live radio spots.")
    if not network_is_online:
        reasons.append("Connect DX Zaza to the internet to enable live radio spots.")
    ready_for_live = operator_configured and network_is_online
    return {
        "operator_configured": operator_configured,
        "operator_masked_present": bool(mask_callsign(operator.get("callsign"))) if operator_configured else False,
        "network_online": network_is_online,
        "ready_for_live": ready_for_live,
        "setup_required": not ready_for_live,
        "reasons": reasons,
    }


def normalize_ui_language(value):
    language = str(value or "").strip().lower()
    if language not in SUPPORTED_LANGUAGES:
        raise ValueError("Supported languages: en, it")
    return language


def load_local_config():
    if not WRITABLE_CONFIG.exists():
        return {}
    with WRITABLE_CONFIG.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def save_local_config(local_config):
    WRITABLE_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    WRITABLE_CONFIG.write_text(
        json.dumps(local_config, indent=2, ensure_ascii=True) + "\n",
        encoding="utf-8",
    )


def save_operator_callsign(callsign):
    local_config = load_local_config()
    local_config.setdefault("operator", {})["callsign"] = callsign
    save_local_config(local_config)
    config.setdefault("operator", {})["callsign"] = callsign


def normalize_locator(value):
    locator = str(value or "").strip()
    if not is_valid_locator(locator):
        raise ValueError("Use a Maidenhead locator like JO01 or JO01ab")
    return locator[:2].upper() + locator[2:4] + locator[4:6].lower() + locator[6:8]


def save_operator_locator(locator, mode="manual", location=None):
    changes = {"locator": locator, "location_mode": mode}
    if location is not None:
        changes["location"] = location
    local_config = load_local_config()
    local_config.setdefault("operator", {}).update(changes)
    save_local_config(local_config)
    config.setdefault("operator", {}).update(changes)


def location_mode():
    """'auto' (from the Internet connection) unless the operator typed a locator."""
    operator = config.get("operator", {}) or {}
    mode = operator.get("location_mode")
    if mode in ("auto", "manual"):
        return mode
    return "manual" if is_valid_locator(operator.get("locator", "")) else "auto"


def apply_auto_location(result):
    locator = latlon_to_locator(result["lat"], result["lon"], 6)
    save_operator_locator(locator, mode="auto", location={
        "city": result.get("city", ""), "region": result.get("region", ""),
        "country": result.get("country", ""), "provider": result.get("provider", ""),
        "updated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    })


auto_location = AutoLocation(location_mode, apply_auto_location)


def get_home():
    """Operator QTH (lat, lon) from the Maidenhead locator, or None."""
    locator = (config.get("operator", {}) or {}).get("locator", "")
    if not is_valid_locator(locator):
        return None
    try:
        return locator_to_latlon(locator)
    except ValueError:
        return None


def save_voice_settings(changes):
    local_config = load_local_config()
    local_config.setdefault("voice", {}).update(changes)
    save_local_config(local_config)
    try:
        os.chmod(WRITABLE_CONFIG, 0o600)   # may hold the DMR hotspot password: owner only
    except OSError:
        pass
    config.setdefault("voice", {}).update(changes)


def operator_callsign():
    callsign = (config.get("operator", {}) or {}).get("callsign", "")
    return callsign if is_valid_operator_callsign(callsign) else ""


def save_ui_language(language):
    local_config = load_local_config()
    local_config.setdefault("ui", {})["language"] = language
    save_local_config(local_config)
    config.setdefault("ui", {})["language"] = language


config = load_config()
PLATFORM = detect_platform()
app = Flask(__name__, static_folder=str(WEBAPP_DIR), static_url_path="")
def _app_version():
    try:
        return (BASE_DIR / "VERSION").read_text().strip()
    except OSError:
        return "dev"


def weather_user_agent():
    """MET Norway asks for an identifying User-Agent: app/version plus a contact
    (config "weather": {"contact": "email or website of the seller"})."""
    contact = str(((config.get("weather") or {}).get("contact") or "")).strip()[:120]
    agent = "DXZaza/%s (amateur radio dashboard)" % _app_version()
    return agent + (" " + contact if contact else "")


def _weather_store():
    try:
        from services.geo_service import _data_dir
        return str(_data_dir() / "weather_last.json")
    except Exception:  # pragma: no cover
        return None


weather = WeatherService(weather_user_agent(), store_path=_weather_store())


@app.get("/api/weather")
def api_weather():
    home = get_home()
    if not home:
        return jsonify({"ok": False, "error": "Set your QTH locator to see the local weather."})
    weather.user_agent = weather_user_agent()
    operator = config.get("operator", {}) or {}
    lang = ((config.get("ui") or {}).get("language") or "en")
    place = ((operator.get("location") or {}).get("city") or "")
    return jsonify(weather.get(home[0], home[1], lang=lang, place=place))


# ------------------------------------------------------------------ QRZ.com (operator's own account)
def qrz_credentials():
    q = config.get("qrz") or {}
    return str(q.get("username") or ""), str(q.get("password") or "")


qrz = QRZClient(qrz_credentials, agent="DXZaza" + _app_version().split("-")[0])


def save_qrz_credentials(username, password):
    local_config = load_local_config()
    if username:
        local_config["qrz"] = {"username": username, "password": password}
    else:
        local_config.pop("qrz", None)
    save_local_config(local_config)
    try:
        os.chmod(WRITABLE_CONFIG, 0o600)   # holds a password: owner only
    except OSError:
        pass
    if username:
        config["qrz"] = {"username": username, "password": password}
    else:
        config.pop("qrz", None)


@app.get("/api/qrz/status")
def api_qrz_status():
    return jsonify(dict(qrz.status(), ok=True))


@app.post("/api/qrz/login")
def api_qrz_login():
    payload = request.get_json(silent=True) or {}
    username = str(payload.get("username", "")).strip()[:64]
    password = str(payload.get("password", ""))[:128]
    if not username or not password:
        return jsonify({"ok": False, "error": "Enter your QRZ.com username and password."}), 400
    try:
        qrz.login(username, password)          # check before saving
    except QRZError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    save_qrz_credentials(username, password)
    return jsonify(dict(qrz.status(), ok=True))


@app.post("/api/qrz/logout")
def api_qrz_logout():
    qrz.logout()
    save_qrz_credentials("", "")
    return jsonify(dict(qrz.status(), ok=True))


@app.get("/api/qrz/lookup")
def api_qrz_lookup():
    call = str(request.args.get("call", ""))[:20]
    if not qrz.configured():
        return jsonify({"ok": False, "configured": False})
    try:
        record = qrz.lookup(call)
    except QRZError as exc:
        return jsonify({"ok": False, "configured": True, "error": str(exc)})
    if not record:
        return jsonify({"ok": False, "configured": True, "notFound": True})
    home = get_home()
    if home and record.get("lat") and record.get("lon"):
        try:
            d = distance_bearing(home[0], home[1], float(record["lat"]), float(record["lon"]))
            record = dict(record, distanceKm=round(d[0]), bearing=round(d[1]))
        except (TypeError, ValueError):
            pass
    return jsonify(dict(record, ok=True))


@app.get("/api/qrz/photo")
def api_qrz_photo():
    from flask import Response
    if not qrz.configured():
        return ("", 404)
    try:
        data, kind = qrz.photo(str(request.args.get("call", ""))[:20])
    except QRZError:
        data = None
    if not data:
        return ("", 404)
    return Response(data, mimetype=kind, headers={"Cache-Control": "private, max-age=86400"})


# live DX cluster session (started with the app, see __main__ and the desktop launcher)
band_activity = BandActivity()
dx_stream = DXClusterStream(lambda: config, on_spot=band_activity.record)

VOICE_BP = create_voice_blueprint(
    get_config=lambda: config,
    save_voice=save_voice_settings,
    get_callsign=operator_callsign,
    data_dir=geo_data_dir(),
    locate=lambda call: geo_locate(call),
    busy_check=pi_busy_check if PLATFORM == "pi" else None,
    resume_on_start=PLATFORM == "pi" and os.environ.get("DX_ZAZA_NO_RESUME") != "1",
)
app.register_blueprint(VOICE_BP)


def _exit_for_restart():
    """systemd (Restart=always) starts DX Zaza again a few seconds later."""
    try:
        VOICE_BP.voice_shutdown()   # release the DVstick cleanly
    finally:
        os._exit(0)


@app.post("/api/system/restart")
def api_system_restart():
    if not platform_features(PLATFORM).get("systemControls"):
        return jsonify({"ok": False, "error": "Not available on this device."}), 403
    target = str((request.get_json(silent=True) or {}).get("target", "app"))
    if target == "app":
        threading.Timer(0.7, _exit_for_restart).start()
        return jsonify({"ok": True, "target": "app", "message": "DX Zaza is restarting..."})
    if target == "reboot":
        import subprocess
        try:
            # allowed by /etc/sudoers.d/dx-zaza-system (installed by update_dx_zaza.sh)
            result = subprocess.run(["sudo", "-n", "/usr/sbin/reboot"], capture_output=True, text=True, timeout=10)
        except Exception as exc:  # pragma: no cover
            return jsonify({"ok": False, "error": str(exc)}), 500
        if result.returncode != 0:
            return jsonify({"ok": False, "error": "Reboot not permitted yet: run the DX Zaza installer once."}), 403
        return jsonify({"ok": True, "target": "reboot", "message": "The Raspberry Pi is restarting..."})
    return jsonify({"ok": False, "error": "unknown target"}), 400


LOCAL_ADDRESSES = {"127.0.0.1", "::1", "::ffff:127.0.0.1"}


def _host_name(value):
    value = (value or "").strip().lower()
    if value.startswith("["):                                  # [::1]:5050
        return value[1:value.find("]")] if "]" in value else value
    return value.rsplit(":", 1)[0] if value.count(":") == 1 else value


def _is_ip(name):
    try:
        ipaddress.ip_address(name)
        return True
    except ValueError:
        return False


@app.before_request
def block_other_websites():
    """Other web pages open in the user's browser must not drive DX Zaza.
    - DNS rebinding: a foreign host name pointing at 127.0.0.1 is refused (only IP addresses,
      "localhost" and the Pi's "<name>.local" are valid Host names).
    - Cross-site requests: anything that changes something (POST...) must come from DX Zaza's
      own page (same Origin); browsers always send Origin on cross-site POSTs."""
    host = _host_name(request.host)
    if not (host == "localhost" or host.endswith(".local") or _is_ip(host)):
        return jsonify({"ok": False, "error": "Unknown host."}), 403
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return None
    origin = request.headers.get("Origin", "")
    if origin and origin != "null":
        if urlparse(origin).netloc.lower() != (request.host or "").lower():
            return jsonify({"ok": False, "error": "Request from another website refused."}), 403
    elif origin == "null" or request.headers.get("Sec-Fetch-Site", "") == "cross-site":
        return jsonify({"ok": False, "error": "Request from another website refused."}), 403
    return None


@app.before_request
def only_the_screen_can_change_things():
    """On the Raspberry Pi the dashboard is reachable from the whole Wi-Fi network (read-only
    viewing is fine). Anything that changes the device - transmit, settings, Wi-Fi, reboot,
    QRZ password - is accepted only from the DX Zaza screen itself, unless the owner turns on
    "remote_control" in the config."""
    if request.method in ("GET", "HEAD", "OPTIONS") or PLATFORM != "pi":
        return None
    if (request.remote_addr or "") in LOCAL_ADDRESSES or config.get("remote_control") is True:
        return None
    return jsonify({"ok": False, "error": "Changes are allowed only on the DX Zaza screen."}), 403


@app.get("/")
def index():
    return send_from_directory(WEBAPP_DIR, "index.html")


@app.get("/favicon.ico")
def favicon():
    return send_from_directory(WEBAPP_DIR / "assets", "dx_zaza_logo.png", mimetype="image/png")


@app.get("/<path:path>")
def static_files(path):
    return send_from_directory(WEBAPP_DIR, path)


@app.get("/api/status")
def api_status():
    return jsonify({
        "ok": True,
        "mode": "live",
        "version": (BASE_DIR / "VERSION").read_text().strip() if (BASE_DIR / "VERSION").exists() else "dev",
        "features": platform_features(PLATFORM),
    })


def startup_sound_enabled():
    return (config.get("ui", {}) or {}).get("startup_sound", True) is not False


@app.get("/api/ui/startup")
def api_ui_startup():
    """What the start-up screen shows: version, platform, whether the sound is on."""
    return jsonify({"ok": True, "version": _app_version(), "platform": PLATFORM,
                    "sound": startup_sound_enabled(), "language": (config.get("ui", {}) or {}).get("language", "en")})


@app.post("/api/ui/startup-chime")
def api_ui_startup_chime():
    if not startup_sound_enabled():
        return jsonify({"ok": True, "played": False})
    from services.startup_chime import play_chime
    return jsonify({"ok": True, "played": play_chime()})


@app.post("/api/ui/startup-sound")
def api_ui_startup_sound():
    enabled = bool((request.get_json(silent=True) or {}).get("enabled", True))
    local_config = load_local_config()
    local_config.setdefault("ui", {})["startup_sound"] = enabled
    save_local_config(local_config)
    config.setdefault("ui", {})["startup_sound"] = enabled
    return jsonify({"ok": True, "sound": enabled})


@app.get("/api/settings")
def api_settings():
    operator = config.get("operator", {}) or {}
    ui = config.get("ui", {}) or {}
    setup_state = get_setup_state(config)
    digital_voice_config = sanitize_digital_voice_config_for_api(config)
    try:
        language = normalize_ui_language(ui.get("language") or "en")
    except ValueError:
        language = "en"
    return jsonify({
        "ok": True,
        "operator": {
            "configured": setup_state["operator_configured"],
            "callsign_masked": mask_callsign(operator.get("callsign")) if setup_state["operator_configured"] else "",
            "locator": operator.get("locator", "") if is_valid_locator(operator.get("locator", "")) else "",
            "location": dict(operator.get("location") or {}, mode=location_mode()),
        },
        "ui": {
            "language": language,
        },
        "platform": platform_features(PLATFORM),
        "network": {
            "online": setup_state["network_online"],
        },
        "digital_voice": {
            "configured": digital_voice_config["configured"],
            "configuration_valid": digital_voice_config["valid"],
        },
        "setup": {
            "required": setup_state["setup_required"],
            "ready_for_live": setup_state["ready_for_live"],
            "reasons": setup_state["reasons"],
        },
    })


@app.post("/api/settings/operator")
def api_settings_operator():
    payload = request.get_json(silent=True) or {}
    try:
        callsign = normalize_operator_callsign(payload.get("callsign"))
    except ValueError as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
        }), 400
    save_operator_callsign(callsign)
    return jsonify({
        "ok": True,
        "message": "Operator callsign saved",
        "operator": {
            "configured": True,
            "callsign_masked": mask_callsign(callsign),
        },
    })


@app.post("/api/settings/locator")
def api_settings_locator():
    payload = request.get_json(silent=True) or {}
    try:
        locator = normalize_locator(payload.get("locator"))
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    save_operator_locator(locator, mode="manual")
    return jsonify({"ok": True, "message": "Locator saved", "operator": {"locator": locator,
                                                                        "location": {"mode": "manual"}}})


@app.post("/api/settings/location")
def api_settings_location():
    """{"mode": "auto"}: find the position from the Internet connection now."""
    payload = request.get_json(silent=True) or {}
    if payload.get("mode") != "auto":
        return jsonify({"ok": False, "error": "unsupported mode"}), 400
    local_config = load_local_config()
    local_config.setdefault("operator", {})["location_mode"] = "auto"
    save_local_config(local_config)
    config.setdefault("operator", {})["location_mode"] = "auto"
    result = auto_location.refresh(force=True)
    if not result:
        return jsonify({"ok": False, "error": "Position not found: check the Internet connection. "
                                              + auto_location.last_error}), 502
    operator = config.get("operator", {})
    return jsonify({"ok": True, "operator": {"locator": operator.get("locator", ""),
                                             "location": dict(operator.get("location") or {}, mode="auto")}})


@app.post("/api/settings/language")
def api_settings_language():
    payload = request.get_json(silent=True) or {}
    try:
        language = normalize_ui_language(payload.get("language"))
    except ValueError as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
        }), 400
    save_ui_language(language)
    return jsonify({
        "ok": True,
        "message": "Language saved",
        "ui": {
            "language": language,
        },
    })


@app.get("/api/solar")
def api_solar():
    return jsonify(get_solar_conditions(config))


@app.get("/api/network/status")
def api_network_status():
    return jsonify(get_network_status(internet_online=network_online()))


@app.get("/api/network/wifi/scan")
def api_network_wifi_scan():
    return jsonify(scan_wifi_networks())


@app.get("/api/digital-voice/status")
def api_digital_voice_status():
    return jsonify(get_digital_voice_status(config))


@app.get("/api/digital-voice/readiness")
def api_digital_voice_readiness():
    setup_state = get_setup_state(config, online=True)
    return jsonify(
        get_digital_voice_readiness(
            operator_configured=setup_state["operator_configured"],
            status_result=get_digital_voice_status(config),
        )
    )


@app.post("/api/network/wifi/connect")
def api_network_wifi_connect():
    payload = request.get_json(silent=True) or {}
    result = connect_wifi_network(
        payload.get("ssid"),
        payload.get("password"),
        payload.get("timeout_seconds", 45),
    )
    return jsonify(result), 200 if result.get("ok") else 400


@app.get("/api/dx-spots")
def api_dx_spots():
    result = get_dx_spots(config, get_setup_state(config), stream=dx_stream)
    home = get_home()
    if home and isinstance(result, dict) and result.get("spots"):
        result = dict(result)
        enriched = []
        for spot in result["spots"]:
            spot = dict(spot)
            lat, lon = spot.get("dxLat", spot.get("lat")), spot.get("dxLon", spot.get("lon"))
            if lat is not None and lon is not None:
                dist, brg = distance_bearing(home[0], home[1], lat, lon)
                spot["distanceKm"], spot["bearing"] = round(dist), round(brg)
            enriched.append(spot)
        result["spots"] = enriched
    return jsonify(result)


@app.get("/api/map/context")
def api_map_context():
    home = get_home()
    return jsonify({
        "ok": True,
        "home": {"lat": round(home[0], 2), "lon": round(home[1], 2),
                 "locator": latlon_to_locator(home[0], home[1], 4)} if home else None,
        "prefixDatabase": cty_status(),
    })


@app.get("/api/aurora")
def api_aurora():
    return jsonify(get_aurora())


@app.get("/api/satellites")
def api_satellites():
    return jsonify(get_satellites(get_home()))


@app.get("/api/band-activity")
def api_band_activity():
    """Which HF bands are open right now, from the live DX cluster spots (last 15 minutes)."""
    return jsonify(band_activity.summary(get_home()))


@app.get("/api/bands")
def api_bands():
    return jsonify(get_band_conditions(config))


@app.get("/api/bluedv/status")
def api_bluedv_status():
    return jsonify(get_bluedv_status(config))


@app.post("/api/bluedv/<action>")
def api_bluedv_action(action):
    result = control_bluedv(action, config)
    return jsonify(result), 200 if result.get("ok") else 400


# online updates: checked by itself, installed with one button (see services/update_service.py)
updater = UpdateService(lambda: config, _app_version,
                        busy_check=lambda: voice_busy_reason(getattr(VOICE_BP, "engine_status", None)))


@app.get("/api/update/status")
def api_update_status():
    return jsonify(updater.status())


@app.post("/api/update/check")
def api_update_check():
    return jsonify(updater.check())


@app.post("/api/update/install")
def api_update_install():
    result = updater.install()
    return jsonify(result), (200 if result.get("ok") else 409)


@app.get("/api/iss")
def api_iss():
    """ISS Live: NASA video stream (embedded player) and ARISS frequencies for the map card."""
    lang = ((config.get("ui") or {}).get("language") or "en")
    return jsonify(get_iss_info(config, home=get_home(), lang=lang, origin=request.host_url))


@app.get("/api/satellite-passes")
def api_satellite_passes():
    return jsonify(get_satellite_passes(config))


def _graceful_exit(signum, _frame):
    """systemd stop / restart: unlink the reflector and release the DVstick, then exit."""
    try:
        VOICE_BP.voice_shutdown()
    finally:
        os._exit(0)


if __name__ == "__main__":
    import signal
    signal.signal(signal.SIGTERM, _graceful_exit)
    auto_location.start()
    dx_stream.start()
    updater.start()
    host = os.environ.get("DX_ZAZA_HOST", "0.0.0.0")
    port = int(os.environ.get("DX_ZAZA_PORT", "5050"))
    app.run(host=host, port=port, debug=False)
