# DX Zaza — Third-party notices

DX Zaza is built with the open-source software and open data listed below. Their licences allow
use in a commercial product; most of them ask that their copyright notice travels with the
product: this file is shipped inside the app for that purpose.

## Software inside the app

| Component | Licence |
|---|---|
| Python runtime | PSF License |
| Flask, Werkzeug, Jinja2, MarkupSafe, itsdangerous, click, blinker (Pallets) | BSD 3-Clause |
| requests | Apache License 2.0 |
| urllib3, charset-normalizer | MIT |
| idna | BSD 3-Clause |
| certifi (CA certificates) | Mozilla Public License 2.0 (unmodified) |
| NumPy | BSD 3-Clause |
| sgp4 (Brandon Rhodes) | MIT |
| pyserial (Chris Liechti) | BSD 3-Clause |
| python-sounddevice (Matthias Geier) | MIT |
| PortAudio | MIT |
| pywebview (Roman Sirokov) | BSD 3-Clause |
| PyObjC (macOS) | MIT |
| PyInstaller bootloader | GPL 2.0 with the PyInstaller exception (allows distributing the built app under any licence) |

### GSM 06.10 codec (EchoLink audio)

`voice/gsm610.py` is a Python port of libgsm:

    Copyright 1992, 1993, 1994 by Jutta Degener and Carsten Bormann,
    Technische Universitaet Berlin

    Any use of this software is permitted provided that this notice is not removed and that
    neither the authors nor the Technische Universitaet Berlin are deemed to have made any
    representations as to the suitability of this software for any purpose nor are held
    responsible for any defects of this software. THERE IS ABSOLUTELY NO WARRANTY FOR THIS
    SOFTWARE.

## Fonts

Chakra Petch, Space Grotesk, JetBrains Mono — SIL Open Font License 1.1 (licence files in
`dx_zaza_webapp/assets/fonts`).

## Map data

Natural Earth (public domain) via world-atlas (ISC). Land mask: GLOBE data via global-land-mask
(MIT). NASA GIBS imagery (satellite, relief and night-lights map styles): NASA, public domain.

## Live data shown in the app (credited in the interface)

- Space weather and aurora: NOAA Space Weather Prediction Center (US Government, public domain).
- Satellites: CelesTrak TLEs (Dr T.S. Kelso).
- Weather: MET Norway Locationforecast (CC BY 4.0) — "Weather data: MET Norway".
- ISS live video: NASA (public domain), played with YouTube's official embedded player under the
  YouTube Terms of Service. ISS amateur radio frequencies: ARISS (ariss.org).
- DX spots: DX cluster network (DXSpider / CC Cluster / AR-Cluster nodes).
- Callsign data: QRZ.com XML service with the operator's own account; RadioID.net (DMR IDs);
  AD1C cty.dat (country of a callsign).
- Reflector and room lists: XLX registry, Pi-Star host files (DVRef).
- EchoLink® is a registered trademark of Synergenics, LLC.
