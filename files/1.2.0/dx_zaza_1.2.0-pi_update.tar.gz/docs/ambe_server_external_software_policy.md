# AMBE Server External Software Policy

Internal technical policy. Not customer-facing legal advice.

## Scope

DX Zaza Digital Voice Phase 2B.5 prepares interoperability architecture for a future separately installed AMBE Server.

This phase does not install AMBE Server, install BlueDV, download third-party binaries, execute third-party install scripts, enable TX, create PTT, or make Digital Voice operational.

## PA7LIM Boundary

PA7LIM AMBEServer3000 for Linux is the current technical interoperability candidate.

The official source currently identified is:

```text
https://www.pa7lim.nl/ambeserver-3000-for-linux/
```

Technical reference parameters from the PA7LIM documentation:

- configurable `serialPort`
- `serialSpeed=460800`
- `network=udp`
- `port=2460`
- bind configuration available

DX Zaza architecture requires:

- serial device `/dev/dvmega-ambestick`
- localhost bind, normalized to `127.0.0.1`
- UDP network
- port `2460`
- serial speed `460800`

DX Zaza Phase 2B.5 must not redistribute PA7LIM AMBEServer3000.

DX Zaza packages must not contain:

- PA7LIM AMBE binary
- PA7LIM install script
- copied PA7LIM executable
- modified PA7LIM binary
- PA7LIM source, unless separately licensed in a future phase

Redistribution and commercial bundling permission has not been confirmed. Do not treat "free" as equivalent to open-source, redistributable, or commercially redistributable.

## External Software Path

The future interoperability path may look for a separately installed external binary at:

```text
/usr/local/ambeserver3k/ambeserver
```

That path is an external software path. It is not owned by DX Zaza and must not be populated by this package.

## NW Digital Radio Boundary

NW Digital Radio AMBEserver remains a separate future GPL/source candidate.

It is not selected for Phase 2B.5 installation or bundling.

Before any future use, DX Zaza must separately validate:

- DVMEGA DVstick 30 compatibility
- localhost binding/security posture
- exact GPL obligations and notices
- source/binary distribution model
- commercial product implications

## Current Phase Rule

Phase 2B.5 may install only DX Zaza-owned integration files:

- preflight helper
- fail-closed wrapper
- disabled systemd service candidate
- install/uninstall helper for those DX Zaza-owned files
- documentation and tests

Phase 2B.5 must not make AMBE Server operational.
