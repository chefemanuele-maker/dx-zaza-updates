# BlueDV Radio Integration (DX Zaza 0.4)

Internal technical document.

## What it is
BlueDV Radio is free software by David PA7LIM (https://www.pa7lim.nl/bluedv-dv-radio/) for
Raspberry Pi 3/4/5, 64-bit Raspberry Pi OS (trixie), with an AMBE3000 USB stick (DVMEGA DVstick 30
or ThumbDV), QX-18B microphone and a USB speaker. It offers D-STAR, DMR, Fusion and EchoLink and is
controlled from a web page (port 8080, default login bluedv / bluedv).

## Architecture (keeps Phase 2B rules)
- DX Zaza Core never opens the DVstick serial device.
- `bluedv.service` (user `bluedv`) runs `/usr/local/bluedv/bluedv-radio`; NOT enabled at boot by default.
- DX Zaza starts/stops it only on an explicit user action through
  `/usr/local/sbin/dx-zaza-bluedv-ctl` (root, allowed by `/etc/sudoers.d/dx-zaza-bluedv`).
- ONE OWNER OF THE DVSTICK AT A TIME:
  - `direct` (default): the helper stops `dx-zaza-ambe-server.service`, sets
    `[AMBE] SerialPort = /dev/dvmega-ambestick` in BlueDV's config.ini and starts BlueDV.
  - `ambe_server`: the AMBE Server owns the stick; BlueDV uses it via
    `[AMBE] Type = net`, `UDPServer = 127.0.0.1`, `UDPPort = 2460`.
  Mode is chosen in config: `digital_voice.blue_dv.ambe_mode`.
- The BlueDV page shows the BlueDV web interface in an iframe (`http://<host>:8080/`).

## Install (on the Raspberry Pi)
    sudo /opt/dx-zaza/scripts/install_bluedv_radio.sh            # BlueDV starts only from DX Zaza
    sudo /opt/dx-zaza/scripts/install_bluedv_radio.sh --enable-at-boot

Differences from the official installer (deliberate):
- no `apt upgrade`, no edits to /boot config (no SPI TFT overlay): the DX Zaza touchscreen setup is untouched;
- BlueDV is not enabled at boot unless requested;
- callsign copied from DX Zaza Operator Setup into `[GENERAL] call`.

Remove: `sudo /opt/dx-zaza/scripts/uninstall_bluedv_radio.sh [--remove-bluedv]`

## After install
Open BlueDV Setup (in the DX Zaza BlueDV page): change the default password, check callsign,
DMR ID and audio devices. Transmitting through reflectors requires a valid amateur licence.

## Open points before selling DX Zaza with BlueDV
- Written permission from PA7LIM to integrate/offer BlueDV Radio in a commercial product.
- Test on the real Pi 4 + DVstick 30 + QX-18B; check that BlueDV's web page allows being framed
  (if not, use the Full screen button / open it directly).
