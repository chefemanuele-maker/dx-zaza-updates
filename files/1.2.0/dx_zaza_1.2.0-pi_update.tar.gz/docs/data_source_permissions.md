# Data Source Permissions

## NOAA/SWPC
NOAA/SWPC puo' essere usato come fonte futura/autorizzata per space weather, rispettando cache e rate limit ragionevoli.

## N2YO
N2YO richiede API key. La chiave deve stare in config locale privata e non deve essere hardcoded.

## AMSAT / Celestrak / SatNOGS
Sono possibili fonti future per dati satellitari, da verificare per licenza, limiti e attribuzione.

## DX Cluster

DX Cluster live richiede fonte autorizzata o nodo Telnet stabile. Nessuno scraping aggressivo.

DX Cluster/Telnet e' l'integrazione live preferita per gli spot rispetto allo scraping HTML. Usare un nodo autorizzato/stabile e rispettare regole d'uso, limiti e policy del gestore.

## QRZ
QRZ non fa parte del MVP. Eventuale integrazione futura richiede API ufficiale e permessi.


## DX Zaza 0.4 — sources added (status for COMMERCIAL sale)

| Source | Used for | Licence / terms | Status for a product for sale |
|---|---|---|---|
| NOAA SWPC (services.swpc.noaa.gov) | Kp, A, SFI, X-ray, solar wind, aurora OVATION | US Government, public domain | OK (credit NOAA SWPC) |
| CelesTrak (celestrak.org) | Satellite TLEs | Free; usage policy: download only when needed, stop on errors | OK: DX Zaza downloads at most every 12 h. Credit CelesTrak. |
| AD1C Country Files (cty.dat) | Callsign -> DXCC entity and position | Free, widely used by logging software; commercial terms not published | TO CONFIRM with AD1C before selling (fallback table works without it) |
| N0NBH (hamqsl.com) | HF band conditions day/night, VHF | Free for personal use with credit; ShackComs sells units WITH N0NBH permission | OFF by default (`data_sources.n0nbh_band_conditions`). Enable on sold units only with written permission |
| DX Cluster node (dxc.hamserve.uk) | Live spots | Node rules apply | TO CONFIRM with the node sysop for many commercial units |
| BlueDV Radio (PA7LIM) | BlueDV page | Free software, not redistributed by DX Zaza | TO CONFIRM with PA7LIM before selling |
| global-land-mask (GLOBE data) | Generated map image | MIT package / public-domain data | OK: the generated map is a DX Zaza asset |

## DX Zaza 0.5 — digital voice sources

| Source | Used for | Status for a product for sale |
|---|---|---|
| XLX registry (xlxapi.rlx.lu) | List of XLX reflectors | Public list used by hotspot software; credit; cached 24 h |
| DExtra host list (pistar.uk) | XRF/XLX addresses | Public list (Pi-Star); cached 24 h. TO CONFIRM for commercial use, or host our own list |
| XLX / XRF reflectors | Voice network | Each reflector has its own rules; operators must use their own licensed callsign |
| DVSI AMBE-3000 (inside the DVstick) | Voice codec | Licensed in the hardware the customer buys; DX Zaza contains no codec |

## DX Zaza 0.5 — automatic position (IP geolocation)

| Source | Used for | Status for a product for sale |
|---|---|---|
| ipinfo.io, ipapi.co, ipwho.is, freeipapi.com (first that answers) | Town of the Internet connection -> QTH locator | One request at start-up and at most every 6 h per unit. Free tiers; for many sold units confirm the terms or buy a key (ipinfo.io / ipapi.co offer commercial plans) and put it first in `services/location_service.py`. The position stays on the device. |
| Natural Earth 1:50m via world-atlas | Base map | Public domain / ISC: OK |
| Fonts Chakra Petch, Space Grotesk, JetBrains Mono | Interface | SIL Open Font License: OK (licences in `dx_zaza_webapp/assets/fonts`) |


## Local weather (top bar) — MET Norway

- Source: MET Norway Locationforecast 2.0 (api.met.no), open data, licence CC BY 4.0
  (commercial use allowed with attribution). Credit shown: "Weather data: MET Norway (CC BY 4.0)".
- Terms followed: identifying User-Agent (`DXZaza/<version> (amateur radio dashboard)` plus the
  seller contact from config `weather.contact` — **set a company email or website before sale**),
  coordinates truncated to 2 decimals, one shared backend cache honouring `Expires`,
  `If-Modified-Since`, at most one request per location every 10-60 minutes.
- Terms: https://developer.yr.no/doc/TermsOfService/


## QRZ.com callsign data (Digital Voice cards)

- Official QRZ XML Logbook Data interface (https://www.qrz.com/XML/current_spec.html), used with
  the operator's own QRZ.com account and subscription; DX Zaza ships no QRZ account.
- No scraping of qrz.com pages. Session key cached; each callsign looked up at most once per day
  (not found: once per hour). Agent string "DXZaza<version>".
- Shown: photo, name, nickname, city, state, country, grid, distance. Not shown: street, e-mail.
- Password stored only in the local config file (mode 600), never logged or returned by the API.
- Before sale: confirm QRZ.com terms for commercial third-party software.


## DMR (Digital Voice)

- DMR masters list: Pi-Star DMR_Hosts.txt (http://www.pistar.uk/downloads/DMR_Hosts.txt), cached 24 h,
  built-in fallback. Networks: BrandMeister, TGIF, FreeDMR... each operator uses their own DMR ID and,
  on BrandMeister, their own hotspot password. Protocol written from the public MMDVM/Homebrew
  description; air interface from ETSI TS 102 361-1. No third-party code copied.
- DMR ID <-> callsign: RadioID.net public API, one request per new ID, cached 30 days on disk.
  Before sale: confirm RadioID.net API terms for a commercial product (or ship their bulk file under
  its licence).
- AMBE+2 vocoding happens in the operator's DVstick (licensed hardware): no software vocoder.


## C4FM (Digital Voice)

- Room list: Pi-Star YSF_Hosts.txt (http://www.pistar.uk/downloads/YSF_Hosts.txt), generated from DVRef
  (https://dvref.com, acceptable use policy https://dvref.com/aup/). Cached 24 h, small built-in fallback.
  Before sale: confirm DVRef's AUP allows use in a commercial product, or let the user fetch the list.
- YSF network protocol and air interface written from the public MMDVM/YSF description; frame coding verified
  against the MMDVM reference output in tests. No third-party code copied.

## EchoLink (Digital Voice)

- EchoLink(R) is a registered trademark of Synergenics, LLC. The directory (servers.echolink.org, TCP 5200)
  and station protocol (UDP 5198/5199) are used by independent compatible software (Qtel, SvxLink, thebridge).
  Each operator logs in with their own validated EchoLink account; passwords stay on the device (mode 600).
  BEFORE SALE: ask Synergenics for permission to ship an EchoLink-compatible client in a commercial product
  and how to name it (e.g. "works with EchoLink").
- GSM 06.10 codec: Python port of libgsm (Jutta Degener and Carsten Bormann, TU Berlin). Its licence permits
  any use, copy, modification and distribution, with or without fee, provided the copyright notice is kept:
  the notice is in voice/gsm610.py and must stay there (and in the product's third-party notices).
- EchoLink public proxies (list from https://www.echolink.org/proxylist.jsp, password "PUBLIC"): used
  automatically only when a station cannot reach the operator directly (router without forwarded UDP
  5198/5199). They are volunteer resources ("please be considerate and use them sparingly"): DX Zaza tries
  direct first, uses one proxy per connection and releases it on disconnect. Before sale: confirm with
  Synergenics that a commercial client may fall back to the public proxies (or run DX Zaza's own proxy).


## DX Zaza 0.9.2 – 0.9.5 — added sources

| Source | Used for | Status for a product for sale |
|---|---|---|
| DX cluster fallback nodes: VE7CC (dxc.ve7cc.net:23), W3LPL (w3lpl.net:7373) | Spots when the main node is down | Public read-only telnet nodes; DX Zaza only logs in and reads (no keep-alive text). TO CONFIRM with the sysops for many sold units, like the main node |
| NOAA SWPC ACE 1-hour and RTSW files | Solar wind speed, density, Bz | Public domain (the old products/solar-wind 5-minute files were retired by NOAA) |
| NASA ISS live video (YouTube) | ISS Live player | NASA content is public domain. Played only through YouTube's official embedded player (YouTube API Services Terms): YouTube's logo/title must stay visible, no overlays on the player. Stream id checked with YouTube's public oEmbed endpoint |
| ARISS (ariss.org) | ISS radio frequencies on the map card | Facts with the source and status date shown; update when ARISS changes the station status |
