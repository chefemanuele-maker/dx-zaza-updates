# DX Zaza desktop app — macOS (phase 17)

The same DX Zaza code runs as a desktop app (macOS now, Windows and Linux next) and on the
Raspberry Pi. The desktop app starts the DX Zaza server on `127.0.0.1` (only this computer can
reach it) and shows it in its own window (pywebview / WKWebView).

## Built-in digital voice (DVstick, no BlueDV needed)

BlueDV is not published for macOS, so DX Zaza has its own voice engine (`voice/`):

| Part | File | What it does |
|---|---|---|
| DVstick driver | `voice/ambe3000.py` | AMBE-3000 packet protocol over the FTDI serial port (460800 baud), D-STAR rate, pipelined encode/decode |
| D-STAR framing | `voice/dstar.py` | radio header + CRC, DSVT voice frames, slow data (20-character message) |
| Reflector links | `voice/linkbase.py` + `voice/dextra.py`, `voice/dplus.py`, `voice/dcs.py` | DExtra (UDP 30001, XLX/XRF), DPlus (UDP 20001, REF, with D-STAR network login), DCS (UDP 30051): link, keep-alive, receive, transmit |
| Reflector list | `voice/reflectors.py` | XLX registry + public DExtra, DPlus and DCS host lists, cached 24 h |
| Audio | `voice/audio.py` | microphone / speaker at the sound card rate, resampled to 8 kHz |
| Engine + API | `voice/engine.py`, `voice/api.py` | one owner of the DVstick, RX/TX threads, last heard, tests, `/api/voice/*` |
| Page | `dx_zaza_webapp/js/dx-zaza-voice.js` | Digital Voice page: on air, PTT (button or space bar), reflector, last heard, DVstick, audio and transmit |

The voice itself is encoded and decoded by the DVSI chip inside the DVstick: DX Zaza contains
no AMBE codec software (no codec licence needed in the app).

Transmit is locked until the operator confirms in the app that they hold an amateur radio
licence; the callsign is the one saved in Settings.

### Verified on the real hardware (MacBook Pro M-series, macOS 27, 20/10/2026)
- macOS sees the DVstick 30 with its built-in FTDI driver: `/dev/cu.usbserial-DT04S2TK`, no driver to install.
- Chip `AMBE3000F`, firmware `V121.E100...`; D-STAR rate set; vocoder self test passes
  (pitch 200 Hz in -> 202.5 Hz out), 7.4 ms per frame encode and decode (real time needs < 20 ms).
- Reflector registry: 1843 reflectors. Links to XLX000, XLX330, XLX299, XRF002 ... accepted.
- Packaged `DX Zaza.app` (43 MB) runs, links XLX000 A, vocoder test OK from the app.
- REF (DPlus) with the operator's registered callsign: D-STAR network login OK, linked REF001 C and
  REF030 C. Real traffic received and decoded on REF030 C: GW4STC 69.6 s (message "Steve QTH Criccieth")
  and KC2RXV 108.5 s, 8951 frames decoded, 0 errors. A REF link carries every module: DX Zaza keeps
  only the streams addressed to the linked module (as ircDDBGateway does).
- Still to verify: a real transmission by the operator.

## Build (developer Mac)

Double-click `desktop/macos/Compila DX Zaza.command` (or the shortcut in `~/Augmentor Linux/DX Zaza`).
It prepares a Python venv in `~/Library/Caches/DXZaza-build`, builds with PyInstaller
(`desktop/dx_zaza.spec`), signs, installs `/Applications/DX Zaza.app` and writes the customer
disk image to `~/Augmentor Linux/DX Zaza/DX Zaza Desktop Mac/Versioni Mac/DX-Zaza-<version>-macOS-arm64.dmg`.

## Selling to Mac customers: signing and notarization

Without an Apple Developer ID the app is signed only locally: on another Mac, Gatekeeper says the
developer cannot be verified (customer must use right-click > Open, or System Settings > Privacy &
Security > Open Anyway). For sale:

1. Join the Apple Developer Program (99 USD/year), create a **Developer ID Application** certificate.
2. Once: `xcrun notarytool store-credentials DXZ --apple-id <id> --team-id <TEAM> --password <app-specific password>`
3. Build with:
   `DXZ_SIGN_ID="Developer ID Application: <Name> (<TEAM>)" DXZ_NOTARY_PROFILE=DXZ "desktop/macos/Compila DX Zaza.command"`
   The script signs with the hardened runtime (`desktop/macos/entitlements.plist`, microphone allowed),
   notarizes and staples the DMG.

Architecture: the build is for the Mac it runs on (`arm64` on Apple Silicon). An Intel build needs
an Intel Mac (or a universal2 build environment).

## User data
- `~/Library/Application Support/DX Zaza/config.json` — callsign, locator, language, voice settings
- `~/Library/Application Support/DX Zaza/` — caches (cty.dat, TLEs, reflector list)
- `~/Library/Logs/DX Zaza/dx-zaza.log`
The developer's own `config.local.json` is never packaged.

## Next
- Windows: same spec (`AppIcon.ico` ready); FTDI driver comes with Windows Update.
- Linux desktop: AppImage.
- More voice modes on the same engine: DMR (BrandMeister/TGIF, needs DMR ID) and Fusion (YSF).
- Raspberry Pi: the voice engine also runs on the Pi (it refuses to start while BlueDV owns the DVstick).
