# Digital Voice Phase 2B.1 Udev Test Plan

Internal technical test plan. Not customer-facing.

This plan validates the candidate stable device symlink:

`/dev/dvmega-ambestick`

This phase must not install AMBE Server, install BlueDV, open the DVstick serial device, send serial data, enable TX, create PTT, restart DX Zaza services, or deploy a package.

## Scope

Phase 2B.1 covers:

- Generic udev rule candidate.
- Optional local serial-specific rule example.
- Dedicated install script.
- Dedicated uninstall/rollback script.
- Read-only verification steps.

Phase 2B.1 does not cover:

- AMBE Server installation.
- BlueDV integration.
- Ownership detection implementation.
- AMBE systemd service creation.
- DX Zaza API or UI changes.

## Pre-Deploy Checks

Run these manually on the Raspberry Pi only during a controlled deploy review.

1. Inspect USB devices:

   ```bash
   lsusb
   ```

2. Inspect current serial devices:

   ```bash
   ls -l /dev/ttyUSB* /dev/ttyACM* 2>/dev/null || true
   ```

3. Identify the current DVstick tty path without opening it.

4. Inspect udev attributes for the current tty device:

   ```bash
   udevadm info -a -n /dev/ttyUSB0
   ```

   Replace `/dev/ttyUSB0` with the observed current device path. Do not hardcode this value into tests or product configuration.

5. Verify vendor:

   Expected generic match: `idVendor` equals `0403`.

6. Verify product:

   Expected generic match: `idProduct` equals `6015`.

7. Verify manufacturer:

   Expected generic match: `manufacturer` equals `FTDI`.

   If the local device reports a different manufacturer string, stop and adjust the local candidate design before install.

8. Check USB serial only locally/admin-side if needed to disambiguate multiple FTDI devices.

   Do not copy the real USB serial into public reports, the repository, or generic packages.

## Install Test

1. Run dry-run:

   ```bash
   sudo scripts/install_dvstick_udev_rule.sh --dry-run
   ```

2. Confirm dry-run prints:

   - source rule path
   - target rule path
   - planned install/update action
   - reload plan
   - tty trigger plan

3. Install the rule:

   ```bash
   sudo scripts/install_dvstick_udev_rule.sh
   ```

4. Confirm `udevadm control --reload-rules` completed.

5. Confirm tty trigger completed, unless `--no-trigger` was intentionally used.

6. Verify symlink:

   ```bash
   ls -l /dev/dvmega-ambestick
   ```

7. Resolve symlink:

   ```bash
   readlink -f /dev/dvmega-ambestick
   ```

8. The resolved target may be a current path like `/dev/ttyUSB0`, but success must not depend on that exact tty number.

9. If `/dev/dvmega-ambestick` is absent, do not treat this as automatically fatal when the DVstick is not connected or local udev attributes differ. Review `udevadm info` attributes first.

## Safety Checks

1. Confirm DX Zaza backend remains active:

   ```bash
   systemctl is-active dx-zaza.service
   ```

2. Confirm kiosk remains active:

   ```bash
   systemctl is-active dx-zaza-kiosk.service
   ```

3. Confirm Digital Voice readiness is otherwise unchanged:

   ```bash
   curl -fsS http://127.0.0.1:5050/api/digital-voice/readiness
   ```

4. Confirm `tx_enabled` remains `false`.

5. Confirm `safe_to_operate` remains `false`.

6. Confirm `listen_only_available` remains `false`.

7. Confirm AMBE Server remains not installed.

8. Confirm BlueDV remains not installed.

9. Confirm no new process owns the DVstick.

## Ownership Safety Checks

Use read-only checks only.

If available:

```bash
fuser /dev/dvmega-ambestick || true
```

If available:

```bash
lsof /dev/dvmega-ambestick || true
```

If these tools are not installed, document that they are unavailable and do not install them during this test unless separately approved.

Do not stop processes.

Do not force ownership handoff.

## Rollback Test

1. Run uninstall dry-run:

   ```bash
   sudo scripts/uninstall_dvstick_udev_rule.sh --dry-run
   ```

2. Confirm dry-run prints:

   - target rule path
   - planned remove action
   - reload plan
   - tty trigger plan

3. Remove the rule:

   ```bash
   sudo scripts/uninstall_dvstick_udev_rule.sh
   ```

4. Confirm udev reload completed.

5. Confirm tty trigger completed, unless `--no-trigger` was intentionally used.

6. Verify symlink behavior:

   ```bash
   ls -l /dev/dvmega-ambestick
   ```

   The symlink should disappear after the rule is removed and tty devices are retriggered, if no other local rule creates it.

7. Confirm DX Zaza backend remains active.

8. Confirm DX Zaza kiosk remains active.

9. Confirm no loss or overwrite of `/etc/dx-zaza/config.local.json`.

## Backup Restore Option

The installer creates timestamped backups only when an existing target rule is replaced.

Default uninstall does not restore backups automatically.

Optional restore:

```bash
sudo scripts/uninstall_dvstick_udev_rule.sh --restore-latest
```

Use this only when the latest backup is clearly a DX Zaza timestamped backup created by the installer.

Do not restore ambiguous udev files.

## Reinstall / Idempotence Test

1. Install once.

2. Install again.

3. Confirm the second install reports the rule is already installed and up to date.

4. Confirm no duplicate rule file is created.

5. Confirm no extra symlink name is created.

6. Confirm services remain active.

## Multi-Device Limit

Future test only. Do not execute in Phase 2B.1 unless explicitly approved.

If multiple FTDI devices with the same vendor/product/manufacturer are connected, the generic rule can be ambiguous.

Future multi-device validation should:

- Connect an additional compatible FTDI serial device.
- Observe whether the generic symlink selects the intended DVstick.
- If ambiguous, use the local serial-specific rule example.
- Keep the real USB serial local only.

## Pass Criteria

Phase 2B.1 passes if:

- The generic rule installs cleanly.
- `/dev/dvmega-ambestick` appears when the DVstick attributes match.
- The symlink target is not hardcoded to a specific tty number.
- DX Zaza backend and kiosk stay active.
- Digital Voice readiness remains non-operational and safe.
- No AMBE Server or BlueDV software is installed.
- No process opens the DVstick due to this phase.
- Uninstall removes only the DX Zaza target rule.
- Reinstall is idempotent.
