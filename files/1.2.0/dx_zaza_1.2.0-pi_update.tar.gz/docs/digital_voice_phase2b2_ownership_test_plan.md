# Digital Voice Phase 2B.2 Ownership Test Plan

Internal technical plan for read-only DVstick ownership detection.

This phase verifies observation only. It must not install AMBE Server, install BlueDV, create an AMBE Server systemd service, open the DVstick serial device, send serial data, enable TX, create PTT, stop owner processes, or restart DX Zaza services.

## Scope

Phase 2B.2 adds a read-only ownership detector for the DVMEGA DVstick 30 stable device:

```text
/dev/dvmega-ambestick
```

The detector reports whether the hardware appears free or currently held by AMBE Server, BlueDV, an unknown process, or multiple holders. DX Zaza remains the status/readiness panel only.

## Pre-Deploy Read-Only Checks

Run these checks on the Raspberry before installing a Phase 2B.2 candidate package.

1. Confirm the stable device exists:

   ```bash
   ls -l /dev/dvmega-ambestick
   ```

2. Confirm the resolved target:

   ```bash
   readlink -f /dev/dvmega-ambestick
   ```

   The resolved target may currently be `/dev/ttyUSB0`, but success must not depend on a fixed tty number.

3. Check current holders without modifying processes:

   ```bash
   fuser /dev/dvmega-ambestick || true
   lsof /dev/dvmega-ambestick || true
   ```

   Empty output means no holder was reported by these tools. If a tool is not installed, record that and continue with the available checks.

4. Confirm DX Zaza services remain active:

   ```bash
   systemctl is-active dx-zaza.service
   systemctl is-active dx-zaza-kiosk.service
   ```

5. Capture the baseline Digital Voice readiness:

   ```bash
   curl -s http://127.0.0.1:5050/api/digital-voice/readiness
   ```

Expected baseline before AMBE Server integration:

- `hardware_ready`: `true`
- `permissions_ready`: `true`
- `ambe_server_ready`: `false`
- `blue_dv_ready`: `false`
- `tx_enabled`: `false`
- `safe_to_operate`: `false`
- `listen_only_available`: `false`

Do not include callsign, USB serial number, password, token, or API key values in reports.

## Deploy

Deploy only through the controlled update/package procedure for the candidate build.

Do not run SSH commands that install AMBE Server or BlueDV. Do not install a future AMBE systemd service in this phase.

## Post-Deploy Free State

With no AMBE Server or BlueDV owner running, query:

```bash
curl -s http://127.0.0.1:5050/api/digital-voice/status
curl -s http://127.0.0.1:5050/api/digital-voice/readiness
```

Expected status fields:

- `stable_device_ready`: `true`
- `hardware_in_use`: `false`
- `hardware_owner`: `free`

Expected readiness fields:

- `stable_device_ready`: `true`
- `hardware_busy`: `false`
- `tx_enabled`: `false`
- `safe_to_operate`: `false`
- `listen_only_available`: `false`

Existing fields such as `ambe_hardware_present`, `module_status`, `dvstick`, `blue_dv`, `ambe_server`, `service_running`, and `warnings` must remain present.

## Unknown Owner Test

Do not create a process on the Raspberry that opens the serial device.

Do not use:

- `screen`
- `minicom`
- `stty`
- `socat`
- `cat` or `echo` against `/dev/tty*`
- Python serial libraries
- `dd` against `/dev/tty*`

Unknown-owner and conflict behavior is covered by local automated tests with mocks only in this phase.

## AMBE Owner Test

AMBE-owner validation is deferred until a later AMBE Server candidate phase. That phase must still enforce one owner of the DVstick at a time and must not infer operational readiness from ownership alone.

## BlueDV Owner Test

BlueDV-owner validation is deferred. BlueDV remains external software and must not directly own the DVstick at the same time as AMBE Server.

## Reboot Check

After a reboot, with no AMBE Server or BlueDV process configured to own the DVstick, verify:

```bash
curl -s http://127.0.0.1:5050/api/digital-voice/status
curl -s http://127.0.0.1:5050/api/digital-voice/readiness
```

Expected result:

- `hardware_owner`: `free`
- `hardware_in_use`: `false`
- `hardware_busy`: `false`
- `tx_enabled`: `false`
- `safe_to_operate`: `false`
- `listen_only_available`: `false`

## Rollback

If the Phase 2B.2 candidate must be rolled back, use the existing DX Zaza rollback/update procedure. Do not remove the Phase 2B.1 udev rule unless the rollback plan specifically targets the stable-device symlink layer.

After rollback, confirm:

- `dx-zaza.service` remains active.
- `dx-zaza-kiosk.service` remains active.
- `config.local.json` is preserved.
- AMBE Server remains not installed unless a later phase explicitly changed that.
- BlueDV remains not installed unless a later phase explicitly changed that.

## Pass Criteria

Phase 2B.2 passes Raspberry read-only validation when:

- The stable symlink is present.
- DX Zaza reports `stable_device_ready=true`.
- DX Zaza reports `hardware_in_use=false` and `hardware_owner=free` with no owner process.
- Readiness reports `hardware_busy=false`.
- `tx_enabled`, `safe_to_operate`, and `listen_only_available` remain false.
- No test opens the serial device.
- No process is stopped, killed, started, or restarted by the ownership detector.
