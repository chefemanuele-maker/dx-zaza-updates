# Digital Voice Phase 2B.3 Config Test Plan

Internal technical plan for local Digital Voice configuration schema and validation.

This phase adds safe runtime defaults and validation only. It must not install AMBE Server, install BlueDV, create an AMBE Server systemd service, open serial hardware, enable TX, create PTT, modify Wi-Fi, or deploy any operational Digital Voice component.

## Scope

Phase 2B.3 validates a local `digital_voice` configuration section while keeping Digital Voice non-operational:

- AMBE Server disabled by default.
- BlueDV disabled by default.
- Audio disabled by default.
- Effective TX disabled.
- Localhost bind preference.
- No automatic config migration writes during GET/status/readiness calls.

## Pre-Deploy

1. Confirm the protected local config path exists if already configured:

   ```bash
   ls -l /etc/dx-zaza/config.local.json
   ```

2. Capture a checksum without printing config contents:

   ```bash
   sha256sum /etc/dx-zaza/config.local.json
   ```

3. Confirm baseline settings without exposing callsign:

   ```bash
   curl -s http://127.0.0.1:5050/api/settings
   ```

   Expected:

   - operator remains configured if it was configured before
   - callsign appears only masked
   - language reflects current local config
   - no Digital Voice device, bind address, port, or serial speed is exposed

4. Confirm Digital Voice baseline:

   ```bash
   curl -s http://127.0.0.1:5050/api/digital-voice/status
   curl -s http://127.0.0.1:5050/api/digital-voice/readiness
   ```

Expected pre-deploy safety baseline:

- `stable_device_ready`: `true`
- `hardware_in_use`: `false`
- `hardware_owner`: `free`
- `hardware_busy`: `false`
- `tx_enabled`: `false`
- `safe_to_operate`: `false`
- `listen_only_available`: `false`

## Post-Deploy

After controlled update deployment, verify:

1. DX Zaza starts with the existing old config, including configs without a `digital_voice` section.
2. Operator setup remains preserved.
3. UI language remains preserved.
4. Network ready state remains preserved.
5. Ownership remains free when no AMBE Server or BlueDV owner is running.
6. `/api/digital-voice/status` reports:

   - `stable_device_ready`: `true`
   - `hardware_in_use`: `false`
   - `hardware_owner`: `free`
   - `configuration.valid`: `true`
   - `configuration.ambe_server_enabled`: `false`
   - `configuration.blue_dv_enabled`: `false`
   - `configuration.audio_enabled`: `false`
   - `configuration.effective_tx_enabled`: `false`

7. `/api/digital-voice/readiness` reports:

   - `configuration_valid`: `true`
   - `ambe_server_configured`: `false`
   - `blue_dv_configured`: `false`
   - `audio_configured`: `false`
   - `tx_enabled`: `false`
   - `safe_to_operate`: `false`
   - `listen_only_available`: `false`

8. Confirm AMBE Server is still not installed.
9. Confirm BlueDV is still not installed.
10. Confirm no new process owns the DVstick.

Use only read-only checks for process ownership. Do not open the serial device.

## Invalid Config Test

Do not modify the real `/etc/dx-zaza/config.local.json` for invalid-config testing.

Invalid config cases are covered by local automated tests with mock dictionaries only:

- invalid bind address
- invalid port
- invalid serial speed
- invalid nested object types
- invalid booleans
- invalid network mode
- invalid BlueDV mode

## Migration Safety

GET/API status/readiness/settings calls must not write to `config.local.json`.

To verify manually without exposing contents:

```bash
sha256sum /etc/dx-zaza/config.local.json
curl -s http://127.0.0.1:5050/api/settings >/dev/null
curl -s http://127.0.0.1:5050/api/digital-voice/status >/dev/null
curl -s http://127.0.0.1:5050/api/digital-voice/readiness >/dev/null
sha256sum /etc/dx-zaza/config.local.json
```

The checksum must remain unchanged.

## Reboot

After reboot, verify:

- `dx-zaza.service` active.
- `dx-zaza-kiosk.service` active.
- `/api/settings` still masks operator callsign.
- Runtime Digital Voice defaults remain safe.
- `configuration_valid=true`.
- `effective_tx_enabled=false`.
- `safe_to_operate=false`.
- `listen_only_available=false`.

## Pass Criteria

Phase 2B.3 passes Raspberry validation when:

- Existing local config is preserved.
- Old schemas without `digital_voice` continue to work.
- Digital Voice config summary is customer-safe.
- No AMBE Server or BlueDV process is installed or launched.
- No serial device is opened.
- Effective TX remains false.
