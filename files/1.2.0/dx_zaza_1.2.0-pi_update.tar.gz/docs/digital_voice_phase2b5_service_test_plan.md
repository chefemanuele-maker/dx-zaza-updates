# Digital Voice Phase 2B.5 Service Test Plan

Internal technical test plan for disabled-by-default AMBE Server integration files.

This phase deploys DX Zaza integration files only. It must not install AMBE Server, install BlueDV, start an AMBE service, enable an AMBE service, open the DVstick, enable TX, or create PTT.

## Pre-Deploy

1. Confirm core services:

   ```bash
   systemctl is-active dx-zaza.service
   systemctl is-active dx-zaza-kiosk.service
   ```

2. Confirm stable DVstick:

   ```bash
   ls -l /dev/dvmega-ambestick
   readlink -f /dev/dvmega-ambestick
   ```

3. Confirm ownership is free:

   ```bash
   fuser /dev/dvmega-ambestick || true
   lsof /dev/dvmega-ambestick || true
   ```

4. Capture local config checksum without printing content:

   ```bash
   sha256sum /etc/dx-zaza/config.local.json
   ```

5. Capture status/readiness:

   ```bash
   curl -s http://127.0.0.1:5050/api/digital-voice/status
   curl -s http://127.0.0.1:5050/api/digital-voice/readiness
   ```

6. Confirm no external AMBE process is running.

7. Confirm `dx-zaza-ambe-server.service` is absent or disabled/inactive:

   ```bash
   systemctl is-enabled dx-zaza-ambe-server.service || true
   systemctl is-active dx-zaza-ambe-server.service || true
   ```

Do not start the AMBE service.

## Deploy

Deploy the Phase 2B.5 candidate package through the normal controlled update process, then run only the DX Zaza AMBE integration candidate installer if this phase explicitly calls for it.

Do not install PA7LIM AMBEServer3000.
Do not install NW Digital Radio AMBEserver.
Do not run a third-party install script.

## Post-Deploy

Verify:

- `dx-zaza-ambe-server.service` file is present.
- `dx-zaza-ambe-server.service` is disabled.
- `dx-zaza-ambe-server.service` is inactive.
- `run_dx_zaza_ambe_server.sh` is present.
- Preflight is safe.
- `execution_enabled` is `false`.
- No AMBE process is running.
- DVstick ownership remains free.
- `fuser` and `lsof` show no holder for `/dev/dvmega-ambestick`.
- `dx-zaza.service` remains active.
- `dx-zaza-kiosk.service` remains active.
- `tx_enabled` remains `false`.
- `safe_to_operate` remains `false`.
- `listen_only_available` remains `false`.
- Local config checksum is unchanged.

Expected API summary:

```text
ambe_integration.service_file_present=true
ambe_integration.service_enabled=false
ambe_integration.service_active=false
ambe_integration.execution_enabled=false
```

External binary presence may be `false` or `true`, depending on the local host. Phase 2B.5 must not execute it either way.

## Reboot

After reboot:

- `dx-zaza.service` active.
- `dx-zaza-kiosk.service` active.
- `dx-zaza-ambe-server.service` disabled.
- `dx-zaza-ambe-server.service` inactive.
- DVstick ownership free.
- No AMBE process running.
- TX/safe/listen-only remain false.

## Do Not Do In Phase 2B.5

- Do not start `dx-zaza-ambe-server.service`.
- Do not enable `dx-zaza-ambe-server.service`.
- Do not run the wrapper manually except for controlled dry diagnostics if explicitly approved.
- Do not install PA7LIM software.
- Do not install BlueDV.
- Do not open the serial device.
- Do not simulate ownership by opening `/dev/dvmega-ambestick`.
