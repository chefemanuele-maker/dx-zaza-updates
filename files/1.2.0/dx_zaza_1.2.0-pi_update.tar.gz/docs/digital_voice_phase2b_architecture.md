# Digital Voice Phase 2B Architecture

Internal technical document. Not customer-facing.

## 1. Scope

Digital Voice Phase 2B prepares the AMBE/Digital Voice architecture for DX Zaza without making Digital Voice operational.

This phase does not enable TX, PTT, listen-only operation, AMBE Server operation, or BlueDV integration. DX Zaza remains a control, readiness, and status panel only. AMBE Server remains a future optional process/service, separate from DX Zaza Core.

Phase 2B is architecture-first:

- Define process boundaries.
- Define safe DVstick ownership rules.
- Define stable device naming strategy.
- Define future local configuration.
- Define future systemd design.
- Define future readiness states.

## 2. Current State

Digital Voice Phase 2A readiness/status is active in the current candidate build.

Verified current state:

- Digital Voice Phase 2A readiness/status is active.
- DVMEGA DVstick 30 is detected.
- AMBE hardware is present.
- `hardware_ready` is `true`.
- `permissions_ready` is `true`.
- AMBE Server is not installed.
- BlueDV is not installed.
- `tx_enabled` is `false`.
- `safe_to_operate` is `false`.
- `listen_only_available` is `false`.

Do not store a real operator callsign in this document.

Do not store a real USB serial number in this document.

## 3. Core Architecture Rule

ONE OWNER OF THE DVSTICK AT A TIME

DX Zaza backend must never open or write to the DVstick serial device.

Possible DVstick ownership states:

- `free`
- `ambe_server`
- `blue_dv`
- `unknown_process`

DX Zaza may observe ownership, service state, local configuration, and health. It must not claim serial ownership of the DVstick.

## 4. Component Boundaries

### DX Zaza Core

DX Zaza Core owns:

- Digital Voice readiness.
- Digital Voice status.
- DVstick ownership observation.
- Local configuration validation.
- Customer-safe API responses.

DX Zaza Core must not:

- Open the DVstick serial device.
- Write to the DVstick serial device.
- Start TX or PTT.
- Emulate AMBE.
- Replace BlueDV.
- Kill AMBE Server or BlueDV automatically.

### AMBE Server

AMBE Server is a separate optional process/service.

AMBE Server:

- Owns the DVstick only when active.
- Is disabled by default.
- Should prefer local-only network binding.
- Must be separate from `dx-zaza.service`.
- Must be separate from `dx-zaza-kiosk.service`.
- Must not block DX Zaza Core if it fails.

### BlueDV

BlueDV is external/separate software.

BlueDV:

- Must not be incorporated artificially into DX Zaza.
- Must not directly own the DVstick while AMBE Server owns it.
- May be monitored in the future for compatibility/status only.
- May use AMBE Server as a remote/local vocoder endpoint if configured that way.

## 5. Official/Primary Sources

The following official or primary sources support this architecture. Long source text is intentionally not copied here.

- DVMEGA DVstick30: https://www.dvmega.nl/dvstick30/
  - Supports that DVstick30 is an AMBE-3000 USB device.
  - Documents UART speed `460800`.
  - Documents compatibility context with BlueDV and AMBE Server.

- PA7LIM AMBEServer3000 Linux: https://www.pa7lim.nl/ambeserver-3000-for-linux/
  - Supports Raspberry Pi 3+ Linux use.
  - Documents AMBE Server 3000 configuration.
  - Documents `serialPort`, `serialSpeed=460800`, UDP network mode, `port=2460`, and bind configuration.

- PA7LIM AMBEServer: https://www.pa7lim.nl/ambeserver/
  - Supports the concept of a separate AMBE Server process for AMBE3000 sticks.
  - Documents DVStick30/ThumbDV style AMBE3000 hardware context.
  - Documents UDP AMBE Server operation.

- PA7LIM BlueDV AMBE Android: https://www.pa7lim.nl/bluedv-ambe-android/
  - Supports BlueDV using an AMBE Server by IP.
  - Supports remote/local AMBE Server usage.
  - Supports keeping BlueDV separate from DX Zaza.

- PA7LIM BlueDV Windows: https://www.pa7lim.nl/bluedv-windows/
  - Supports BlueDV use with DVMEGA DVstick/DVstick30.
  - Documents `460800` as the DVMEGA DVstick baudrate context.
  - Supports treating BlueDV as a separate application.

- NW Digital Radio ambeserver-install: https://github.com/nwdigitalradio/ambeserver-install
  - Provides an open-source GPL-3.0 AMBE Server install/reference candidate.
  - Documents systemd packaging patterns, udev symlink strategy, and UDP `2460`.
  - Must be technically validated with DVMEGA DVstick 30 before any use in DX Zaza.

- Google Play BlueDV AMBE: https://play.google.com/store/apps/details?id=com.pa7lim.BlueDVAMBE
  - Supports BlueDV AMBE as PA7LIM software.
  - Supports treating BlueDV as external software rather than DX Zaza code.

## 6. AMBE Server Candidate Decision

Primary technical compatibility candidate:

PA7LIM AMBEServer3000 for Linux.

Reasons:

- AMBE3000 support.
- DVStick30 compatibility context.
- Raspberry Pi 3+ Linux documentation.
- `serialSpeed=460800`.
- Configurable `serialPort`.
- UDP `2460`.
- Bind configuration.

Important licensing and redistribution rule:

PA7LIM AMBEServer3000 must NOT be bundled or redistributed with DX Zaza until redistribution/licensing permission is verified.

Separate open-source candidate:

NW Digital Radio AMBEserver is a GPL-3.0 candidate. It should be evaluated separately and validated technically with DVMEGA DVstick 30 before any use. GPL-3.0 obligations must be reviewed before distribution or modification.

## 7. Serial Parameters

Parameters currently supported by the primary sources:

- Serial speed: `460800`.
- Typical Linux device path: `/dev/ttyUSB0`.
- DVMEGA DVstick 30 USB ID context: `0403:6015`.
- USB chip context: FTDI FT230X.

DX Zaza must not depend on `ttyUSB` numbering. `/dev/ttyUSB0` can change when additional USB serial devices are present.

## 8. Stable Device Strategy

Target stable device path:

`/dev/dvmega-ambestick`

Design-only udev template:

```udev
SUBSYSTEM=="tty", ATTRS{idVendor}=="0403", ATTRS{idProduct}=="6015", ATTRS{manufacturer}=="FTDI", SYMLINK+="dvmega-ambestick", GROUP="dialout", MODE="0660"
```

This is an architecture example only. This phase does not install a udev rule.

Risk:

Multiple FTDI devices can share compatible vendor/product/manufacturer attributes. A generic rule may choose the wrong device on systems with more than one matching FTDI serial adapter.

Optional local USB serial match:

```udev
SUBSYSTEM=="tty", ATTRS{idVendor}=="0403", ATTRS{idProduct}=="6015", ATTRS{manufacturer}=="FTDI", ATTRS{serial}=="REPLACE_WITH_LOCAL_USB_SERIAL", SYMLINK+="dvmega-ambestick", GROUP="dialout", MODE="0660"
```

The real USB serial number must remain only in customer-local configuration or a local-only template. It must not be committed to the repository, included in a generic package, or published in customer-facing docs.

## 9. Multi-Customer Strategy

The generic package should use vendor/product/manufacturer detection.

Customer-specific systems may add optional local serial matching when multiple matching FTDI devices are present.

Rules:

- No real USB serial in repo.
- No real USB serial in generic package.
- No real USB serial in public/customer-facing docs.
- Updates must preserve local device configuration.
- Customer-safe APIs must not expose USB serial numbers.
- Internal diagnostics may expose the device path and owner, but should avoid serial numbers unless explicitly needed for local support.

## 10. Ownership Guard Design

Proposed future component:

`services/dvstick_ownership_service.py`

Do not create this file in Phase 2B documentation step.

Read-only methods to evaluate:

- `fuser`
- `lsof`
- `/proc/*/fd`
- systemd service state

Rules:

- No automatic process killing.
- No automatic process stopping.
- No forced ownership handoff.
- No serial reads/writes from DX Zaza.

Internal state example:

```json
{
  "device": "/dev/dvmega-ambestick",
  "owner": "ambe_server",
  "pid": 1234,
  "service": "dx-zaza-ambe-server.service",
  "method": "fuser"
}
```

Customer-safe state example:

```json
{
  "device": "detected",
  "stable_device_ready": true,
  "hardware_in_use": true,
  "digital_voice": "not_ready"
}
```

Owner classification:

- `free`
- `ambe_server`
- `blue_dv`
- `unknown_process`

## 11. Local Configuration Design

Future local configuration shape:

```json
{
  "digital_voice": {
    "tx_enabled": false,
    "ambe_server": {
      "enabled": false,
      "device": "/dev/dvmega-ambestick",
      "bind_address": "127.0.0.1",
      "port": 2460,
      "serial_speed": 460800,
      "network": "udp"
    },
    "blue_dv": {
      "enabled": false,
      "mode": "external",
      "uses_ambe_server": false
    },
    "audio": {
      "enabled": false,
      "input_device": "",
      "output_device": ""
    }
  }
}
```

Validation rules:

- AMBE Server disabled by default.
- TX false by default.
- No auto-enable.
- Port must be `1..65535`.
- Bind default must be `127.0.0.1`.
- No `0.0.0.0` default.
- No Internet exposure by default.
- No password/token hardcoded.
- Configuration must be preserved across update.
- Local customer configuration belongs outside generic distributed defaults.

## 12. Future Systemd Design

Future design-only service name:

`dx-zaza-ambe-server.service`

Do not create the service file in this phase.

Future requirements:

- Separate from `dx-zaza.service`.
- Separate from `dx-zaza-kiosk.service`.
- Disabled by default.
- `ConditionPathExists=/dev/dvmega-ambestick`.
- Ownership preflight before start.
- Preflight must not kill processes.
- Non-root where possible.
- `Group=dialout`.
- `Restart=on-failure`.
- Controlled `RestartSec`.
- Local-only network preference.
- AMBE failure must not stop DX Zaza Core.
- Logs should be available through `journalctl`.
- Must not interfere with Wi-Fi or network management.
- Must not block boot of DX Zaza Core.

Future service sketch, design only:

```ini
[Unit]
Description=DX Zaza Optional AMBE Server
After=network-online.target
Wants=network-online.target
ConditionPathExists=/dev/dvmega-ambestick

[Service]
Type=simple
User=dx-zaza
Group=dialout
ExecStartPre=/usr/local/bin/dx-zaza-dvstick-preflight --device /dev/dvmega-ambestick
ExecStart=/usr/local/bin/dx-zaza-ambe-server-wrapper
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
```

The real `ExecStart` must be chosen only after AMBE Server candidate and licensing decisions are complete.

## 13. Network Model

UDP `2460` is the documented AMBE Server port candidate.

Initial bind preference:

`127.0.0.1`

Rules:

- Do not expose UDP `2460` to the Internet.
- Do not default to `0.0.0.0`.
- LAN exposure requires an explicit architecture/security decision.
- Firewall and network exposure must be reviewed before BlueDV remote testing.
- Remote BlueDV testing must not begin until DVstick ownership and AMBE Server binding are controlled.

## 14. Phase 2B Readiness Model

Future readiness states:

- `hardware_absent`
- `hardware_present`
- `stable_device_missing`
- `hardware_busy`
- `ambe_server_not_installed`
- `ambe_server_disabled`
- `ambe_server_stopped`
- `ambe_server_unreachable`
- `blue_dv_unavailable`
- `blue_dv_not_configured`
- `audio_not_ready`
- `operator_not_ready`
- `tx_disabled`
- `listen_only_infra_ready`
- `listen_only_unavailable`

Rules:

- AMBE Server running does not equal `safe_to_operate`.
- AMBE Server running does not equal `listen_only_available`.
- Never set `safe_to_operate` true without full verified prerequisites.
- Never set `listen_only_available` true without a verified audio/protocol path.
- Hardware detected does not mean Digital Voice is operational.
- Stable device ready does not mean the DVstick is free.
- BlueDV installed does not mean BlueDV is configured safely.

## 15. Implementation Roadmap

### Phase 2B.1

Stable device udev candidate.

### Phase 2B.2

Read-only ownership detection.

### Phase 2B.3

Local `digital_voice` config schema.

### Phase 2B.4

AMBE Server candidate/license decision.

### Phase 2B.5

Disabled-by-default systemd candidate.

### Phase 2B.6

Local-only UDP health test.

### Phase 2B.7

DX Zaza readiness/status integration.

### Phase 2B.8

BlueDV AMBE Server compatibility test.

### Phase 2B.9

Listen-only architecture verification.

## 16. Risk Register

- `ttyUSB` numbering changes.
- Double ownership of the DVstick.
- LAN/Internet exposure of UDP `2460`.
- PA7LIM redistribution/licensing is unclear.
- BlueDV direct serial conflict with AMBE Server.
- AMBE Server running falsely interpreted as operational readiness.
- USB power or undervoltage problems.
- Invasive diagnostics that open the serial device.
- Commercial redistribution obligations.
- Customer-specific USB serial privacy.
- GPL-3.0 obligations if NW Digital Radio AMBEserver is used or modified.
- Local firewall assumptions that do not hold on all Raspberry Pi images.

## 17. Explicit Non-Goals

- No TX.
- No PTT.
- No automatic BlueDV integration.
- No AMBE software emulator.
- No software AMBE encoder replacement.
- No serial access from DX Zaza.
- No automatic process killing.
- No Internet exposure.
- No bundled PA7LIM binary until licensing is verified.
- No AMBE Server installation in this phase.
- No operational AMBE systemd service in this phase.

## 18. Next Safest Micro-Step

The next safest technical micro-step after this document is:

Digital Voice Phase 2B.1 - stable device udev candidate and test plan.

Phase 2B.1 should create only:

- udev rule template.
- installer design.
- uninstall/rollback design.
- test plan.

Phase 2B.1 must not install AMBE Server.

## Phase 2B.1 Implementation Candidate

Phase 2B.1 may add a non-installed implementation candidate under the build tree:

- `udev/99-dx-zaza-dvmega-ambestick.rules`
- `udev/99-dx-zaza-dvmega-ambestick-local.rules.example`
- `scripts/install_dvstick_udev_rule.sh`
- `scripts/uninstall_dvstick_udev_rule.sh`
- `docs/digital_voice_phase2b1_udev_test_plan.md`

These files are candidate assets only. They must not install AMBE Server, install BlueDV, create an AMBE systemd service, open the serial device, enable TX/PTT, or modify DX Zaza APIs/UI.

## Phase 2B.2 Implementation Candidate

Phase 2B.2 may add read-only DVstick ownership observation under the build tree:

- `services/dvstick_ownership_service.py`
- customer-safe Digital Voice status/readiness fields
- `docs/digital_voice_phase2b2_ownership_test_plan.md`

The ownership detector must prefer `/dev/dvmega-ambestick`, fall back to the existing serial-device detection model, and observe ownership without opening the serial device. It may use read-only signals such as `/proc/*/fd`, `fuser`, `lsof`, and `systemctl is-active`.

Phase 2B.2 must not install AMBE Server, install BlueDV, create an AMBE systemd service, enable TX/PTT, stop processes, start processes, or perform any serial read/write. `safe_to_operate` and `listen_only_available` must remain false unless a later phase verifies all real prerequisites.

## Phase 2B.3 Implementation Candidate

Phase 2B.3 may add a local Digital Voice configuration schema and validation layer under the build tree:

- `services/digital_voice_config_service.py`
- Digital Voice defaults in `config.example.json`
- Digital Voice defaults in `config.local.json.example`
- customer-safe configuration summaries in Digital Voice status/readiness/settings APIs
- `docs/digital_voice_phase2b3_config_test_plan.md`

The schema is disabled by default:

- `tx_enabled=false`
- `ambe_server.enabled=false`
- `blue_dv.enabled=false`
- `audio.enabled=false`
- AMBE bind preference `127.0.0.1`
- AMBE network `udp`
- AMBE port `2460`
- AMBE serial speed `460800`

This phase must not write or migrate existing `config.local.json` files during GET/status/readiness calls. Older local configs without a `digital_voice` section must keep working through runtime defaults. Config validation issues must be machine-readable and customer-safe.

Phase 2B.3 must not install AMBE Server, install BlueDV, create an AMBE systemd service, open serial hardware, enable TX/PTT, or start/stop/restart processes from configuration. `tx_enabled` in runtime readiness must remain effectively false even if a future config intent is present.

## Phase 2B.5 Implementation Candidate

Phase 2B.5 may add disabled-by-default AMBE Server integration architecture:

- `docs/ambe_server_external_software_policy.md`
- `services/ambe_server_preflight_service.py`
- `scripts/run_dx_zaza_ambe_server.sh`
- `systemd/dx-zaza-ambe-server.service`
- `scripts/install_ambe_integration_candidate.sh`
- `scripts/uninstall_ambe_integration_candidate.sh`
- `docs/digital_voice_phase2b5_service_test_plan.md`

PA7LIM AMBEServer3000 remains an external software interoperability candidate only. DX Zaza must not bundle the PA7LIM binary, install script, copied executable, modified binary, or source unless future licensing clears it.

NW Digital Radio AMBEserver remains a separate future GPL/source candidate and is not selected for Phase 2B.5.

The Phase 2B.5 wrapper is fail-closed. It runs preflight, reports the result, and exits non-zero. Even if every future startup condition is satisfied, it must not execute the external AMBE binary in this phase.

The systemd unit is a disabled candidate service. It must not be enabled or started by package/update scripts. `Restart=no` is intentional because Phase 2B.5 exits by design.

Current Raspberry permission note:

- The udev design used `dialout`.
- The real Raspberry device has previously shown group `plugdev`.
- Phase 2B.5 service design therefore includes both `dialout` and `plugdev` as supplementary groups while the exact production permission model remains under review.

Phase 2B.5 must not make AMBE Server operational, must not open the DVstick, and must keep TX, `safe_to_operate`, and `listen_only_available` false.
