# DX Cluster Integration Plan

## A. Obiettivo
Usare un DX Cluster/Telnet come fonte live per DX Zaza Live DX Spots.

## B. Perche' Telnet/DX Cluster
Piu' adatto di scraping HTML per spot live.

## C. Sicurezza
- connessione read-only
- nessuna password
- nessun invio spot
- nessun credential hardcoding
- fallback demo se cluster non disponibile

## D. Config
La configurazione interna mantiene host, porta, timeout e limiti. In product mode il servizio e' disponibile automaticamente e il cliente non gestisce `dx_cluster.enabled`; eventuali valori legacy non bloccano il setup.

## E. Limiti
- formati cluster possono variare
- alcuni nodi richiedono login/callsign
- rate limit/uso corretto da rispettare
- per prodotto commerciale scegliere fonte stabile/autorizzata
