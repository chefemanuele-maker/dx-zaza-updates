# Language / i18n Plan

## A. Obiettivo
Permettere al cliente di scegliere la lingua dell’interfaccia DX Zaza.

## B. Lingue iniziali consigliate
- English
- Italian

## C. Lingue future
- Spanish
- French
- German
- Portuguese
- Dutch
- Polish
- Japanese
- altre lingue aggiungibili

## D. Regole UI
- testi grandi e leggibili
- nessun layout rotto se una lingua ha parole più lunghe
- menu touch-friendly
- fallback English se traduzione manca
- lingua salvata in config.local.json o settings locale

## E. Cosa tradurre
- menu
- titoli pagine
- bottoni
- status badge
- messaggi errore
- note Wi-Fi/Operator Setup
- Radio Tools labels
- HF Propagation labels

## F. Cosa non tradurre
- callsign
- frequenze
- band/mode tecnici come FT8, CW, SSB
- valori API
- dati live grezzi

## G. Backend settings
Aggiungere in futuro:
GET /api/settings
POST /api/settings/language

## H. Storage
La lingua selezionata deve essere salvata in config.local.json senza sovrascrivere callsign o altre preferenze.
