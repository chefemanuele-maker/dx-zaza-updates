# Live Data Architecture

DX Zaza Mac live test usa una webapp statica servita da Flask e un backend locale con endpoint JSON.

## Componenti
- Frontend: `dx_zaza_webapp/`
- Backend: `app.py`
- Servizi dati: `services/`
- Cache TTL: `services/cache.py`

## Refresh
La UI aggiorna i dati ogni 2.5 secondi. Il backend protegge le fonti esterne con cache e intervalli piu' lunghi:

- Solar/HF: cache consigliata 300 secondi
- DX spots: cache demo 10 secondi
- Satellite: cache consigliata 1800 secondi

## Fallback
Ogni endpoint deve restituire dati demo se la fonte live non e' configurata o fallisce. La UI non deve bloccarsi.

## Regole
- niente API key hardcoded
- niente credenziali reali nei file
- niente scraping aggressivo
- QRZ fuori dal MVP
