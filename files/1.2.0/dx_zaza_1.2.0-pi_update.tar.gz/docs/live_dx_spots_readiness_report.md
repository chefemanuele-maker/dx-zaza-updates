# Live DX Spots Readiness Report

## A. Stato
DX Zaza riceve spot reali da DX Cluster/Telnet.

## B. Source
`dx-cluster-telnet`

## C. Sicurezza
- read-only
- nessuna password
- nessun invio spot
- nessun DX Callsign nel JSON pubblico/UI
- Operator Callsign mascherato nei report

## D. Prefix Mapping
Campione live verificato: 20 spot.

Prima del raffinamento, gli spot live normalizzati dal backend risultavano con country/region Unknown perche' il servizio non applicava ancora un mapping prefix allo Spotter/DE.

Dopo il raffinamento:
- prefissi risolti: 20 spot su 20 nel campione live
- Unknown residui: 0 nel campione live
- mapping basato su prefisso callsign generale e longest-prefix matching
- supporto portable/slash callsign mantenuto

## E. UI
Global Map e Live DX Spots verificate con dati live.

La UI mostra Spotter/DE, frequency, band e mode. Il DX Callsign resta escluso dal JSON pubblico e dalla UI.

MVP visible UI now focuses on live DX and live solar; Satellite hidden as future feature.

Global Map visual limit changed from 6 to 3 markers.

Live DX Spots page remains full/list view.

Global Map marker style changed to dot + leader line + compact label.

Reason: improve clarity and reduce overlap on touchscreen map.

## F. Limiti
- country/region approssimati tramite prefix mapping
- non GPS esatto
- alcuni prefissi possono restare Unknown in campioni futuri
- alcune frequenze fuori dalle bande modellate possono restare con band Unknown
- serve dataset migliore/licenziato per versione commerciale

## G. Prossimo step
Preparare build Raspberry Pi live. Satellite Passes puo' tornare dopo una fonte orbitale live autorizzata.
