# DX Zaza Live Mac Test Status

## Stato server
Server Flask attivo su `http://127.0.0.1:5050` in modalita' `mac-live-test`, versione `0.1`.

## Endpoint verificati
- `/api/status`: OK
- `/api/solar`: OK
- `/api/dx-spots`: OK
- `/api/satellite-passes`: OK
- `/favicon.ico`: OK, usa il logo DX Zaza come favicon

## Pagine verificate
- Global Map
- Live DX Spots
- HF Propagation
- Satellite Passes
- Wi-Fi Setup
- Radio Tools

## Dati live reali
- Solar/HF: dati reali NOAA/SWPC disponibili tramite endpoint locale `/api/solar`.

## Dati ancora fallback/demo
- DX Spots: fallback demo nella v0.1.
- Satellite Passes: fallback demo nella v0.1.
- Wi-Fi Setup: demo su Mac.
- Radio Tools: statico.

## Problemi trovati
- Favicon inizialmente restituiva 404; corretto nella live webapp usando il logo DX Zaza.
- Nessun System Health visibile nella UI cliente.
- Nessun refresh count o Last Update tecnico visibile.

## Prossimo step consigliato
Validare la UI live sul MacBook per qualche sessione, poi scegliere tra integrazione DX Spots reale autorizzata o porting backend su Raspberry Pi.

