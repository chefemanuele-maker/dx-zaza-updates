# Mac Test Runbook

## Avvio
```bash
cd /path/to/DX_Zaza_Project/13_live_backend_mac_test
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Aprire:

http://127.0.0.1:5050

## Verifica endpoint
```bash
curl http://127.0.0.1:5050/api/status
curl http://127.0.0.1:5050/api/solar
curl http://127.0.0.1:5050/api/dx-spots
curl http://127.0.0.1:5050/api/satellite-passes
```

## Stop server
Premere `Ctrl+C` nel terminale dove gira Flask.

## Log
Per ora Flask stampa log su terminale. La cartella `logs/` e' pronta per log file futuri.
