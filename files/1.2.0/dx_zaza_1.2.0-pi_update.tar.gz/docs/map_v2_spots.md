# Global Map 0.5 — who is transmitting, where

## What changed
- **The callsign on the map is now the DX station, i.e. the station that is transmitting** on the
  spotted frequency. Until 0.4 the map showed the spotter (DE, who *heard* the station), so the
  callsign, the frequency and the country did not belong together (e.g. "EA5KEP 7.150 SSB" in Spain
  while the station on 7.150 was EA5ET; "CT7AUT" in Portugal while the station on 14.080 was EP2AES
  in Iran). This reverses the phase-10 rule "no DX callsign on the map".
- The spotter is still shown: small ring at its position, joined to the DX station by the
  great-circle path (the propagation path that was actually heard).
- Position accuracy (backend `services/geo_service.py`):
  1. Maidenhead locator pair in the comment (`JN36dv -> KO01nb`, `KO85SO<TR>KP50DU`): spotter -> DX;
  2. call area for large countries (USA 0-9, Canada incl. VO1/VO2/VY0-2, Australia, Japan, Brazil,
     European/Asiatic Russia, China, Spain, Italy, Argentina);
  3. DXCC entity from AD1C cty.dat (islands and territories are separate entities: Azores, Canary
     Islands, Sicily, Sardinia, Crete, Alaska, Hawaii ...).
  Maritime/aeronautical mobile (/MM, /AM) are not placed.
- Distance and beam heading from the operator QTH are computed to the DX station.
- No more fake rotation of the spot list every 2.5 s: the map and the table keep the real cluster
  order (newest first) and the map is redrawn only when the data changes.

## Look
- New base map (`tools/make_world_map_v2.py`, Natural Earth 1:50m via world-atlas): dark ocean,
  land with country borders and bright coastline, 15° graticule, tropics and polar circle.
- Paths coloured by band with a dark halo (readable over land, sea and night), newest path animated.
- One label per DX station, next to its dot, placed to avoid overlaps; band chip in the label.
- Legend of the bands on the map; hover/click a station for its card (country and how precise the
  position is, frequency, mode, time, heard by, distance/heading from your QTH, comment).
- Satellites: only the ISS keeps its name; sun drawn as a soft golden disc; aurora lighter.

## 0.5 — sharp zoom and map styles
- The base map is drawn as vectors on a canvas for the current zoom (Natural Earth 1:50m, and
  1:10m from 2.4x): coastlines, borders and text stay sharp at every zoom level. Night shading is
  computed for the visible area. The old picture is only a fallback.
  Data built by `tools/make_vector_map.py` -> `dx_zaza_webapp/assets/map/world50.json`, `world10.json`.
- Map styles (button "Map" on the map): Tactical (vector, offline), Satellite (NASA Blue Marble),
  Relief (Blue Marble shaded relief + bathymetry), Night lights (NASA Black Marble).
  Imagery from NASA GIBS (WMTS, EPSG:4326 = same projection as DX Zaza, 512 px tiles, levels 0-7),
  no key, public domain, credit shown on the map. Without Internet the app falls back to Tactical.
- Why not Google Maps: it needs an API key with billing for every customer, its terms do not allow
  this kind of re-use without a contract, and it uses the Web Mercator projection (wrong for the
  day/night line, the aurora oval and great-circle paths, and it cannot show the poles).
