# Map Visual Calibration

## Obiettivo
Calibrare i marker Spotter/DE sulla mappa immagine usata da DX Zaza.

## Metodo
Callsign prefix -> country/region -> visual X/Y percent calibrated to the DX Zaza world map image.

The live Global Map uses:
- \`dx_zaza_webapp/assets/dx_zaza_world_map_bg.jpeg\`
- image size: 1536 x 878 px
- visual marker layer matched to the same image aspect ratio

## Limiti
Non e GPS exact. E posizione approssimata per paese/regione. Per posizione esatta servirebbe Maidenhead locator/API/dataset autorizzato.

## Priorita
Europa calibrata con maggiore attenzione perche molti spot live provengono da li.

## Note UI
Il dot resta sulla posizione visuale calibrata. La label viene offsettata con leader line per evitare sovrapposizioni senza spostare il punto geografico.
