# MVP Scope Decision

## Current MVP Pages
- Global Map
- Live DX Spots
- HF Propagation
- Wi-Fi Setup
- Radio Tools

## Removed from visible MVP
- Satellite Passes

## Reason
Satellite Passes is not live yet and would make the first real prototype feel unfinished. It remains a future feature after an authorised live satellite data source is selected.

## Current live data
- DX Cluster/Telnet for DX spots
- NOAA/SWPC for solar/propagation

## Future
Satellite Passes can return when live orbital data source is implemented.
