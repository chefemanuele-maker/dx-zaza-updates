# Network Setup Notes

## Primo avvio
- Preferire Ethernet per install/test iniziale.
- Wi-Fi Setup e' UI MVP; cambi Wi-Fi reali richiedono backend Pi dedicato futuro.

## Accesso locale
- Dashboard: `http://raspberrypi.local:5050` o IP LAN.
- Servizio Flask ascolta su `0.0.0.0:5050`.
- Se funziona sul Pi ma non dal Mac, controllare `DX_ZAZA_HOST=0.0.0.0` in `systemd/dx-zaza.service` e verificare `ss -tulpn | grep 5050`.
- Se la pagina risponde `Not Found`, verificare il path webapp: la build Pi deve avere `dx_zaza_webapp`; `app.py` ha fallback solo verso `dx_zaza_live_webapp`.

## Accesso remoto futuro
- Usare Tailscale o SSH protetto.
- Non esporre SSH pubblico con port forwarding internet.
- Non hardcodare token o password.

## DX Cluster
- Richiede Operator Callsign valido.
- Connessione read-only.
- Nessun invio spot.
- La configurazione ufficiale su Pi e' `/etc/dx-zaza/config.local.json`.
- Se `/api/dx-spots` non e' live, controllare `/api/settings`: Operator Callsign e rete devono risultare pronti.
- Se appare `No readable DX spots`, verificare che il cluster accetti il login e che il backend invii `sh/dx/20`.
