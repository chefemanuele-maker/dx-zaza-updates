# Operator Callsign Setup

## Obiettivo
Ogni utente DX Zaza deve poter inserire il proprio callsign valido.

## Uso
Il callsign viene usato solo per login read-only al DX Cluster.

## Sicurezza
- non password
- non TX
- non invio spot
- non credenziali QRZ
- non hardcoded nel codice
- config locale

## Raspberry Pi futuro
Sul Raspberry Pi questa opzione sara' nella schermata Setup del cliente.
