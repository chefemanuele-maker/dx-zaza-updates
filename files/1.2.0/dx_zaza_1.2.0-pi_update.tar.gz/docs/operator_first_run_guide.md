# Operator First Run Guide

## 1. Aprire dashboard
Aprire `http://raspberrypi.local:5050` o l'indirizzo IP del Raspberry Pi.

## 2. Operator Callsign
- Andare in Wi-Fi Setup > Operator Setup.
- Inserire il proprio callsign valido.
- Premere Save Callsign.

Il callsign viene usato solo per accesso read-only ai dati radio live. DX Zaza non trasmette e non invia spot.

## 3. Lingua
- Andare in Wi-Fi Setup > System Settings.
- Scegliere English o Italiano.
- Premere Save Language.

## 4. Live DX
In product mode il servizio Live Radio Spots e' disponibile automaticamente dopo Operator Callsign valido e rete online. Il cliente non gestisce toggle tecnici DX Cluster.

La fonte ufficiale della configurazione Pi e' `/etc/dx-zaza/config.local.json`. Non usare `/opt/dx-zaza/config.local.json`.

## 5. Verifica
- Global Map massimo 3 marker.
- Live DX Spots senza DX Callsign.
- HF Propagation con dati live o fallback sicuro.
- La sidebar deve mostrare `ONLINE` solo se radio spots e propagazione sono live.
- Se i radio spots non sono live, Global Map e DX Spots devono mostrare `STATIC PREVIEW` o `OFFLINE / STATIC PREVIEW`.
- Se la propagazione non e' live, HF Propagation deve mostrare `PROPAGATION PREVIEW / FALLBACK`.
- Fallback/static data must never be presented as live.
- La UI cliente non deve mostrare nomi tecnici di sorgenti, servizi, endpoint o adapter.

## Troubleshooting Live DX
- `/api/settings` deve mostrare setup pronto quando Operator Callsign e rete sono validi.
- `/api/dx-spots` deve tornare `source: dx-cluster-telnet` quando live DX e callsign sono configurati.
- Se torna `fallback-demo`, controllare prima `/etc/dx-zaza/config.local.json`, poi il log servizio.
- Se la UI mostra `ONLINE` mentre `/api/dx-spots` o `/api/solar` sono in fallback, fermarsi e correggere prima della consegna cliente.
- I nomi sorgente tecnici possono comparire in API/log/diagnostica, ma non nella UI customer-facing.
