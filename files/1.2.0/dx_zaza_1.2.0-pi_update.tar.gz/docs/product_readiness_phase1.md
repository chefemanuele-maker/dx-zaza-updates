# Product Readiness Phase 1

This candidate adds setup gating without changing Raspberry Pi or Mac network configuration.

## Readiness rules

- `operator.callsign` is the only canonical Operator Callsign.
- Legacy DX Cluster callsign fields do not complete setup.
- Live radio spots require a valid Operator Callsign and network availability.
- Product mode enables the internal live-radio service automatically; customers do not manage a DX Cluster toggle.
- Incomplete setup returns no demo radio spots and the customer UI shows `SETUP REQUIRED`.
- Non-live and failed live-cluster states keep the Global Map and Live Radio Spots activity empty.
- Marker and spot rows are rendered only from a confirmed live DX Cluster response.

## Wi-Fi scope

- Demo networks and simulated Wi-Fi actions are removed.
- Real Wi-Fi scan, connect, hotspot and profile changes are not implemented in this phase.
- No network-management commands are executed by DX Zaza.
