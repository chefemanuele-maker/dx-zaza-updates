# Raspberry Pi Live Install Guide

## 1. Preparare Raspberry Pi
- Flash Raspberry Pi OS 64-bit Desktop.
- Abilitare SSH se serve.
- Collegare Ethernet o Wi-Fi.
- Collegare touchscreen HDMI/USB se disponibile.

## 2. Copiare build
Copiare `14_raspberry_pi_live_build/` sul Raspberry Pi.

## 3. Installare
Da dentro la cartella build:

    sudo scripts/install_dx_zaza_pi_live.sh

Lo script crea `/opt/dx-zaza`, `/etc/dx-zaza`, `/var/log/dx-zaza` e i servizi systemd.
La configurazione ufficiale Pi e' solo `/etc/dx-zaza/config.local.json`. Lo script la crea da `config.local.json.example` solo se manca, non la sovrascrive e non installa un `config.local.json` reale dentro `/opt/dx-zaza`.

## 4. Avviare

    sudo systemctl start dx-zaza.service
    sudo systemctl status dx-zaza.service
    sudo systemctl status dx-zaza-kiosk.service

Aprire `http://raspberrypi.local:5050` oppure `http://<pi-ip>:5050`.
Il servizio usa `DX_ZAZA_HOST=0.0.0.0`, `DX_ZAZA_PORT=5050` e `DX_ZAZA_CONFIG=/etc/dx-zaza/config.local.json`.

## 5. Primo setup cliente
- Aprire Wi-Fi Setup > Operator Setup.
- Inserire Operator Callsign valido.
- Salvare.
- Aprire System Settings e scegliere la lingua.

## 6. Kiosk
L'installer configura `dx-zaza-kiosk.service` come owner principale dell'avvio kiosk.
Per rigenerare lo start script e disabilitare vecchi autostart DX Zaza:

    sudo scripts/setup_kiosk_autostart.sh

Il browser previsto e' `/usr/bin/chromium`.
Il service kiosk esegue `/home/pi/dx-zaza-kiosk/start-dx-zaza-kiosk.sh`.

## 7. Test
Usare `scripts/diagnose_dx_zaza.sh` e la checklist Pi live.

## Troubleshooting
- DX Zaza Not Found: verificare che esista `/opt/dx-zaza/dx_zaza_webapp/index.html`; `app.py` prova prima `dx_zaza_webapp`, poi `dx_zaza_live_webapp`.
- Non apre da Mac/LAN: verificare `DX_ZAZA_HOST=0.0.0.0` nel servizio e che la porta 5050 sia in ascolto.
- Popup keyring Chromium: verificare `--password-store=basic`.
- Errore SingletonLock: rimuovere i lock in `/home/pi/.config/dx-zaza-chromium/` o rigenerare lo start script.
- Live DX Spots offline: controllare `/api/settings`, Operator Callsign configurato e rete disponibile.
- No readable DX spots: verificare con diagnose che il backend usi sorgente DX Cluster e che il servizio invii `sh/dx/20`.
