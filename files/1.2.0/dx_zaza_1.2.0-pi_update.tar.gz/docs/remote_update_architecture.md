# Remote Update Architecture

DX Zaza remote updates are prepared as a controlled manual workflow. No automatic updater is enabled in this build.

## Recommended access model

- Use a private Git repository or a local update bundle.
- Reach Raspberry Pi devices only through a private network path such as Tailscale or private SSH.
- Do not expose SSH publicly.
- Do not hardcode tokens, passwords, API keys, or SSH keys in DX Zaza files.
- Keep customer configuration in `/etc/dx-zaza/config.local.json`.

## Update flow

1. Prepare the update on the MacBook/private repo.
2. Create a clean bundle or configure a private repo URL externally.
3. Copy the bundle to the Raspberry Pi over a private route.
4. Run `sudo /opt/dx-zaza/scripts/update_dx_zaza.sh`.
5. The script creates a backup first.
6. The app is updated and verified.
7. The service restarts.
8. Health check runs on `/api/status`.
9. If health check fails, rollback restores the previous app backup.

## Safety rules

- Customer config is preserved by default.
- `/etc/dx-zaza/config.local.json` is not overwritten during updates.
- Backups are stored under `/opt/dx-zaza/backups`.
- Rollback does not restore config unless `--restore-config` is explicitly used.
- Exact technical source names may appear in API/logs/diagnostics, not in the customer-facing UI.

## Future option

A `dx-zaza-update.timer` could be added later for scheduled checks, but no timer is installed or enabled in this build.

