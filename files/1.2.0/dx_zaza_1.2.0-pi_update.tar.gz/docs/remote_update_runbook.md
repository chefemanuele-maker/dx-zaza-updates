# Remote Update Runbook

## A. MacBook

1. Prepare the update in the Raspberry Pi build folder.
2. Create the update bundle:

```bash
cd /Users/emanuelezaralli/Desktop/ZUMspot_Elite_Custom_WPSD_Project/14_raspberry_pi_live_build
bash scripts/create_update_bundle.sh
```

3. Copy the bundle to the Raspberry Pi over a private route such as Tailscale/private SSH:

```bash
scp /Users/emanuelezaralli/Desktop/ZUMspot_Elite_Custom_WPSD_Project/dx_zaza_update_bundle.tar.gz pi@DEVICE:/tmp/
```

## B. Raspberry Pi

1. Extract the bundle:

```bash
rm -rf /tmp/dx-zaza-update
mkdir -p /tmp/dx-zaza-update
tar -xzf /tmp/dx_zaza_update_bundle.tar.gz -C /tmp/dx-zaza-update
```

2. Run the update:

```bash
sudo /opt/dx-zaza/scripts/update_dx_zaza.sh
```

The script preserves `/etc/dx-zaza/config.local.json`, creates a backup, installs updated systemd service files when present, disables legacy DX Zaza kiosk autostarts, verifies Python/JavaScript where available, restarts the backend and kiosk services, and runs a health check.

## C. Diagnose

```bash
sudo /opt/dx-zaza/scripts/diagnose_dx_zaza.sh
```

## D. Rollback

List backups:

```bash
sudo /opt/dx-zaza/scripts/rollback_dx_zaza.sh
```

Rollback app only:

```bash
sudo /opt/dx-zaza/scripts/rollback_dx_zaza.sh /opt/dx-zaza/backups/BACKUP_NAME
```

Rollback app and config only when explicitly needed:

```bash
sudo /opt/dx-zaza/scripts/rollback_dx_zaza.sh --restore-config /opt/dx-zaza/backups/BACKUP_NAME
```

Do not use public SSH, hardcoded tokens, or automatic updates for this release.
