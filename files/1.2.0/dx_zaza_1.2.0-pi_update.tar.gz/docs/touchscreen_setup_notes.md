# Touchscreen Setup Notes

## Hardware
- Touchscreen 10.1 inch HDMI.
- HDMI per video.
- USB per touch.

## Display
- Verificare risoluzione e scaling in Raspberry Pi OS.
- Chromium kiosk deve mostrare DX Zaza a schermo intero.
- Testare Global Map, filtri, Operator Setup e System Settings.

## Touch keyboard
- La tastiera virtuale DX Zaza deve funzionare per Operator Callsign, SSID e password.
- Verificare che il testo venga inserito nell'ordine corretto.

## Kiosk
Avvio consigliato via `dx-zaza-kiosk.service`.

`scripts/setup_kiosk_autostart.sh` resta lo script di supporto per creare
`/home/pi/dx-zaza-kiosk/start-dx-zaza-kiosk.sh` e disabilitare i vecchi autostart
desktop DX Zaza. Non deve essere usato come owner principale dell'avvio.

Il launcher usa `/usr/bin/chromium` con:

- `--kiosk`
- `--no-first-run`
- `--disable-infobars`
- `--noerrdialogs`
- `--disable-session-crashed-bubble`
- `--password-store=basic`
- `--touch-events=enabled`
- `--overscroll-history-navigation=0`
- `--enable-features=OverlayScrollbar,TouchpadOverscrollHistoryNavigation`
- `--user-data-dir=/home/pi/.config/dx-zaza-chromium`

Se compare il popup keyring, il browser non e' partito con `--password-store=basic`. Se Chromium segnala `SingletonLock`, chiudere le istanze Chromium e rimuovere i file `SingletonLock`, `SingletonCookie`, `SingletonSocket` nel profilo dedicato.

## Touch scrolling

DX Zaza kiosk enables touch events in Chromium and sets CSS touch scrolling for tablet-like page scrolling.

Troubleshooting:
- If scrolling works only with scrollbar, check Chromium flag `--touch-events=enabled`.
- Check CSS `touch-action: pan-y` on `html`, `body`, `.dashboard` and active page containers.
- Check no global `preventDefault()` on `touchmove`.
- Restart kiosk after update.
- Verificare `systemctl status dx-zaza-kiosk.service`.
