# DX Zaza Mockup

Webapp live per DX Zaza, sistema di monitoraggio globale radio/DX con mappa e dati live/fallback sicuro.

## Avvio

Aprire index.html nel browser.

## Limiti

- Non e collegato allo ZUMspot.
- Non usa API.
- Non legge file radio host locali.
- Non contiene dati sensibili reali.
- Usa backend live quando disponibile e fallback sicuro quando la fonte live non risponde.
