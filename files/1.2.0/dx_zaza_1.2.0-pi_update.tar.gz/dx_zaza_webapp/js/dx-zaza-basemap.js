/* DX Zaza 0.5 — vector base map, redrawn for the current zoom: sharp at every level.
 * Coastlines, land and borders from Natural Earth (1:50m, and 1:10m when zoomed in),
 * night shading computed for the visible area. Drawn on a canvas under the zoomed layers. */
(function () {
  "use strict";

  const G = window.dxZazaGeo;
  const MAP = G.MAP;
  const SPAN = MAP.latTop - MAP.latBottom;
  const RAD = Math.PI / 180;
  const DETAIL_K = 2.4;              // above this zoom use the 1:10m data

  // map styles: our vector map (offline) or NASA GIBS imagery (online, public domain, same projection)
  const GIBS = "https://gibs.earthdata.nasa.gov/wmts/epsg4326/best/";
  const STYLES = {
    vector: null,
    satellite: { layer: "BlueMarble_NextGeneration", ext: "jpeg", dim: 0.18 },
    relief: { layer: "BlueMarble_ShadedRelief_Bathymetry", ext: "jpeg", dim: 0.12 },
    lights: { layer: "VIIRS_Black_Marble", ext: "png", dim: 0 }
  };
  const TILE_PX = 512, Z_MAX = 7;
  const tiles = new Map();
  let style = "vector";
  try { style = JSON.parse(localStorage.getItem("dxz.mapstyle")) || "vector"; } catch (e) { /* default */ }
  if (!(style in STYLES)) style = "vector";

  function tile(st, z, row, col) {
    const key = st.layer + "/" + z + "/" + row + "/" + col;
    let t = tiles.get(key);
    if (!t) {
      t = new Image();
      t.decoding = "async";
      t.onload = () => { t.ok = true; request(); };
      t.onerror = () => { t.bad = true; };
      t.src = GIBS + st.layer + "/default/500m/" + z + "/" + row + "/" + col + "." + st.ext;
      tiles.set(key, t);
      if (tiles.size > 600) tiles.delete(tiles.keys().next().value);
    }
    return t;
  }

  // draws imagery for the visible window; returns false when nothing is loaded yet
  function drawTiles(st, X, Y, sx, lonA, lonB, latA, latB, dpr) {
    let z = 0;
    while (z < Z_MAX && (TILE_PX / (288 / Math.pow(2, z))) < sx * dpr * 0.9) z++;
    const deg = 288 / Math.pow(2, z);
    const c0 = Math.max(0, Math.floor((Math.max(lonA, -180) + 180) / deg));
    const c1 = Math.floor((Math.min(lonB, 180) + 180 - 1e-9) / deg);
    const r0 = Math.max(0, Math.floor((90 - Math.min(latA, 90)) / deg));
    const r1 = Math.floor((90 - Math.max(latB, -90) - 1e-9) / deg);
    let any = false;
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        const lon0 = -180 + c * deg, lat0 = 90 - r * deg;
        const lon1 = Math.min(180, lon0 + deg), lat1 = Math.max(-90, lat0 - deg);
        if (lon0 >= 180 || lat0 <= -90) continue;
        // best loaded tile: this level, else a coarser one (cropped)
        for (let zz = z; zz >= 0; zz--) {
          const d = 288 / Math.pow(2, zz);
          const cc = Math.floor((lon0 + 180) / d), rr = Math.floor((90 - lat0) / d);
          const t = tile(st, zz, rr, cc);
          if (t.ok) {
            const ppd = TILE_PX / d;
            const srcX = (lon0 - (-180 + cc * d)) * ppd, srcY = ((90 - rr * d) - lat0) * ppd;
            const srcW = (lon1 - lon0) * ppd, srcH = (lat0 - lat1) * ppd;
            const dx = X(lon0), dy = Y(lat0);
            ctx.drawImage(t, srcX, srcY, srcW, srcH, dx, dy, X(lon1) - dx + 0.5, Y(lat1) - dy + 0.5);
            any = true;
            break;
          }
          if (zz === z && !t.bad && zz > 0) continue;
        }
      }
    }
    return any;
  }

  const sets = { 50: null, 10: null };
  let loading10 = false;
  let canvas = null, ctx = null, nightCanvas = null;
  let lastView = { W: 1, H: 1, k: 1, tx: 0, ty: 0 };
  let pending = false;

  function prepare(raw) {
    const make = (list) => list.map((a) => {
      let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
      for (let i = 0; i < a.length; i += 2) {
        const x = a[i] / 100, y = a[i + 1] / 100;
        if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
      }
      return { a, x0, x1, y0, y1 };
    });
    return { fill: make(raw.fill), coast: make(raw.coast), borders: make(raw.borders) };
  }

  async function load(level) {
    const res = await fetch("assets/map/world" + level + ".json", { cache: "force-cache" });
    sets[level] = prepare(await res.json());
    request();
  }

  // ------------------------------------------------------------------ drawing
  function draw() {
    pending = false;
    if (!ctx) return;
    const { W, H, k, tx, ty } = lastView;
    const dpr = window.devicePixelRatio || 1;
    if (canvas.width !== Math.round(W * dpr) || canvas.height !== Math.round(H * dpr)) {
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const sx = W * k / 360, sy = H * k / SPAN;
    const X = (lon) => (lon + 180) * sx + tx;
    const Y = (lat) => (MAP.latTop - lat) * sy + ty;
    // visible window in degrees
    const lonA = -tx / sx - 180, lonB = (W - tx) / sx - 180;
    const latA = MAP.latTop + ty / sy, latB = MAP.latTop - (H - ty) / sy;

    // ocean
    const g = ctx.createRadialGradient(W * 0.5, H * 0.45, 0, W * 0.5, H * 0.45, Math.max(W, H) * 0.75);
    g.addColorStop(0, "#0b1f3a");
    g.addColorStop(1, "#050d1a");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    // graticule (denser when zoomed in)
    const step = k >= 5 ? 5 : k >= 2.2 ? 10 : 15;
    ctx.lineWidth = 1;
    ctx.strokeStyle = "rgba(110, 160, 205, 0.16)";
    ctx.beginPath();
    for (let lon = -180; lon <= 180; lon += step) {
      const x = Math.round(X(lon)) + 0.5;
      if (x >= -1 && x <= W + 1) { ctx.moveTo(x, 0); ctx.lineTo(x, H); }
    }
    for (let lat = -90; lat <= 90; lat += step) {
      const y = Math.round(Y(lat)) + 0.5;
      if (y >= -1 && y <= H + 1) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
    }
    ctx.stroke();
    ctx.strokeStyle = "rgba(110, 160, 205, 0.32)";
    ctx.beginPath();
    const ye = Math.round(Y(0)) + 0.5;
    ctx.moveTo(0, ye); ctx.lineTo(W, ye);
    ctx.stroke();
    ctx.setLineDash([6, 8]);
    ctx.strokeStyle = "rgba(230, 190, 90, 0.30)";
    ctx.beginPath();
    [23.44, -23.44, 66.56].forEach((lat) => { const y = Math.round(Y(lat)) + 0.5; ctx.moveTo(0, y); ctx.lineTo(W, y); });
    ctx.stroke();
    ctx.setLineDash([]);

    const data = (k >= DETAIL_K && sets[10]) || sets[50];
    const st = STYLES[style];
    let imagery = false;
    if (st) {
      imagery = drawTiles(st, X, Y, sx, lonA, lonB, latA, latB, dpr);
      if (imagery && st.dim) { ctx.fillStyle = "rgba(2, 8, 18, " + st.dim + ")"; ctx.fillRect(0, 0, W, H); }
    }
    if (!data) return;
    const visible = (r, off) => r.x1 + off >= lonA - 1 && r.x0 + off <= lonB + 1 && r.y1 >= latB - 1 && r.y0 <= latA + 1;
    const pathOf = (list, closed) => {
      ctx.beginPath();
      for (const r of list) {
        for (const off of [0, -360, 360]) {
          if (!visible(r, off)) continue;
          const a = r.a;
          ctx.moveTo(X(a[0] / 100 + off), Y(a[1] / 100));
          for (let i = 2; i < a.length; i += 2) ctx.lineTo(X(a[i] / 100 + off), Y(a[i + 1] / 100));
          if (closed) ctx.closePath();
          if (!closed) break;           // lines are never wrapped
        }
      }
    };

    if (imagery) {
      // over the imagery: only fine borders and coastline
      ctx.lineJoin = "round";
      pathOf(data.borders, false);
      ctx.strokeStyle = "rgba(255, 255, 255, 0.45)";
      ctx.lineWidth = 0.8;
      ctx.stroke();
      pathOf(data.coast, false);
      ctx.strokeStyle = "rgba(160, 235, 255, 0.55)";
      ctx.lineWidth = 0.9;
      ctx.stroke();
      if (G.geo.layers.daynight && style !== "lights") drawNight(W, H, X, Y, sx, sy, tx, ty);
      credit(true);
      if (k >= DETAIL_K && !sets[10] && !loading10) { loading10 = true; load(10).catch(() => { loading10 = false; }); }
      return;
    }
    credit(false);
    // land
    pathOf(data.fill, true);
    const lg = ctx.createLinearGradient(0, Y(80), 0, Y(-60));
    lg.addColorStop(0, "#285a6b");
    lg.addColorStop(0.42, "#1f4a59");
    lg.addColorStop(1, "#285a6b");
    ctx.fillStyle = lg;
    ctx.fill("evenodd");

    const grow = Math.min(1.7, 1 + (k - 1) * 0.12);
    // borders
    pathOf(data.borders, false);
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    ctx.strokeStyle = "rgba(120, 175, 190, 0.55)";
    ctx.lineWidth = 0.9 * grow;
    ctx.stroke();
    // coastline: soft glow + sharp line
    pathOf(data.coast, false);
    ctx.strokeStyle = "rgba(40, 200, 230, 0.13)";
    ctx.lineWidth = 6 * grow;
    ctx.stroke();
    ctx.strokeStyle = "rgba(95, 222, 240, 0.95)";
    ctx.lineWidth = 1.3 * grow;
    ctx.stroke();

    // night, computed for the visible area only (smooth at every zoom)
    if (G.geo.layers.daynight) drawNight(W, H, X, Y, sx, sy, tx, ty);

    if (k >= DETAIL_K && !sets[10] && !loading10) {
      loading10 = true;
      load(10).catch(() => { loading10 = false; });
    }
  }

  function drawNight(W, H, X, Y, sx, sy, tx, ty) {
    const cell = 4;
    const w = Math.ceil(W / cell), h = Math.ceil(H / cell);
    if (!nightCanvas) nightCanvas = document.createElement("canvas");
    nightCanvas.width = w;
    nightCanvas.height = h;
    const nctx = nightCanvas.getContext("2d");
    const img = nctx.createImageData(w, h);
    const sun = G.sunPosition(new Date());
    for (let j = 0; j < h; j++) {
      const lat = MAP.latTop - ((j + 0.5) * cell - ty) / sy;
      for (let i = 0; i < w; i++) {
        const lon = ((i + 0.5) * cell - tx) / sx - 180;
        const alt = G.sunAltitude(lat, lon, sun);
        const sh = G.dayNightShade(alt);
        const p = (j * w + i) * 4;
        img.data[p] = sh[0]; img.data[p + 1] = sh[1]; img.data[p + 2] = sh[2]; img.data[p + 3] = sh[3] * 255;
      }
    }
    nctx.putImageData(img, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(nightCanvas, 0, 0, w * cell, h * cell);
  }

  let creditEl = null;
  function credit(on) {
    if (!creditEl && canvas) {
      creditEl = document.createElement("div");
      creditEl.className = "dxz-credit";
      creditEl.textContent = "Imagery: NASA GIBS · Blue Marble / Black Marble";
      canvas.parentElement.appendChild(creditEl);
    }
    if (creditEl) creditEl.hidden = !on;
  }

  function request() {
    if (pending) return;
    pending = true;
    requestAnimationFrame(draw);
  }

  // ------------------------------------------------------------------ API used by the zoom
  window.dxzBaseMap = {
    init(layerBox) {
      canvas = document.createElement("canvas");
      canvas.className = "dxz-basemap";
      layerBox.insertBefore(canvas, layerBox.firstChild);
      ctx = canvas.getContext("2d");
      layerBox.classList.add("vector-map");
      load(50).catch(() => layerBox.classList.remove("vector-map"));   // fallback: the picture
      document.addEventListener("click", (e) => { if (e.target.closest && e.target.closest(".dxz-layer-chip")) request(); });
      setInterval(request, 60 * 1000);       // night moves
    },
    draw(view) {
      lastView = view;
      request();
    },
    styles: Object.keys(STYLES),
    style() { return style; },
    setStyle(name) {
      if (!(name in STYLES)) return;
      style = name;
      try { localStorage.setItem("dxz.mapstyle", JSON.stringify(name)); } catch (e) { /* ignore */ }
      request();
    }
  };
})();
