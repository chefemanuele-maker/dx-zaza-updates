/* DX Zaza — Digital Voice: C4FM rooms (YSF reflectors, DN through the DVstick) and EchoLink
   (directory, stations / links / repeaters / conferences, text messages, settings). */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const TEXT = {
    en: {
      "ysf.rooms": "C4FM ROOMS", "ysf.search": "Room (number, name or country)", "ysf.manual": "Room not in the list: address and port",
      "ysf.port": "Port", "ysf.note": "C4FM digital narrow (DN) through the DVstick. Wide (VW) voice is shown but not played.",
      "ysf.joining": "Joining the C4FM room...", "ysf.joined": "In the room {name}", "ysf.pick": "Choose a room from the list.",
      "ysf.parrot": "Parrot (test)", "ysf.italy": "Italy", "ysf.uk": "UK", "ysf.count": "{n} rooms · {m} shown",
      "ysf.warning": "Room list: {w}",
      "el.target": "Station, link, repeater or conference (callsign or node)", "el.all": "All", "el.conferences": "Conferences",
      "el.links": "Links", "el.repeaters": "Repeaters", "el.users": "Stations", "el.connect": "Connect", "el.disconnect": "Disconnect",
      "el.echo": "Echo test", "el.send": "Send", "el.settings": "EchoLink settings: password, name, location",
      "el.callsign": "EchoLink callsign", "el.password": "EchoLink password", "el.name": "Name", "el.location": "Location",
      "el.settings_note": "Use the callsign and password you validated on echolink.org: they stay on this computer. Nothing to set on the router: if the station cannot reach you directly, DX Zaza goes through a public EchoLink proxy by itself. Works without the DVstick.",
      "el.connecting": "Logging in to EchoLink and calling {t} (up to 30 seconds)...", "el.connected": "Connected to {t}",
      "el.loading": "Reading the EchoLink directory...", "el.count": "{n} on line · {m} shown", "el.saved": "EchoLink settings saved.",
      "el.need_password": "Enter your EchoLink password in EchoLink settings first.", "el.password_set": "saved — type to change",
      "el.busy": "busy", "el.via": "via public proxy {p}"
    },
    it: {
      "ysf.rooms": "STANZE C4FM", "ysf.search": "Stanza (numero, nome o nazione)", "ysf.manual": "Stanza non in elenco: indirizzo e porta",
      "ysf.port": "Porta", "ysf.note": "C4FM digitale stretto (DN) tramite la DVstick. La voce larga (VW) viene mostrata ma non riprodotta.",
      "ysf.joining": "Collegamento alla stanza C4FM...", "ysf.joined": "Nella stanza {name}", "ysf.pick": "Scegli una stanza dall'elenco.",
      "ysf.parrot": "Pappagallo (prova)", "ysf.italy": "Italia", "ysf.uk": "Regno Unito", "ysf.count": "{n} stanze · {m} mostrate",
      "ysf.warning": "Elenco stanze: {w}",
      "el.target": "Stazione, link, ripetitore o conferenza (nominativo o nodo)", "el.all": "Tutti", "el.conferences": "Conferenze",
      "el.links": "Link", "el.repeaters": "Ripetitori", "el.users": "Stazioni", "el.connect": "Collega", "el.disconnect": "Scollega",
      "el.echo": "Test eco", "el.send": "Invia", "el.settings": "Impostazioni EchoLink: password, nome, località",
      "el.callsign": "Nominativo EchoLink", "el.password": "Password EchoLink", "el.name": "Nome", "el.location": "Località",
      "el.settings_note": "Usa il nominativo e la password convalidati su echolink.org: restano su questo computer. Niente da impostare sul router: se la stazione non ti raggiunge direttamente, DX Zaza passa da solo tramite un proxy pubblico EchoLink. Funziona anche senza DVstick.",
      "el.connecting": "Accesso a EchoLink e chiamata a {t} (fino a 30 secondi)...", "el.connected": "Collegato a {t}",
      "el.loading": "Lettura dell'elenco EchoLink...", "el.count": "{n} in linea · {m} mostrati", "el.saved": "Impostazioni EchoLink salvate.",
      "el.need_password": "Inserisci prima la password EchoLink nelle impostazioni EchoLink.", "el.password_set": "salvata — scrivi per cambiarla",
      "el.busy": "occupato", "el.via": "tramite proxy pubblico {p}"
    }
  };
  if (typeof translations === "object") {
    Object.keys(TEXT).forEach((l) => { if (translations[l]) Object.assign(translations[l], TEXT[l]); });
  }
  const tr = (k) => (typeof t === "function" ? t(k) : null) || TEXT.en[k] || k;
  const st = { rooms: [], room: null, stations: [], kind: "", settings: null, link: {}, mode: "", elLoaded: false, elTimer: null };

  async function post(path, body) {
    const res = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) throw new Error(data.error || "HTTP " + res.status);
    return data;
  }
  const ysfMsg = (x) => { $("ysfMessage").textContent = x || ""; };
  const elMsg = (x) => { $("elMessage").textContent = x || ""; };
  const kbClose = () => { if (typeof closeTouchKeyboard === "function") closeTouchKeyboard(); };

  // ================================================================= C4FM
  async function loadRooms(refresh) {
    try {
      const d = await (await fetch("/api/voice/ysf/rooms" + (refresh ? "?refresh=1" : ""), { cache: "no-store" })).json();
      st.rooms = d.rooms || [];
      if (d.warning) $("ysfInfo").textContent = tr("ysf.warning").replace("{w}", d.warning);
      const last = (st.settings && st.settings.ysfLast) || {};
      if (!st.room && last.host) st.room = st.rooms.find((r) => r.host === last.host && r.port === last.port) || last;
      renderRooms();
    } catch (_) { /* offline */ }
  }
  function roomLabel(r) { return (r.id ? r.id + " · " : "") + (r.name || r.host) + (r.description ? " — " + r.description : ""); }
  function renderRooms() {
    const q = $("ysfSearch").value.trim().toUpperCase();
    let list = st.rooms;
    if (q === "PARROT" || q === "PAPPAGALLO") list = list.filter((r) => r.parrot);
    else if (q) list = list.filter((r) => r.id.indexOf(q) === 0 || (r.name + " " + r.description).toUpperCase().indexOf(q) >= 0);
    const shown = list.slice(0, 60);
    $("ysfRoomList").innerHTML = shown.map((r, i) =>
      '<button type="button" class="voice-pick' + (st.room && st.room.host === r.host && st.room.port === r.port ? " active" : "") +
      '" data-i="' + st.rooms.indexOf(r) + '"><strong>' + esc(r.id) + "</strong> " + esc(r.name) +
      (r.description ? " <small>" + esc(r.description) + "</small>" : "") + "</button>").join("");
    $("ysfSelected").textContent = st.room ? roomLabel(st.room) : tr("ysf.count").replace("{n}", st.rooms.length).replace("{m}", shown.length);
  }
  async function joinRoom(room) {
    room = room || st.room;
    const host = $("ysfHost").value.trim();
    if (host) room = { id: "", name: host.toUpperCase(), host, port: Number($("ysfPort").value) || 42000 };
    if (!room) { ysfMsg(tr("ysf.pick")); return; }
    st.room = room;
    ysfMsg(tr("ysf.joining"));
    try {
      await post("/api/voice/ysf/link", { id: room.id || "", host: room.host, port: room.port, name: room.name });
      ysfMsg(tr("ysf.joined").replace("{name}", roomLabel(room)));
    } catch (err) { ysfMsg(err.message); }
    refresh();
  }
  function ysfFavs() { return (st.settings && st.settings.ysfFavorites) || []; }
  function renderYsfFavs() {
    $("ysfFavs").innerHTML = ysfFavs().map((f, i) =>
      '<span class="voice-fav"><button type="button" class="voice-fav-go" data-i="' + i + '">' + esc((f.id ? f.id + " " : "") + f.name) + "</button>" +
      '<button type="button" class="voice-fav-del" data-del="' + i + '" aria-label="remove">×</button></span>').join("");
  }
  async function saveYsfFavs(list) {
    try { const r = await post("/api/voice/settings", { ysfFavorites: list }); st.settings = r.settings; renderYsfFavs(); } catch (err) { ysfMsg(err.message); }
  }

  // ================================================================= EchoLink
  async function loadStations(refresh) {
    const q = $("elTarget").value.trim();
    if (!st.elLoaded) $("elList").innerHTML = '<p class="wifi-demo-note">' + esc(tr("el.loading")) + "</p>";
    try {
      const url = "/api/voice/echolink/stations?kind=" + encodeURIComponent(st.kind) + "&q=" + encodeURIComponent(q) + (refresh ? "&refresh=1" : "");
      const d = await (await fetch(url, { cache: "no-store" })).json();
      if (!d.ok) throw new Error(d.error);
      st.elLoaded = true;
      st.stations = d.stations || [];
      $("elList").innerHTML = st.stations.slice(0, 80).map((s) =>
        '<button type="button" class="voice-pick' + (s.status === "BUSY" ? " busy" : "") + '" data-call="' + esc(s.callsign) + '"><strong>' +
        esc(s.callsign) + "</strong> <small>" + esc(s.node) + "</small> " + esc(s.description) +
        (s.status === "BUSY" ? " <small>(" + esc(tr("el.busy")) + ")</small>" : "") + "</button>").join("") +
        '<p class="wifi-demo-note">' + esc(tr("el.count").replace("{n}", d.total).replace("{m}", d.matches)) + "</p>" +
        (d.serverMessage && !d.total ? '<p class="wifi-demo-note">' + esc(d.serverMessage).replace(/\n/g, "<br>") + "</p>" : "");
    } catch (err) { $("elList").innerHTML = '<p class="wifi-demo-note">' + esc(err.message) + "</p>"; }
  }
  function debounceStations() { clearTimeout(st.elTimer); st.elTimer = setTimeout(() => loadStations(false), 350); }
  async function connectEl(target) {
    target = String(target || $("elTarget").value || "").trim().toUpperCase();
    if (!target) return;
    if (!st.settings || !st.settings.echolinkPasswordSet) { elMsg(tr("el.need_password")); $("elSettingsBox").open = true; return; }
    elMsg(tr("el.connecting").replace("{t}", target));
    try {
      const r = await post("/api/voice/echolink/connect", { target });
      const s = r.station || {};
      const via = (r.link && r.link.via) ? " · " + tr("el.via").replace("{p}", r.link.via) : "";
      elMsg(tr("el.connected").replace("{t}", s.callsign + (s.description ? " — " + s.description : "")) + via);
    } catch (err) { elMsg(err.message); }
    refresh();
  }
  function elFavs() { return (st.settings && st.settings.echolinkFavorites) || []; }
  function renderElFavs() {
    $("elFavs").innerHTML = elFavs().map((f, i) =>
      '<span class="voice-fav"><button type="button" class="voice-fav-go" data-i="' + i + '">' + esc(f.callsign) +
      (f.node ? " <small>" + esc(f.node) + "</small>" : "") + "</button>" +
      '<button type="button" class="voice-fav-del" data-del="' + i + '" aria-label="remove">×</button></span>').join("");
  }
  async function saveElFavs(list) {
    try { const r = await post("/api/voice/settings", { echolinkFavorites: list }); st.settings = r.settings; renderElFavs(); } catch (err) { elMsg(err.message); }
  }
  function fillElSettings() {
    const s = st.settings || {};
    const set = (id, v) => { if (document.activeElement !== $(id)) $(id).value = v || ""; };
    set("elCallsign", s.echolinkCallsign);
    set("elName", s.echolinkName);
    set("elLocation", s.echolinkLocation);
    $("elPassword").placeholder = s.echolinkPasswordSet ? tr("el.password_set") : "";
    if (!s.echolinkPasswordSet) $("elSettingsBox").open = true;
  }
  async function saveElSettings(e) {
    if (e) e.preventDefault();
    kbClose();
    const body = { echolinkCallsign: $("elCallsign").value.trim(), echolinkName: $("elName").value.trim(), echolinkLocation: $("elLocation").value.trim() };
    if ($("elPassword").value) body.echolinkPassword = $("elPassword").value;
    try {
      const r = await post("/api/voice/settings", body);
      st.settings = r.settings;
      $("elPassword").value = "";
      fillElSettings();
      elMsg(tr("el.saved"));
      st.elLoaded = false;
      loadStations(true);
    } catch (err) { elMsg(err.message); }
  }
  function renderChat() {
    const link = st.link || {};
    const on = link.mode === "echolink" && link.state !== "unlinked";
    $("elChat").hidden = !on;
    if (!on) return;
    const box = $("elMessages");
    box.innerHTML = (link.messages || []).map((m) => '<p class="el-msg ' + esc(m.kind) + '">' + esc(m.text).replace(/\n/g, "<br>") + "</p>").join("");
  }

  // ================================================================= status
  async function refresh() {
    try {
      const d = await (await fetch("/api/voice/status", { cache: "no-store" })).json();
      const first = !st.settings;
      st.settings = d.settings || st.settings;
      st.link = d.link || {};
      if (first) { renderYsfFavs(); renderElFavs(); fillElSettings(); }
      const link = st.link;
      $("ysfLeave").disabled = !(link.mode === "ysf" && link.state !== "unlinked");
      $("elLeave").disabled = !(link.mode === "echolink" && link.state !== "unlinked");
      renderChat();
    } catch (_) { /* */ }
  }

  function onMode(mode) {
    st.mode = mode;
    if (mode === "ysf" && !st.rooms.length) loadRooms(false);
    if (mode === "echolink" && !st.elLoaded) loadStations(false);
  }

  function init() {
    if (!$("ysfLinkForm")) return;
    // C4FM
    $("ysfChips").innerHTML = [["PARROT", "ysf.parrot"], ["IT-", "ysf.italy"], ["GB-", "ysf.uk"]].map(([q, k]) =>
      '<button type="button" class="voice-small ysf-chip" data-q="' + q + '">' + esc(tr(k)) + "</button>").join("");
    $("ysfChips").addEventListener("click", (e) => { const b = e.target.closest(".ysf-chip"); if (b) { $("ysfSearch").value = b.dataset.q; renderRooms(); } });
    $("ysfSearch").addEventListener("input", renderRooms);
    $("ysfRoomList").addEventListener("click", (e) => {
      const b = e.target.closest(".voice-pick");
      if (b) { st.room = st.rooms[Number(b.dataset.i)]; $("ysfHost").value = ""; renderRooms(); }
    });
    $("ysfRoomList").addEventListener("dblclick", (e) => { if (e.target.closest(".voice-pick")) joinRoom(); });
    $("ysfLinkForm").addEventListener("submit", (e) => { e.preventDefault(); kbClose(); joinRoom(); });
    $("ysfLeave").addEventListener("click", async () => { try { await post("/api/voice/unlink"); ysfMsg(""); } catch (err) { ysfMsg(err.message); } refresh(); });
    $("ysfRefresh").addEventListener("click", () => loadRooms(true));
    $("ysfFavAdd").addEventListener("click", () => {
      const r = st.room;
      if (!r) { ysfMsg(tr("ysf.pick")); return; }
      const list = ysfFavs().filter((f) => !(f.host === r.host && f.port === r.port));
      list.unshift({ id: r.id || "", name: r.name || r.host, host: r.host, port: r.port });
      saveYsfFavs(list.slice(0, 30));
    });
    $("ysfFavs").addEventListener("click", (e) => {
      const del = e.target.closest(".voice-fav-del");
      if (del) { const list = ysfFavs().slice(); list.splice(Number(del.dataset.del), 1); saveYsfFavs(list); return; }
      const go = e.target.closest(".voice-fav-go");
      if (go) joinRoom(ysfFavs()[Number(go.dataset.i)]);
    });
    // EchoLink
    $("elKinds").addEventListener("click", (e) => {
      const b = e.target.closest(".el-kind");
      if (!b) return;
      st.kind = b.dataset.kind;
      document.querySelectorAll(".el-kind").forEach((x) => x.classList.toggle("active", x === b));
      loadStations(false);
    });
    $("elTarget").addEventListener("input", debounceStations);
    $("elList").addEventListener("click", (e) => { const b = e.target.closest(".voice-pick"); if (b) $("elTarget").value = b.dataset.call; });
    $("elList").addEventListener("dblclick", (e) => { const b = e.target.closest(".voice-pick"); if (b) connectEl(b.dataset.call); });
    $("elLinkForm").addEventListener("submit", (e) => { e.preventDefault(); kbClose(); connectEl(); });
    $("elEcho").addEventListener("click", () => { $("elTarget").value = "*ECHOTEST*"; connectEl("*ECHOTEST*"); });
    $("elLeave").addEventListener("click", async () => { try { await post("/api/voice/unlink"); elMsg(""); } catch (err) { elMsg(err.message); } refresh(); });
    $("elRefresh").addEventListener("click", () => loadStations(true));
    $("elFavAdd").addEventListener("click", () => {
      const call = $("elTarget").value.trim().toUpperCase();
      if (!call) return;
      const s = st.stations.find((x) => x.callsign === call || String(x.node) === call);
      const list = elFavs().filter((f) => f.callsign !== (s ? s.callsign : call));
      list.unshift({ callsign: s ? s.callsign : call, node: s ? s.node : (/^\d+$/.test(call) ? Number(call) : 0) });
      saveElFavs(list.slice(0, 30));
    });
    $("elFavs").addEventListener("click", (e) => {
      const del = e.target.closest(".voice-fav-del");
      if (del) { const list = elFavs().slice(); list.splice(Number(del.dataset.del), 1); saveElFavs(list); return; }
      const go = e.target.closest(".voice-fav-go");
      if (go) { const f = elFavs()[Number(go.dataset.i)]; $("elTarget").value = f.callsign; connectEl(f.callsign); }
    });
    $("elSettingsForm").addEventListener("submit", saveElSettings);
    $("elChatForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      kbClose();
      const text = $("elChatText").value.trim();
      if (!text) return;
      try { await post("/api/voice/echolink/text", { text }); $("elChatText").value = ""; } catch (err) { elMsg(err.message); }
    });
    document.addEventListener("dxz-voice-mode", (e) => onMode(e.detail));
    const active = document.querySelector(".voice-mode.active");
    if (active) onMode(active.dataset.mode);
    refresh();
    setInterval(() => { if ((typeof activePage === "undefined" || activePage === "voice") && (st.mode === "ysf" || st.mode === "echolink")) refresh(); }, 4000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
