/* DX Zaza — Digital Voice modes: D-STAR / DMR tabs, DMR networks (BrandMeister, TGIF, FreeDMR...),
   talkgroups, favourites and DMR settings (ID from RadioID.net, hotspot password). */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const TEXT = {
    en: {
      "dmr.soon": "soon", "dmr.network": "DMR NETWORK", "dmr.master": "Network", "dmr.talkgroup": "Talkgroup",
      "dmr.join": "Join", "dmr.listen": "Listen (key up)", "dmr.settings": "DMR settings: ID and password",
      "dmr.id": "DMR ID", "dmr.essid": "Hotspot suffix (ESSID)", "dmr.password": "BrandMeister hotspot password",
      "dmr.find_id": "Find my DMR ID",
      "dmr.settings_note": "Your DMR ID comes from RadioID.net. BrandMeister needs the hotspot password you set in BrandMeister SelfCare; TGIF and FreeDMR do not.",
      "dmr.joining": "Joining the DMR network...", "dmr.joined": "Joined {net} · TG {tg} {name}",
      "dmr.bm_hint": "BrandMeister: press Listen once (a short key-up) to start hearing this talkgroup, or make it static in SelfCare.",
      "dmr.saved": "DMR settings saved.", "dmr.need_id": "Enter your DMR ID in DMR settings first.",
      "dmr.searching": "Looking up RadioID.net...", "dmr.found": "DMR ID found: {id}", "dmr.not_found": "No DMR ID registered for {call} on RadioID.net.",
      "dmr.pick": "Several IDs: tap one", "dmr.password_set": "saved — type to change", "dmr.listening": "Key-up sent: the talkgroup will start in a moment.",
      "dmr.eyebrow": "DIGITAL VOICE · DMR", "dstar.eyebrow": "DIGITAL VOICE · D-STAR", "ysf.eyebrow": "DIGITAL VOICE · C4FM", "el.eyebrow": "VOICE · ECHOLINK", "dmr.list_warning": "Network list: {w}"
    },
    it: {
      "dmr.soon": "presto", "dmr.network": "RETE DMR", "dmr.master": "Rete", "dmr.talkgroup": "Talkgroup",
      "dmr.join": "Collega", "dmr.listen": "Ascolta (breve PTT)", "dmr.settings": "Impostazioni DMR: ID e password",
      "dmr.id": "ID DMR", "dmr.essid": "Suffisso hotspot (ESSID)", "dmr.password": "Password hotspot BrandMeister",
      "dmr.find_id": "Trova il mio ID DMR",
      "dmr.settings_note": "L'ID DMR viene da RadioID.net. BrandMeister richiede la password hotspot impostata in BrandMeister SelfCare; TGIF e FreeDMR no.",
      "dmr.joining": "Collegamento alla rete DMR...", "dmr.joined": "Collegato a {net} · TG {tg} {name}",
      "dmr.bm_hint": "BrandMeister: premi Ascolta una volta (breve PTT) per iniziare a sentire questo talkgroup, oppure rendilo statico in SelfCare.",
      "dmr.saved": "Impostazioni DMR salvate.", "dmr.need_id": "Inserisci prima il tuo ID DMR nelle impostazioni DMR.",
      "dmr.searching": "Ricerca su RadioID.net...", "dmr.found": "ID DMR trovato: {id}", "dmr.not_found": "Nessun ID DMR registrato per {call} su RadioID.net.",
      "dmr.pick": "Più ID: toccane uno", "dmr.password_set": "salvata — scrivi per cambiarla", "dmr.listening": "PTT breve inviato: il talkgroup partirà tra un attimo.",
      "dmr.eyebrow": "VOCE DIGITALE · DMR", "dstar.eyebrow": "VOCE DIGITALE · D-STAR", "ysf.eyebrow": "VOCE DIGITALE · C4FM", "el.eyebrow": "VOCE · ECHOLINK", "dmr.list_warning": "Elenco reti: {w}"
    }
  };
  if (typeof translations === "object") {
    Object.keys(TEXT).forEach((l) => { if (translations[l]) Object.assign(translations[l], TEXT[l]); });
  }
  const tr = (k) => (typeof t === "function" ? t(k) : null) || TEXT.en[k] || k;
  const QUICK_TG = [91, 92, 93, 235, 222, 262, 310, 9990];
  const FAMILY_ORDER = ["BrandMeister", "TGIF", "FreeDMR", "DMR+", "SystemX", "Other"];
  const st = { mode: "dstar", masters: [], tgNames: {}, settings: null, status: null, pickedMode: false };

  function msg(text) { const el = $("dmrMessage"); if (el) el.textContent = text || ""; }
  async function post(path, body) {
    const res = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) throw new Error(data.error || "HTTP " + res.status);
    return data;
  }

  // ------------------------------------------------------------ tabs
  function setMode(mode, remember) {
    st.mode = mode;
    document.querySelectorAll(".voice-mode").forEach((b) => b.classList.toggle("active", b.dataset.mode === mode));
    const ref = document.querySelector(".voice-reflector"), card = document.querySelector(".voice-dmr");
    if (ref) ref.hidden = mode !== "dstar";
    if (card) card.hidden = mode !== "dmr";
    const ysfCard = document.querySelector(".voice-ysf"), elCard = document.querySelector(".voice-echolink");
    if (ysfCard) ysfCard.hidden = mode !== "ysf";
    if (elCard) elCard.hidden = mode !== "echolink";
    const eyebrow = document.querySelector("#page-voice .section-heading .eyebrow");
    if (eyebrow) eyebrow.textContent = tr({ dmr: "dmr.eyebrow", ysf: "ysf.eyebrow", echolink: "el.eyebrow" }[mode] || "dstar.eyebrow");
    document.dispatchEvent(new CustomEvent("dxz-voice-mode", { detail: mode }));
    if (remember) { st.pickedMode = true; try { localStorage.setItem("dxz.voiceMode", mode); } catch (_) { /* */ } }
    if (mode === "dmr" && !st.masters.length) loadMasters();
  }

  // ------------------------------------------------------------ networks + talkgroups
  async function loadMasters(refresh) {
    try {
      const d = await (await fetch("/api/voice/dmr/masters" + (refresh ? "?refresh=1" : ""), { cache: "no-store" })).json();
      st.masters = d.masters || [];
      st.tgNames = d.talkgroups || {};
      renderMasters();
      renderTgList();
      if (d.warning) $("dmrInfo").textContent = tr("dmr.list_warning").replace("{w}", d.warning);
    } catch (_) { /* offline */ }
  }
  function renderMasters() {
    const sel = $("dmrNetwork");
    if (!sel) return;
    const last = (st.settings && st.settings.dmrLast) || {};
    const groups = {};
    st.masters.forEach((m, i) => { (groups[m.family] = groups[m.family] || []).push([m, i]); });
    sel.innerHTML = FAMILY_ORDER.filter((f) => groups[f]).map((f) =>
      '<optgroup label="' + esc(f) + '">' + groups[f].map(([m, i]) =>
        '<option value="' + i + '"' + (m.host === last.host ? " selected" : "") + ">" + esc(m.name.replace(/_/g, " ")) + "</option>").join("") +
      "</optgroup>").join("");
    if (!last.host) {
      const uk = st.masters.findIndex((m) => /^BM_2341/.test(m.name));
      if (uk >= 0) sel.value = String(uk);
    }
    if (last.talkgroup && !$("dmrTalkgroup").value) $("dmrTalkgroup").value = last.talkgroup;
    showTgName();
  }
  function tgName(tg) { return st.tgNames[String(tg)] || ""; }
  function renderTgList() {
    $("dmrTgList").innerHTML = Object.keys(st.tgNames).map((k) => '<option value="' + esc(k) + '">' + esc(st.tgNames[k]) + "</option>").join("");
    $("dmrTgChips").innerHTML = QUICK_TG.map((tg) =>
      '<button type="button" class="voice-small dmr-tg" data-tg="' + tg + '">' + tg + (tgName(tg) ? " · " + esc(tgName(tg)) : "") + "</button>").join("");
  }
  function showTgName() { const v = $("dmrTalkgroup").value.trim(); $("dmrTgName").textContent = tgName(v); }
  function selectedMaster() { return st.masters[Number($("dmrNetwork").value)] || null; }

  // ------------------------------------------------------------ join / leave / listen
  async function join(master, tg) {
    master = master || selectedMaster();
    tg = String(tg || $("dmrTalkgroup").value || "").trim();
    if (!master || !/^\d{1,8}$/.test(tg)) { msg(tr("dmr.talkgroup") + "?"); return; }
    if (!st.settings || !st.settings.dmrId) { msg(tr("dmr.need_id")); $("dmrSettingsBox").open = true; return; }
    msg(tr("dmr.joining"));
    try {
      await post("/api/voice/dmr/link", { name: master.name, host: master.host, port: master.port, family: master.family, talkgroup: Number(tg) });
      msg(tr("dmr.joined").replace("{net}", master.name.replace(/_/g, " ")).replace("{tg}", tg).replace("{name}", tgName(tg)) +
        (master.family === "BrandMeister" ? " — " + tr("dmr.bm_hint") : ""));
      refreshStatus();
    } catch (err) { msg(err.message); }
  }

  // ------------------------------------------------------------ favourites
  function favs() { return (st.settings && st.settings.dmrFavorites) || []; }
  function renderFavs() {
    const box = $("dmrFavs");
    if (!box) return;
    box.innerHTML = favs().map((f, i) =>
      '<span class="voice-fav"><button type="button" class="voice-fav-go" data-i="' + i + '">' + esc("TG " + f.talkgroup + (tgName(f.talkgroup) ? " " + tgName(f.talkgroup) : "")) +
      " <small>" + esc(String(f.name || "").replace(/_/g, " ").slice(0, 22)) + "</small></button>" +
      '<button type="button" class="voice-fav-del" data-del="' + i + '" aria-label="remove">×</button></span>').join("");
  }
  async function saveFavs(list) {
    try { const r = await post("/api/voice/settings", { dmrFavorites: list }); st.settings = r.settings; renderFavs(); } catch (err) { msg(err.message); }
  }

  // ------------------------------------------------------------ settings
  function fillSettings() {
    const s = st.settings || {};
    if (document.activeElement !== $("dmrId")) $("dmrId").value = s.dmrId || "";
    if (document.activeElement !== $("dmrEssid")) $("dmrEssid").value = s.dmrEssid || "";
    $("dmrPassword").placeholder = s.dmrPasswordSet ? tr("dmr.password_set") : "";
    if (!s.dmrId) $("dmrSettingsBox").open = true;
  }
  async function saveSettings(e) {
    if (e) e.preventDefault();
    if (typeof closeTouchKeyboard === "function") closeTouchKeyboard();
    const body = { dmrId: $("dmrId").value.trim(), dmrEssid: $("dmrEssid").value.trim() };
    if ($("dmrPassword").value) body.dmrPassword = $("dmrPassword").value;
    try {
      const r = await post("/api/voice/settings", body);
      st.settings = r.settings;
      $("dmrPassword").value = "";
      fillSettings();
      msg(tr("dmr.saved"));
    } catch (err) { msg(err.message); }
  }
  async function findId() {
    msg(tr("dmr.searching"));
    try {
      const d = await (await fetch("/api/voice/dmr/id", { cache: "no-store" })).json();
      if (!d.ok) throw new Error(d.error);
      const ids = d.ids || [];
      if (!ids.length) { msg(tr("dmr.not_found").replace("{call}", "")); return; }
      if (ids.length === 1) {
        $("dmrId").value = ids[0].id;
        msg(tr("dmr.found").replace("{id}", ids[0].id + " · " + ids[0].callsign + " " + ids[0].name));
        return;
      }
      $("dmrMessage").innerHTML = esc(tr("dmr.pick")) + ": " + ids.map((x) =>
        '<button type="button" class="voice-small dmr-pick-id" data-id="' + x.id + '">' + x.id + " " + esc(x.callsign) + "</button>").join(" ");
    } catch (err) { msg(err.message || "RadioID.net"); }
  }

  // ------------------------------------------------------------ status
  async function refreshStatus() {
    try {
      const d = await (await fetch("/api/voice/status", { cache: "no-store" })).json();
      st.status = d;
      const firstTime = !st.settings;
      st.settings = d.settings || st.settings;
      if (firstTime) {
        let saved = "";
        try { saved = localStorage.getItem("dxz.voiceMode") || ""; } catch (_) { /* */ }
        const linkMode = d.link && d.link.state !== "unlinked" ? d.link.mode : "";
        setMode(linkMode || saved || (st.settings && st.settings.lastMode) || "dstar", false);
        fillSettings();
        renderFavs();
        if (st.masters.length) renderMasters();
      }
      const link = d.link || {};
      $("dmrLeave").disabled = !(link.mode === "dmr" && link.state !== "unlinked");
      $("dmrListen").disabled = !(link.mode === "dmr" && link.state === "linked" && st.settings && st.settings.txEnabled);
    } catch (_) { /* */ }
  }

  function init() {
    if (!$("dmrLinkForm")) return;
    document.querySelectorAll(".voice-mode").forEach((b) => b.addEventListener("click", () => { if (!b.disabled) setMode(b.dataset.mode, true); }));
    $("dmrLinkForm").addEventListener("submit", (e) => { e.preventDefault(); if (typeof closeTouchKeyboard === "function") closeTouchKeyboard(); join(); });
    $("dmrLeave").addEventListener("click", async () => { try { await post("/api/voice/unlink"); msg(""); refreshStatus(); } catch (err) { msg(err.message); } });
    $("dmrListen").addEventListener("click", async () => { try { await post("/api/voice/dmr/listen"); msg(tr("dmr.listening")); } catch (err) { msg(err.message); } });
    $("dmrRefresh").addEventListener("click", () => loadMasters(true));
    $("dmrTalkgroup").addEventListener("input", showTgName);
    $("dmrTgChips").addEventListener("click", (e) => {
      const b = e.target.closest(".dmr-tg");
      if (b) { $("dmrTalkgroup").value = b.dataset.tg; showTgName(); }
    });
    $("dmrFavAdd").addEventListener("click", () => {
      const m = selectedMaster(), tg = $("dmrTalkgroup").value.trim();
      if (!m || !/^\d+$/.test(tg)) return;
      const list = favs().filter((f) => !(f.host === m.host && String(f.talkgroup) === tg));
      list.unshift({ name: m.name, host: m.host, port: m.port, family: m.family, talkgroup: Number(tg) });
      saveFavs(list.slice(0, 30));
    });
    $("dmrFavs").addEventListener("click", (e) => {
      const del = e.target.closest(".voice-fav-del");
      if (del) { const list = favs().slice(); list.splice(Number(del.dataset.del), 1); saveFavs(list); return; }
      const go = e.target.closest(".voice-fav-go");
      if (go) {
        const f = favs()[Number(go.dataset.i)];
        const idx = st.masters.findIndex((m) => m.host === f.host);
        if (idx >= 0) $("dmrNetwork").value = String(idx);
        $("dmrTalkgroup").value = f.talkgroup;
        showTgName();
        join({ name: f.name, host: f.host, port: f.port, family: f.family }, f.talkgroup);
      }
    });
    $("dmrSettingsForm").addEventListener("submit", saveSettings);
    $("dmrFindId").addEventListener("click", findId);
    $("dmrMessage").addEventListener("click", (e) => {
      const b = e.target.closest(".dmr-pick-id");
      if (b) { $("dmrId").value = b.dataset.id; msg(tr("dmr.found").replace("{id}", b.dataset.id)); }
    });
    refreshStatus();
    loadMasters();
    setInterval(() => { if (typeof activePage === "undefined" || activePage === "voice") refreshStatus(); }, 4000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
