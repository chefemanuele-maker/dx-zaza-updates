/* DX Zaza — ISS Live.
   - "ISS Live" button in the Global Map layer bar: opens NASA's official live video from the
     space station in a small player in the sidebar (under Radio Tools), with sound on/off,
     enlarge and close. The player stays open while moving between pages.
   - The ISS dot on the map: hover (or tap) shows position, next pass and the ARISS
     amateur radio frequencies (uplink / downlink), with the uplink for the operator's region. */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[c]));
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (_) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) { /* private mode */ } }
  };
  const TXT = {
    en: {
      chip: "ISS Live", title: "ISS LIVE", sound_on: "Sound on", sound_off: "Sound off", bigger: "Enlarge",
      smaller: "Smaller", close: "Close", source: "NASA live video from the space station",
      dark: "Black or blue screen: the ISS is on the night side or NASA's video link is between satellites. It comes back by itself.",
      youtube: "Open on YouTube", alt: "Altitude", pos: "Position", next: "Next pass", now_visible: "Above your horizon now",
      el: "max", min: "min", freqs: "Amateur radio (ARISS)", your: "your region", status: "Status", off: "not always active",
      hover: "Point at the ISS on the map for its radio frequencies", loading: "Connecting to NASA…",
      nostream: "NASA's live video is not reachable right now. Retrying in a minute…", reload: "Back to live",
      stuck: "The video did not restart: tap ↻ to bring it back.",
      radio: "Paused while you are linked on the radio (keeps the Raspberry fast). It comes back when you unlink."
    },
    it: {
      chip: "ISS Live", title: "ISS LIVE", sound_on: "Audio attivo", sound_off: "Audio spento", bigger: "Ingrandisci",
      smaller: "Riduci", close: "Chiudi", source: "Video in diretta NASA dalla stazione spaziale",
      dark: "Schermo nero o blu: la ISS è nella notte o il collegamento video NASA sta passando da un satellite all'altro. Torna da solo.",
      youtube: "Apri su YouTube", alt: "Quota", pos: "Posizione", next: "Prossimo passaggio", now_visible: "Sopra il tuo orizzonte ora",
      el: "max", min: "min", freqs: "Radioamatori (ARISS)", your: "tua regione", status: "Stato", off: "non sempre attivo",
      hover: "Passa sulla ISS nella mappa per le frequenze radio", loading: "Collegamento a NASA…",
      nostream: "Il video NASA in diretta non è raggiungibile ora. Nuovo tentativo tra un minuto…", reload: "Torna alla diretta",
      stuck: "Il video non è ripartito: tocca ↻ per riprenderlo.",
      radio: "In pausa mentre sei collegato in radio (il Raspberry resta veloce). Riparte quando ti scolleghi."
    }
  };
  const lang = () => ((window.dxZazaState && dxZazaState.language) || document.documentElement.lang || "en").startsWith("it") ? "it" : "en";
  const tx = (k) => (TXT[lang()] || TXT.en)[k] || TXT.en[k] || k;

  const ICON = {
    muted: '<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M17 9l5 6M22 9l-5 6"/></svg>',
    sound: '<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/></svg>',
    big: '<svg viewBox="0 0 24 24"><path d="M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7"/></svg>',
    small: '<svg viewBox="0 0 24 24"><path d="M20 10h-6V4M4 14h6v6M14 10l7-7M10 14l-7 7"/></svg>',
    close: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    reload: '<svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 1 1-2.34-5.66"/><path d="M20 4v5h-5"/></svg>'
  };

  let info = null;            // /api/iss
  let on = Boolean(store.get("dxz.issLive", false));
  let muted = true;           // always starts muted (autoplay rules); the user turns the sound on
  let big = false;
  let playing = "";           // video id in the player
  let radioPause = false;     // Raspberry: the video stops while a radio link is up (CPU for the audio)

  async function loadInfo() {
    try {
      const res = await fetch("/api/iss", { cache: "no-store" });
      const d = await res.json();
      if (d && d.ok) info = d;
    } catch (_) { /* keep the last */ }
    return info;
  }

  // ------------------------------------------------------------------ player (sidebar)
  function panel() {
    let p = $("dxzIssLive");
    if (p) return p;
    p = document.createElement("section");
    p.id = "dxzIssLive";
    p.className = "iss-live-panel";
    p.hidden = true;
    p.innerHTML =
      "<header><span class=\"iss-live-tag\"><i></i><b data-k=\"title\"></b></span>" +
      "<span class=\"iss-live-btns\">" +
      "<button type=\"button\" class=\"iss-btn\" data-act=\"sound\"></button>" +
      "<button type=\"button\" class=\"iss-btn\" data-act=\"reload\"></button>" +
      "<button type=\"button\" class=\"iss-btn\" data-act=\"big\"></button>" +
      "<button type=\"button\" class=\"iss-btn\" data-act=\"close\"></button></span></header>" +
      "<div class=\"iss-video\"><div class=\"iss-wait\" data-k=\"loading\"></div></div>" +
      "<p class=\"iss-foot\"><span data-k=\"source\"></span></p>" +
      "<p class=\"iss-dark\" data-k=\"dark\"></p>";
    // lives in <body> (the sidebar clips its content) and is placed over the sidebar, under the
    // navigation; it is never moved in the page, so the video does not restart
    document.body.appendChild(p);
    enableDrag(p);
    p.addEventListener("click", (e) => {
      const b = e.target.closest("[data-act]");
      if (!b) return;
      e.preventDefault();
      const act = b.dataset.act;
      if (act === "sound") setMuted(!muted);
      else if (act === "big") { big = !big; dragPos = null; render(); }
      else if (act === "reload") { heal = 0; hint(false); stopPlayer(); loadInfo().then(() => startPlayer(true)); }
      else if (act === "close") setOn(false);
    });
    return p;
  }

  function command(func, args) {
    const f = document.querySelector("#dxzIssLive iframe");
    if (!f || !f.contentWindow) return;
    try { f.contentWindow.postMessage(JSON.stringify({ event: "command", func, args: args || [] }), "*"); } catch (_) { /* not ready */ }
  }

  function setMuted(m) {
    muted = m;
    if (muted) command("mute");
    else { command("unMute"); command("setVolume", [100]); command("playVideo"); }
    render();
  }

  // player health: the YouTube player reports its state; a player that does not reach "playing"
  // (paused by the browser's autoplay rules, stuck buffering after a reload) is fixed by itself
  let ytState = null, loadedAt = 0, stateAt = 0, heal = 0;
  window.addEventListener("message", (e) => {
    if (!/youtube(-nocookie)?\.com$/.test((e.origin || "").replace(/^https?:\/\/(www\.)?/, ""))) return;
    let d = e.data;
    try { if (typeof d === "string") d = JSON.parse(d); } catch (_) { return; }
    if (!d || typeof d !== "object") return;
    let st = null;
    if (d.event === "onStateChange" && typeof d.info === "number") st = d.info;
    else if (d.info && typeof d.info === "object" && typeof d.info.playerState === "number") st = d.info.playerState;
    if (st !== null && st !== ytState) { ytState = st; stateAt = Date.now(); if (st === 1) { heal = 0; hint(false); } }
  });

  function hint(show) {
    const el = document.querySelector("#dxzIssLive .iss-foot span");
    if (el) { el.dataset.k = show ? "stuck" : "source"; el.textContent = tx(el.dataset.k); }
    const foot = document.querySelector("#dxzIssLive .iss-foot");
    if (foot) foot.classList.toggle("stuck", Boolean(show));
  }

  function checkHealth() {
    const f = document.querySelector("#dxzIssLive iframe");
    if (!on || !f || radioPause || document.hidden) return;
    const now = Date.now();
    // only act on what the player itself reports (never restart a player we cannot hear from)
    if (now - loadedAt < 12000 || ytState === 1 || ytState === null) return;
    const stuckBuffering = ytState === 3 && now - stateAt > 20000;
    if (ytState === 3 && !stuckBuffering) return;
    heal += 1;
    if (heal <= 2 && !stuckBuffering) {
      // usually the browser refused to start it with sound: start it muted
      muted = true; command("mute"); command("playVideo"); render();
    } else if (heal <= 4) {
      stopPlayer(); startPlayer(false);              // a fresh player at the live edge
    } else {
      hint(true);                                    // ask for one tap on the reload button
    }
  }

  async function startPlayer(userGesture) {
    if (!userGesture) muted = true;                  // automatic (re)starts are always silent
    const p = panel();
    const box = p.querySelector(".iss-video");
    if (box.querySelector("iframe")) return;
    if (!info) await loadInfo();
    if (!on || box.querySelector("iframe")) return;
    const wait = box.querySelector(".iss-wait");
    if (radioPause) { if (wait) { wait.dataset.k = "radio"; wait.textContent = tx("radio"); } return; }
    if (!info || !info.stream.embedUrl) {
      // NASA's stream could not be found right now: say so and try again in a minute
      if (wait) { wait.dataset.k = "nostream"; wait.textContent = tx("nostream"); }
      setTimeout(() => { if (on) loadInfo().then(startPlayer); }, 60000);
      return;
    }
    if (wait) { wait.dataset.k = "loading"; wait.textContent = tx("loading"); }
    playing = info.stream.videoId;
    const f = document.createElement("iframe");
    f.src = info.stream.embedUrl;
    f.title = "NASA ISS live video";
    f.allow = "autoplay; encrypted-media; picture-in-picture; fullscreen";
    f.referrerPolicy = "strict-origin-when-cross-origin";
    f.setAttribute("allowfullscreen", "");
    ytState = null; loadedAt = Date.now(); stateAt = loadedAt;
    f.addEventListener("load", () => {
      // subscribe to the player (repeated until it answers), then apply the sound choice
      let n = 0;
      const hello = setInterval(() => {
        try { f.contentWindow.postMessage(JSON.stringify({ event: "listening", id: "dxzIss" }), "*"); } catch (_) { /* ignore */ }
        if (++n >= 10 || ytState !== null) clearInterval(hello);
      }, 1000);
      setTimeout(() => setMuted(muted), 1500);
    });
    box.appendChild(f);
  }

  function stopPlayer() {
    const f = document.querySelector("#dxzIssLive iframe");
    if (f) f.remove();          // stops the video and the download
    playing = "";
  }

  function setOn(v) {
    on = v;
    store.set("dxz.issLive", on);
    if (on) { muted = true; heal = 0; startPlayer(true); } else { big = false; dragPos = null; stopPlayer(); }
    render();
  }

  let dragPos = null;          // where the operator moved the floating / enlarged player
  function bottomOfMenu() {
    // the lowest visible item of the menu (Restart button on the Pi, status card on the Mac)
    const items = ["dxzRestartButton", "liveStatusCard"].map($).filter((el) => el && !el.hidden && el.offsetParent);
    const nav = document.querySelector(".sidebar nav");
    if (nav) items.push(nav);
    let best = null;
    items.forEach((el) => { const r = el.getBoundingClientRect(); if (r.width && (!best || r.bottom > best.bottom)) best = r; });
    return best;
  }

  function placeFree(p) {
    if (!dragPos) return false;
    const w = p.offsetWidth, h = p.offsetHeight;
    const x = Math.max(4, Math.min(window.innerWidth - w - 4, dragPos.x));
    const y = Math.max(4, Math.min(window.innerHeight - h - 4, dragPos.y));
    p.style.left = x + "px"; p.style.top = y + "px"; p.style.bottom = "auto";
    return true;
  }

  function dock() {
    const p = $("dxzIssLive");
    if (!p || p.hidden) return;
    const clear = () => { p.style.left = p.style.top = p.style.width = p.style.bottom = ""; };
    p.classList.remove("narrow");
    if (big) { p.classList.remove("float"); clear(); placeFree(p); return; }
    // normally the player sits INSIDE the menu column, under its last button: it covers nothing
    const a = bottomOfMenu();
    const side = document.querySelector(".sidebar");
    const sr = side && side.getBoundingClientRect();
    const width = a ? a.width : 0;
    const room = a ? window.innerHeight - 4 - (a.bottom + 8) : 0;
    // full player with caption, or the compact one (no caption) when the menu is narrow or short
    const narrow = width < 175 || room < width * 9 / 16 + 90;
    const height = width * 9 / 16 + (narrow ? 38 : 90);
    const fits = a && sr && sr.width > 0 && width >= 120 && height <= room;
    p.classList.toggle("float", !fits);
    if (!fits) {
      clear();
      if (placeFree(p)) return;
      // next to the menu, not over it (the Restart button lives at the bottom of the menu on the Pi)
      if (sr && sr.width > 0 && sr.right + 310 < window.innerWidth) p.style.left = (sr.right + 10).toFixed(0) + "px";
      return;
    }
    dragPos = null;
    p.classList.toggle("narrow", narrow);
    p.style.left = a.left.toFixed(0) + "px";
    p.style.top = (a.bottom + 8).toFixed(0) + "px";
    p.style.width = width.toFixed(0) + "px";
  }

  // floating or enlarged player: drag it by its title bar (mouse or finger) out of the way
  function enableDrag(p) {
    let start = null;
    p.querySelector("header").addEventListener("pointerdown", (e) => {
      if (!(p.classList.contains("float") || p.classList.contains("big")) || e.target.closest("button")) return;
      const r = p.getBoundingClientRect();
      start = { id: e.pointerId, dx: e.clientX - r.left, dy: e.clientY - r.top };
      p.setPointerCapture(e.pointerId);
      p.classList.add("dragging");
      e.preventDefault();
    });
    p.addEventListener("pointermove", (e) => {
      if (!start || e.pointerId !== start.id) return;
      dragPos = { x: e.clientX - start.dx, y: e.clientY - start.dy };
      placeFree(p);
    });
    const end = (e) => { if (start && e.pointerId === start.id) { start = null; p.classList.remove("dragging"); } };
    p.addEventListener("pointerup", end);
    p.addEventListener("pointercancel", end);
  }

  function render() {
    const p = panel();
    p.hidden = !on;
    p.classList.toggle("big", big);
    document.body.classList.toggle("iss-live-on", on);
    p.querySelectorAll("[data-k]").forEach((el) => { el.textContent = tx(el.dataset.k); });
    const sound = p.querySelector("[data-act=sound]");
    sound.innerHTML = muted ? ICON.muted : ICON.sound;
    sound.title = muted ? tx("sound_off") : tx("sound_on");
    sound.classList.toggle("on", !muted);
    const b = p.querySelector("[data-act=big]");
    b.innerHTML = big ? ICON.small : ICON.big;
    b.title = big ? tx("smaller") : tx("bigger");
    const rl = p.querySelector("[data-act=reload]");
    rl.innerHTML = ICON.reload;
    rl.title = tx("reload");
    const c = p.querySelector("[data-act=close]");
    c.innerHTML = ICON.close;
    c.title = tx("close");
    document.querySelectorAll(".dxz-iss-chip").forEach((chip) => {
      chip.classList.toggle("on", on);
      chip.querySelector("span").textContent = tx("chip");
      chip.title = tx("hover");
    });
    placeHotspot();
    dock();
  }

  // ------------------------------------------------------------------ "ISS Live" button on the map
  function addChip() {
    const bar = document.querySelector(".global-map-page .dxz-layer-toggles");
    if (!bar) return false;
    if (bar.querySelector(".dxz-iss-chip")) return true;
    const b = document.createElement("button");
    b.type = "button";
    b.className = "dxz-layer-chip dxz-iss-chip";
    b.innerHTML = "<i class=\"iss-rec\"></i><span>ISS Live</span>";
    b.addEventListener("click", () => setOn(!on));
    bar.appendChild(b);
    return true;
  }

  // ------------------------------------------------------------------ ISS dot: hover / tap card
  function iss() {
    const g = window.dxzGeo;
    if (!g || !g.layers || !g.layers.satellites) return null;
    return (g.sats || []).find((s) => s.name === "ISS") || null;
  }

  function placeHotspot() {
    const layer = $("dxMarkers");
    if (!layer) return;
    let hot = $("dxzIssHot");
    const s = iss();
    const pt = s && window.dxzMapPoint ? window.dxzMapPoint(s.lon, s.lat) : null;
    if (!pt || pt.x < -20 || pt.x > pt.W + 20 || pt.y < -20 || pt.y > pt.H + 20) { if (hot) hot.hidden = true; return; }
    if (!hot) {
      hot = document.createElement("div");
      hot.id = "dxzIssHot";
      hot.className = "dxz-iss-hot";
      hot.setAttribute("role", "button");
      hot.tabIndex = 0;
      hot.innerHTML = "<span class=\"ring\"></span><span class=\"live\">LIVE</span>";
    }
    if (hot.parentElement !== layer) layer.appendChild(hot);   // the markers layer is redrawn often
    hot.hidden = false;
    hot.classList.toggle("is-live", on);
    hot.dataset.lon = s.lon;
    hot.dataset.lat = s.lat;
    hot.style.left = pt.x.toFixed(1) + "px";
    hot.style.top = pt.y.toFixed(1) + "px";
    hot.setAttribute("aria-label", "ISS · " + tx("freqs"));
    const card = $("dxzIssCard");
    if (card && !card.hidden) fillCard(card);
  }
  window.dxzAfterMarkers = () => placeHotspot();

  function fmtTime(iso) {
    const d = new Date(iso);
    if (isNaN(d)) return "";
    return d.toLocaleTimeString(lang() === "it" ? "it-IT" : "en-GB", { hour: "2-digit", minute: "2-digit", hour12: false });
  }

  function fillCard(card) {
    const s = iss();
    if (!s) { card.hidden = true; return; }
    const r = info && info.radio;
    const pass = (s.passes || [])[0];
    const rows = r ? r.items.map((it) => (
      "<div class=\"iss-row" + (it.yourRegion === false ? " other" : "") + (it.yourRegion ? " mine" : "") + (it.active ? "" : " idle") + "\">" +
      "<span class=\"lbl\">" + esc(it.label) + (it.yourRegion ? " <em>" + esc(tx("your")) + "</em>" : "") + "</span>" +
      "<span class=\"val\"><b>" + esc(it.freq) + "</b><small>" + esc(it.mode) + (it.active ? "" : " · " + esc(tx("off"))) + "</small></span></div>"
    )).join("") : "<div class=\"iss-row\">…</div>";
    card.innerHTML =
      "<h4>ISS <small>" + esc(r ? r.callsigns : "NA1SS · RS0ISS") + "</small></h4>" +
      "<p>" + esc(tx("alt")) + " <strong>" + esc(s.altKm) + " km</strong> · " + esc(tx("pos")) + " " +
      esc(Math.abs(s.lat).toFixed(1) + (s.lat >= 0 ? "N" : "S") + " " + Math.abs(s.lon).toFixed(1) + (s.lon >= 0 ? "E" : "W")) + "</p>" +
      (s.visible ? "<p class=\"vis\">" + esc(tx("now_visible")) + " · El " + esc(s.elevation) + "° Az " + esc(s.azimuth) + "°</p>"
        : (pass ? "<p>" + esc(tx("next")) + " <strong>" + esc(fmtTime(pass.aos)) + "</strong> · " + esc(tx("el")) + " " + esc(pass.maxEl) + "° · " + esc(pass.durationMin) + " " + esc(tx("min")) + "</p>" : "")) +
      "<h5>" + esc(tx("freqs")) + "</h5><div class=\"iss-freqs\">" + rows + "</div>" +
      (r ? "<p class=\"note\">" + esc(r.note) + "</p><p class=\"src\">" + esc(tx("status")) + ": " + esc(r.source) + " · " + esc(r.statusDate) + "</p>" : "");
  }

  let pinned = false;
  function cardEl() {
    let card = $("dxzIssCard");
    if (card) return card;
    const frame = document.querySelector(".global-map-page .map-image-frame");
    if (!frame) return null;
    card = document.createElement("div");
    card.id = "dxzIssCard";
    card.className = "dxz-card dxz-iss-card";
    card.hidden = true;
    frame.appendChild(card);
    return card;
  }

  async function showCard(hot) {
    const card = cardEl();
    if (!card) return;
    fillCard(card);
    card.hidden = false;
    position(card, hot);
    if (!info) { await loadInfo(); if (!card.hidden) { fillCard(card); position(card, hot); } }
  }
  function position(card, hot) {
    const frame = card.parentElement.getBoundingClientRect();
    const r = hot.getBoundingClientRect();
    const x = r.left + r.width / 2 - frame.left, y = r.top + r.height / 2 - frame.top;
    const W = frame.width, H = frame.height, cw = card.offsetWidth, ch = card.offsetHeight;
    card.style.left = Math.max(6, Math.min(W - cw - 6, x + 18 > W - cw - 6 ? x - cw - 18 : x + 18)) + "px";
    card.style.top = Math.max(6, Math.min(H - ch - 6, y - ch / 2)) + "px";
  }
  function hideCard() { const c = $("dxzIssCard"); if (c) c.hidden = true; pinned = false; }

  document.addEventListener("mouseover", (e) => {
    const hot = e.target.closest && e.target.closest("#dxzIssHot");
    if (hot && !pinned) showCard(hot);
  });
  document.addEventListener("mouseout", (e) => {
    const hot = e.target.closest && e.target.closest("#dxzIssHot");
    if (hot && !pinned && !(e.relatedTarget && hot.contains(e.relatedTarget))) { const c = $("dxzIssCard"); if (c) c.hidden = true; }
  });
  document.addEventListener("click", (e) => {
    const hot = e.target.closest && e.target.closest("#dxzIssHot");
    if (hot) { pinned = true; showCard(hot); e.stopPropagation(); return; }
    if (!(e.target.closest && e.target.closest("#dxzIssCard"))) hideCard();
  }, true);
  document.addEventListener("keydown", (e) => {
    if (e.target && e.target.id === "dxzIssHot" && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); pinned = true; showCard(e.target); }
    if (e.key === "Escape") hideCard();
  });

  // ------------------------------------------------------------------ start
  function init() {
    panel();
    let tries = 0;
    const wait = setInterval(() => { if (addChip() || ++tries > 60) { clearInterval(wait); render(); } }, 250);
    loadInfo().then(() => { if (on) startPlayer(); render(); });
    // Raspberry: the browser's video and DX Zaza's voice use the same HDMI sound output. The video is
    // stopped the moment a link is requested (before the speaker opens), not a few seconds later.
    const LINK_RE = /\/api\/voice\/(link|dmr\/link|ysf\/link|echolink\/connect)(\?|$)/;
    const realFetch = window.fetch.bind(window);
    window.fetch = function (input, init) {
      try {
        const url = typeof input === "string" ? input : (input && input.url) || "";
        const method = ((init && init.method) || (input && input.method) || "GET").toUpperCase();
        if (method === "POST" && LINK_RE.test(url) && on && document.body.classList.contains("dxz-pi") && !radioPause) {
          radioPause = true; stopPlayer(); startPlayer();
        }
      } catch (_) { /* never block the request */ }
      return realFetch(input, init);
    };
    // On the Raspberry the video decoder and the voice audio share 4 small cores: while a radio
    // link is up the video is stopped (not just hidden) and starts again, live, after unlinking.
    setInterval(async () => {
      if (!on || !document.body.classList.contains("dxz-pi")) { if (radioPause) { radioPause = false; startPlayer(); } return; }
      let linked = false;
      try {
        const st = await (await fetch("/api/voice/status", { cache: "no-store" })).json();
        linked = Boolean(st.link && ["linked", "linking", "lost"].includes(st.link.state));
      } catch (_) { return; }
      if (linked && !radioPause) { radioPause = true; stopPlayer(); startPlayer(); }
      else if (!linked && radioPause) { radioPause = false; startPlayer(); }
    }, 4000);
    setInterval(checkHealth, 4000);
    let shownLang = lang();
    setInterval(() => {                              // follows the ISS (positions refresh every 30 s)
      if (lang() !== shownLang) { shownLang = lang(); loadInfo().then(render); }
      placeHotspot();
      dock();
    }, 3000);
    window.addEventListener("resize", () => { placeHotspot(); dock(); });
    // NASA restarts the stream now and then with a new address: switch the player to it
    setInterval(() => loadInfo().then(() => {
      if (on && info && info.stream.videoId && playing && info.stream.videoId !== playing) { stopPlayer(); startPlayer(); }
    }), 30 * 60 * 1000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
  window.dxzIssLive = { set: setOn, info: () => info };
})();
