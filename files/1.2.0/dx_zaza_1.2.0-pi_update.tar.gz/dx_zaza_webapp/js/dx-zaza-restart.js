/* DX Zaza — Restart button (Raspberry Pi appliance): reload the screen, restart DX Zaza,
   or reboot the Raspberry Pi. Shown only where the platform allows system controls. */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const TEXT = {
    en: {
      "restart.button": "Restart", "restart.title": "Restart", "restart.screen": "Reload screen",
      "restart.screen_hint": "Quick: redraws the pages", "restart.app": "Restart DX Zaza",
      "restart.app_hint": "About 15 seconds, reconnects the reflector", "restart.reboot": "Restart Raspberry Pi",
      "restart.reboot_hint": "About 1 minute", "restart.cancel": "Cancel",
      "restart.confirm_reboot": "Tap again to restart the Raspberry Pi",
      "restart.app_wait": "DX Zaza is restarting... the screen comes back by itself.",
      "restart.reboot_wait": "The Raspberry Pi is restarting... DX Zaza comes back in about a minute."
    },
    it: {
      "restart.button": "Riavvia", "restart.title": "Riavvia", "restart.screen": "Ricarica schermo",
      "restart.screen_hint": "Veloce: ridisegna le pagine", "restart.app": "Riavvia DX Zaza",
      "restart.app_hint": "Circa 15 secondi, ricollega il riflettore", "restart.reboot": "Riavvia Raspberry Pi",
      "restart.reboot_hint": "Circa 1 minuto", "restart.cancel": "Annulla",
      "restart.confirm_reboot": "Tocca di nuovo per riavviare il Raspberry Pi",
      "restart.app_wait": "DX Zaza si sta riavviando... lo schermo torna da solo.",
      "restart.reboot_wait": "Il Raspberry Pi si sta riavviando... DX Zaza torna tra circa un minuto."
    }
  };
  if (typeof translations === "object") {
    Object.keys(TEXT).forEach((lang) => { if (translations[lang]) Object.assign(translations[lang], TEXT[lang]); });
  }
  const tr = (key) => (typeof t === "function" ? t(key) : TEXT.en[key]) || TEXT.en[key] || key;
  let armedReboot = false;

  function open() {
    armedReboot = false;
    $("dxzRestartMessage").textContent = "";
    $("dxzRestartChoices").hidden = false;
    $("dxzRestartCancel").hidden = false;
    $("dxzRestartPanel").hidden = false;
  }
  function close() { $("dxzRestartPanel").hidden = true; }
  function waiting(text) {
    $("dxzRestartChoices").hidden = true;
    $("dxzRestartCancel").hidden = true;
    $("dxzRestartMessage").textContent = text;
  }
  function reloadWhenBack(delay) {
    setTimeout(function poll() {
      fetch("/api/status", { cache: "no-store" })
        .then((r) => (r.ok ? location.reload() : setTimeout(poll, 1500)))
        .catch(() => setTimeout(poll, 1500));
    }, delay);
  }
  async function post(target) {
    const res = await fetch("/api/system/restart", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ target })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.ok) throw new Error(data.error || ("HTTP " + res.status));
    return data;
  }
  async function choose(kind) {
    if (kind === "screen") { location.reload(); return; }
    if (kind === "reboot" && !armedReboot) {
      armedReboot = true;
      $("dxzRestartMessage").textContent = tr("restart.confirm_reboot");
      return;
    }
    try {
      await post(kind);
      waiting(tr(kind === "app" ? "restart.app_wait" : "restart.reboot_wait"));
      reloadWhenBack(kind === "app" ? 4000 : 30000);
    } catch (err) {
      $("dxzRestartMessage").textContent = err.message;
    }
  }
  function init() {
    const button = $("dxzRestartButton");
    if (!button) return;
    button.addEventListener("click", open);
    $("dxzRestartCancel").addEventListener("click", close);
    $("dxzRestartPanel").addEventListener("click", (e) => { if (e.target.id === "dxzRestartPanel") close(); });
    document.querySelectorAll("[data-restart]").forEach((b) => b.addEventListener("click", () => choose(b.dataset.restart)));
    fetch("/api/status", { cache: "no-store" }).then((r) => r.json()).then((d) => {
      button.hidden = !(d.features && d.features.systemControls);
    }).catch(() => {});
    if (typeof applyTranslations === "function") { try { applyTranslations(); } catch (_) { /* */ } }
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
