/* DX Zaza start-up screen: version, "DX" in Morse (lights in time with the start-up sound,
   which the backend plays on the speaker), progress while the app gets ready. Tap to skip. */
(function () {
  "use strict";
  const splash = document.getElementById("dxzSplash");
  if (!splash) return;
  const $ = (id) => document.getElementById(id);
  const EN = ["Starting", "World map", "DX cluster", "HF propagation", "Digital voice", "Ready"];
  const IT = ["Avvio", "Mappa mondiale", "DX cluster", "Propagazione HF", "Voce digitale", "Pronto"];
  let STEPS = EN;
  function setLanguage(lang) {
    const it = /^it/i.test(lang || "");
    STEPS = it ? IT : EN;
    $("dxzSplashSkip").textContent = it ? "tocca per saltare" : "tap to skip";
  }
  setLanguage(document.documentElement.lang || navigator.language);
  const MIN_MS = 4200, MAX_MS = 7000;
  const started = performance.now();
  let closed = false, ready = false, soundOn = true;

  function post(path, body) {
    return fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) })
      .then((r) => r.json()).catch(() => ({}));
  }

  // version + sound preference
  fetch("/api/ui/startup", { cache: "no-store" }).then((r) => r.json()).then((d) => {
    const v = String(d.version || "").replace(/-(desktop|pi)$/, "");
    const where = d.platform === "pi" ? "Raspberry Pi" : (d.platform === "desktop" || d.platform === "mac" ? "Desktop" : "");
    $("dxzSplashVersion").innerHTML = "VERSION " + v.replace(/[<>&]/g, "") + (where ? " <small>· " + where + "</small>" : "");
    soundOn = d.sound !== false;
    if (d.language) setLanguage(d.language);
    $("dxzSplashSound").classList.toggle("off", !soundOn);
    $("dxzSplashSound").innerHTML = soundOn ? "&#128266;" : "&#128263;";
    if (soundOn) { post("/api/ui/startup-chime"); morse(); } else { morse(); }
  }).catch(() => { $("dxzSplashVersion").textContent = ""; morse(); });

  // "DX" in Morse lighting up with the sound (same timing as services/startup_chime.py)
  function morse() {
    const marks = Array.prototype.slice.call(splash.querySelectorAll(".splash-morse b"));
    const dit = 65, pattern = [3, 1, 1, null, 3, 1, 1, 3];
    let t = 120, mi = 0;
    pattern.forEach((len) => {
      if (len === null) { t += dit * 2; return; }
      const el = marks[mi++];
      setTimeout(() => el && el.classList.add("on"), t);
      t += dit * len + dit;
    });
  }

  // progress
  let step = 0;
  const bar = $("dxzSplashBar"), status = $("dxzSplashStatus");
  function advance() {
    if (closed) return;
    step = Math.min(step + 1, STEPS.length - 1);
    status.textContent = STEPS[step];
    bar.style.width = Math.round(step / (STEPS.length - 1) * 100) + "%";
    if (step < STEPS.length - 1) setTimeout(advance, 620);
  }
  status.textContent = STEPS[0];
  setTimeout(advance, 450);
  window.addEventListener("load", () => { ready = true; });

  function close() {
    if (closed) return;
    closed = true;
    bar.style.width = "100%";
    status.textContent = STEPS[STEPS.length - 1];
    splash.classList.add("leaving");
    setTimeout(() => {
      splash.remove();
      document.body.classList.remove("dxz-splashing");
      window.dispatchEvent(new Event("resize"));          // the map measures itself again
    }, 750);
  }
  (function wait() {
    const elapsed = performance.now() - started;
    if ((ready && elapsed >= MIN_MS) || elapsed >= MAX_MS) close(); else setTimeout(wait, 150);
  })();
  splash.addEventListener("click", (e) => {
    if (e.target.closest("#dxzSplashSound")) {
      soundOn = !soundOn;
      e.currentTarget.querySelector("#dxzSplashSound").classList.toggle("off", !soundOn);
      $("dxzSplashSound").innerHTML = soundOn ? "&#128266;" : "&#128263;";
      post("/api/ui/startup-sound", { enabled: soundOn });
      return;
    }
    close();
  });
})();
