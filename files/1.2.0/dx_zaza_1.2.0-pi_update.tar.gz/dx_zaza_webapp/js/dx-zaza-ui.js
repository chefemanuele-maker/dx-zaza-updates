/* DX Zaza 0.5 — map zoom, multiple band/mode filters, automatic position.
 * Loaded after dx-zaza-map.js. */
(function () {
  "use strict";

  Object.assign(translations.en, {
    "filters.all_bands": "All bands",
    "filters.all_modes": "All modes",
    "filters.n_bands": "bands",
    "filters.n_modes": "modes",
    "filters.clear": "All",
    "zoom.in": "Zoom in",
    "zoom.out": "Zoom out",
    "zoom.world": "World",
    "zoom.custom": "Area",
    "zoom.europe": "Europe",
    "zoom.namerica": "N. America",
    "zoom.samerica": "S. America",
    "zoom.africa": "Africa",
    "zoom.asia": "Asia",
    "zoom.oceania": "Oceania",
    "zoom.qth": "My QTH",
    "style.title": "Map",
    "style.vector": "Tactical",
    "style.satellite": "Satellite",
    "style.relief": "Relief",
    "style.lights": "Night lights",
    "loc.title": "Position",
    "loc.auto": "Automatic",
    "loc.manual": "Manual",
    "loc.detecting": "Finding your position from the Internet connection...",
    "loc.use_auto": "Use automatic position",
    "loc.update": "Update now",
    "loc.note": "Found from your Internet connection (accurate to the town, enough for the 4-character locator). With a VPN, type your locator below instead.",
    "loc.failed": "Position not found",
    "loc.none": "Not set yet",
    "loc.manual_label": "Or type your QTH locator"
  });
  Object.assign(translations.it, {
    "filters.all_bands": "Tutte le bande",
    "filters.all_modes": "Tutti i modi",
    "filters.n_bands": "bande",
    "filters.n_modes": "modi",
    "filters.clear": "Tutti",
    "zoom.in": "Ingrandisci",
    "zoom.out": "Riduci",
    "zoom.world": "Mondo",
    "zoom.custom": "Zona",
    "zoom.europe": "Europa",
    "zoom.namerica": "Nord America",
    "zoom.samerica": "Sud America",
    "zoom.africa": "Africa",
    "zoom.asia": "Asia",
    "zoom.oceania": "Oceania",
    "zoom.qth": "Il mio QTH",
    "style.title": "Mappa",
    "style.vector": "Tattica",
    "style.satellite": "Satellite",
    "style.relief": "Rilievo",
    "style.lights": "Luci notturne",
    "loc.title": "Posizione",
    "loc.auto": "Automatica",
    "loc.manual": "Manuale",
    "loc.detecting": "Cerco la tua posizione dalla connessione Internet...",
    "loc.use_auto": "Usa la posizione automatica",
    "loc.update": "Aggiorna ora",
    "loc.note": "Trovata dalla tua connessione Internet (precisa alla città, basta per il locatore a 4 caratteri). Se usi una VPN, scrivi il locatore qui sotto.",
    "loc.failed": "Posizione non trovata",
    "loc.none": "Non ancora impostata",
    "loc.manual_label": "Oppure scrivi il tuo locatore QTH"
  });

  const $ = (sel, root) => (root || document).querySelector(sel);
  const esc = (v) => escapeHtml(v == null ? "" : v);
  const store = {
    get(key, fallback) { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch (e) { return fallback; } },
    set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* private mode */ } }
  };
  const G = window.dxZazaGeo;
  const MAP = G.MAP;
  const span = MAP.latTop - MAP.latBottom;

  // ================================================================== multiple filters
  dxZazaState.bands = store.get("dxz.bands", []);
  dxZazaState.modes = store.get("dxz.modes", []);
  dxZazaState.band = "all";
  dxZazaState.mode = "all";

  const BAND_ORDER = ["160m", "80m", "60m", "40m", "30m", "20m", "17m", "15m", "12m", "10m", "6m", "4m", "2m", "70cm"];
  function bandChoices() { return BAND_ORDER.slice(); }
  function modeChoices() {
    const known = ["SSB", "CW", "FT8", "FT4", "RTTY", "PSK", "DIG", "AM", "FM"];
    const live = (typeof dxSpotsLive !== "undefined" ? dxSpotsLive : []).map((s) => String(s.mode || "").toUpperCase());
    const all = known.concat(live, dxZazaState.modes).filter((m) => m && m !== "UNKNOWN");
    return Array.from(new Set(all));
  }

  let popover = null;
  function closePopover() { if (popover) { popover.remove(); popover = null; } }

  function summary(kind) {
    const list = kind === "band" ? dxZazaState.bands : dxZazaState.modes;
    if (!list.length) return t(kind === "band" ? "filters.all_bands" : "filters.all_modes");
    if (list.length <= 3) return list.join(" · ");
    return list.length + " " + t(kind === "band" ? "filters.n_bands" : "filters.n_modes");
  }

  function toggle(kind, value) {
    const key = kind === "band" ? "bands" : "modes";
    let list = dxZazaState[key].slice();
    if (value === "*") list = [];
    else if (list.includes(value)) list = list.filter((v) => v !== value);
    else list.push(value);
    if (kind === "band") list.sort((a, b) => BAND_ORDER.indexOf(a) - BAND_ORDER.indexOf(b));
    dxZazaState[key] = list;
    store.set("dxz." + key, list);
    renderAllDxViews();
    if (popover) fillPopover(popover, kind);
  }

  function fillPopover(pop, kind) {
    const list = kind === "band" ? dxZazaState.bands : dxZazaState.modes;
    const choices = kind === "band" ? bandChoices() : modeChoices();
    const colors = window.dxzBandColor || (() => "");
    pop.innerHTML = "<button type=\"button\" class=\"dxz-chip all" + (list.length ? "" : " on") + "\" data-v=\"*\">" + esc(t("filters.clear")) + "</button>" +
      choices.map((c) => "<button type=\"button\" class=\"dxz-chip" + (list.includes(c) ? " on" : "") + "\" data-v=\"" + esc(c) +
        "\"" + (kind === "band" ? " style=\"--c:" + colors(c) + "\"" : "") + ">" + esc(c) + "</button>").join("");
  }

  function openPopover(btn, kind) {
    closePopover();
    popover = document.createElement("div");
    popover.className = "dxz-ms-pop";
    fillPopover(popover, kind);
    document.body.appendChild(popover);
    const r = btn.getBoundingClientRect();
    popover.style.left = Math.min(window.innerWidth - popover.offsetWidth - 10, r.left) + "px";
    popover.style.top = (r.bottom + 6) + "px";
    popover.addEventListener("click", (e) => {
      const chip = e.target.closest(".dxz-chip");
      if (chip) { toggle(kind, chip.dataset.v); e.stopPropagation(); }
    });
    popover.dataset.kind = kind;
  }

  function setupMultiFilters() {
    document.querySelectorAll("select[data-filter='band'], select[data-filter='mode']").forEach((select) => {
      const kind = select.dataset.filter;
      select.hidden = true;
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "dxz-ms";
      btn.dataset.kind = kind;
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        if (popover && popover.dataset.kind === kind && popover._owner === btn) closePopover();
        else { openPopover(btn, kind); popover._owner = btn; }
      });
      select.insertAdjacentElement("afterend", btn);
    });
    document.addEventListener("click", (e) => { if (popover && !e.target.closest(".dxz-ms-pop")) closePopover(); });
    window.addEventListener("resize", closePopover);
  }

  window.syncFilterControls = function () {
    document.querySelectorAll(".dxz-ms").forEach((btn) => {
      btn.textContent = summary(btn.dataset.kind);
      btn.classList.toggle("active", (btn.dataset.kind === "band" ? dxZazaState.bands : dxZazaState.modes).length > 0);
    });
    const search = document.getElementById("callsignSearch");
    if (search && document.activeElement !== search) search.value = dxZazaState.search;
    const badge = document.getElementById("activeFilterBadge");
    if (badge) badge.textContent = summary("band") + " / " + summary("mode");
  };

  // ================================================================== zoom
  const REGIONS = {
    world: [-180, 180, MAP.latTop, MAP.latBottom],
    europe: [-25, 45, 71, 34],
    namerica: [-170, -50, 72, 12],
    samerica: [-95, -30, 14, -57],
    africa: [-25, 55, 38, -36],
    asia: [25, 150, 75, -10],
    oceania: [95, 180, 8, -48]
  };
  const K_MAX = 8;
  const zoom = { k: 1, tx: 0, ty: 0 };
  let zoomBox = null, layerBox = null;

  window.dxzZoom = { view: () => ({ k: zoom.k, tx: zoom.tx, ty: zoom.ty }), region: (r) => zoomTo(r) };

  function size() { return { W: layerBox.clientWidth || 1, H: layerBox.clientHeight || 1 }; }
  function clamp() {
    const { W, H } = size();
    zoom.k = Math.max(1, Math.min(K_MAX, zoom.k));
    zoom.tx = Math.min(0, Math.max(W - W * zoom.k, zoom.tx));
    zoom.ty = Math.min(0, Math.max(H - H * zoom.k, zoom.ty));
  }

  let relabelTimer = null;
  function apply(relabelNow) {
    clamp();
    // Nothing with text or lines is scaled as a picture (WebKit would keep it blurry):
    //  - the SVG layer gets a viewBox for the visible window (drawn natively, sharp),
    //  - markers are placed in screen pixels,
    //  - only soft pictures (aurora, fallback map, old night layer) are transformed.
    const tf = "translate(" + zoom.tx.toFixed(1) + "px," + zoom.ty.toFixed(1) + "px) scale(" + zoom.k.toFixed(4) + ")";
    zoomBox.querySelectorAll("img.world-map-image, canvas.dxz-layer").forEach((el) => {
      el.style.transformOrigin = "0 0";
      el.style.transform = tf;
    });
    const { W: vw, H: vh } = size();
    const svg = document.getElementById("dxzVector");
    if (svg) {
      svg.setAttribute("viewBox", (-zoom.tx * 360 / (vw * zoom.k)).toFixed(4) + " " + (-zoom.ty * span / (vh * zoom.k)).toFixed(4) +
        " " + (360 / zoom.k).toFixed(4) + " " + (span / zoom.k).toFixed(4));
    }
    if (window.dxzPositionMarkers) window.dxzPositionMarkers();
    layerBox.classList.toggle("zoomed", zoom.k > 1.01);
    if (window.dxzBaseMap) {
      const sz = size();
      window.dxzBaseMap.draw({ W: sz.W, H: sz.H, k: zoom.k, tx: zoom.tx, ty: zoom.ty });
    }
    const pct = $(".dxz-zoom-level");
    if (pct) pct.textContent = zoom.k.toFixed(1) + "×";
    clearTimeout(relabelTimer);
    const run = () => {
      store.set("dxz.zoom", zoom);
      if (typeof renderMapMarkers === "function") renderMapMarkers();
      if (G.drawVectorLayer) G.drawVectorLayer();
    };
    if (relabelNow) run(); else relabelTimer = setTimeout(run, 140);
  }

  function zoomAt(factor, cx, cy) {
    const k2 = Math.max(1, Math.min(K_MAX, zoom.k * factor));
    zoom.tx = cx - (cx - zoom.tx) * (k2 / zoom.k);
    zoom.ty = cy - (cy - zoom.ty) * (k2 / zoom.k);
    zoom.k = k2;
    apply();
  }

  function setStyleName() {
    const cur = window.dxzBaseMap ? window.dxzBaseMap.style() : "vector";
    const n = $(".dxz-style-name");
    if (n) n.textContent = t("style." + cur);
    document.querySelectorAll(".dxz-style").forEach((b) => b.classList.toggle("on", b.dataset.style === cur));
  }

  let currentRegion = store.get("dxz.region", "world");
  function setRegionName(region) {
    currentRegion = region || "";
    store.set("dxz.region", currentRegion);
    document.querySelectorAll(".dxz-region").forEach((b) => b.classList.toggle("on", b.dataset.region === currentRegion));
    const n = $(".dxz-region-name");
    // the zoom level is already shown between − and +: here a name, never the same number twice
    if (n) n.textContent = currentRegion ? t("zoom." + currentRegion) : (zoom.k <= 1.01 ? t("zoom.world") : t("zoom.custom"));
  }

  function zoomTo(region) {
    const { W, H } = size();
    let lon1, lon2, lat1, lat2;
    if (region === "qth") {
      const home = G.geo.home;
      if (!home) return;
      lon1 = home.lon - 22; lon2 = home.lon + 22; lat1 = home.lat + 12; lat2 = home.lat - 12;
    } else {
      [lon1, lon2, lat1, lat2] = REGIONS[region] || REGIONS.world;
    }
    const k = Math.max(1, Math.min(K_MAX, Math.min(360 / (lon2 - lon1), span / (lat1 - lat2))));
    const cx = ((lon1 + lon2) / 2 + 180) / 360 * W, cy = (MAP.latTop - (lat1 + lat2) / 2) / span * H;
    setRegionName(region);
    flyTo(k, W / 2 - cx * k, H / 2 - cy * k);
  }

  // smooth flight to a view (log-zoom interpolation), labels placed at the end
  let flight = 0;
  function flyTo(k2, tx2, ty2, ms) {
    const id = ++flight;
    const from = { k: zoom.k, tx: zoom.tx, ty: zoom.ty };
    const t0 = performance.now(), dur = ms || 900;
    const ease = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
    const { W, H } = size();
    // interpolate in "map centre + log zoom" space so the motion looks natural
    const c0 = { x: (W / 2 - from.tx) / from.k, y: (H / 2 - from.ty) / from.k };
    const c1 = { x: (W / 2 - tx2) / k2, y: (H / 2 - ty2) / k2 };
    const step = (now) => {
      if (id !== flight) return;
      const p = Math.min(1, (now - t0) / dur), e = ease(p);
      const k = Math.exp(Math.log(from.k) + (Math.log(k2) - Math.log(from.k)) * e);
      const cx = c0.x + (c1.x - c0.x) * e, cy = c0.y + (c1.y - c0.y) * e;
      zoom.k = k; zoom.tx = W / 2 - cx * k; zoom.ty = H / 2 - cy * k;
      if (p < 1) { apply(); requestAnimationFrame(step); } else apply(true);
    };
    requestAnimationFrame(step);
  }

  function setupZoom() {
    layerBox = $(".global-map-page .map-visual-layer");
    if (!layerBox) return;
    zoomBox = document.createElement("div");
    zoomBox.className = "dxz-zoom-box";
    const movable = Array.from(layerBox.children).filter((el) =>
      el.matches("img.world-map-image, canvas.dxz-layer, svg.dxz-layer, .map-shade, #dxMarkers"));
    layerBox.insertBefore(zoomBox, layerBox.firstChild);
    movable.forEach((el) => zoomBox.appendChild(el));
    if (window.dxzBaseMap) window.dxzBaseMap.init(layerBox);

    const controls = document.createElement("div");
    controls.className = "dxz-zoom-controls";
    const regionKeys = ["world", "europe", "namerica", "samerica", "africa", "asia", "oceania", "qth"];
    controls.innerHTML =
      "<div class=\"dxz-region-pick\"><button type=\"button\" class=\"dxz-region-btn\"><span class=\"globe\"></span>" +
      "<span class=\"dxz-region-name\">" + esc(t("zoom.world")) + "</span></button>" +
      "<div class=\"dxz-regions\" hidden>" + regionKeys.map((r) =>
        "<button type=\"button\" class=\"dxz-region\" data-region=\"" + r + "\">" + esc(t("zoom." + r)) + "</button>").join("") +
      "</div></div>" +
      "<div class=\"dxz-region-pick dxz-style-pick\"><button type=\"button\" class=\"dxz-region-btn dxz-style-btn\"><span class=\"layers\"></span>" +
      "<span class=\"dxz-style-name\"></span></button><div class=\"dxz-regions dxz-styles\" hidden>" +
      ["vector", "satellite", "relief", "lights"].map((st) => "<button type=\"button\" class=\"dxz-region dxz-style\" data-style=\"" + st +
        "\">" + esc(t("style." + st)) + "</button>").join("") + "</div></div>" +
      "<div class=\"dxz-zoom-buttons\"><button type=\"button\" data-z=\"out\" aria-label=\"zoom out\">−</button>" +
      "<span class=\"dxz-zoom-level\">1.0×</span><button type=\"button\" data-z=\"in\" aria-label=\"zoom in\">+</button></div>";
    layerBox.appendChild(controls);
    const list = controls.querySelector(".dxz-regions:not(.dxz-styles)");
    const styleList = controls.querySelector(".dxz-styles");
    controls.addEventListener("click", (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      e.stopPropagation();
      const { W, H } = size();
      if (b.classList.contains("dxz-style-btn")) { styleList.hidden = !styleList.hidden; list.hidden = true; return; }
      if (b.classList.contains("dxz-region-btn")) { list.hidden = !list.hidden; styleList.hidden = true; return; }
      list.hidden = true;
      styleList.hidden = true;
      if (b.dataset.style && window.dxzBaseMap) { window.dxzBaseMap.setStyle(b.dataset.style); setStyleName(); return; }
      if (b.dataset.z === "in") zoomAt(1.6, W / 2, H / 2);
      else if (b.dataset.z === "out") zoomAt(1 / 1.6, W / 2, H / 2);
      else if (b.dataset.region) zoomTo(b.dataset.region);
    });
    document.addEventListener("click", () => { list.hidden = true; styleList.hidden = true; });
    setStyleName();

    // wheel / trackpad pinch
    layerBox.addEventListener("wheel", (e) => {
      if (e.target.closest(".dxz-zoom-controls, .dxz-card, .dxz-legend")) return;
      e.preventDefault();
      const r = layerBox.getBoundingClientRect();
      const factor = Math.exp(-e.deltaY * (e.ctrlKey ? 0.012 : 0.0022));
      zoomAt(factor, e.clientX - r.left, e.clientY - r.top);
      if (currentRegion) setRegionName("");
    }, { passive: false });

    // drag to pan, two fingers to pinch
    const pointers = new Map();
    let last = null, pinch = null, moved = false;
    layerBox.addEventListener("pointerdown", (e) => {
      if (e.target.closest(".dxz-zoom-controls, .dxz-card, .dxz-dx")) return;
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      layerBox.setPointerCapture(e.pointerId);
      moved = false;
      if (pointers.size === 1) last = { x: e.clientX, y: e.clientY };
      if (pointers.size === 2) {
        const [a, b] = Array.from(pointers.values());
        pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), k: zoom.k };
      }
    });
    layerBox.addEventListener("pointermove", (e) => {
      if (!pointers.has(e.pointerId)) return;
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      const r = layerBox.getBoundingClientRect();
      if (pointers.size === 2 && pinch) {
        const [a, b] = Array.from(pointers.values());
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        zoomAt((pinch.k * d / pinch.d) / zoom.k, (a.x + b.x) / 2 - r.left, (a.y + b.y) / 2 - r.top);
        moved = true;
      } else if (last && zoom.k > 1) {
        const dx = e.clientX - last.x, dy = e.clientY - last.y;
        if (Math.abs(dx) + Math.abs(dy) > 2) moved = true;
        zoom.tx += dx; zoom.ty += dy;
        last = { x: e.clientX, y: e.clientY };
        apply();
      }
      if (moved) layerBox.classList.add("dragging");
    });
    const end = (e) => {
      pointers.delete(e.pointerId);
      if (pointers.size < 2) pinch = null;
      if (!pointers.size) { last = null; layerBox.classList.remove("dragging"); }
      else last = Array.from(pointers.values())[0];
    };
    layerBox.addEventListener("pointerup", end);
    layerBox.addEventListener("pointercancel", end);
    layerBox.addEventListener("dblclick", (e) => {
      if (e.target.closest(".dxz-zoom-controls, .dxz-card")) return;
      const r = layerBox.getBoundingClientRect();
      zoomAt(2, e.clientX - r.left, e.clientY - r.top);
      setRegionName("");
    });

    Object.assign(zoom, store.get("dxz.zoom", { k: 1, tx: 0, ty: 0 }));
    requestAnimationFrame(() => { apply(true); setRegionName(currentRegion); });
    window.addEventListener("resize", () => apply());
  }

  // ================================================================== automatic position
  async function refreshHome() {
    try {
      const ctx = await fetchLiveJson("/api/map/context");
      G.geo.home = ctx.home || null;
      G.drawAll();
      if (typeof renderPropagationPage === "function") renderPropagationPage();
      return !!ctx.home;
    } catch (e) { return false; }
  }

  function renderLocation(op) {
    const box = $("#dxzAutoLoc");
    if (!box) return;
    const loc = (op && op.location) || {};
    const mode = loc.mode || "auto";
    let country = loc.country || "";
    if (/^[A-Z]{2}$/.test(country) && window.Intl && Intl.DisplayNames) {
      try { country = new Intl.DisplayNames([dxZazaState.language === "it" ? "it" : "en"], { type: "region" }).of(country) || country; } catch (e) { /* keep code */ }
    }
    const place = [loc.city, country].filter(Boolean).join(", ");
    const square = op && op.locator ? op.locator.slice(0, 4) : "";
    const text = mode === "auto"
      ? (place || square ? (place + (square ? " · " + square : "")) : t("loc.detecting"))
      : (square ? square : t("loc.none"));
    box.innerHTML =
      "<div class=\"dxz-autoloc-head\"><p class=\"eyebrow\">" + esc(t("loc.title")) + "</p>" +
      "<span class=\"dxz-loc-mode " + mode + "\">" + esc(t(mode === "auto" ? "loc.auto" : "loc.manual")) + "</span></div>" +
      "<p class=\"dxz-loc-place\"><span class=\"pin\"></span>" + esc(text) + "</p>" +
      "<button type=\"button\" class=\"secondary-action\" id=\"dxzLocBtn\">" + esc(t(mode === "auto" ? "loc.update" : "loc.use_auto")) + "</button>" +
      "<p class=\"wifi-demo-note\">" + esc(t("loc.note")) + "</p><p class=\"wifi-demo-message\" id=\"dxzLocMsg\" role=\"status\"></p>";
    $("#dxzLocBtn").addEventListener("click", detectNow);
    const lbl = $("#operatorLocator") && $("#operatorLocator").closest("label");
    if (lbl && lbl.firstElementChild) lbl.firstElementChild.textContent = t("loc.manual_label");
  }

  async function loadLocation() {
    try {
      const s = await fetchLiveJson("/api/settings");
      renderLocation(s.operator);
      return s.operator;
    } catch (e) { return null; }
  }

  async function detectNow() {
    const msg = $("#dxzLocMsg");
    if (msg) msg.textContent = t("loc.detecting");
    try {
      const res = await postLiveJson("/api/settings/location", { mode: "auto" });
      renderLocation(res.operator);
      await refreshHome();
    } catch (err) {
      const m = $("#dxzLocMsg");
      if (m) m.textContent = t("loc.failed") + ": " + err.message;
    }
  }

  function setupLocation() {
    const card = $("#page-wifi .operator-setup-card");
    if (!card) return;
    const box = document.createElement("div");
    box.id = "dxzAutoLoc";
    box.className = "dxz-autoloc";
    const locForm = card.querySelector(".dxz-locator-form");
    if (locForm) card.insertBefore(box, locForm); else card.appendChild(box);
    if (locForm) {
      locForm.addEventListener("submit", () => setTimeout(() => { loadLocation(); refreshHome(); }, 600));
    }
    loadLocation();
    // the backend looks the position up at start-up: pick it up as soon as it is there
    let tries = 0;
    const poll = async () => {
      tries += 1;
      const has = await refreshHome();
      if (has) { loadLocation(); return; }
      if (tries < 12) setTimeout(poll, 5000);
    };
    setTimeout(poll, 3000);
  }

  // ================================================================== start
  setupMultiFilters();
  setupZoom();
  setupLocation();
  const previousApply = window.applyTranslations;
  window.applyTranslations = function () {
    previousApply.apply(this, arguments);
    document.querySelectorAll(".dxz-region").forEach((b) => { b.textContent = t("zoom." + b.dataset.region); });
    if (typeof setRegionName === "function") setRegionName(currentRegion);
    document.querySelectorAll(".dxz-style").forEach((b) => { b.textContent = t("style." + b.dataset.style); });
    setStyleName();
    loadLocation();
  };
  renderAllDxViews();
})();
