/* DX Zaza 0.5 — built-in digital voice (DVstick + D-STAR reflectors) and
 * desktop/Pi feature switches. Loaded after dx-zaza-geo.js. */
(function () {
  "use strict";

  Object.assign(translations.en, {
    "nav.settings": "Settings",
    "settings.desk_eyebrow": "SETTINGS",
    "settings.desk_title": "Operator and app",
    "settings.desk_subtitle": "Your callsign, QTH locator and language. The network is managed by your computer.",
    "operator.readonly_note": "Used for DX cluster access and as your callsign in digital voice. DX Zaza transmits only when you enable it in Digital Voice and press PTT.",
    "voice.eyebrow": "DIGITAL VOICE · D-STAR",
    "voice.title": "DVstick Digital Voice",
    "voice.on_air": "ON AIR",
    "voice.idle": "Link a reflector to listen.",
    "voice.listening": "Listening — nobody is talking right now.",
    "voice.talking_you": "YOU ARE TRANSMITTING",
    "voice.mic": "MIC",
    "voice.speaker": "SPK",
    "voice.audio_route": "Speaker: {spk}",
    "voice.ptt": "PTT",
    "voice.ptt_hint": "Hold to talk · Space bar",
    "voice.ptt_locked": "Transmit locked — see Audio and transmit",
    "voice.ptt_link_first": "Link a reflector to talk",
    "voice.reflector": "REFLECTOR",
    "voice.refresh_list": "Refresh list",
    "voice.search": "Reflector",
    "voice.module": "Module",
    "voice.host": "Address (not in the list)",
    "voice.link": "Link",
    "voice.unlink": "Unlink",
    "voice.fav_add": "★ Favourite",
    "voice.fav_remove": "Remove favourite",
    "voice.last_heard": "LAST HEARD",
    "voice.col_time": "UTC",
    "voice.col_call": "Callsign",
    "voice.col_country": "Country",
    "voice.col_msg": "Message",
    "voice.col_ref": "Reflector",
    "voice.col_len": "Sec",
    "voice.nobody": "Nobody heard yet.",
    "voice.dvstick": "DVSTICK",
    "voice.connect": "Connect",
    "voice.disconnect": "Disconnect",
    "voice.selftest": "Vocoder test",
    "voice.looptest": "Microphone test",
    "voice.settings": "AUDIO AND TRANSMIT",
    "voice.input": "Microphone",
    "voice.output": "Speaker",
    "voice.default_device": "System default",
    "voice.volume": "Volume",
    "voice.mic_gain": "Mic gain",
    "voice.suffix": "Suffix (4 characters)",
    "voice.text": "Text message (20 characters)",
    "voice.licence": "I hold an amateur radio licence: enable transmit with my callsign",
    "voice.save": "Save",
    "voice.saved": "Saved.",
    "voice.credit": "D-STAR voice through your DVstick (AMBE-3000 vocoder). REF (DPlus), XLX/XRF (DExtra) and DCS reflectors; lists from the XLX registry and the public host lists. REF reflectors need a callsign registered on the D-STAR network.",
    "voice.state_ready": "DVstick ready",
    "voice.state_linked": "Linked",
    "voice.state_linking": "Linking...",
    "voice.state_lost": "Link lost",
    "voice.state_absent": "DVstick not connected",
    "voice.state_closed": "DVstick idle",
    "voice.port": "Port",
    "voice.chip": "Chip",
    "voice.firmware": "Firmware",
    "voice.mode": "Mode",
    "voice.frames": "Frames enc/dec",
    "voice.found": "Found",
    "voice.not_found": "Not found — plug the DVstick into a USB port",
    "voice.selftest_ok": "Vocoder OK: the DVstick encoded and decoded a test voice correctly",
    "voice.selftest_bad": "Vocoder test failed",
    "voice.loop_recording": "Speak now: recording",
    "voice.loop_playing": "Playing back through the DVstick...",
    "voice.loop_done": "Microphone test finished. You heard your voice as the other stations will hear it.",
    "voice.working": "Please wait...",
    "voice.callsign_needed": "Save your callsign in Settings > Operator Setup first.",
    "voice.reflectors_count": "reflectors in the list",
    "voice.since": "since",
    "voice.seconds": "s"
  });
  Object.assign(translations.it, {
    "nav.settings": "Impostazioni",
    "settings.desk_eyebrow": "IMPOSTAZIONI",
    "settings.desk_title": "Operatore e app",
    "settings.desk_subtitle": "Nominativo, locatore QTH e lingua. La rete è gestita dal tuo computer.",
    "operator.readonly_note": "Usato per il DX cluster e come tuo nominativo nella voce digitale. DX Zaza trasmette solo se lo abiliti in Voce digitale e premi il PTT.",
    "voice.eyebrow": "VOCE DIGITALE · D-STAR",
    "voice.title": "Voce digitale DVstick",
    "voice.on_air": "IN ARIA",
    "voice.idle": "Collegati a un riflettore per ascoltare.",
    "voice.listening": "In ascolto — al momento nessuno parla.",
    "voice.talking_you": "STAI TRASMETTENDO",
    "voice.mic": "MIC",
    "voice.speaker": "ALT",
    "voice.audio_route": "Altoparlante: {spk}",
    "voice.ptt": "PTT",
    "voice.ptt_hint": "Tieni premuto per parlare · Barra spaziatrice",
    "voice.ptt_locked": "Trasmissione bloccata — vedi Audio e trasmissione",
    "voice.ptt_link_first": "Collegati a un riflettore per parlare",
    "voice.reflector": "RIFLETTORE",
    "voice.refresh_list": "Aggiorna elenco",
    "voice.search": "Riflettore",
    "voice.module": "Modulo",
    "voice.host": "Indirizzo (se non è in elenco)",
    "voice.link": "Collega",
    "voice.unlink": "Scollega",
    "voice.fav_add": "★ Preferito",
    "voice.fav_remove": "Togli dai preferiti",
    "voice.last_heard": "ULTIMI ASCOLTATI",
    "voice.col_time": "UTC",
    "voice.col_call": "Nominativo",
    "voice.col_country": "Paese",
    "voice.col_msg": "Messaggio",
    "voice.col_ref": "Riflettore",
    "voice.col_len": "Sec",
    "voice.nobody": "Ancora nessuno ascoltato.",
    "voice.dvstick": "DVSTICK",
    "voice.connect": "Connetti",
    "voice.disconnect": "Disconnetti",
    "voice.selftest": "Prova vocoder",
    "voice.looptest": "Prova microfono",
    "voice.settings": "AUDIO E TRASMISSIONE",
    "voice.input": "Microfono",
    "voice.output": "Altoparlante",
    "voice.default_device": "Predefinito di sistema",
    "voice.volume": "Volume",
    "voice.mic_gain": "Guadagno microfono",
    "voice.suffix": "Suffisso (4 caratteri)",
    "voice.text": "Messaggio di testo (20 caratteri)",
    "voice.licence": "Ho la licenza di radioamatore: abilita la trasmissione con il mio nominativo",
    "voice.save": "Salva",
    "voice.saved": "Salvato.",
    "voice.credit": "Voce D-STAR tramite la tua DVstick (vocoder AMBE-3000). Riflettori REF (DPlus), XLX/XRF (DExtra) e DCS; elenchi dal registro XLX e dagli elenchi pubblici. I REF richiedono un nominativo registrato sulla rete D-STAR.",
    "voice.state_ready": "DVstick pronta",
    "voice.state_linked": "Collegato",
    "voice.state_linking": "Collegamento...",
    "voice.state_lost": "Collegamento perso",
    "voice.state_absent": "DVstick non collegata",
    "voice.state_closed": "DVstick a riposo",
    "voice.port": "Porta",
    "voice.chip": "Chip",
    "voice.firmware": "Firmware",
    "voice.mode": "Modo",
    "voice.frames": "Frame cod/dec",
    "voice.found": "Trovata",
    "voice.not_found": "Non trovata — collega la DVstick a una porta USB",
    "voice.selftest_ok": "Vocoder OK: la DVstick ha codificato e decodificato correttamente una voce di prova",
    "voice.selftest_bad": "Prova vocoder non riuscita",
    "voice.loop_recording": "Parla ora: registrazione",
    "voice.loop_playing": "Riascolto attraverso la DVstick...",
    "voice.loop_done": "Prova microfono finita. Hai sentito la tua voce come la sentiranno gli altri.",
    "voice.working": "Attendere...",
    "voice.callsign_needed": "Prima salva il tuo nominativo in Impostazioni > Configurazione operatore.",
    "voice.reflectors_count": "riflettori in elenco",
    "voice.since": "dal",
    "voice.seconds": "s"
  });

  const $ = (id) => document.getElementById(id);
  const voice = {
    status: null,
    settings: null,
    reflectors: [],
    byName: {},
    ports: [],
    pttDown: false,
    busy: false,
    features: null,
    timer: null
  };

  function esc(value) { return escapeHtml(value == null ? "" : value); }

  // ------------------------------------------------------------ features
  // the on-screen keyboard is for the Pi touchscreen only
  const originalOpenKeyboard = window.openTouchKeyboard;
  window.openTouchKeyboard = function (input) {
    const wanted = voice.features ? voice.features.touchKeyboard : navigator.maxTouchPoints > 0;
    if (!wanted) return;
    originalOpenKeyboard.apply(this, arguments);
  };

  async function loadFeatures() {
    try {
      const data = await fetchLiveJson("/api/status");
      voice.features = data.features || null;
    } catch (_) {
      voice.features = null;
    }
    applyFeatures();
  }

  function applyFeatures() {
    const f = voice.features;
    if (!f) return;
    document.body.classList.toggle("dxz-desktop", f.platform === "desktop");
    document.body.classList.toggle("dxz-pi", f.platform === "pi");
    const bluedvNav = document.querySelector(".nav-button[data-page='bluedv']");
    // one Digital Voice page: BlueDV gets its own entry only when it is really installed
    if (bluedvNav) bluedvNav.hidden = !(f.bluedvRadio && window.dxzBlueDvInstalled === true);
    const wifiNav = document.querySelector(".nav-button[data-page='wifi']");
    if (wifiNav) {
      wifiNav.dataset.i18n = f.wifiSetup ? "nav.wifiSetup" : "nav.settings";
      wifiNav.textContent = t(wifiNav.dataset.i18n);
    }
    const desk = !f.wifiSetup;
    [["#page-wifi .section-heading .eyebrow", "wifi.eyebrow", "settings.desk_eyebrow"],
     ["#page-wifi .section-heading h2", "wifi.title", "settings.desk_title"],
     ["#page-wifi .wifi-intro", "wifi.subtitle", "settings.desk_subtitle"]].forEach(([sel, pi, dk]) => {
      const el = document.querySelector(sel);
      if (el) { el.dataset.i18n = desk ? dk : pi; el.textContent = t(el.dataset.i18n); }
    });
    const piPill = document.querySelector("#page-wifi .section-heading .source-pill");
    if (piPill) piPill.hidden = desk;
    document.querySelectorAll("#page-wifi .wifi-layout > .wifi-card:not(.operator-setup-card):not(.system-settings-card):not(.qrz-card)")
      .forEach((card) => { card.hidden = !f.wifiSetup; });
    document.body.classList.toggle("dxz-lite", f.platform === "pi");
    if (!f.touchKeyboard) {
      if (typeof closeTouchKeyboard === "function") closeTouchKeyboard();
      document.querySelectorAll("[data-touch-keyboard]").forEach((el) => el.removeAttribute("data-touch-keyboard"));
    }
  }

  // ------------------------------------------------------------ helpers
  async function call(path, payload) {
    voice.busy = true;
    try {
      return await postLiveJson(path, payload || {});
    } finally {
      voice.busy = false;
    }
  }

  function say(text, kind) {
    const el = $("voiceMessage");
    if (!el) return;
    el.textContent = text || "";
    el.dataset.kind = kind || "";
  }

  function flag(country) {
    return country ? esc(country) : "";
  }

  function hhmm(iso) {
    if (!iso) return "";
    const d = new Date(iso);
    return isNaN(d) ? "" : d.toISOString().slice(11, 19);
  }

  // ------------------------------------------------------------ status
  async function refreshStatus() {
    try {
      const data = await fetchLiveJson("/api/voice/status");
      voice.status = data;
      if (!voice.settings) voice.settings = data.settings;
      render();
    } catch (_) { /* backend restarting */ }
  }

  async function refreshPorts() {
    try {
      const data = await fetchLiveJson("/api/voice/ports");
      voice.ports = data.ports || [];
    } catch (_) {
      voice.ports = [];
    }
    renderDevice();
  }

  function stateLabel() {
    const s = voice.status;
    if (!s) return { text: t("status.checking"), cls: "" };
    const link = s.link || {};
    if (link.state === "linked") return { text: t("voice.state_linked") + " " + link.reflector + " " + link.module, cls: "live-source" };
    if (link.state === "linking") return { text: t("voice.state_linking"), cls: "status-partial" };
    if (link.state === "lost") return { text: t("voice.state_lost"), cls: "fallback-source" };
    if (s.device && s.device.open) return { text: t("voice.state_ready"), cls: "live-source" };
    if (!voice.ports.length) return { text: t("voice.state_absent"), cls: "fallback-source" };
    return { text: t("voice.state_closed"), cls: "status-partial" };
  }

  function render() {
    if (!$("page-voice")) return;
    const s = voice.status;
    const pill = $("voiceStatePill");
    const st = stateLabel();
    pill.textContent = st.text;
    pill.className = "source-pill " + st.cls;
    renderOnAir();
    renderHeard();
    renderDevice();
    renderPtt();
    if (s && s.link && s.link.error && s.link.state !== "linked") say(s.link.error, "error");
  }

  function renderOnAir() {
    const s = voice.status || {};
    const link = s.link || {};
    const badge = $("voiceLinkBadge");
    const proto = { dextra: "DExtra", dplus: "DPlus", dcs: "DCS", dmr: "DMR", ysf: "C4FM", echolink: "EchoLink" }[link.protocol] || "";
    badge.textContent = link.state === "linked" ? link.reflector + " " + link.module + (proto ? " · " + proto : "") : "—";
    badge.classList.toggle("on", link.state === "linked");
    const body = $("voiceOnAir");
    const card = body.closest(".voice-onair");
    card.classList.toggle("rx", !!s.rx);
    card.classList.toggle("tx", !!(s.tx && s.tx.active));
    if (s.tx && s.tx.active) {
            body.innerHTML = '<p class="voice-big tx">' + esc(t("voice.talking_you")) + "</p>" +
        '<p class="voice-sub">' + esc(s.tx.seconds) + " " + esc(t("voice.seconds")) + "</p>";
    } else if (s.rx) {
      const rx = s.rx;
      body.innerHTML =
        '<p class="voice-big">' + esc(rx.my) + (rx.suffix ? ' <small>/ ' + esc(rx.suffix) + "</small>" : "") + "</p>" +
        '<p class="voice-sub">' + flag(rx.country) + (rx.message ? " · “" + esc(rx.message) + "”" : "") +
        " · " + esc(rx.seconds) + " " + esc(t("voice.seconds")) + "</p>" +
        '<p class="voice-path">' + esc([rx.ur, rx.rpt1, rx.rpt2].filter(Boolean).join("  ›  ")) + "</p>" +
        (rx.note ? '<p class="voice-note">' + esc(rx.note) + "</p>" : "");
    } else if (link.state === "linked") {
      body.innerHTML = '<p class="voice-idle">' + esc(t("voice.listening")) + "</p>";
    } else {
      body.innerHTML = '<p class="voice-idle">' + esc(t("voice.idle")) + "</p>";
    }
    const levels = s.levels || {};
    const route = $("voiceAudioRoute");
    if (route) {
      const a = s.audio || {};
      route.textContent = a.speaker ? t("voice.audio_route").replace("{spk}", a.speaker) + (a.microphone ? " · MIC: " + a.microphone : "") : (a.error || "");
    }
    const pct = (db) => Math.max(0, Math.min(100, ((Number(db) || -90) + 60) / 60 * 100)) + "%";
    $("voiceMeterIn").style.width = pct((s.tx && s.tx.active) ? s.tx.level : levels.input);
    $("voiceMeterOut").style.width = pct(levels.output);
  }

  function renderHeard() {
    const s = voice.status || {};
    const rows = (s.lastHeard || []).slice(0, 25);
    const tbody = $("voiceHeardBody");
    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="6" class="voice-empty">' + esc(t("voice.nobody")) + "</td></tr>";
      return;
    }
    tbody.innerHTML = rows.map((h) =>
      '<tr class="' + (h.direction === "tx" ? "tx" : "") + '">' +
      "<td>" + esc(hhmm(h.time)) + "</td>" +
      "<td><strong>" + esc(h.my || h.callsign) + "</strong>" + (h.suffix ? " <small>" + esc(h.suffix) + "</small>" : "") + "</td>" +
      "<td>" + flag(h.country) + "</td>" +
      "<td>" + esc(h.message) + "</td>" +
      "<td>" + esc(h.reflector) + (h.mode && h.mode !== "dstar" ? ' <small class="voice-mode-tag">' + esc({ dmr: "DMR", ysf: "C4FM", echolink: "EL" }[h.mode] || h.mode) + "</small>" : "") + "</td>" +
      "<td>" + esc(h.seconds) + "</td></tr>").join("");
  }

  function renderDevice() {
    const grid = $("voiceDeviceGrid");
    if (!grid) return;
    const d = (voice.status && voice.status.device) || {};
    const port = voice.ports[0];
    const cells = [
      [t("voice.dvstick"), d.open ? t("voice.state_ready") : (port ? t("voice.found") : t("voice.not_found")), d.open || port ? "ok" : "warn"],
      [t("voice.port"), d.port || (port ? port.device : "—"), ""],
      [t("voice.chip"), d.product || (port ? port.label : "—"), ""],
      [t("voice.firmware"), d.version ? d.version.split(".").slice(0, 2).join(".") : "—", ""],
      [t("voice.mode"), d.mode ? d.mode.toUpperCase().replace("DSTAR", "D-STAR") : "—", ""],
      [t("voice.frames"), (d.open && d.stats) ? ((d.stats.encoded || 0) + " / " + (d.stats.decoded || 0)) : "—", ""]
    ];
    grid.innerHTML = cells.map((c) => '<div class="' + c[2] + '"><span>' + esc(c[0]) + "</span><strong>" + esc(c[1]) + "</strong></div>").join("");
    $("voiceOpen").disabled = !!d.open;
    $("voiceClose").disabled = !d.open;
  }

  function txAllowed() {
    const s = voice.status || {};
    const set = voice.settings || {};
    return set.txEnabled && set.callsignConfigured && s.link && s.link.state === "linked";
  }

  function renderPtt() {
    const btn = $("voicePtt");
    const s = voice.status || {};
    const set = voice.settings || {};
    const linked = s.link && s.link.state === "linked";
    btn.disabled = !txAllowed();
    btn.classList.toggle("active", !!(s.tx && s.tx.active));
    btn.classList.toggle("busy", !!s.rx);
    $("voicePttHint").textContent = !linked ? t("voice.ptt_link_first")
      : (!set.txEnabled || !set.callsignConfigured) ? t("voice.ptt_locked") : t("voice.ptt_hint");
  }

  // ------------------------------------------------------------ PTT
  async function ptt(on) {
    if (on === voice.pttDown) return;
    if (on && !txAllowed()) return;
    voice.pttDown = on;
    try {
      const res = await postLiveJson("/api/voice/ptt", { on });
      if (voice.status) voice.status.tx = res.tx;
      if (on) say("");
    } catch (err) {
      voice.pttDown = false;
      say(err.message, "error");
    }
    refreshStatus();
  }

  function setupPtt() {
    const btn = $("voicePtt");
    btn.addEventListener("pointerdown", (e) => { e.preventDefault(); btn.setPointerCapture(e.pointerId); ptt(true); });
    ["pointerup", "pointercancel", "lostpointercapture"].forEach((ev) => btn.addEventListener(ev, () => ptt(false)));
    btn.addEventListener("contextmenu", (e) => e.preventDefault());
    const typing = (el) => el && (el.tagName === "INPUT" || el.tagName === "SELECT" || el.tagName === "TEXTAREA");
    document.addEventListener("keydown", (e) => {
      if (e.code !== "Space" || e.repeat || activePage !== "voice" || typing(document.activeElement)) return;
      e.preventDefault();
      ptt(true);
    });
    document.addEventListener("keyup", (e) => {
      if (e.code !== "Space" || activePage !== "voice") return;
      if (voice.pttDown) { e.preventDefault(); ptt(false); }
    });
    window.addEventListener("blur", () => { if (voice.pttDown) ptt(false); });
  }

  // ------------------------------------------------------------ reflectors
  async function loadReflectors(force) {
    try {
      const data = await fetchLiveJson("/api/voice/reflectors" + (force ? "?refresh=1" : ""));
      voice.reflectors = data.reflectors || [];
      voice.byName = {};
      voice.reflectors.forEach((r) => { voice.byName[r.name] = r; });
      $("voiceReflectorList").innerHTML = voice.reflectors.map((r) =>
        '<option value="' + esc(r.name) + '">' + esc([r.country, r.comment, r.host].filter(Boolean).join(" · ")) + "</option>").join("");
      $("voiceRefInfo").textContent = voice.reflectors.length + " " + t("voice.reflectors_count") +
        (data.warning ? " — " + data.warning : "");
    } catch (err) {
      $("voiceRefInfo").textContent = err.message;
    }
    syncHostRow();
  }

  function syncHostRow() {
    const name = $("voiceReflector").value.trim().toUpperCase();
    $("voiceHostRow").hidden = !name || !!voice.byName[name];
  }

  function currentTarget() {
    const name = $("voiceReflector").value.trim().toUpperCase();
    const known = voice.byName[name];
    const host = known ? known.host : ($("voiceHost").value.trim() || name);
    return { name: name, host: host, module: $("voiceModule").value, port: known ? known.port : 0,
      protocol: known ? (known.protocol || "") : "" };
  }

  async function link(target) {
    if (!(voice.settings && voice.settings.callsignConfigured)) { say(t("voice.callsign_needed"), "error"); return; }
    if (!target.host) return;
    say(t("voice.working"));
    try {
      await call("/api/voice/link", target);
      say("");
    } catch (err) {
      say(err.message, "error");
    }
    refreshStatus();
    loadSettings();
  }

  function renderFavs() {
    const box = $("voiceFavs");
    const favs = (voice.settings && voice.settings.favorites) || [];
    box.innerHTML = favs.map((f, i) =>
      '<span class="voice-fav"><button type="button" data-i="' + i + '" class="voice-fav-go">' + esc(f.name || f.host) + " " + esc(f.module) +
      '</button><button type="button" data-del="' + i + '" class="voice-fav-del" title="' + esc(t("voice.fav_remove")) + '">×</button></span>').join("");
  }

  async function saveFavs(favs) {
    try {
      const res = await postLiveJson("/api/voice/settings", { favorites: favs });
      voice.settings = res.settings;
      renderFavs();
    } catch (err) {
      say(err.message, "error");
    }
  }

  function setupReflector() {
    const mod = $("voiceModule");
    mod.innerHTML = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").map((m) => '<option value="' + m + '">' + m + "</option>").join("");
    $("voiceReflector").addEventListener("input", syncHostRow);
    $("voiceLinkForm").addEventListener("submit", (e) => { e.preventDefault(); link(currentTarget()); });
    $("voiceUnlink").addEventListener("click", async () => { await call("/api/voice/unlink"); say(""); refreshStatus(); });
    $("voiceRefresh").addEventListener("click", () => loadReflectors(true));
    $("voiceFavAdd").addEventListener("click", () => {
      const target = currentTarget();
      if (!target.host) return;
      const favs = ((voice.settings && voice.settings.favorites) || []).filter((f) => !(f.host === target.host && f.module === target.module));
      favs.push(target);
      saveFavs(favs);
    });
    $("voiceFavs").addEventListener("click", (e) => {
      const favs = ((voice.settings && voice.settings.favorites) || []).slice();
      const go = e.target.closest(".voice-fav-go");
      const del = e.target.closest(".voice-fav-del");
      if (go) {
        const f = favs[Number(go.dataset.i)];
        $("voiceReflector").value = f.name || f.host;
        $("voiceModule").value = f.module;
        syncHostRow();
        link(f);
      } else if (del) {
        favs.splice(Number(del.dataset.del), 1);
        saveFavs(favs);
      }
    });
  }

  // ------------------------------------------------------------ device & tests
  function setupDevice() {
    $("voiceOpen").addEventListener("click", async () => {
      say(t("voice.working"));
      try { await call("/api/voice/device/open"); say(""); } catch (err) { say(err.message, "error"); }
      refreshPorts(); refreshStatus();
    });
    $("voiceClose").addEventListener("click", async () => {
      await call("/api/voice/device/close"); refreshPorts(); refreshStatus();
    });
    $("voiceSelfTest").addEventListener("click", async () => {
      const out = $("voiceTestResult");
      out.textContent = t("voice.working");
      try {
        const res = await call("/api/voice/selftest");
        const r = res.result;
        out.textContent = (r.ok ? t("voice.selftest_ok") : t("voice.selftest_bad")) +
          " (" + r.product + ", " + r.encode_ms_per_frame + " / " + r.decode_ms_per_frame + " ms)";
        out.dataset.kind = r.ok ? "ok" : "error";
      } catch (err) {
        out.textContent = err.message; out.dataset.kind = "error";
      }
      refreshStatus();
    });
    $("voiceLoopTest").addEventListener("click", async () => {
      const out = $("voiceTestResult");
      try {
        await call("/api/voice/looptest", { seconds: 4 });
      } catch (err) {
        out.textContent = err.message; out.dataset.kind = "error"; return;
      }
      const poll = setInterval(async () => {
        await refreshStatus();
        const test = (voice.status && voice.status.test) || {};
        if (test.state === "recording") out.textContent = t("voice.loop_recording") + " " + (test.seconds || "") + " s…";
        else if (test.state === "playing") out.textContent = t("voice.loop_playing");
        else if (test.state === "done") { out.textContent = t("voice.loop_done"); clearInterval(poll); }
        else if (test.state === "error") { out.textContent = test.error || "error"; clearInterval(poll); }
        out.dataset.kind = "";
      }, 400);
      setTimeout(() => clearInterval(poll), 30000);
    });
  }

  // ------------------------------------------------------------ settings
  async function loadSettings() {
    try {
      const data = await fetchLiveJson("/api/voice/status");
      if (!data || !data.settings) return;
      voice.settings = data.settings;
    } catch (_) { return; }
    const s = voice.settings;
    showVolume(s.volume);
    $("voiceMicGain").value = s.micGain;
    $("voiceSuffix").value = s.suffix || "";
    $("voiceText").value = s.message || "";
    $("voiceTxEnabled").checked = !!s.txEnabled;
    if (s.last && s.last.host && !$("voiceReflector").value) {
      $("voiceReflector").value = s.last.name || s.last.host;
      $("voiceModule").value = s.last.module || "A";
      if (!s.last.name) $("voiceHost").value = s.last.host;
    }
    renderFavs();
    syncHostRow();
    loadAudioDevices();
    renderPtt();
  }

  async function loadAudioDevices() {
    try {
      const data = await fetchLiveJson("/api/voice/audio-devices");
      const fill = (el, list, current) => {
        el.innerHTML = '<option value="">' + esc(t("voice.default_device")) + "</option>" +
          (list || []).map((d) => '<option value="' + esc(d.name) + '">' + esc(d.name) + (d.default ? " ✓" : "") + "</option>").join("");
        el.value = current || "";
        if (el.value !== (current || "")) el.value = "";
      };
      fill($("voiceInput"), data.inputs, voice.settings.inputDevice);
      fill($("voiceOutput"), data.outputs, voice.settings.outputDevice);
    } catch (_) { /* no audio library */ }
  }

  // ------------------------------------------------------------ live volume (applies at once)
  let volumeTimer = null;
  function showVolume(value, from) {
    const v = Math.max(0, Math.min(3, Number(value) || 0));
    if (from !== "live") $("voiceVolumeLive").value = v;
    if (from !== "form") $("voiceVolume").value = v;
    $("voiceVolumeValue").textContent = Math.round(v * 100) + "%";
    return v;
  }
  function sendVolume(v) {
    clearTimeout(volumeTimer);
    volumeTimer = setTimeout(async () => {
      try {
        const res = await postLiveJson("/api/voice/settings", { volume: v });
        voice.settings = res.settings;
      } catch (_) { /* shown on next status */ }
    }, 150);
  }
  function setupVolume() {
    const live = $("voiceVolumeLive");
    if (!live) return;
    live.addEventListener("input", () => sendVolume(showVolume(live.value, "live")));
    $("voiceVolume").addEventListener("input", () => sendVolume(showVolume($("voiceVolume").value, "form")));
    const step = (d) => sendVolume(showVolume(Math.round((Number(live.value) + d) * 20) / 20));
    $("voiceVolDown").addEventListener("click", () => step(-0.1));
    $("voiceVolUp").addEventListener("click", () => step(0.1));
  }

  function setupSettings() {
    setupVolume();
    $("voiceSettingsForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      const msg = $("voiceSettingsMessage");
      try {
        const res = await postLiveJson("/api/voice/settings", {
          inputDevice: $("voiceInput").value,
          outputDevice: $("voiceOutput").value,
          volume: Number($("voiceVolume").value),
          micGain: Number($("voiceMicGain").value),
          suffix: $("voiceSuffix").value,
          message: $("voiceText").value,
          txEnabled: $("voiceTxEnabled").checked
        });
        voice.settings = res.settings;
        msg.textContent = t("voice.saved");
        renderPtt();
      } catch (err) {
        msg.textContent = err.message;
      }
    });
  }

  // ------------------------------------------------------------ start
  function tick() {
    const st = voice.status || {};
    const onAir = Boolean(st.rx || (st.tx && st.tx.active));
    const lite = document.body.classList.contains("dxz-pi");
    refreshStatus();
    clearTimeout(voice.timer);
    // level meters need ~0.6 s only while someone is on air; the Raspberry polls less when idle
    let next = onAir ? 600 : (activePage === "voice" ? (lite ? 1500 : 800) : (lite ? 5000 : 3000));
    if (document.hidden) next = 10000;
    voice.timer = setTimeout(tick, next);
  }

  if ($("page-voice")) {
    setupPtt();
    setupReflector();
    setupDevice();
    setupSettings();
    document.querySelector(".nav-button[data-page='voice']").addEventListener("click", () => {
      refreshPorts(); loadSettings(); refreshStatus();
      if (!voice.reflectors.length) loadReflectors(false);
    });
    refreshPorts();
    loadSettings();
    loadReflectors(false);
    tick();
  }
  loadFeatures();

  const previousApply = window.applyTranslations;
  window.applyTranslations = function () {
    previousApply.apply(this, arguments);
    applyFeatures();
    if ($("page-voice")) { render(); renderFavs(); }
  };
  applyTranslations();
})();
