/* DX Zaza — local weather next to the clocks: temperature and sky at the operator's QTH.
   Data: MET Norway (CC BY 4.0), fetched and cached by the DX Zaza backend. */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const REFRESH_MS = 10 * 60 * 1000;

  // small line icons (stroke = currentColor), 24x24
  const SUN = '<circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2.4M12 19.1v2.4M2.5 12h2.4M19.1 12h2.4M5.3 5.3l1.7 1.7M17 17l1.7 1.7M5.3 18.7 7 17M17 7l1.7-1.7"/>';
  const MOON = '<path d="M19.5 14.6A8 8 0 0 1 9.4 4.5a8 8 0 1 0 10.1 10.1z"/>';
  const CLOUD = '<path d="M7 18.5h10.2a4.2 4.2 0 0 0 .5-8.4A6 6 0 0 0 6.2 11.6 3.5 3.5 0 0 0 7 18.5z"/>';
  const SMALL_SUN = '<circle cx="8" cy="8" r="3"/><path d="M8 2.2v1.4M2.2 8h1.4M3.9 3.9l1 1M12.1 3.9l-1 1"/>';
  const SMALL_MOON = '<path d="M11.5 9.6A4.6 4.6 0 0 1 5.4 3.5a4.6 4.6 0 1 0 6.1 6.1z"/>';
  const SMALL_CLOUD = '<path d="M9 19h8.6a3.6 3.6 0 0 0 .4-7.2 5.1 5.1 0 0 0-9.5 1.3A3 3 0 0 0 9 19z"/>';
  const ICONS = {
    clear: (n) => n ? MOON : SUN,
    partly: (n) => (n ? SMALL_MOON : SMALL_SUN) + SMALL_CLOUD,
    cloudy: () => CLOUD,
    fog: () => '<path d="M4 9h16M3 13h18M5 17h14"/>',
    rain: () => CLOUD + '<path d="M9 20.6l-.8 2M13 20.6l-.8 2M17 20.6l-.8 2"/>',
    sleet: () => CLOUD + '<path d="M9 21l.6-1.6M14 21h.01"/>',
    snow: () => CLOUD + '<path d="M9 21.5h.01M13 21.5h.01M17 21.5h.01"/>',
    thunder: () => CLOUD + '<path d="M12.5 13.5 10 18h3l-2 4"/>'
  };
  function icon(kind, night) {
    const body = (ICONS[kind] || ICONS.cloudy)(night);
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' + body + "</svg>";
  }

  let timer = null;
  let shown = false;
  function schedule(ms) {
    clearTimeout(timer);
    timer = setTimeout(load, Math.max(15000, Math.min(REFRESH_MS, ms)));
  }

  function it() { return (document.documentElement.lang || "").startsWith("it") || (window.dxZazaState && window.dxZazaState.language === "it"); }

  async function load() {
    const chip = $("dxzWeather");
    if (!chip) return;
    let d = null;
    try {
      const res = await fetch("/api/weather", { cache: "no-store" });
      d = await res.json();
    } catch (_) {
      d = null;   // the app itself is restarting: try again soon
    }
    if (!d || !d.ok || typeof d.tempC !== "number") {
      const noQth = d && /QTH|locator/i.test(d.error || "");
      if (noQth) { chip.hidden = true; shown = false; schedule(60000); return; }
      // temporarily unreachable: keep the last value on screen (dimmed) and retry soon
      if (!shown) {
        $("dxzWeatherTemp").textContent = "--°";
        $("dxzWeatherIcon").innerHTML = icon("cloudy", false);
        $("dxzWeatherLabel").textContent = it() ? "Meteo in arrivo…" : "Weather loading…";
        chip.hidden = false;
      }
      chip.classList.add("is-stale");
      chip.title = (it() ? "Meteo momentaneamente non raggiungibile, nuovo tentativo automatico." :
        "Weather temporarily unreachable, retrying automatically.") + "\n" + ((d && d.attribution) || "");
      schedule(((d && d.retryIn) || 30) * 1000);
      return;
    }
    $("dxzWeatherTemp").textContent = Math.round(d.tempC) + "°C";
    $("dxzWeatherIcon").innerHTML = icon(d.sky, d.night);
    $("dxzWeatherIcon").dataset.sky = d.sky;
    $("dxzWeatherLabel").textContent = [d.text, d.place].filter(Boolean).join(" · ") || "Weather";
    const extra = [];
    if (typeof d.windMs === "number") extra.push("Wind " + Math.round(d.windMs * 3.6) + " km/h");
    if (typeof d.humidity === "number") extra.push("RH " + Math.round(d.humidity) + "%");
    const note = d.stale ? (it() ? "Ultimo dato di " + d.fetchedAgoMin + " min fa, aggiornamento in corso" :
      "Last data " + d.fetchedAgoMin + " min ago, updating") : "";
    chip.title = [d.text, d.place, extra.join(" · "), note, d.attribution].filter(Boolean).join("\n");
    chip.classList.toggle("is-stale", Boolean(d.stale));
    chip.hidden = false;
    shown = true;
    schedule(d.retrying ? (d.retryIn || 30) * 1000 : REFRESH_MS);
  }

  function init() {
    load();
    // back from sleep / network back: refresh at once
    window.addEventListener("online", () => schedule(15000));
    document.addEventListener("visibilitychange", () => { if (!document.hidden) schedule(15000); });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
  window.dxzWeatherRefresh = load;   // after the QTH changes
})();
