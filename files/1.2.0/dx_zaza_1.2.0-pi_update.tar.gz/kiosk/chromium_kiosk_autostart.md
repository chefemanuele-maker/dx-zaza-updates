# Chromium Kiosk Autostart

## Enable
The installer runs:

    sudo scripts/setup_kiosk_autostart.sh

It creates:

- `/home/pi/dx-zaza-kiosk/start-dx-zaza-kiosk.sh`
- `/home/pi/.config/autostart/dx-zaza-kiosk.desktop`
- `/home/pi/dx-zaza-kiosk/kiosk.log`

The launcher waits for the backend, closes old Chromium instances, removes stale Singleton lock files and starts:

    /usr/bin/chromium \
      --kiosk \
      --no-first-run \
      --disable-infobars \
      --disable-features=Translate,TranslateUI \
      --disable-translate \
      --noerrdialogs \
      --disable-session-crashed-bubble \
      --password-store=basic \
      --touch-events=enabled \
      --overscroll-history-navigation=0 \
      --enable-features=OverlayScrollbar,TouchpadOverscrollHistoryNavigation \
      --user-data-dir=/home/pi/.config/dx-zaza-chromium \
      http://127.0.0.1:5050/

Reboot the Raspberry Pi. Chromium should open:

http://127.0.0.1:5050

## Troubleshooting
- Keyring popup: confirm Chromium is launched with `--password-store=basic`.
- SingletonLock error: remove `SingletonLock`, `SingletonCookie` and `SingletonSocket` under `/home/pi/.config/dx-zaza-chromium/`.
- Touch scroll works only with scrollbar: confirm Chromium is launched with `--touch-events=enabled`.
- Multiple windows: remove old DX Zaza autostart files and rerun `sudo scripts/setup_kiosk_autostart.sh`.

## Exit kiosk
- Press Ctrl+Alt+F2 for another TTY if needed.
- Or connect over SSH/Tailscale and stop Chromium.

## Test touchscreen
- Confirm HDMI display resolution is correct.
- Confirm USB touch cable is connected.
- Confirm DX Zaza buttons, filters, Operator Setup and System Settings are touch-friendly.
