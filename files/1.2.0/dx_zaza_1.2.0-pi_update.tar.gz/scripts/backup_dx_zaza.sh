#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/dx-zaza}"
CONFIG_FILE="${CONFIG_FILE:-/etc/dx-zaza/config.local.json}"
BACKUP_ROOT="${BACKUP_ROOT:-${APP_DIR}/backups}"
LOG_DIR="${LOG_DIR:-/var/log/dx-zaza}"
LOG_FILE="${LOG_FILE:-${LOG_DIR}/backup.log}"
KEEP_BACKUPS="${KEEP_BACKUPS:-10}"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="${BACKUP_ROOT}/${TIMESTAMP}"

log() {
  printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" | tee -a "${LOG_FILE}"
}

if [ "$(id -u)" -ne 0 ]; then
  echo "Run with sudo/root." >&2
  exit 1
fi

mkdir -p "${BACKUP_DIR}/app" "${BACKUP_DIR}/etc" "${LOG_DIR}"
touch "${LOG_FILE}"

log "Creating DX Zaza backup: ${BACKUP_DIR}"

if [ -d "${APP_DIR}" ]; then
  rsync -a --delete --exclude ".venv" --exclude "backups" "${APP_DIR}/" "${BACKUP_DIR}/app/"
fi

if [ -f "${CONFIG_FILE}" ]; then
  cp "${CONFIG_FILE}" "${BACKUP_DIR}/etc/config.local.json"
  chmod 600 "${BACKUP_DIR}/etc/config.local.json" || true
  log "Local config backed up with protected permissions."
else
  log "No local config found at ${CONFIG_FILE}."
fi

find "${BACKUP_ROOT}" -mindepth 1 -maxdepth 1 -type d | sort -r | tail -n +$((KEEP_BACKUPS + 1)) | xargs -r rm -rf

log "Backup complete."
echo "${BACKUP_DIR}"

