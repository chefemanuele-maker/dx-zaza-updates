#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/dx-zaza}"
BASE_URL="${BASE_URL:-http://127.0.0.1:5050}"
KIOSK_LOG="${KIOSK_LOG:-/home/pi/dx-zaza-kiosk/kiosk.log}"
UPDATE_LOG="${UPDATE_LOG:-/var/log/dx-zaza/update.log}"
BACKUP_ROOT="${BACKUP_ROOT:-${APP_DIR}/backups}"

mask_callsigns() {
  sed -E "s/[A-Z0-9/]{3,20}/***MASKED***/g"
}

json_summary() {
  python3 -c "$1" 2>/dev/null || true
}

echo "DX Zaza diagnostics"
echo

echo "Version:"
if [ -f "${APP_DIR}/VERSION" ]; then
  cat "${APP_DIR}/VERSION"
else
  echo "VERSION not found"
fi

echo
echo "Backend service enabled/running:"
systemctl is-enabled dx-zaza.service 2>/dev/null || true
systemctl is-active dx-zaza.service 2>/dev/null || true
systemctl --no-pager --lines=12 status dx-zaza.service || true

echo
echo "Kiosk service enabled/running:"
systemctl is-enabled dx-zaza-kiosk.service 2>/dev/null || true
systemctl is-active dx-zaza-kiosk.service 2>/dev/null || true
systemctl --no-pager --lines=12 status dx-zaza-kiosk.service || true

echo
echo "Port 5050 listener:"
ss -tulpn 2>/dev/null | grep ":5050" || true

echo
echo "Local DX Zaza URL:"
curl --silent --show-error --head --max-time 10 "${BASE_URL}/" | sed -n "1,6p" || true

echo
echo "API status:"
curl --silent --show-error --max-time 10 "${BASE_URL}/api/status" | json_summary 'import json,sys; data=json.load(sys.stdin); print({"ok": data.get("ok"), "version": data.get("version"), "mode": data.get("mode")})' || true

echo
echo "Settings summary:"
curl --silent --show-error --max-time 10 "${BASE_URL}/api/settings" | json_summary 'import json,sys; data=json.load(sys.stdin); print({"ok": data.get("ok"), "operator_masked_present": bool(data.get("operator", {}).get("callsign_masked")), "language": data.get("ui", {}).get("language"), "digital_voice_configured": data.get("digital_voice", {}).get("configured"), "digital_voice_configuration_valid": data.get("digital_voice", {}).get("configuration_valid")})' || true

echo
echo "Digital Voice ownership:"
curl --silent --show-error --max-time 10 "${BASE_URL}/api/digital-voice/status" | json_summary 'import json,sys; data=json.load(sys.stdin); dv=data.get("digital_voice", {}); print({"ok": data.get("ok"), "stable_device_ready": dv.get("stable_device_ready"), "hardware_in_use": dv.get("hardware_in_use"), "hardware_owner": dv.get("hardware_owner")})' || true

echo
echo "Digital Voice configuration:"
curl --silent --show-error --max-time 10 "${BASE_URL}/api/digital-voice/status" | json_summary 'import json,sys; data=json.load(sys.stdin); cfg=data.get("digital_voice", {}).get("configuration", {}); print({"configuration_valid": cfg.get("valid"), "ambe_server_enabled": cfg.get("ambe_server_enabled"), "blue_dv_enabled": cfg.get("blue_dv_enabled"), "audio_enabled": cfg.get("audio_enabled"), "effective_tx_enabled": cfg.get("effective_tx_enabled")})' || true

echo
echo "AMBE integration candidate:"
curl --silent --show-error --max-time 10 "${BASE_URL}/api/digital-voice/status" | json_summary 'import json,sys; data=json.load(sys.stdin); integ=data.get("digital_voice", {}).get("ambe_integration", {}); print({"service_file_present": integ.get("service_file_present"), "service_enabled": integ.get("service_enabled"), "service_active": integ.get("service_active"), "external_binary_present": integ.get("external_binary_present"), "preflight_can_start": integ.get("preflight_can_start"), "execution_enabled": integ.get("execution_enabled")})' || true

echo
echo "Digital Voice readiness:"
curl --silent --show-error --max-time 10 "${BASE_URL}/api/digital-voice/readiness" | json_summary 'import json,sys; data=json.load(sys.stdin); r=data.get("readiness", {}); print({"ok": data.get("ok"), "stable_device_ready": r.get("stable_device_ready"), "hardware_busy": r.get("hardware_busy"), "configuration_valid": r.get("configuration_valid"), "tx_enabled": r.get("tx_enabled"), "safe_to_operate": r.get("safe_to_operate"), "listen_only_available": r.get("listen_only_available")})' || true

echo
echo "DX spots internal source:"
curl --silent --show-error --max-time 20 "${BASE_URL}/api/dx-spots" | json_summary 'import json,sys; data=json.load(sys.stdin); print({"ok": data.get("ok"), "source": data.get("source"), "spots": len(data.get("spots", [])), "public_dx_field": any("dx" in s for s in data.get("spots", []))})' || true

echo
echo "Solar internal source:"
curl --silent --show-error --max-time 20 "${BASE_URL}/api/solar" | json_summary 'import json,sys; data=json.load(sys.stdin); print({"ok": data.get("ok"), "source": data.get("source"), "kp": data.get("kp"), "sfi": data.get("sfi")})' || true

echo
echo "Update log tail:"
if [ -f "${UPDATE_LOG}" ]; then
  tail -40 "${UPDATE_LOG}" | mask_callsigns
else
  echo "No update log found at ${UPDATE_LOG}"
fi

echo
echo "Kiosk log tail:"
if [ -f "${KIOSK_LOG}" ]; then
  tail -40 "${KIOSK_LOG}" | mask_callsigns
else
  echo "No kiosk log found at ${KIOSK_LOG}"
fi

echo
echo "Chromium processes:"
CHROMIUM_PROCESSES="$(pgrep -af "chromium|chromium-browser" || true)"
if [ -n "${CHROMIUM_PROCESSES}" ]; then
  printf '%s\n' "${CHROMIUM_PROCESSES}" | mask_callsigns
else
  echo "No Chromium process found"
fi

echo
echo "Chromium kiosk checks:"
if printf '%s\n' "${CHROMIUM_PROCESSES}" | grep -q -- "--kiosk"; then
  echo "kiosk_flag=present"
else
  echo "kiosk_flag=missing"
fi
if printf '%s\n' "${CHROMIUM_PROCESSES}" | grep -q "127.0.0.1:5050"; then
  echo "local_url=present"
else
  echo "local_url=missing"
fi

echo
echo "Backup count:"
if [ -d "${BACKUP_ROOT}" ]; then
  find "${BACKUP_ROOT}" -mindepth 1 -maxdepth 1 -type d | wc -l | tr -d " "
  find "${BACKUP_ROOT}" -mindepth 1 -maxdepth 1 -type d | sort -r | sed -n "1,5p"
else
  echo "0"
fi

echo
echo "Disk free space:"
df -h / /opt 2>/dev/null || df -h

echo
echo "Memory:"
free -h || true

echo
echo "Uptime:"
uptime || true

echo
echo "Network:"
hostname -I || true
ip route | sed -n "1,8p" || true
