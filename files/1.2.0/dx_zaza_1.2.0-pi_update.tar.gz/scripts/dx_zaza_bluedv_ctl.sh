#!/usr/bin/env bash
# DX Zaza BlueDV helper (installed as /usr/local/sbin/dx-zaza-bluedv-ctl, run via sudo).
# Starts/stops BlueDV Radio while keeping ONE OWNER OF THE DVSTICK AT A TIME.
#   dx-zaza-bluedv-ctl start direct       -> stop AMBE Server, BlueDV opens the DVstick itself
#   dx-zaza-bluedv-ctl start ambe_server  -> AMBE Server owns the DVstick, BlueDV uses it via UDP 2460
#   dx-zaza-bluedv-ctl stop
set -euo pipefail

ACTION="${1:-}"
MODE="${2:-direct}"
INI="/usr/local/bluedv/config.ini"
DEFAULT_TYPE_FILE="/etc/dx-zaza/bluedv_default_ambe_type"
STABLE_DEVICE="/dev/dvmega-ambestick"

set_ini() {  # set_ini SECTION KEY VALUE  (creates section/key if missing)
  python3 - "$INI" "$1" "$2" "$3" <<'PY'
import sys, re
path, section, key, value = sys.argv[1:5]
try:
    lines = open(path, encoding="utf-8").read().splitlines()
except FileNotFoundError:
    lines = []
out, in_sec, done, found_sec = [], False, False, False
for line in lines:
    m = re.match(r"\s*\[(.+)\]\s*$", line)
    if m:
        if in_sec and not done:
            out.append(f"{key} = {value}"); done = True
        in_sec = m.group(1).strip().upper() == section.upper()
        found_sec = found_sec or in_sec
    elif in_sec and re.match(rf"\s*{re.escape(key)}\s*=", line, re.I):
        out.append(f"{key} = {value}"); done = True
        continue
    out.append(line)
if not done:
    if not found_sec:
        out.append(f"[{section}]")
    out.append(f"{key} = {value}")
open(path, "w", encoding="utf-8").write("\n".join(out) + "\n")
PY
}

case "$ACTION" in
  start)
    case "$MODE" in
      direct)
        systemctl stop dx-zaza-ambe-server.service 2>/dev/null || true
        if [ -f "$INI" ]; then
          [ -e "$STABLE_DEVICE" ] && set_ini AMBE SerialPort "$STABLE_DEVICE"
          if [ -s "$DEFAULT_TYPE_FILE" ]; then set_ini AMBE Type "$(cat "$DEFAULT_TYPE_FILE")"; fi
        fi
        ;;
      ambe_server)
        systemctl start dx-zaza-ambe-server.service
        if [ -f "$INI" ]; then
          set_ini AMBE Type net
          set_ini AMBE UDPServer 127.0.0.1
          set_ini AMBE UDPPort 2460
        fi
        ;;
      *) echo "Unknown mode: $MODE" >&2; exit 2 ;;
    esac
    chown bluedv:bluedv "$INI" 2>/dev/null || true
    systemctl start bluedv.service
    echo "BlueDV Radio started (mode: $MODE)"
    ;;
  stop)
    systemctl stop bluedv.service
    echo "BlueDV Radio stopped"
    ;;
  *)
    echo "Usage: dx-zaza-bluedv-ctl start [direct|ambe_server] | stop" >&2
    exit 2
    ;;
esac
