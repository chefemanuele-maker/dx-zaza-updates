#!/usr/bin/env python3
"""DX Zaza online update helper (Raspberry Pi). Installed root-owned as
/usr/local/sbin/dx-zaza-online-update; the app (user pi) may run it with sudo, nothing else.

    sudo dx-zaza-online-update <download folder> <bundle file name>

The app has already downloaded latest.json, latest.json.sig and the bundle into the folder. This
helper does NOT trust the app: it copies everything into a root-only folder, checks the Ed25519
signature with the public key below, checks the bundle SHA-256 against the signed manifest and the
version, unpacks the bundle safely and starts the normal update script (backup, health check,
automatic rollback) as a separate systemd job, so it survives the app being stopped.
"""
import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile

PUBLIC_KEY_B64 = "m7utnL/j8vS/kcHiCKZb1vVCCN8wBbzICoysuaPcZps="
LIB_DIR = "/usr/local/lib/dx-zaza"
APP_DIR = "/opt/dx-zaza"
WORK = "/var/lib/dx-zaza-update"
UNIT = "dx-zaza-online-update"
NAME_RE = re.compile(r"^[A-Za-z0-9._-]{1,120}\.tar\.gz$")
VERSION_RE = re.compile(r"(\d+)\.(\d+)\.(\d+)")
MAX_BUNDLE = 300 * 1024 * 1024


def fail(message):
    print("ERROR: " + message, file=sys.stderr)
    sys.exit(1)


def version(text):
    match = VERSION_RE.search(text or "")
    return tuple(int(x) for x in match.groups()) if match else None


def load_verifier():
    path = os.path.join(LIB_DIR, "ed25519.py")
    info = os.stat(path)
    if info.st_uid != 0 or info.st_mode & 0o022:
        fail("verifier is not root-owned")
    sys.path.insert(0, LIB_DIR)
    import ed25519  # noqa: E402
    return ed25519


def read_limited(path, limit):
    with open(path, "rb") as handle:
        data = handle.read(limit + 1)
    if len(data) > limit:
        fail("file too large: " + os.path.basename(path))
    return data


def main(argv):
    if os.geteuid() != 0:
        fail("run with sudo")
    if len(argv) != 3:
        fail("usage: dx-zaza-online-update <folder> <bundle.tar.gz>")
    folder, name = argv[1], argv[2]
    if not NAME_RE.match(name):
        fail("bad bundle name")

    active = subprocess.run(["systemctl", "is-active", "--quiet", UNIT + ".service"])
    if active.returncode == 0:
        fail("an update is already running")

    # private copy first: the app can no longer change what we check
    shutil.rmtree(WORK, ignore_errors=True)
    os.makedirs(WORK, mode=0o700)
    raw = read_limited(os.path.join(folder, "latest.json"), 1024 * 1024)
    sig_text = read_limited(os.path.join(folder, "latest.json.sig"), 4096).decode("ascii", "replace").strip()
    bundle = os.path.join(WORK, name)
    with open(os.path.join(folder, name), "rb") as src, open(bundle, "wb") as dst:
        digest = hashlib.sha256()
        total = 0
        while True:
            chunk = src.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_BUNDLE:
                fail("bundle too large")
            digest.update(chunk)
            dst.write(chunk)

    ed25519 = load_verifier()
    try:
        signature = base64.b64decode(sig_text, validate=True)
    except ValueError:
        fail("bad signature format")
    if not ed25519.verify(base64.b64decode(PUBLIC_KEY_B64), raw, signature):
        fail("signature check failed: this is not an official DX Zaza update")
    manifest = json.loads(raw.decode("utf-8"))
    if manifest.get("product") != "dx-zaza":
        fail("not a DX Zaza manifest")
    asset = (manifest.get("platforms") or {}).get("pi") or {}
    if digest.hexdigest() != asset.get("sha256"):
        fail("bundle does not match the signed checksum")
    try:
        installed = open(os.path.join(APP_DIR, "VERSION")).read()
    except OSError:
        installed = "0.0.0"
    if not (version(manifest.get("version")) and version(installed) and version(manifest["version"]) > version(installed)):
        fail("not newer than the installed version")

    target = os.path.join(WORK, "bundle")
    with tarfile.open(bundle, "r:gz") as tar:
        tar.extractall(target, filter="data")
    script = os.path.join(target, "scripts", "update_dx_zaza.sh")
    if not os.path.isfile(script):
        fail("bundle has no update script")

    subprocess.run(["systemctl", "reset-failed", UNIT + ".service"], capture_output=True)
    started = subprocess.run(["systemd-run", "--unit=" + UNIT, "--collect", "--quiet",
                              "--setenv=BUNDLE_DIR=" + target, "/bin/bash", script],
                             capture_output=True, text=True)
    if started.returncode != 0:
        fail("could not start the update: " + (started.stderr or "").strip()[-200:])
    print("update to %s started" % manifest["version"])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
