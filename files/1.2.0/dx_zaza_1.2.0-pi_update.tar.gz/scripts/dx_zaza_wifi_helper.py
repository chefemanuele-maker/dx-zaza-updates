#!/usr/bin/env python3
import json
import os
import socket
import subprocess
import sys
import time
import urllib.request
import uuid
from pathlib import Path


DEVICE = "wlan0"
ROLLBACK_UNIT = "dx-zaza-wifi-rollback"
NM_CONNECTION_DIR = Path("/etc/NetworkManager/system-connections")
PUBLIC_FAILURE_MESSAGE = "Unable to connect to this Wi-Fi network. The previous connection was restored."
PUBLIC_REASONS = {
    "auth_failed",
    "network_not_found",
    "timeout",
    "no_ip",
    "no_gateway",
    "dns_failed",
    "internet_failed",
    "rollback_failed",
    "permission_error",
    "unknown_error",
}


def respond(payload, code=0):
    print(json.dumps(payload, ensure_ascii=True), flush=True)
    return code


def success(ssid, checks):
    return respond({
        "ok": True,
        "status": "connected",
        "ssid": ssid,
        "message": "Connected successfully",
        "checks": checks,
    })


def failure(reason):
    if reason not in PUBLIC_REASONS:
        reason = "unknown_error"
    return respond({
        "ok": False,
        "status": "failed",
        "message": PUBLIC_FAILURE_MESSAGE,
        "reason": reason,
    }, 1)


def run(command, timeout=15):
    return subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
        shell=False,
    )


def split_terse(line):
    values = []
    current = []
    escaped = False
    for character in line.rstrip("\n"):
        if escaped:
            current.append(character)
            escaped = False
        elif character == "\\":
            escaped = True
        elif character == ":":
            values.append("".join(current))
            current = []
        else:
            current.append(character)
    if escaped:
        current.append("\\")
    values.append("".join(current))
    return values


def nmcli(command, timeout=15):
    return run(["nmcli", *command], timeout=timeout)


def active_wifi_connection():
    result = nmcli(["-t", "-f", "UUID,TYPE,DEVICE,NAME", "connection", "show", "--active"])
    if result.returncode != 0:
        return None
    for line in result.stdout.splitlines():
        fields = split_terse(line)
        if len(fields) >= 4 and fields[1] == "802-11-wireless" and fields[2] == DEVICE:
            return {"uuid": fields[0], "name": fields[3]}
    return None


def visible_ssids():
    nmcli(["device", "wifi", "rescan", "ifname", DEVICE], timeout=10)
    result = nmcli(["-t", "-f", "SSID", "device", "wifi", "list", "ifname", DEVICE], timeout=10)
    if result.returncode != 0:
        return set()
    return {split_terse(line)[0] for line in result.stdout.splitlines() if split_terse(line)[0]}


def keyfile_escape(value):
    return str(value).replace("\\", "\\\\").replace("\n", "")


def candidate_keyfile(candidate_uuid, candidate_name, ssid, password):
    lines = [
        "[connection]",
        f"id={keyfile_escape(candidate_name)}",
        f"uuid={candidate_uuid}",
        "type=wifi",
        f"interface-name={DEVICE}",
        "autoconnect=false",
        "",
        "[wifi]",
        "mode=infrastructure",
        f"ssid={keyfile_escape(ssid)}",
        "",
    ]
    if password:
        lines.extend([
            "[wifi-security]",
            "key-mgmt=wpa-psk",
            f"psk={keyfile_escape(password)}",
            "",
        ])
    lines.extend([
        "[ipv4]",
        "method=auto",
        "",
        "[ipv6]",
        "addr-gen-mode=default",
        "method=auto",
        "",
    ])
    return "\n".join(lines)


def write_candidate(candidate_uuid, candidate_name, ssid, password):
    NM_CONNECTION_DIR.mkdir(parents=True, exist_ok=True)
    path = NM_CONNECTION_DIR / f"{candidate_name}.nmconnection"
    tmp_path = NM_CONNECTION_DIR / f".{candidate_name}.tmp"
    with tmp_path.open("w", encoding="utf-8") as handle:
        handle.write(candidate_keyfile(candidate_uuid, candidate_name, ssid, password))
    os.chmod(tmp_path, 0o600)
    os.replace(tmp_path, path)
    nmcli(["connection", "reload"], timeout=10)
    return path


def delete_candidate(candidate_uuid):
    nmcli(["connection", "delete", "uuid", candidate_uuid], timeout=10)
    for path in NM_CONNECTION_DIR.glob("dx-zaza-wifi-candidate-*.nmconnection"):
        try:
            if candidate_uuid in path.read_text(encoding="utf-8", errors="ignore"):
                path.unlink()
        except OSError:
            pass
    nmcli(["connection", "reload"], timeout=10)


def arm_rollback(old_uuid, candidate_uuid, delay_seconds):
    if not old_uuid:
        return
    run(["systemctl", "stop", f"{ROLLBACK_UNIT}.timer", f"{ROLLBACK_UNIT}.service"], timeout=10)
    command = [
        "systemd-run",
        f"--unit={ROLLBACK_UNIT}",
        f"--on-active={delay_seconds}",
        "/usr/local/sbin/dx-zaza-wifi-helper",
        "--rollback",
        old_uuid,
        candidate_uuid,
    ]
    run(command, timeout=10)


def cancel_rollback():
    run(["systemctl", "stop", f"{ROLLBACK_UNIT}.timer", f"{ROLLBACK_UNIT}.service"], timeout=10)
    run(["systemctl", "reset-failed", f"{ROLLBACK_UNIT}.timer", f"{ROLLBACK_UNIT}.service"], timeout=10)


def rollback(old_uuid, candidate_uuid):
    ok = True
    if old_uuid and old_uuid != "-":
        result = nmcli(["connection", "up", "uuid", old_uuid, "ifname", DEVICE], timeout=45)
        ok = result.returncode == 0
    if candidate_uuid and candidate_uuid != "-":
        delete_candidate(candidate_uuid)
    return ok


def device_values():
    result = nmcli(["-t", "-f", "IP4.ADDRESS,IP4.GATEWAY,IP4.DNS", "device", "show", DEVICE], timeout=10)
    values = {}
    if result.returncode != 0:
        return values
    for line in result.stdout.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        values[key.strip()] = value.strip()
    return values


def has_ip(values):
    return any(key.startswith("IP4.ADDRESS") and value for key, value in values.items())


def has_dns(values):
    return any(key.startswith("IP4.DNS") and value for key, value in values.items())


def dns_check():
    try:
        socket.getaddrinfo("example.com", 443, type=socket.SOCK_STREAM)
        return True
    except OSError:
        return False


def internet_check():
    try:
        with urllib.request.urlopen("https://example.com", timeout=6) as response:
            return 200 <= response.status < 500
    except Exception:
        return False


def verify_connection(timeout_seconds):
    deadline = time.monotonic() + timeout_seconds
    checks = {"ip": False, "gateway": False, "dns": False, "internet": False}
    while time.monotonic() < deadline:
        values = device_values()
        checks["ip"] = has_ip(values)
        checks["gateway"] = bool(values.get("IP4.GATEWAY"))
        checks["dns"] = has_dns(values) and dns_check()
        checks["internet"] = checks["dns"] and internet_check()
        if all(checks.values()):
            return checks
        time.sleep(2)
    return checks


def reason_from_checks(checks):
    if not checks.get("ip"):
        return "no_ip"
    if not checks.get("gateway"):
        return "no_gateway"
    if not checks.get("dns"):
        return "dns_failed"
    if not checks.get("internet"):
        return "internet_failed"
    return "unknown_error"


def classify_nmcli_failure(result):
    text = f"{result.stdout}\n{result.stderr}".lower()
    if "secrets were required" in text or "no secrets" in text or "password" in text or "authentication" in text:
        return "auth_failed"
    if "not found" in text or "no network" in text:
        return "network_not_found"
    return "unknown_error"


def validate_payload(payload):
    ssid = str(payload.get("ssid") or "").strip()
    password = "" if payload.get("password") is None else str(payload.get("password"))
    try:
        timeout_seconds = int(payload.get("timeout_seconds", 45))
    except (TypeError, ValueError):
        timeout_seconds = 45
    timeout_seconds = max(15, min(120, timeout_seconds))
    if not ssid or "\n" in ssid or "\r" in ssid or "\n" in password or "\r" in password:
        return None
    if len(ssid.encode("utf-8")) > 32:
        return None
    if password and not (8 <= len(password) <= 64):
        return None
    return ssid, password, timeout_seconds


def connect_from_stdin():
    try:
        payload = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return failure("unknown_error")
    validated = validate_payload(payload)
    if not validated:
        return failure("unknown_error")
    ssid, password, timeout_seconds = validated
    if ssid not in visible_ssids():
        return failure("network_not_found")

    previous = active_wifi_connection() or {}
    old_uuid = previous.get("uuid", "")
    candidate_uuid = str(uuid.uuid4())
    candidate_name = f"dx-zaza-wifi-candidate-{candidate_uuid[:8]}"
    write_candidate(candidate_uuid, candidate_name, ssid, password)
    arm_rollback(old_uuid, candidate_uuid, timeout_seconds + 45)

    up_result = nmcli(["-w", str(timeout_seconds), "connection", "up", "uuid", candidate_uuid, "ifname", DEVICE], timeout=timeout_seconds + 10)
    if up_result.returncode != 0:
        restored = rollback(old_uuid, candidate_uuid)
        return failure(classify_nmcli_failure(up_result) if restored else "rollback_failed")

    checks = verify_connection(timeout_seconds)
    if all(checks.values()):
        nmcli(["connection", "modify", "uuid", candidate_uuid, "connection.autoconnect", "yes"], timeout=10)
        cancel_rollback()
        return success(ssid, checks)

    restored = rollback(old_uuid, candidate_uuid)
    return failure(reason_from_checks(checks) if restored else "rollback_failed")


def main():
    if os.geteuid() != 0:
        return failure("permission_error")
    if len(sys.argv) == 4 and sys.argv[1] == "--rollback":
        return 0 if rollback(sys.argv[2], sys.argv[3]) else 1
    return connect_from_stdin()


if __name__ == "__main__":
    raise SystemExit(main())
