#!/usr/bin/env bash
# Install BlueDV Radio (PA7LIM) on the DX Zaza Raspberry Pi and connect it to DX Zaza.
#
# BlueDV Radio is free software by PA7LIM, downloaded here from the OFFICIAL site
# (it is not bundled with DX Zaza). This installer reproduces the official
# installation (https://www.pa7lim.nl/bluedv-linux-install/) with two safe differences:
#   - it does NOT run "apt upgrade" and does NOT edit /boot config (no SPI TFT overlay),
#     so the DX Zaza touchscreen/kiosk setup is left untouched;
#   - BlueDV is NOT started at boot by default: DX Zaza starts/stops it from the
#     BlueDV page, keeping one DVstick owner at a time. Use --enable-at-boot to change.
#
# Usage on the Raspberry Pi:  sudo scripts/install_bluedv_radio.sh [--enable-at-boot] [--force]
set -euo pipefail

TARBALL_URL="https://software.pa7lim.nl/BlueDV-Radio/bluedv-radio-linux-full.tar.gz"
BLUEDV_DIR="/usr/local/bluedv"
DX_CONFIG="/etc/dx-zaza/config.local.json"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENABLE_AT_BOOT=0
FORCE=0
for arg in "$@"; do
  case "$arg" in
    --enable-at-boot) ENABLE_AT_BOOT=1 ;;
    --force) FORCE=1 ;;
  esac
done

[ "$(id -u)" -eq 0 ] || { echo "Run with sudo on the Raspberry Pi." >&2; exit 1; }
[ "$(uname -s)" = "Linux" ] || { echo "Raspberry Pi / Linux only." >&2; exit 1; }
if [ "$(uname -m)" != "aarch64" ]; then
  echo "BlueDV Radio needs 64-bit Raspberry Pi OS (aarch64). Found: $(uname -m)" >&2; exit 1
fi
. /etc/os-release
if [ "${VERSION_CODENAME:-}" != "trixie" ] && [ "$FORCE" -ne 1 ]; then
  echo "BlueDV Radio is published for Raspberry Pi OS / Debian 'trixie' (64-bit)."
  echo "This system is '${VERSION_CODENAME:-unknown}'. Re-run with --force to try anyway."
  exit 1
fi

SERVICE_USER="${SUDO_USER:-pi}"
id "$SERVICE_USER" >/dev/null 2>&1 || SERVICE_USER="pi"

echo "== 1/6 System packages (audio)"
apt-get update
apt-get install -y portaudio19-dev libasound2-dev alsa-utils curl python3

echo "== 2/6 User 'bluedv' (required by BlueDV Radio)"
if ! id bluedv >/dev/null 2>&1; then
  useradd -m -s /bin/bash bluedv
fi
usermod -a -G audio,dialout,plugdev,input bluedv

echo "== 3/6 Download BlueDV Radio from the official PA7LIM site"
TMP="$(mktemp -d)"
curl -fSL "$TARBALL_URL" -o "$TMP/bluedv.tar.gz"
if [ -d "$BLUEDV_DIR" ]; then
  [ -f "$BLUEDV_DIR/config.ini" ] && cp "$BLUEDV_DIR/config.ini" "$TMP/config.ini.keep"
  systemctl stop bluedv.service 2>/dev/null || true
  rm -rf "$BLUEDV_DIR"
fi
mkdir -p "$BLUEDV_DIR"
tar -xzf "$TMP/bluedv.tar.gz" -C "$BLUEDV_DIR"
[ -f "$TMP/config.ini.keep" ] && cp "$TMP/config.ini.keep" "$BLUEDV_DIR/config.ini"
chown -R bluedv:bluedv "$BLUEDV_DIR"
chmod +x "$BLUEDV_DIR/bluedv-radio"
rm -rf "$TMP"

echo "== 4/6 Microphone (QX-18B PTT) udev rule, as in the official installer"
cat > /etc/udev/rules.d/99-uacdemo.rules <<'EOF'
KERNEL=="event*", ATTRS{name}=="Jieli Technology UACDemoV1.0 Keyboard", SYMLINK+="mymic"
KERNEL=="event*", ATTRS{name}=="UACDemoV1.0 UACDemoV1.0 Keyboard", SYMLINK+="mymic"
KERNEL=="event*", ATTRS{name}=="RunSheng Technol USB Composite Device Keyboard", SYMLINK+="mymic"
EOF
udevadm control --reload-rules
udevadm trigger || true

echo "== 5/6 Service bluedv.service"
cat > /etc/systemd/system/bluedv.service <<'EOF'
[Unit]
Description=BlueDV Radio (PA7LIM)
After=network-online.target sound.target
Wants=network-online.target

[Service]
Type=simple
User=bluedv
WorkingDirectory=/usr/local/bluedv
ExecStartPre=/bin/bash -c 'if [ -f /tmp/bluedvupdate/bluedv-radio ]; then cp /tmp/bluedvupdate/bluedv-radio /usr/local/bluedv/bluedv-radio && chmod +x /usr/local/bluedv/bluedv-radio && rm -rf /tmp/bluedvupdate; fi'
ExecStart=/usr/local/bluedv/bluedv-radio
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
if [ "$ENABLE_AT_BOOT" -eq 1 ]; then systemctl enable bluedv.service; else systemctl disable bluedv.service 2>/dev/null || true; fi

echo "== 6/6 Connect BlueDV to DX Zaza"
install -o root -g root -m 0755 "$SRC_DIR/scripts/dx_zaza_bluedv_ctl.sh" /usr/local/sbin/dx-zaza-bluedv-ctl
cat > /etc/sudoers.d/dx-zaza-bluedv <<EOF
$SERVICE_USER ALL=(root) NOPASSWD: /usr/local/sbin/dx-zaza-bluedv-ctl
EOF
chmod 0440 /etc/sudoers.d/dx-zaza-bluedv
visudo -cf /etc/sudoers.d/dx-zaza-bluedv >/dev/null

INI="$BLUEDV_DIR/config.ini"
touch "$INI"
mkdir -p /etc/dx-zaza
# remember BlueDV's own AMBE type so "direct" mode can restore it
python3 - "$INI" > /etc/dx-zaza/bluedv_default_ambe_type <<'PY' || true
import configparser, sys
p = configparser.ConfigParser(strict=False, interpolation=None)
p.read(sys.argv[1], encoding="utf-8")
t = p.get("AMBE", "Type", fallback="").strip()
print("" if t.lower() == "net" else t)
PY
CALL=""
if [ -f "$DX_CONFIG" ]; then
  CALL="$(python3 -c "import json;c=json.load(open('$DX_CONFIG'));print(c.get('operator',{}).get('callsign',''))" 2>/dev/null || true)"
fi
python3 - "$INI" "$CALL" <<'PY'
import sys, re
path, call = sys.argv[1:3]
lines = open(path, encoding="utf-8").read().splitlines()
def setv(lines, section, key, value):
    out, in_sec, done, found = [], False, False, False
    for line in lines:
        m = re.match(r"\s*\[(.+)\]\s*$", line)
        if m:
            if in_sec and not done:
                out.append(f"{key} = {value}"); done = True
            in_sec = m.group(1).strip().upper() == section.upper(); found = found or in_sec
        elif in_sec and re.match(rf"\s*{re.escape(key)}\s*=", line, re.I):
            out.append(f"{key} = {value}"); done = True; continue
        out.append(line)
    if not done:
        if not found: out.append(f"[{section}]")
        out.append(f"{key} = {value}")
    return out
if call:
    lines = setv(lines, "GENERAL", "call", call.upper())
lines = setv(lines, "AMBE", "SerialPort", "/dev/dvmega-ambestick")
open(path, "w", encoding="utf-8").write("\n".join(lines) + "\n")
PY
chown bluedv:bluedv "$INI"

echo
echo "BlueDV Radio installed."
echo " - Open DX Zaza > BlueDV and press Start (the DVstick and QX-18B mic must be connected)."
echo " - BlueDV web page: http://$(hostname).local:8080  (default login bluedv / bluedv: change it!)"
echo " - Check DMR ID and other settings in BlueDV's own Setup page."
