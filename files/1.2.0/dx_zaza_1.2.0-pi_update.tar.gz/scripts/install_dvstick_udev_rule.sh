#!/usr/bin/env bash
set -euo pipefail

RULE_NAME="99-dx-zaza-dvmega-ambestick.rules"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SOURCE_RULE="${SOURCE_DIR}/udev/${RULE_NAME}"
TARGET_RULE="/etc/udev/rules.d/99-dx-zaza-dvmega-ambestick.rules"
SYMLINK_PATH="/dev/dvmega-ambestick"
DRY_RUN=0
RUN_TRIGGER=1

usage() {
  cat <<EOF
Usage: sudo $0 [--dry-run] [--no-trigger]

Installs only the DX Zaza DVMEGA DVstick 30 udev rule candidate.
EOF
}

for arg in "$@"; do
  case "${arg}" in
    --dry-run)
      DRY_RUN=1
      ;;
    --no-trigger)
      RUN_TRIGGER=0
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: ${arg}" >&2
      usage >&2
      exit 2
      ;;
  esac
done

if [ ! -f "${SOURCE_RULE}" ]; then
  echo "Source rule not found: ${SOURCE_RULE}" >&2
  exit 1
fi

if [ "${DRY_RUN}" -eq 0 ] && [ "$(id -u)" -ne 0 ]; then
  echo "Run with sudo/root to install the udev rule." >&2
  exit 1
fi

if [ "${DRY_RUN}" -eq 0 ] && ! command -v udevadm >/dev/null 2>&1; then
  echo "udevadm not found; cannot reload udev rules." >&2
  exit 1
fi

echo "DX Zaza DVstick udev rule install"
echo "Source: ${SOURCE_RULE}"
echo "Target: ${TARGET_RULE}"
echo "Reload rules: yes"
if [ "${RUN_TRIGGER}" -eq 1 ]; then
  echo "Trigger tty subsystem: yes"
else
  echo "Trigger tty subsystem: no"
fi

if [ "${DRY_RUN}" -eq 1 ]; then
  if [ -f "${TARGET_RULE}" ]; then
    echo "Planned action: update existing target with timestamped DX Zaza backup"
  else
    echo "Planned action: install new target"
  fi
  echo "Dry run complete; no system changes made."
  exit 0
fi

if [ -f "${TARGET_RULE}" ] && cmp -s "${SOURCE_RULE}" "${TARGET_RULE}"; then
  echo "Rule already installed and up to date."
else
  if [ -f "${TARGET_RULE}" ]; then
    BACKUP_RULE="${TARGET_RULE}.dx-zaza-backup.$(date +%Y%m%d_%H%M%S)"
    cp -p "${TARGET_RULE}" "${BACKUP_RULE}"
    echo "Existing target backed up: ${BACKUP_RULE}"
  fi
  install -o root -g root -m 0644 "${SOURCE_RULE}" "${TARGET_RULE}"
  echo "Rule installed: ${TARGET_RULE}"
fi

udevadm control --reload-rules
echo "udev reload completed."

if [ "${RUN_TRIGGER}" -eq 1 ]; then
  udevadm trigger --subsystem-match=tty
  echo "udev tty trigger completed."
fi

if [ -L "${SYMLINK_PATH}" ]; then
  echo "Symlink currently present: ${SYMLINK_PATH}"
else
  echo "Symlink currently absent: ${SYMLINK_PATH}"
  echo "This is not fatal if the DVstick is not connected or the local udev attributes differ."
fi
