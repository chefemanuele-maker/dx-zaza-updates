#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/dx-zaza}"
CONFIG_FILE="${CONFIG_FILE:-/etc/dx-zaza/config.local.json}"
BACKUP_ROOT="${BACKUP_ROOT:-${APP_DIR}/backups}"
LOG_DIR="${LOG_DIR:-/var/log/dx-zaza}"
LOG_FILE="${LOG_FILE:-${LOG_DIR}/rollback.log}"
SERVICE_NAME="${SERVICE_NAME:-dx-zaza}"
RESTORE_CONFIG=false
BACKUP_PATH=""

log() {
  printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" | tee -a "${LOG_FILE}"
}

usage() {
  echo "Usage: sudo $0 [--restore-config] /opt/dx-zaza/backups/BACKUP_NAME"
  echo
  echo "Available backups:"
  find "${BACKUP_ROOT}" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort -r || true
}

if [ "$(id -u)" -ne 0 ]; then
  echo "Run with sudo/root." >&2
  exit 1
fi

while [ "$#" -gt 0 ]; do
  case "$1" in
    --restore-config) RESTORE_CONFIG=true ;;
    -h|--help) usage; exit 0 ;;
    *) BACKUP_PATH="$1" ;;
  esac
  shift
done

mkdir -p "${LOG_DIR}"
touch "${LOG_FILE}"

if [ -z "${BACKUP_PATH}" ]; then
  usage
  exit 1
fi

if [ ! -d "${BACKUP_PATH}/app" ]; then
  echo "Backup app directory not found: ${BACKUP_PATH}/app" >&2
  exit 1
fi

log "Rolling back DX Zaza from ${BACKUP_PATH}"
systemctl stop "${SERVICE_NAME}.service" || true

rsync -a --delete --exclude ".venv" --exclude "backups" "${BACKUP_PATH}/app/" "${APP_DIR}/"

if [ "${RESTORE_CONFIG}" = true ]; then
  if [ -f "${BACKUP_PATH}/etc/config.local.json" ]; then
    cp "${BACKUP_PATH}/etc/config.local.json" "${CONFIG_FILE}"
    chmod 600 "${CONFIG_FILE}" || true
    log "Local config restored by explicit request."
  else
    log "No config found in backup."
  fi
else
  log "Local config preserved. Use --restore-config to restore backup config."
fi

if [ -d "${APP_DIR}/.venv" ] && [ -f "${APP_DIR}/requirements.txt" ]; then
  "${APP_DIR}/.venv/bin/pip" install -r "${APP_DIR}/requirements.txt" || true
fi

systemctl start "${SERVICE_NAME}.service"

log "Running rollback health check"
for _ in $(seq 1 20); do
  if curl -fsS --max-time 5 "http://127.0.0.1:5050/api/status" >/dev/null; then
    log "Rollback OK."
    exit 0
  fi
  sleep 1
done

log "Rollback health check failed."
exit 1

