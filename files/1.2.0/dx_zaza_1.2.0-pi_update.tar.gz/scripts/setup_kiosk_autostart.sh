#!/usr/bin/env bash
set -euo pipefail

if [ "$(uname -s)" != "Linux" ]; then
  echo "This kiosk setup is for Raspberry Pi/Linux only." >&2
  exit 1
fi

if [ "$(id -u)" -ne 0 ]; then
  echo "Run with sudo on Raspberry Pi." >&2
  exit 1
fi

SERVICE_USER="${SERVICE_USER:-${SUDO_USER:-pi}}"
if ! id "${SERVICE_USER}" >/dev/null 2>&1; then
  SERVICE_USER="pi"
fi
if ! id "${SERVICE_USER}" >/dev/null 2>&1; then
  SERVICE_USER="$(logname 2>/dev/null || echo root)"
fi

USER_HOME="$(getent passwd "${SERVICE_USER}" | cut -d: -f6)"
if [ -z "${USER_HOME}" ] || [ ! -d "${USER_HOME}" ]; then
  USER_HOME="/home/pi"
fi

KIOSK_DIR="${USER_HOME}/dx-zaza-kiosk"
START_SCRIPT="${KIOSK_DIR}/start-dx-zaza-kiosk.sh"
AUTOSTART_DIR="${USER_HOME}/.config/autostart"

mkdir -p "${KIOSK_DIR}" "${AUTOSTART_DIR}" "${USER_HOME}/.config/dx-zaza-chromium"

disable_legacy_dx_zaza_autostart() {
  rm -f "${AUTOSTART_DIR}/dx_zaza_kiosk.desktop" \
        "${AUTOSTART_DIR}/dx-zaza.desktop" \
        "${AUTOSTART_DIR}/dx-zaza-kiosk.desktop"

  find "${USER_HOME}/.config" -path "*/autostart*" -type f \
    \( -name "*dx*zaza*.desktop" -o -name "*DX*Zaza*.desktop" \) \
    -delete 2>/dev/null || true

  if [ -f "${USER_HOME}/.config/labwc/autostart" ]; then
    grep -v "dx-zaza-kiosk\\|start-dx-zaza-kiosk.sh" \
      "${USER_HOME}/.config/labwc/autostart" > "${USER_HOME}/.config/labwc/autostart.tmp" || true
    mv "${USER_HOME}/.config/labwc/autostart.tmp" "${USER_HOME}/.config/labwc/autostart"
  fi

  rm -f "${USER_HOME}/.config/wayfire.ini.d/dx-zaza-kiosk.ini"
}

cat > "${START_SCRIPT}" <<'EOF'
#!/bin/bash

LOG="/home/pi/dx-zaza-kiosk/kiosk.log"
echo "---- DX Zaza kiosk start $(date) ----" >> "$LOG"

export DISPLAY=${DISPLAY:-:0}
export XAUTHORITY=/home/pi/.Xauthority
export XDG_RUNTIME_DIR=${XDG_RUNTIME_DIR:-/run/user/1000}

sleep 20

echo "DISPLAY=$DISPLAY" >> "$LOG"
echo "XDG_RUNTIME_DIR=$XDG_RUNTIME_DIR" >> "$LOG"
echo "Checking DX Zaza backend..." >> "$LOG"

for i in $(seq 1 20); do
  if curl -s -I http://127.0.0.1:5050/ | grep -q "200 OK"; then
    echo "Backend OK" >> "$LOG"
    break
  fi
  echo "Waiting for backend... $i" >> "$LOG"
  sleep 2
done

pkill -f "chromium.*(127.0.0.1:5050|dx-zaza-chromium|dx-zaza-kiosk)" || true
pkill -f "chromium-browser.*(127.0.0.1:5050|dx-zaza-chromium|dx-zaza-kiosk)" || true

rm -f /home/pi/.config/dx-zaza-chromium/SingletonLock
rm -f /home/pi/.config/dx-zaza-chromium/SingletonCookie
rm -f /home/pi/.config/dx-zaza-chromium/SingletonSocket

xset s off >> "$LOG" 2>&1 || true
xset -dpms >> "$LOG" 2>&1 || true
xset s noblank >> "$LOG" 2>&1 || true

echo "Starting Chromium kiosk..." >> "$LOG"

/usr/bin/chromium \
  --kiosk \
  --autoplay-policy=no-user-gesture-required \
  --disable-renderer-accessibility \
  --no-first-run \
  --disable-infobars \
  --disable-features=Translate,TranslateUI \
  --disable-translate \
  --noerrdialogs \
  --disable-session-crashed-bubble \
  --password-store=basic \
  --touch-events=enabled \
  --overscroll-history-navigation=0 \
  --enable-features=OverlayScrollbar,TouchpadOverscrollHistoryNavigation \
  --user-data-dir=/home/pi/.config/dx-zaza-chromium \
  http://127.0.0.1:5050/ >> "$LOG" 2>&1
EOF

sed -i "s#/home/pi#${USER_HOME}#g" "${START_SCRIPT}"
chmod 755 "${START_SCRIPT}"

disable_legacy_dx_zaza_autostart

chown -R "${SERVICE_USER}:${SERVICE_USER}" "${KIOSK_DIR}" "${AUTOSTART_DIR}" "${USER_HOME}/.config/dx-zaza-chromium" || true
[ -f "${USER_HOME}/.config/labwc/autostart" ] && chown "${SERVICE_USER}:${SERVICE_USER}" "${USER_HOME}/.config/labwc/autostart" || true

echo "Kiosk start script installed: ${START_SCRIPT}"
echo "Legacy DX Zaza desktop autostart entries disabled; systemd owns kiosk startup."
