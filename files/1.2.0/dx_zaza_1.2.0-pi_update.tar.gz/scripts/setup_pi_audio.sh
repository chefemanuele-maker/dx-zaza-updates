#!/usr/bin/env bash
# DX Zaza on the Raspberry Pi: send the default audio (digital voice) to the HDMI port the
# screen is connected to. The Pi's HDMI needs the "hdmi:" ALSA device (IEC958), the raw hw
# device PortAudio would pick plays nothing. Run as the kiosk/service user (not root).
# Leaves an existing ~/.asoundrc alone unless FORCE=1.
set -euo pipefail
RC="${HOME}/.asoundrc"
if [ -f "${RC}" ] && [ "${FORCE:-0}" != "1" ]; then
  echo "${RC} already present: left unchanged"; exit 0
fi
CARD=""
for i in 1 2; do
  st=$(cat /sys/class/drm/card*-HDMI-A-${i}/status 2>/dev/null | head -1 || true)
  [ "${st}" = "connected" ] && CARD="vc4hdmi$((i-1))"
done
if [ -z "${CARD}" ]; then
  echo "No HDMI screen detected: audio left on the system default"; exit 0
fi
[ -f "${RC}" ] && cp "${RC}" "${RC}.bak_$(date +%Y%m%d_%H%M%S)"
cat > "${RC}" <<CONF
# DX Zaza: default audio = screen speakers (HDMI)
pcm.!default { type plug; slave.pcm "hdmi:CARD=${CARD},DEV=0" }
ctl.!default { type hw; card ${CARD} }
CONF
echo "Default audio set to ${CARD}"
