#!/usr/bin/env bash
# Remove the DX Zaza <-> BlueDV integration. Add --remove-bluedv to also delete BlueDV Radio itself.
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Run with sudo." >&2; exit 1; }
systemctl stop bluedv.service 2>/dev/null || true
systemctl disable bluedv.service 2>/dev/null || true
rm -f /usr/local/sbin/dx-zaza-bluedv-ctl /etc/sudoers.d/dx-zaza-bluedv /etc/dx-zaza/bluedv_default_ambe_type
if [ "${1:-}" = "--remove-bluedv" ]; then
  rm -f /etc/systemd/system/bluedv.service /etc/udev/rules.d/99-uacdemo.rules
  rm -rf /usr/local/bluedv
  systemctl daemon-reload
  echo "BlueDV Radio removed."
fi
echo "DX Zaza BlueDV integration removed."
