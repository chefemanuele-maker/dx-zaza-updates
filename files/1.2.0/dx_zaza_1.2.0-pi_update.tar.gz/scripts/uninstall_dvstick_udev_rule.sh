#!/usr/bin/env bash
set -euo pipefail

RULE_NAME="99-dx-zaza-dvmega-ambestick.rules"
TARGET_RULE="/etc/udev/rules.d/99-dx-zaza-dvmega-ambestick.rules"
BACKUP_NAME_PATTERN="${RULE_NAME}.dx-zaza-backup.[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]_[0-9][0-9][0-9][0-9][0-9][0-9]"
SYMLINK_PATH="/dev/dvmega-ambestick"
DRY_RUN=0
RUN_TRIGGER=1
RESTORE_LATEST=0

usage() {
  cat <<EOF
Usage: sudo $0 [--dry-run] [--no-trigger] [--restore-latest]

Removes only the DX Zaza DVMEGA DVstick 30 udev rule candidate.
Use --restore-latest only to restore a timestamped backup created by the DX Zaza installer.
EOF
}

for arg in "$@"; do
  case "${arg}" in
    --dry-run)
      DRY_RUN=1
      ;;
    --no-trigger)
      RUN_TRIGGER=0
      ;;
    --restore-latest)
      RESTORE_LATEST=1
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: ${arg}" >&2
      usage >&2
      exit 2
      ;;
  esac
done

if [ "${DRY_RUN}" -eq 0 ] && [ "$(id -u)" -ne 0 ]; then
  echo "Run with sudo/root to remove the udev rule." >&2
  exit 1
fi

if [ "${DRY_RUN}" -eq 0 ] && ! command -v udevadm >/dev/null 2>&1; then
  echo "udevadm not found; cannot reload udev rules." >&2
  exit 1
fi

LATEST_BACKUP=""
if [ "${RESTORE_LATEST}" -eq 1 ]; then
  LATEST_BACKUP="$(find /etc/udev/rules.d -maxdepth 1 -type f -name "${BACKUP_NAME_PATTERN}" 2>/dev/null | sort -r | sed -n '1p')"
  if [ -z "${LATEST_BACKUP}" ]; then
    echo "No DX Zaza timestamped backup found for restore." >&2
    exit 1
  fi
  case "$(basename "${LATEST_BACKUP}")" in
    ${RULE_NAME}.dx-zaza-backup.[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]_[0-9][0-9][0-9][0-9][0-9][0-9])
      ;;
    *)
      echo "Refusing to restore backup with unexpected name: ${LATEST_BACKUP}" >&2
      exit 1
      ;;
  esac
fi

echo "DX Zaza DVstick udev rule uninstall"
echo "Target: ${TARGET_RULE}"
if [ "${RESTORE_LATEST}" -eq 1 ]; then
  echo "Restore latest DX Zaza backup: ${LATEST_BACKUP}"
else
  echo "Restore latest DX Zaza backup: no"
fi
echo "Reload rules: yes"
if [ "${RUN_TRIGGER}" -eq 1 ]; then
  echo "Trigger tty subsystem: yes"
else
  echo "Trigger tty subsystem: no"
fi

if [ "${DRY_RUN}" -eq 1 ]; then
  if [ -f "${TARGET_RULE}" ]; then
    echo "Planned action: remove target"
  else
    echo "Planned action: target already absent"
  fi
  if [ "${RESTORE_LATEST}" -eq 1 ]; then
    echo "Planned action: restore ${LATEST_BACKUP}"
  fi
  echo "Dry run complete; no system changes made."
  exit 0
fi

if [ -f "${TARGET_RULE}" ]; then
  rm -f "${TARGET_RULE}"
  echo "Rule removed: ${TARGET_RULE}"
else
  echo "Rule already absent: ${TARGET_RULE}"
fi

if [ "${RESTORE_LATEST}" -eq 1 ]; then
  install -o root -g root -m 0644 "${LATEST_BACKUP}" "${TARGET_RULE}"
  echo "Restored DX Zaza backup: ${TARGET_RULE}"
fi

udevadm control --reload-rules
echo "udev reload completed."

if [ "${RUN_TRIGGER}" -eq 1 ]; then
  udevadm trigger --subsystem-match=tty
  echo "udev tty trigger completed."
fi

if [ -L "${SYMLINK_PATH}" ]; then
  echo "Symlink currently present: ${SYMLINK_PATH}"
else
  echo "Symlink currently absent: ${SYMLINK_PATH}"
fi
