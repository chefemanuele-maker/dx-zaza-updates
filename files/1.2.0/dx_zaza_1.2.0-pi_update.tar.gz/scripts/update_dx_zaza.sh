#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/dx-zaza}"
CONFIG_DIR="${CONFIG_DIR:-/etc/dx-zaza}"
CONFIG_FILE="${CONFIG_FILE:-${CONFIG_DIR}/config.local.json}"
BACKUP_ROOT="${BACKUP_ROOT:-${APP_DIR}/backups}"
LOG_DIR="${LOG_DIR:-/var/log/dx-zaza}"
LOG_FILE="${LOG_FILE:-${LOG_DIR}/update.log}"
SERVICE_NAME="${SERVICE_NAME:-dx-zaza}"
KIOSK_SERVICE_NAME="${KIOSK_SERVICE_NAME:-dx-zaza-kiosk}"
BUNDLE_DIR="${BUNDLE_DIR:-/tmp/dx-zaza-update}"
REPO_URL="${DX_ZAZA_REPO_URL:-}"
BRANCH="${DX_ZAZA_BRANCH:-main}"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="${BACKUP_ROOT}/${TIMESTAMP}"

log() {
  printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" | tee -a "${LOG_FILE}"
}

require_root() {
  if [ "$(id -u)" -ne 0 ]; then
    echo "Run with sudo/root." >&2
    exit 1
  fi
}

current_version() {
  if [ -f "${APP_DIR}/VERSION" ]; then
    tr -d '\r\n' < "${APP_DIR}/VERSION"
  else
    echo "unknown"
  fi
}

prepare_dirs() {
  mkdir -p "${LOG_DIR}" "${BACKUP_ROOT}"
  touch "${LOG_FILE}"
}

create_backup() {
  log "Creating backup: ${BACKUP_DIR}"
  mkdir -p "${BACKUP_DIR}/app" "${BACKUP_DIR}/etc"
  if [ -d "${APP_DIR}" ]; then
    rsync -a --delete --exclude ".venv" --exclude "backups" "${APP_DIR}/" "${BACKUP_DIR}/app/"
  fi
  local unit
  for unit in "${SERVICE_NAME}.service" "${KIOSK_SERVICE_NAME}.service"; do
    [ -f "/etc/systemd/system/${unit}" ] && cp "/etc/systemd/system/${unit}" "${BACKUP_DIR}/etc/${unit}" || true
  done
  if [ -f "${CONFIG_FILE}" ]; then
    cp "${CONFIG_FILE}" "${BACKUP_DIR}/etc/config.local.json"
    chmod 600 "${BACKUP_DIR}/etc/config.local.json" || true
  fi
}

stop_service() {
  log "Stopping ${SERVICE_NAME}.service"
  systemctl stop "${SERVICE_NAME}.service" || true
}

stop_kiosk_service() {
  log "Stopping ${KIOSK_SERVICE_NAME}.service"
  systemctl stop "${KIOSK_SERVICE_NAME}.service" || true
}

start_service() {
  log "Starting ${SERVICE_NAME}.service"
  systemctl start "${SERVICE_NAME}.service"
}

start_kiosk_service_if_enabled() {
  if systemctl is-enabled "${KIOSK_SERVICE_NAME}.service" >/dev/null 2>&1; then
    log "Starting ${KIOSK_SERVICE_NAME}.service"
    systemctl restart "${KIOSK_SERVICE_NAME}.service" || true
  else
    log "${KIOSK_SERVICE_NAME}.service is not enabled; leaving kiosk stopped"
  fi
}

copy_update_bundle() {
  local source_dir="$1"
  log "Applying update bundle from ${source_dir}"
  mkdir -p "${APP_DIR}"
  rsync -a --delete "${source_dir}/services/" "${APP_DIR}/services/"
  rsync -a --delete "${source_dir}/dx_zaza_webapp/" "${APP_DIR}/dx_zaza_webapp/"
  local extra
  for extra in voice udev kiosk docs; do
    if [ -d "${source_dir}/${extra}" ]; then
      mkdir -p "${APP_DIR}/${extra}"
      rsync -a --delete "${source_dir}/${extra}/" "${APP_DIR}/${extra}/"
    fi
  done
  [ -f "${source_dir}/config.example.json" ] && cp "${source_dir}/config.example.json" "${APP_DIR}/config.example.json"
  [ -f "${source_dir}/RELEASE_NOTES.md" ] && cp "${source_dir}/RELEASE_NOTES.md" "${APP_DIR}/RELEASE_NOTES.md"
  cp "${source_dir}/app.py" "${APP_DIR}/app.py"
  cp "${source_dir}/requirements.txt" "${APP_DIR}/requirements.txt"
  cp "${source_dir}/VERSION" "${APP_DIR}/VERSION"
  if [ -d "${source_dir}/systemd" ]; then
    mkdir -p "${APP_DIR}/systemd"
    rsync -a "${source_dir}/systemd/" "${APP_DIR}/systemd/"
  fi
  if [ -d "${source_dir}/scripts" ]; then
    mkdir -p "${APP_DIR}/scripts"
    rsync -a "${source_dir}/scripts/" "${APP_DIR}/scripts/"
    chmod +x "${APP_DIR}"/scripts/*.sh 2>/dev/null || true
  fi
  rm -f "${APP_DIR}/config.local.json"
}

install_systemd_services_if_present() {
  local service_user
  service_user="$(systemctl show -p User --value "${SERVICE_NAME}.service" 2>/dev/null || true)"
  if [ -z "${service_user}" ] || [ "${service_user}" = "root" ]; then
    service_user="$(stat -c '%U' "${APP_DIR}" 2>/dev/null || echo pi)"
  fi

  if [ -f "${APP_DIR}/systemd/dx-zaza.service" ]; then
    log "Installing ${SERVICE_NAME}.service"
    cp "${APP_DIR}/systemd/dx-zaza.service" "/etc/systemd/system/${SERVICE_NAME}.service"
    sed -i "s/^User=.*/User=${service_user}/" "/etc/systemd/system/${SERVICE_NAME}.service"
  fi

  if [ -f "${APP_DIR}/systemd/dx-zaza-kiosk.service" ]; then
    log "Installing ${KIOSK_SERVICE_NAME}.service"
    cp "${APP_DIR}/systemd/dx-zaza-kiosk.service" "/etc/systemd/system/${KIOSK_SERVICE_NAME}.service"
  fi

  systemctl daemon-reload
  if [ -f "/etc/systemd/system/${SERVICE_NAME}.service" ]; then
    systemctl enable "${SERVICE_NAME}.service"
  fi
  if [ -f "/etc/systemd/system/${KIOSK_SERVICE_NAME}.service" ]; then
    systemctl enable "${KIOSK_SERVICE_NAME}.service"
  fi
}

install_system_packages() {
  # PortAudio is needed by the built-in DVstick voice engine (speaker / microphone)
  if dpkg -s libportaudio2 >/dev/null 2>&1; then
    log "libportaudio2 already installed"
  else
    log "Installing libportaudio2 (audio for Digital Voice)"
    apt-get install -y libportaudio2 >>"${LOG_FILE}" 2>&1 || \
      { apt-get update >>"${LOG_FILE}" 2>&1 && apt-get install -y libportaudio2 >>"${LOG_FILE}" 2>&1; } || \
      log "WARNING: libportaudio2 not installed; Digital Voice audio will be unavailable until it is"
  fi
}

clear_kiosk_browser_cache() {
  # the kiosk Chromium keeps a disk cache: drop it so the new pages and scripts load
  local profile="/home/pi/.config/dx-zaza-chromium"
  if [ -d "${profile}" ]; then
    log "Clearing kiosk browser cache"
    rm -rf "${profile}/Default/Cache" "${profile}/Default/Code Cache" "${profile}/Default/GPUCache" || true
  fi
}

setup_kiosk_if_present() {
  if [ "${SETUP_KIOSK:-0}" != "1" ]; then
    log "Keeping the existing kiosk start script (set SETUP_KIOSK=1 to reinstall it)"
    return 0
  fi
  if [ -x "${APP_DIR}/scripts/setup_kiosk_autostart.sh" ]; then
    log "Installing kiosk start script and disabling legacy DX Zaza autostart"
    SERVICE_USER=pi "${APP_DIR}/scripts/setup_kiosk_autostart.sh"
  else
    log "Kiosk setup script not present; skipping kiosk start script refresh"
  fi
}

install_wifi_helper_if_present() {
  if [ ! -f "${APP_DIR}/scripts/dx_zaza_wifi_helper.py" ]; then
    log "Wi-Fi helper not present in bundle; skipping helper install"
    return 0
  fi
  local service_user
  service_user="$(systemctl show -p User --value "${SERVICE_NAME}.service" 2>/dev/null || true)"
  if [ -z "${service_user}" ] || [ "${service_user}" = "root" ]; then
    service_user="$(stat -c '%U' "${APP_DIR}" 2>/dev/null || echo pi)"
  fi
  install -o root -g root -m 0755 "${APP_DIR}/scripts/dx_zaza_wifi_helper.py" /usr/local/sbin/dx-zaza-wifi-helper
  cat > /etc/sudoers.d/dx-zaza-wifi-helper <<EOF
${service_user} ALL=(root) NOPASSWD: /usr/local/sbin/dx-zaza-wifi-helper
EOF
  chmod 0440 /etc/sudoers.d/dx-zaza-wifi-helper
  visudo -cf /etc/sudoers.d/dx-zaza-wifi-helper >/dev/null
  log "Installed restricted Wi-Fi helper for ${service_user}"
}

install_system_controls() {
  # lets DX Zaza (user pi) reboot the Pi and restart its own services from the touchscreen
  local service_user
  service_user="$(stat -c '%U' "${APP_DIR}" 2>/dev/null || echo pi)"
  cat > /etc/sudoers.d/dx-zaza-system <<EOF
${service_user} ALL=(root) NOPASSWD: /usr/sbin/reboot, /usr/bin/systemctl restart dx-zaza.service, /usr/bin/systemctl restart dx-zaza-kiosk.service
EOF
  chmod 0440 /etc/sudoers.d/dx-zaza-system
  if visudo -cf /etc/sudoers.d/dx-zaza-system >/dev/null; then
    log "Installed system controls (reboot / restart) for ${service_user}"
  else
    rm -f /etc/sudoers.d/dx-zaza-system
    log "WARNING: system controls rule rejected by visudo; removed"
  fi
}

install_update_helper() {
  # one-button online updates: the app (user pi) may run only this root-owned helper, which
  # re-checks the update signature before applying anything
  if [ ! -f "${APP_DIR}/scripts/dx_zaza_update_helper.py" ] || [ ! -f "${APP_DIR}/services/ed25519.py" ]; then
    log "Online update helper not present in bundle; skipping"
    return 0
  fi
  local service_user
  service_user="$(stat -c '%U' "${APP_DIR}" 2>/dev/null || echo pi)"
  install -d -o root -g root -m 0755 /usr/local/lib/dx-zaza
  install -o root -g root -m 0644 "${APP_DIR}/services/ed25519.py" /usr/local/lib/dx-zaza/ed25519.py
  install -o root -g root -m 0755 "${APP_DIR}/scripts/dx_zaza_update_helper.py" /usr/local/sbin/dx-zaza-online-update
  cat > /etc/sudoers.d/dx-zaza-online-update <<EOF
${service_user} ALL=(root) NOPASSWD: /usr/local/sbin/dx-zaza-online-update
EOF
  chmod 0440 /etc/sudoers.d/dx-zaza-online-update
  if visudo -cf /etc/sudoers.d/dx-zaza-online-update >/dev/null; then
    log "Installed online update helper for ${service_user}"
  else
    rm -f /etc/sudoers.d/dx-zaza-online-update
    log "WARNING: online update rule rejected by visudo; removed"
  fi
}

fix_ownership() {
  # files written as root during the update (e.g. Python caches) must stay editable by the app user
  local service_user
  service_user="$(stat -c '%U' "${APP_DIR}" 2>/dev/null || echo pi)"
  chown -R "${service_user}:${service_user}" "${APP_DIR}/services" "${APP_DIR}/voice" "${APP_DIR}/dx_zaza_webapp" \
    "${APP_DIR}/scripts" "${APP_DIR}/app.py" "${APP_DIR}/VERSION" 2>/dev/null || true
}

install_requirements_if_needed() {
  if [ -d "${APP_DIR}/.venv" ] && [ -x "${APP_DIR}/.venv/bin/pip" ]; then
    log "Installing requirements in existing virtualenv"
    "${APP_DIR}/.venv/bin/pip" install -r "${APP_DIR}/requirements.txt"
  else
    log "Creating virtualenv"
    python3 -m venv "${APP_DIR}/.venv"
    "${APP_DIR}/.venv/bin/pip" install --upgrade pip
    "${APP_DIR}/.venv/bin/pip" install -r "${APP_DIR}/requirements.txt"
  fi
}

verify_code() {
  log "Verifying Python files"
  "${APP_DIR}/.venv/bin/python" -c "import ast,sys; [ast.parse(open(f).read(), f) for f in sys.argv[1:]]" "${APP_DIR}/app.py" "${APP_DIR}"/services/*.py
  if [ -d "${APP_DIR}/voice" ]; then
    "${APP_DIR}/.venv/bin/python" -c "import ast,sys; [ast.parse(open(f).read(), f) for f in sys.argv[1:]]" "${APP_DIR}"/voice/*.py
  fi
  if command -v node >/dev/null 2>&1; then
    log "Verifying frontend JavaScript"
    node --check "${APP_DIR}/dx_zaza_webapp/js/cybernode-zumspot.js"
  else
    log "Node not installed; skipping JavaScript syntax check"
  fi
}

health_check() {
  log "Running health check"
  for _ in $(seq 1 20); do
    if curl -fsS --max-time 5 "http://127.0.0.1:5050/api/status" >/dev/null; then
      curl -fsS --max-time 5 "http://127.0.0.1:5050/api/settings" >/dev/null || true
      return 0
    fi
    sleep 1
  done
  return 1
}

rollback_from_backup() {
  log "Rolling back from ${BACKUP_DIR}"
  systemctl stop "${KIOSK_SERVICE_NAME}.service" || true
  systemctl stop "${SERVICE_NAME}.service" || true
  if [ -d "${BACKUP_DIR}/app" ]; then
    rsync -a --delete --exclude ".venv" --exclude "backups" "${BACKUP_DIR}/app/" "${APP_DIR}/"
  fi
  if [ -d "${APP_DIR}/.venv" ]; then
    "${APP_DIR}/.venv/bin/pip" install -r "${APP_DIR}/requirements.txt" || true
  fi
  systemctl daemon-reload || true
  systemctl start "${SERVICE_NAME}.service" || true
  start_kiosk_service_if_enabled
}

cleanup_backups() {
  log "Keeping latest 5 backups"
  find "${BACKUP_ROOT}" -mindepth 1 -maxdepth 1 -type d | sort -r | tail -n +6 | xargs -r rm -rf
}

main() {
  require_root
  prepare_dirs
  log "DX Zaza update started. Current version: $(current_version)"
  log "Config protected: ${CONFIG_FILE}"

  if [ ! -d "${APP_DIR}" ]; then
    log "App directory not found: ${APP_DIR}"
    exit 1
  fi

  create_backup
  stop_kiosk_service
  stop_service

  if [ -d "${BUNDLE_DIR}" ]; then
    copy_update_bundle "${BUNDLE_DIR}"
  elif [ -n "${REPO_URL}" ]; then
    log "Git update placeholder configured for branch ${BRANCH}. No credentials are stored in this script."
    log "Clone/pull workflow must be wired to a private repo over Tailscale/private SSH before use."
    exit 1
  else
    log "No repo URL configured. Use this script after setting DX_ZAZA_REPO_URL or copy an update bundle into /tmp/dx-zaza-update."
    start_service || true
    start_kiosk_service_if_enabled
    exit 1
  fi

  install_system_packages
  install_requirements_if_needed
  install_wifi_helper_if_present
  install_system_controls
  install_update_helper
  install_systemd_services_if_present
  if [ -x "${APP_DIR}/scripts/setup_pi_audio.sh" ]; then
    log "Audio: default output to the HDMI screen (only if not configured yet)"
    sudo -u pi -H "${APP_DIR}/scripts/setup_pi_audio.sh" >>"${LOG_FILE}" 2>&1 || true
  fi
  setup_kiosk_if_present
  clear_kiosk_browser_cache
  verify_code
  fix_ownership
  start_service
  start_kiosk_service_if_enabled

  if health_check; then
    log "Update OK. New version: $(current_version)"
    cleanup_backups
  else
    log "Health check failed; starting rollback"
    rollback_from_backup
    if health_check; then
      log "Rollback OK. Restored version: $(current_version)"
    else
      log "Rollback health check failed. Manual service review required."
    fi
    exit 1
  fi
}

main "$@"
