import copy
import json
import os
import sys
from pathlib import Path

from services.digital_voice_config_service import get_digital_voice_config
from services.dvstick_ownership_service import get_dvstick_ownership


EXTERNAL_AMBE_BINARY_PATH = "/usr/local/ambeserver3k/ambeserver"
PHASE_2B5_EXECUTION_ENABLED = False


def _deep_merge(base, override):
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value
    return base


def _load_json(path):
    try:
        with Path(path).open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def load_runtime_config():
    app_dir = Path(__file__).resolve().parents[1]
    config = _load_json(app_dir / "config.example.json")
    env_config = os.environ.get("DX_ZAZA_CONFIG", "").strip()
    local_config = _load_json(env_config) if env_config else _load_json(app_dir / "config.local.json")
    if isinstance(config, dict) and isinstance(local_config, dict):
        return _deep_merge(config, local_config)
    return config if isinstance(config, dict) else {}


def _binary_status(binary_path):
    present = os.path.exists(binary_path)
    regular_file = os.path.isfile(binary_path)
    executable = regular_file and os.access(binary_path, os.X_OK)
    return {
        "present": present,
        "external": True,
        "regular_file": regular_file,
        "executable": executable,
    }


def _configuration_reasons(validation):
    reasons = []
    issue_map = {
        "ambe_server.bind_address_invalid": "bind_not_local",
        "ambe_server.network_invalid": "network_not_udp",
        "ambe_server.port_invalid": "invalid_port",
        "ambe_server.serial_speed_invalid": "invalid_serial_speed",
    }
    for issue in validation.get("issues", []):
        mapped = issue_map.get(issue)
        if mapped and mapped not in reasons:
            reasons.append(mapped)
    return reasons


def _ownership_reasons(ownership):
    owner = ownership.get("owner")
    if not ownership.get("stable_device_ready"):
        return ["stable_device_missing"]
    if owner == "free" and not ownership.get("hardware_in_use"):
        return []
    if owner == "blue_dv":
        return ["device_owned_by_blue_dv", "device_busy"]
    if owner == "conflict":
        return ["device_conflict", "device_busy"]
    if owner in ("unknown_process", "device_absent"):
        return ["device_owner_unknown", "device_busy"]
    return ["device_busy"]


def get_ambe_server_preflight(config=None, ownership=None, binary_path=EXTERNAL_AMBE_BINARY_PATH):
    validation = get_digital_voice_config(config if config is not None else load_runtime_config())
    normalized = validation["config"]
    ambe_config = normalized.get("ambe_server", {})
    ownership = ownership or get_dvstick_ownership()
    binary = _binary_status(binary_path)
    reasons = []

    if not validation["valid"]:
        reasons.append("configuration_invalid")
    reasons.extend(_configuration_reasons(validation))

    if not ambe_config.get("enabled"):
        reasons.append("ambe_server_disabled")

    reasons.extend(_ownership_reasons(ownership))

    if not binary["present"]:
        reasons.append("external_binary_missing")
    elif not binary["regular_file"]:
        reasons.append("external_binary_not_regular")
    elif not binary["executable"]:
        reasons.append("external_binary_not_executable")

    if ambe_config.get("bind_address") != "127.0.0.1":
        reasons.append("bind_not_local")
    if ambe_config.get("network") != "udp":
        reasons.append("network_not_udp")
    if not isinstance(ambe_config.get("port"), int) or not (1 <= ambe_config.get("port") <= 65535):
        reasons.append("invalid_port")
    if ambe_config.get("serial_speed") != 460800:
        reasons.append("invalid_serial_speed")

    unique_reasons = []
    for reason in reasons:
        if reason not in unique_reasons:
            unique_reasons.append(reason)

    can_start = (
        validation["valid"]
        and ambe_config.get("enabled") is True
        and ownership.get("stable_device_ready") is True
        and ownership.get("owner") == "free"
        and ownership.get("hardware_in_use") is False
        and binary["present"]
        and binary["regular_file"]
        and binary["executable"]
        and ambe_config.get("bind_address") == "127.0.0.1"
        and ambe_config.get("network") == "udp"
        and isinstance(ambe_config.get("port"), int)
        and 1 <= ambe_config.get("port") <= 65535
        and ambe_config.get("serial_speed") == 460800
    )

    return {
        "ok": True,
        "can_start": can_start,
        "execution_enabled": PHASE_2B5_EXECUTION_ENABLED,
        "reasons": unique_reasons,
        "binary": binary,
        "device": {
            "stable_ready": bool(ownership.get("stable_device_ready")),
            "busy": bool(ownership.get("hardware_in_use")),
            "owner": ownership.get("owner", "unknown_process"),
        },
        "configuration": {
            "valid": bool(validation["valid"]),
            "issues": copy.deepcopy(validation.get("issues", [])),
        },
    }


def main():
    result = get_ambe_server_preflight()
    print(json.dumps(result, sort_keys=True))
    return 0 if result.get("can_start") else 1


if __name__ == "__main__":
    sys.exit(main())
