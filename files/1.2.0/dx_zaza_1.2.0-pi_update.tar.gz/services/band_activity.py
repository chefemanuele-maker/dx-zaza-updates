"""Live HF band activity, computed by DX Zaza from the DX cluster spots it receives.

Every spot is real evidence that a band is open: someone (the spotter) is hearing a station (the
DX) on that band right now. For each band, over the last WINDOW minutes, this counts the spots,
the different DX stations and countries, the longest path, and above all the spots heard by
stations NEAR THE OPERATOR (spotter within NEAR_KM of the QTH): those tell what the operator's
own antenna can most likely hear. No third-party forecast is used, so there is nothing to license.
"""

import collections
import math
import threading
import time

HF_BANDS = ["160m", "80m", "60m", "40m", "30m", "20m", "17m", "15m", "12m", "10m", "6m"]
WINDOW = 15 * 60
KEEP = 60 * 60
NEAR_KM = 2000


def _distance_km(lat1, lon1, lat2, lon2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 6371.0 * 2 * math.atan2(math.sqrt(a), math.sqrt(max(0.0, 1 - a)))


def rating(near, total, has_home):
    """Excellent / Good / Fair / Quiet / Closed, from the spots heard near the operator (or, with no
    QTH, from all spots)."""
    n = near if has_home else total / 3.0
    if n >= 10:
        return "excellent"
    if n >= 4:
        return "good"
    if n >= 1:
        return "fair"
    if total > 0:
        return "far"          # open elsewhere in the world, nothing heard near you yet
    return "closed"


class BandActivity:
    def __init__(self, clock=time.time):
        self.clock = clock
        self.lock = threading.Lock()
        self.items = collections.deque()
        self.started = clock()

    def record(self, spot, when=None):
        band = spot.get("band")
        if band not in HF_BANDS:
            return
        when = self.clock() if when is None else when
        if self.clock() - when > KEEP:
            return
        item = (when, band, spot.get("lat"), spot.get("lon"), spot.get("dxLat"), spot.get("dxLon"),
                spot.get("dxCountry") or "", str(spot.get("dx") or ""), str(spot.get("mode") or ""))
        with self.lock:
            self.items.append(item)
            cutoff = self.clock() - KEEP
            while self.items and self.items[0][0] < cutoff:
                self.items.popleft()

    def summary(self, home=None, window=WINDOW):
        now = self.clock()
        with self.lock:
            items = [i for i in self.items if now - i[0] <= window]
        bands = {b: {"band": b, "spots": 0, "near": 0, "dx": set(), "countries": set(), "maxKm": 0,
                     "modes": collections.Counter()} for b in HF_BANDS}
        for when, band, de_lat, de_lon, dx_lat, dx_lon, country, dx, mode in items:
            b = bands[band]
            b["spots"] += 1
            b["dx"].add(dx)
            if country:
                b["countries"].add(country)
            if mode:
                b["modes"][mode] += 1
            if None not in (de_lat, de_lon, dx_lat, dx_lon):
                b["maxKm"] = max(b["maxKm"], int(_distance_km(de_lat, de_lon, dx_lat, dx_lon)))
            if home and None not in (de_lat, de_lon) and _distance_km(home[0], home[1], de_lat, de_lon) <= NEAR_KM:
                b["near"] += 1
        out = []
        for name in HF_BANDS:
            b = bands[name]
            out.append({
                "band": name, "spots": b["spots"], "near": b["near"], "stations": len(b["dx"]),
                "countries": len(b["countries"]), "maxKm": b["maxKm"],
                "modes": [m for m, _ in b["modes"].most_common(3)],
                "rating": rating(b["near"], b["spots"], bool(home)),
                "score": b["near"] * 3 + b["spots"] + len(b["countries"]),
            })
        best = [b["band"] for b in sorted(out, key=lambda b: -b["score"]) if b["score"] > 0][:3]
        return {
            "ok": True,
            "source": "DX cluster (DX Zaza live analysis)",
            "windowMinutes": window // 60,
            "warmingUp": now - self.started < window and not items,
            "nearKm": NEAR_KM if home else None,
            "totalSpots": len(items),
            "best": best,
            "bands": out,
        }
