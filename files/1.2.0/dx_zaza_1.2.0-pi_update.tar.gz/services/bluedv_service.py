"""BlueDV Radio integration (PA7LIM) for DX Zaza.

BlueDV Radio is external, free software by PA7LIM. DX Zaza never bundles it:
`scripts/install_bluedv_radio.sh` downloads it from the official site.

DX Zaza Core still never opens the DVstick serial device. It only:
- reports whether BlueDV Radio is installed / running / reachable,
- reports who owns the DVstick (via dvstick_ownership_service),
- asks the root helper `dx-zaza-bluedv-ctl` (sudoers-limited) to start or stop
  bluedv.service on an explicit user action. Starting BlueDV in "direct" mode stops
  the DX Zaza AMBE Server first, so only one program owns the DVstick at a time.
"""

import configparser
import os
import shutil
import socket
import subprocess
from pathlib import Path

from services.dvstick_ownership_service import get_customer_safe_ownership, get_dvstick_ownership

BLUEDV_DIR = Path(os.environ.get("DX_ZAZA_BLUEDV_DIR", "/usr/local/bluedv"))
BLUEDV_BINARY = BLUEDV_DIR / "bluedv-radio"
BLUEDV_CONFIG = BLUEDV_DIR / "config.ini"
BLUEDV_SERVICE = "bluedv.service"
AMBE_SERVICE = "dx-zaza-ambe-server.service"
HELPER = "/usr/local/sbin/dx-zaza-bluedv-ctl"
COMMAND_TIMEOUT_SECONDS = 25


def _bluedv_settings(config):
    dv = (config or {}).get("digital_voice", {}) or {}
    blue = dv.get("blue_dv", {}) or {}
    return {
        "web_port": int(blue.get("web_port", 8080) or 8080),
        "mode": blue.get("ambe_mode", "direct") if blue.get("ambe_mode") in ("direct", "ambe_server") else "direct",
    }


def _systemctl(*args):
    if not shutil.which("systemctl"):
        return None
    try:
        out = subprocess.run(["systemctl", *args], capture_output=True, text=True, timeout=5)
        return out.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return None


def _port_open(port, host="127.0.0.1", timeout=0.6):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _read_ini():
    if not BLUEDV_CONFIG.exists():
        return None
    parser = configparser.ConfigParser(strict=False, interpolation=None)
    try:
        parser.read(BLUEDV_CONFIG, encoding="utf-8")
    except (configparser.Error, OSError):
        return None
    return parser


def get_bluedv_status(config=None):
    settings = _bluedv_settings(config)
    installed = BLUEDV_BINARY.exists()
    active = _systemctl("is-active", BLUEDV_SERVICE)
    enabled = _systemctl("is-enabled", BLUEDV_SERVICE)
    ambe_active = _systemctl("is-active", AMBE_SERVICE)
    running = active == "active"
    web_ready = running and _port_open(settings["web_port"])
    ownership = get_customer_safe_ownership(get_dvstick_ownership())
    ini = _read_ini()
    ambe_type = ""
    callsign_set = False
    default_password = False
    if ini is not None:
        ambe_type = ini.get("AMBE", "Type", fallback="").strip()
        callsign_set = bool(ini.get("GENERAL", "call", fallback="").strip())
        default_password = not ini.get("WEB", "PasswordHash", fallback="").strip()

    if not installed:
        state, message = "not_installed", "BlueDV Radio is not installed on this DX Zaza."
    elif running and web_ready:
        state, message = "running", "BlueDV Radio is running."
    elif running:
        state, message = "starting", "BlueDV Radio is starting..."
    elif ownership["hardware_owner"] in ("ambe_server",) and settings["mode"] == "direct":
        state, message = "stopped", "BlueDV is stopped. Starting it will stop the AMBE Server (one DVstick owner at a time)."
    elif ownership["hardware_owner"] == "busy":
        state, message = "blocked", "The DVstick is in use by another program."
    else:
        state, message = "stopped", "BlueDV Radio is stopped."

    return {
        "ok": True,
        "installed": installed,
        "state": state,
        "message": message,
        "running": running,
        "enabled_at_boot": enabled == "enabled",
        "web_ready": web_ready,
        "web_port": settings["web_port"],
        "ambe_mode": settings["mode"],
        "ambe_type": ambe_type,
        "ambe_server_running": ambe_active == "active",
        "callsign_configured": callsign_set,
        "default_password": default_password if installed else False,
        "dvstick": ownership,
        "helper_installed": Path(HELPER).exists(),
        "credit": "BlueDV Radio by PA7LIM - https://www.pa7lim.nl/bluedv-dv-radio/",
    }


def control_bluedv(action, config=None):
    if action not in ("start", "stop"):
        return {"ok": False, "error": "Unknown action"}
    if not BLUEDV_BINARY.exists():
        return {"ok": False, "error": "BlueDV Radio is not installed. Run scripts/install_bluedv_radio.sh on the Raspberry Pi."}
    if not Path(HELPER).exists():
        return {"ok": False, "error": "DX Zaza BlueDV helper is not installed."}
    mode = _bluedv_settings(config)["mode"]
    try:
        out = subprocess.run(["sudo", "-n", HELPER, action, mode], capture_output=True, text=True,
                             timeout=COMMAND_TIMEOUT_SECONDS)
    except (OSError, subprocess.SubprocessError) as exc:
        return {"ok": False, "error": type(exc).__name__}
    if out.returncode != 0:
        return {"ok": False, "error": (out.stderr or out.stdout or "Helper failed").strip()[-300:]}
    return {"ok": True, "message": (out.stdout or "").strip()[-300:], "status": get_bluedv_status(config)}
