import time
from threading import RLock


class TTLCache:
    def __init__(self):
        self._items = {}
        self._lock = RLock()

    def get(self, key):
        now = time.time()
        with self._lock:
            item = self._items.get(key)
            if not item:
                return None
            expires_at, value = item
            if expires_at <= now:
                self._items.pop(key, None)
                return None
            return value

    def set(self, key, value, ttl_seconds):
        expires_at = time.time() + max(1, int(ttl_seconds))
        with self._lock:
            self._items[key] = (expires_at, value)
        return value

    def clear(self):
        with self._lock:
            self._items.clear()


cache = TTLCache()
