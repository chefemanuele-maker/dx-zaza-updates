import copy


DEFAULT_DIGITAL_VOICE_CONFIG = {
    "tx_enabled": False,
    "ambe_server": {
        "enabled": False,
        "device": "/dev/dvmega-ambestick",
        "bind_address": "127.0.0.1",
        "port": 2460,
        "serial_speed": 460800,
        "network": "udp",
    },
    "blue_dv": {
        "enabled": False,
        "mode": "external",
        "uses_ambe_server": False,
    },
    "audio": {
        "enabled": False,
        "input_device": "",
        "output_device": "",
    },
}

LOCAL_BIND_ALIASES = {
    "127.0.0.1": "127.0.0.1",
    "localhost": "127.0.0.1",
}
ALLOWED_SERIAL_SPEEDS = {460800}
ALLOWED_NETWORKS = {"udp"}
ALLOWED_BLUE_DV_MODES = {"external"}


def _is_bool(value):
    return isinstance(value, bool)


def _is_int(value):
    return type(value) is int


def _source_section(config):
    if not isinstance(config, dict):
        return {}
    value = config.get("digital_voice", {})
    return value if isinstance(value, dict) else {}


def _copy_defaults():
    return copy.deepcopy(DEFAULT_DIGITAL_VOICE_CONFIG)


def _nested(source, key, issues):
    value = source.get(key, {})
    if value is None:
        return {}
    if not isinstance(value, dict):
        issues.append(f"{key}.invalid_object")
        return {}
    return value


def _bool_value(source, key, default, issue_key, issues):
    if key not in source:
        return default
    value = source.get(key)
    if not _is_bool(value):
        issues.append(issue_key)
        return default
    return value


def _string_value(source, key, default, issue_key, issues, allow_empty=False):
    if key not in source:
        return default
    value = source.get(key)
    if not isinstance(value, str):
        issues.append(issue_key)
        return default
    if not allow_empty and not value.strip():
        issues.append(issue_key)
        return default
    return value.strip() if not allow_empty else value


def _port_value(source, default, issues):
    if "port" not in source:
        return default
    value = source.get("port")
    if not _is_int(value) or not (1 <= value <= 65535):
        issues.append("ambe_server.port_invalid")
        return default
    return value


def _serial_speed_value(source, default, issues):
    if "serial_speed" not in source:
        return default
    value = source.get("serial_speed")
    if not _is_int(value) or value not in ALLOWED_SERIAL_SPEEDS:
        issues.append("ambe_server.serial_speed_invalid")
        return default
    return value


def _bind_address_value(source, default, issues):
    if "bind_address" not in source:
        return default
    value = source.get("bind_address")
    if not isinstance(value, str):
        issues.append("ambe_server.bind_address_invalid")
        return default
    normalized = value.strip().lower()
    if normalized in LOCAL_BIND_ALIASES:
        return LOCAL_BIND_ALIASES[normalized]
    issues.append("ambe_server.bind_address_invalid")
    return default


def _network_value(source, default, issues):
    value = _string_value(
        source,
        "network",
        default,
        "ambe_server.network_invalid",
        issues,
    ).lower()
    if value not in ALLOWED_NETWORKS:
        issues.append("ambe_server.network_invalid")
        return default
    return value


def _blue_dv_mode_value(source, default, issues):
    value = _string_value(
        source,
        "mode",
        default,
        "blue_dv.mode_invalid",
        issues,
    ).lower()
    if value not in ALLOWED_BLUE_DV_MODES:
        issues.append("blue_dv.mode_invalid")
        return default
    return value


def validate_digital_voice_config(config):
    config = config if isinstance(config, dict) else {}
    source = _source_section(config)
    normalized = _copy_defaults()
    issues = []

    if "digital_voice" in config and not isinstance(config.get("digital_voice"), dict):
        issues.append("digital_voice.invalid_object")

    normalized["tx_enabled"] = _bool_value(
        source,
        "tx_enabled",
        False,
        "digital_voice.tx_enabled_invalid",
        issues,
    )

    ambe_source = _nested(source, "ambe_server", issues)
    normalized["ambe_server"]["enabled"] = _bool_value(
        ambe_source,
        "enabled",
        False,
        "ambe_server.enabled_invalid",
        issues,
    )
    normalized["ambe_server"]["device"] = _string_value(
        ambe_source,
        "device",
        DEFAULT_DIGITAL_VOICE_CONFIG["ambe_server"]["device"],
        "ambe_server.device_invalid",
        issues,
    )
    normalized["ambe_server"]["bind_address"] = _bind_address_value(
        ambe_source,
        DEFAULT_DIGITAL_VOICE_CONFIG["ambe_server"]["bind_address"],
        issues,
    )
    normalized["ambe_server"]["port"] = _port_value(
        ambe_source,
        DEFAULT_DIGITAL_VOICE_CONFIG["ambe_server"]["port"],
        issues,
    )
    normalized["ambe_server"]["serial_speed"] = _serial_speed_value(
        ambe_source,
        DEFAULT_DIGITAL_VOICE_CONFIG["ambe_server"]["serial_speed"],
        issues,
    )
    normalized["ambe_server"]["network"] = _network_value(
        ambe_source,
        DEFAULT_DIGITAL_VOICE_CONFIG["ambe_server"]["network"],
        issues,
    )

    blue_dv_source = _nested(source, "blue_dv", issues)
    normalized["blue_dv"]["enabled"] = _bool_value(
        blue_dv_source,
        "enabled",
        False,
        "blue_dv.enabled_invalid",
        issues,
    )
    normalized["blue_dv"]["mode"] = _blue_dv_mode_value(
        blue_dv_source,
        DEFAULT_DIGITAL_VOICE_CONFIG["blue_dv"]["mode"],
        issues,
    )
    normalized["blue_dv"]["uses_ambe_server"] = _bool_value(
        blue_dv_source,
        "uses_ambe_server",
        False,
        "blue_dv.uses_ambe_server_invalid",
        issues,
    )

    audio_source = _nested(source, "audio", issues)
    normalized["audio"]["enabled"] = _bool_value(
        audio_source,
        "enabled",
        False,
        "audio.enabled_invalid",
        issues,
    )
    normalized["audio"]["input_device"] = _string_value(
        audio_source,
        "input_device",
        "",
        "audio.input_device_invalid",
        issues,
        allow_empty=True,
    )
    normalized["audio"]["output_device"] = _string_value(
        audio_source,
        "output_device",
        "",
        "audio.output_device_invalid",
        issues,
        allow_empty=True,
    )

    return {
        "config": normalized,
        "valid": not issues,
        "issues": issues,
        "effective_tx_enabled": False,
    }


def get_digital_voice_config(config):
    return validate_digital_voice_config(config if isinstance(config, dict) else {})


def sanitize_digital_voice_config_for_api(config):
    result = get_digital_voice_config(config)
    normalized = result["config"]
    return {
        "valid": result["valid"],
        "issues": result["issues"],
        "ambe_server_enabled": normalized["ambe_server"]["enabled"],
        "blue_dv_enabled": normalized["blue_dv"]["enabled"],
        "audio_enabled": normalized["audio"]["enabled"],
        "configured": bool(
            normalized["ambe_server"]["enabled"]
            or normalized["blue_dv"]["enabled"]
            or normalized["audio"]["enabled"]
        ),
        "effective_tx_enabled": result["effective_tx_enabled"],
    }
