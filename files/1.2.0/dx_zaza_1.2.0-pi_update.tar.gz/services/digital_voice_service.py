import glob
import os
import shutil
import subprocess

from services.ambe_server_preflight_service import get_ambe_server_preflight
from services.digital_voice_config_service import sanitize_digital_voice_config_for_api
from services.dvstick_ownership_service import (
    get_customer_safe_ownership,
    get_dvstick_ownership,
    select_canonical_dvstick_device,
)


COMMAND_TIMEOUT_SECONDS = 5
DVSTICK_USB_IDS = {
    "0403:6015": {
        "type": "DVMEGA DVstick 30 / AMBE USB device",
        "chip": "FTDI FT230X",
    },
}
POWER_WARNING = "Use a stable Raspberry Pi power supply for USB digital voice hardware."
READINESS_MESSAGE = (
    "AMBE hardware is detected. Digital Voice operation requires AMBE Server or BlueDV, "
    "audio setup, and operator configuration."
)


def _run_read_only(command):
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=COMMAND_TIMEOUT_SECONDS,
            check=False,
            shell=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return ""
    return result.stdout if result.returncode == 0 else ""


def _serial_ports():
    ports = sorted(glob.glob("/dev/ttyUSB*") + glob.glob("/dev/ttyACM*"))
    return [port for port in ports if port.startswith(("/dev/ttyUSB", "/dev/ttyACM"))]


def _lsusb_text():
    return _run_read_only(["lsusb"])


def _service_running(service_name):
    result = _run_read_only(["systemctl", "is-active", service_name])
    return result.strip() == "active"


def _service_enabled(service_name):
    result = _run_read_only(["systemctl", "is-enabled", service_name])
    return result.strip() == "enabled"


def _installed(binary_name):
    return shutil.which(binary_name) is not None


def _detect_dvstick(ports, lsusb_text):
    normalized_lsusb = lsusb_text.lower()
    selection = select_canonical_dvstick_device(ports=ports)
    device = selection.get("device", "")
    for usb_id, metadata in DVSTICK_USB_IDS.items():
        if usb_id.lower() in normalized_lsusb and ports:
            return {
                "detected": True,
                "device": device,
                "type": metadata["type"],
                "chip": metadata["chip"],
            }
    if ports:
        return {
            "detected": False,
            "device": device,
            "type": "Unknown USB serial device",
            "chip": "",
        }
    return {
        "detected": False,
        "device": "",
        "type": "",
        "chip": "",
    }


def get_digital_voice_status(config=None):
    ports = _serial_ports()
    dvstick = _detect_dvstick(ports, _lsusb_text())
    hardware_present = dvstick["detected"] is True
    ownership_internal = get_dvstick_ownership()
    ownership = get_customer_safe_ownership(ownership_internal)
    configuration = sanitize_digital_voice_config_for_api(config or {})
    preflight = get_ambe_server_preflight(config or {}, ownership=ownership_internal)
    integration_service = "dx-zaza-ambe-server.service"
    integration_service_file = f"/etc/systemd/system/{integration_service}"
    integration_service_enabled = _service_enabled(integration_service)
    integration_service_active = _service_running(integration_service)
    return {
        "ok": True,
        "digital_voice": {
            "module_status": "hardware_detected" if hardware_present else "not_configured",
            "ambe_hardware_present": hardware_present,
            "stable_device_ready": ownership["stable_device_ready"],
            "hardware_in_use": ownership["hardware_in_use"],
            "hardware_owner": ownership["hardware_owner"],
            "configuration": configuration,
            "ambe_integration": {
                "candidate_installed": os.path.exists(integration_service_file),
                "service_file_present": os.path.exists(integration_service_file),
                "service_enabled": integration_service_enabled,
                "service_active": integration_service_active,
                "external_binary_present": preflight["binary"]["present"],
                "preflight_can_start": preflight["can_start"],
                "execution_enabled": preflight["execution_enabled"],
            },
            "dvstick": dvstick,
            "blue_dv": {
                "installed": _installed("BlueDV"),
                "running": _service_running("bluedv.service"),
            },
            "ambe_server": {
                "installed": _installed("AMBEserver") or _installed("ambeserver"),
                "running": _service_running("ambeserver.service"),
            },
            "service_running": False,
            "modes": {
                "dmr": "planned",
                "dstar": "planned",
                "c4fm": "planned",
            },
            "warnings": [POWER_WARNING] if hardware_present else [],
        },
    }


def _device_permissions_ready(device):
    if not device:
        return False
    try:
        return os.path.exists(device) and os.access(device, os.R_OK | os.W_OK)
    except OSError:
        return False


def get_digital_voice_readiness(operator_configured=False, status_result=None):
    status_result = status_result or get_digital_voice_status()
    digital_voice = status_result.get("digital_voice", {}) or {}
    dvstick = digital_voice.get("dvstick", {}) or {}
    blue_dv = digital_voice.get("blue_dv", {}) or {}
    ambe_server = digital_voice.get("ambe_server", {}) or {}
    configuration = digital_voice.get("configuration", {}) or {}
    hardware_ready = bool(digital_voice.get("ambe_hardware_present") or dvstick.get("detected"))
    permissions_ready = _device_permissions_ready(dvstick.get("device")) if hardware_ready else False
    stable_device_ready = bool(digital_voice.get("stable_device_ready"))
    hardware_busy = bool(digital_voice.get("hardware_in_use"))
    ambe_server_ready = False
    blue_dv_ready = bool(blue_dv.get("installed") and blue_dv.get("running"))
    audio_ready = False
    tx_enabled = False
    safe_to_operate = False
    listen_only_available = False
    operator_config_ready = bool(operator_configured)
    configuration_valid = bool(configuration.get("valid", True))
    ambe_server_configured = bool(configuration.get("ambe_server_enabled"))
    blue_dv_configured = bool(configuration.get("blue_dv_enabled"))
    audio_configured = bool(configuration.get("audio_enabled"))
    if hardware_ready:
        overall_status = "hardware_ready_not_configured"
        message = READINESS_MESSAGE
    else:
        overall_status = "not_configured"
        message = (
            "Digital Voice hardware is not detected. Operation requires compatible AMBE "
            "hardware, AMBE Server or BlueDV, audio setup, and operator configuration."
        )
    return {
        "ok": True,
        "readiness": {
            "overall_status": overall_status,
            "hardware_ready": hardware_ready,
            "permissions_ready": permissions_ready,
            "stable_device_ready": stable_device_ready,
            "hardware_busy": hardware_busy,
            "configuration_valid": configuration_valid,
            "ambe_server_configured": ambe_server_configured,
            "blue_dv_configured": blue_dv_configured,
            "audio_configured": audio_configured,
            "ambe_server_ready": ambe_server_ready,
            "blue_dv_ready": blue_dv_ready,
            "audio_ready": audio_ready,
            "operator_config_ready": operator_config_ready,
            "tx_enabled": tx_enabled,
            "safe_to_operate": safe_to_operate,
            "listen_only_available": listen_only_available,
            "message": message,
        },
    }
