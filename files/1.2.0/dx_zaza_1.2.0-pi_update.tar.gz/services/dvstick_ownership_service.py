import glob
import os
import shutil
import subprocess


STABLE_DEVICE = "/dev/dvmega-ambestick"
PROC_ROOT = "/proc"
COMMAND_TIMEOUT_SECONDS = 3

AMBE_SERVICE_CANDIDATES = (
    "dx-zaza-ambe-server.service",
    "ambeserver.service",
)
BLUE_DV_SERVICE_CANDIDATES = (
    "bluedv.service",
)

AMBE_PROCESS_HINTS = (
    "ambeserver",
    "ambeserver3k",
    "ambe-server",
)
BLUE_DV_PROCESS_HINTS = (
    "bluedv",
)


def _serial_ports():
    ports = sorted(glob.glob("/dev/ttyUSB*") + glob.glob("/dev/ttyACM*"))
    return [port for port in ports if port.startswith(("/dev/ttyUSB", "/dev/ttyACM"))]


def _device_selection(ports=None):
    if ports is None:
        ports = _serial_ports()
    stable_device_ready = os.path.exists(STABLE_DEVICE)
    if stable_device_ready:
        return {
            "device_present": True,
            "device": STABLE_DEVICE,
            "resolved_device": os.path.realpath(STABLE_DEVICE),
            "stable_device_ready": True,
        }

    if ports:
        return {
            "device_present": True,
            "device": ports[0],
            "resolved_device": os.path.realpath(ports[0]),
            "stable_device_ready": False,
        }

    return {
        "device_present": False,
        "device": "",
        "resolved_device": "",
        "stable_device_ready": False,
    }


def select_canonical_dvstick_device(ports=None):
    """Return the canonical DVstick device selection.

    Prefer the stable udev symlink /dev/dvmega-ambestick when it exists so
    every consumer reports the same device path. Fall back to the first raw
    ttyUSB/ttyACM port only when the symlink is missing. Never opens the
    device and never hardcodes /dev/ttyUSB0.
    """
    return _device_selection(ports=ports)


def _run_read_only(command):
    try:
        return subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=COMMAND_TIMEOUT_SECONDS,
            check=False,
            shell=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None


def _service_states():
    states = {}
    for service in AMBE_SERVICE_CANDIDATES + BLUE_DV_SERVICE_CANDIDATES:
        result = _run_read_only(["systemctl", "is-active", service])
        states[service] = bool(result and result.stdout.strip() == "active")
    return states


def _process_name(pid, proc_root=None):
    proc_root = proc_root or PROC_ROOT
    comm_path = os.path.join(proc_root, str(pid), "comm")
    try:
        with open(comm_path, "r", encoding="utf-8", errors="replace") as handle:
            name = handle.read().strip()
        if name:
            return name
    except (FileNotFoundError, PermissionError, ProcessLookupError, OSError):
        pass

    exe_path = os.path.join(proc_root, str(pid), "exe")
    try:
        return os.path.basename(os.readlink(exe_path))
    except (FileNotFoundError, PermissionError, ProcessLookupError, OSError):
        return ""


def _holder_from_pid(pid, method, proc_root=None):
    proc_root = proc_root or PROC_ROOT
    return {
        "pid": int(pid),
        "process": _process_name(pid, proc_root=proc_root),
        "method": method,
    }


def _scan_proc_fd(resolved_device, proc_root=None):
    proc_root = proc_root or PROC_ROOT
    holders = {}
    if not resolved_device:
        return holders

    try:
        proc_entries = os.listdir(proc_root)
    except (FileNotFoundError, PermissionError, OSError):
        return holders

    for pid in proc_entries:
        if not pid.isdigit():
            continue

        fd_dir = os.path.join(proc_root, pid, "fd")
        try:
            fd_entries = os.listdir(fd_dir)
        except (FileNotFoundError, PermissionError, ProcessLookupError, OSError):
            continue

        for fd_name in fd_entries:
            fd_path = os.path.join(fd_dir, fd_name)
            try:
                target = os.readlink(fd_path)
                target_realpath = os.path.realpath(target.replace(" (deleted)", ""))
            except (FileNotFoundError, PermissionError, ProcessLookupError, OSError):
                continue

            if target_realpath == resolved_device:
                holders[int(pid)] = _holder_from_pid(pid, "proc_fd", proc_root=proc_root)
                break

    return holders


def _pids_from_fuser(device):
    if not device or not shutil.which("fuser"):
        return []
    result = _run_read_only(["fuser", device])
    if not result:
        return []
    tokens = (result.stdout or "").split() + (result.stderr or "").split()
    return [int(token) for token in tokens if token.isdigit()]


def _holders_from_fuser(device, proc_root=None):
    proc_root = proc_root or PROC_ROOT
    return {
        pid: _holder_from_pid(pid, "fuser", proc_root=proc_root)
        for pid in _pids_from_fuser(device)
    }


def _holders_from_lsof(device, proc_root=None):
    proc_root = proc_root or PROC_ROOT
    if not device or not shutil.which("lsof"):
        return {}
    result = _run_read_only(["lsof", "-F", "pc", "--", device])
    if not result or result.returncode not in (0, 1):
        return {}

    holders = {}
    current_pid = None
    current_name = ""
    for line in (result.stdout or "").splitlines():
        if line.startswith("p") and line[1:].isdigit():
            if current_pid is not None:
                holders[current_pid] = {
                    "pid": current_pid,
                    "process": current_name or _process_name(current_pid, proc_root=proc_root),
                    "method": "lsof",
                }
            current_pid = int(line[1:])
            current_name = ""
        elif line.startswith("c"):
            current_name = line[1:].strip()

    if current_pid is not None:
        holders[current_pid] = {
            "pid": current_pid,
            "process": current_name or _process_name(current_pid, proc_root=proc_root),
            "method": "lsof",
        }

    return holders


def _merge_holders(*holder_maps):
    merged = {}
    for holder_map in holder_maps:
        for pid, holder in holder_map.items():
            existing = merged.get(pid)
            if existing:
                if not existing.get("process") and holder.get("process"):
                    existing["process"] = holder["process"]
                if holder.get("method") and holder["method"] not in existing["method"].split("+"):
                    existing["method"] = f"{existing['method']}+{holder['method']}"
            else:
                merged[pid] = dict(holder)
    return merged


def _classify_process(process_name):
    normalized = (process_name or "").lower()
    if any(hint in normalized for hint in AMBE_PROCESS_HINTS):
        return "ambe_server"
    if any(hint in normalized for hint in BLUE_DV_PROCESS_HINTS):
        return "blue_dv"
    return "unknown_process"


def _service_for_owner(owner, service_states):
    if owner == "ambe_server":
        for service in AMBE_SERVICE_CANDIDATES:
            if service_states.get(service):
                return service
    if owner == "blue_dv":
        for service in BLUE_DV_SERVICE_CANDIDATES:
            if service_states.get(service):
                return service
    return None


def _ownership_result(selection, owner, hardware_in_use, pid=None, process=None, service=None, method="none", multiple_holders=False):
    return {
        "device_present": bool(selection.get("device_present")),
        "device": selection.get("device", ""),
        "resolved_device": selection.get("resolved_device", ""),
        "stable_device_ready": bool(selection.get("stable_device_ready")),
        "owner": owner,
        "hardware_in_use": bool(hardware_in_use),
        "pid": pid,
        "process": process,
        "service": service,
        "method": method,
        "multiple_holders": bool(multiple_holders),
    }


def get_dvstick_ownership():
    selection = _device_selection()
    if not selection["device_present"]:
        return _ownership_result(selection, "device_absent", False)

    service_states = _service_states()
    holders = _merge_holders(
        _scan_proc_fd(selection["resolved_device"]),
        _holders_from_fuser(selection["device"]),
        _holders_from_lsof(selection["device"]),
    )

    if not holders:
        return _ownership_result(selection, "free", False)

    if len(holders) > 1:
        method = "+".join(sorted({holder.get("method", "unknown") for holder in holders.values()}))
        return _ownership_result(
            selection,
            "conflict",
            True,
            method=method or "multiple",
            multiple_holders=True,
        )

    holder = next(iter(holders.values()))
    owner = _classify_process(holder.get("process"))
    service = _service_for_owner(owner, service_states)
    return _ownership_result(
        selection,
        owner,
        True,
        pid=holder.get("pid"),
        process=holder.get("process") or None,
        service=service,
        method=holder.get("method", "unknown"),
    )


def get_customer_safe_ownership(ownership=None):
    ownership = ownership or get_dvstick_ownership()
    owner = ownership.get("owner")
    if owner in ("free", "ambe_server", "blue_dv"):
        hardware_owner = owner
    elif owner in ("conflict", "unknown_process"):
        hardware_owner = "busy"
    else:
        hardware_owner = "unknown"

    return {
        "stable_device_ready": bool(ownership.get("stable_device_ready")),
        "hardware_in_use": bool(ownership.get("hardware_in_use")),
        "hardware_owner": hardware_owner,
    }
