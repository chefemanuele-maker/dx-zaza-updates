"""Live DX cluster feed: one long-lived, read-only telnet session.

The cluster pushes every new spot ("DX de ...") the moment it is posted, so the operator
sees who is transmitting now and on which exact frequency, within seconds. On connect we
ask for the latest spots once (sh/dx) to fill the list, then just listen.

Read-only: the only commands ever sent are the login callsign, "sh/dx/N" and an empty line
as keep-alive. Nothing is ever posted to the cluster.
"""

import logging
import random
import re
import socket
import uuid
import threading
import time

from services.dx_spots_service import (is_valid_login_callsign, load_dx_cluster_config, login_rejected,
                                       normalise_dx_spot, parse_dx_cluster_line, parse_standard_dx_line)

log = logging.getLogger("dxzaza.cluster")

MAX_SPOTS = 80
BACKLOG = 40
# No keep-alive text is ever sent: some nodes (dxc.hamserve.uk) drop the session on an empty
# line, which made the feed reconnect every few minutes. A dead link is found by the OS (TCP
# keep-alive probes) and by the spot-silence check below.
TCP_KEEPALIVE_IDLE = 60
# the world-wide cluster network posts several spots a minute, day and night: ten minutes
# without a single spot means the session is dead (half-open TCP, node stuck), not quiet bands
SPOT_SILENCE_RECONNECT_SECONDS = 600
SILENCE_RECONNECT_SECONDS = SPOT_SILENCE_RECONNECT_SECONDS
FIRST_SPOT_TIMEOUT_SECONDS = 90

# public read-only telnet nodes tried in turn when the configured one does not answer
FALLBACK_HOSTS = [
    ("dxc.hamserve.uk", 7300),
    ("dxc.ve7cc.net", 23),
    ("w3lpl.net", 7373),
]


# A cluster allows one session per login: when the same callsign logs in from another device
# (e.g. the DX Zaza Raspberry Pi and the Mac at the same station), the node drops the older
# session ("Reconnected as M7ESZ ..., this instance is disconnected") and the two devices keep
# pushing each other out. DX Zaza then logs in with an SSID (M7ESZ-2 ... M7ESZ-15), the usual
# way to run several cluster connections with one callsign.
DUPLICATE_LOGIN_RE = re.compile(r"reconnected as|this instance is disconnected|already (logged|connected)|"
                                r"duplicate (login|connection)|logged in elsewhere", re.I)


def is_duplicate_notice(line):
    """The node's own message (not a spot, announcement or talk that happens to contain the words)."""
    text = str(line or "").strip()
    if not text or text.startswith(("DX de", "To ", "WWV", "WCY", "WX ")) or text[:1].isdigit():
        return False
    return bool(DUPLICATE_LOGIN_RE.search(text))


def device_ssid():
    """A stable number 2..9 for this computer, so two devices rarely pick the same SSID."""
    return random.Random(uuid.getnode()).randint(2, 9)


def cluster_hosts(config, fallbacks=None):
    """Configured node first, then the public fallbacks (no duplicates)."""
    hosts = [(config["host"], int(config["port"]))]
    for host, port in (FALLBACK_HOSTS if fallbacks is None else fallbacks):
        if (host, int(port)) not in hosts:
            hosts.append((host, int(port)))
    return hosts


def enable_tcp_keepalive(sock):
    """Let the operating system notice a dead connection (no data is sent to the cluster)."""
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        idle = getattr(socket, "TCP_KEEPIDLE", None) or getattr(socket, "TCP_KEEPALIVE", None) or 0x10
        sock.setsockopt(socket.IPPROTO_TCP, idle, TCP_KEEPALIVE_IDLE)
        if hasattr(socket, "TCP_KEEPINTVL"):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 20)
        if hasattr(socket, "TCP_KEEPCNT"):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 4)
    except (OSError, AttributeError):
        pass


def spot_key(spot):
    """Same station on (about) the same frequency = same activity: keep only the newest."""
    return spot.get("_key") or (spot.get("dx") or "", spot.get("frequency") or "")


def spot_epoch(hhmm, now):
    """sh/dx history can be hours old: date it by its own UTC time ("HH:MMZ"), not by arrival."""
    try:
        hh, mm = int(hhmm[0:2]), int(hhmm[3:5])
    except (TypeError, ValueError, IndexError):
        return now
    day = now - (now % 86400)
    when = day + hh * 3600 + mm * 60
    if when > now + 300:          # e.g. 23:58Z seen at 00:02Z: yesterday
        when -= 86400
    return min(when, now)


def age_text(seconds):
    if seconds < 60:
        return "Just now"
    minutes = seconds // 60
    if minutes < 60:
        return "%d min ago" % minutes
    return "%d h ago" % (minutes // 60)


class DXClusterStream:
    def __init__(self, get_config, connect=socket.create_connection, clock=time.time, fallbacks=None, on_spot=None):
        self.get_config = get_config
        self.on_spot = on_spot          # every new spot (live or recent history), e.g. band activity
        self.fallbacks = fallbacks
        self.host = ""
        self.host_index = 0
        self.last_spot = 0.0
        self.spot_count = 0
        self.connect = connect
        self.clock = clock
        self.lock = threading.Lock()
        self.spots = []              # newest first
        self.state = "idle"          # idle | connecting | live | error | setup
        self.error = ""
        self.since = 0.0
        self.last_data = 0.0
        self.thread = None
        self.stop_event = threading.Event()
        self.login = ""             # operator callsign (from the settings)
        self.ssid = None            # set after another device took the plain callsign
        self.login_as = ""          # what was actually sent to the cluster
    # ------------------------------------------------------------ public
    def start(self):
        if self.thread and self.thread.is_alive():
            return self
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._run, name="dx-cluster", daemon=True)
        self.thread.start()
        return self

    def stop(self):
        self.stop_event.set()

    def running(self):
        return bool(self.thread and self.thread.is_alive())

    def snapshot(self, max_spots=60):
        with self.lock:
            now = self.clock()
            spots = []
            for spot in self.spots[:max_spots]:
                item = dict(spot)
                item.pop("_key", None)
                item["ageSeconds"] = max(0, int(now - item.pop("_received", now)))
                item["lastSeen"] = age_text(item["ageSeconds"])
                spots.append(item)
            return {"state": self.state, "error": self.error, "spots": spots, "login": self.login,
                    "loginAs": self.login_as,
                    "host": self.host, "stateSeconds": int(now - self.since) if self.since else 0,
                    "lastSpotSeconds": int(now - self.last_spot) if self.last_spot else None}

    # ------------------------------------------------------------ spots
    def add_line(self, line):
        raw = parse_dx_cluster_line(line)
        if not raw:
            return None
        live = parse_standard_dx_line(" ".join(str(line).strip().split())) is not None
        spot = normalise_dx_spot(raw)
        if not spot:
            return None
        spot["_received"] = self.clock() if live else spot_epoch(raw.get("time"), self.clock())
        spot["_key"] = (spot.get("dx") or "", int(round(float(raw.get("frequency_mhz") or 0) * 1000)))
        key = spot_key(spot)
        with self.lock:
            self.last_spot = self.clock()
            self.spot_count += 1
            if self.state == "connecting":
                self.state, self.error = "live", ""
            existing = [s for s in self.spots if spot_key(s) == key]
            if existing and not live:
                return None            # backlog line for something we already have
            self.spots = [s for s in self.spots if spot_key(s) != key]
            if live:
                self.spots.insert(0, spot)          # just posted: on top
            else:
                self.spots.append(spot)             # sh/dx history arrives newest first
            del self.spots[MAX_SPOTS:]
        if self.on_spot is not None:
            try:
                self.on_spot(spot, spot["_received"])
            except Exception as exc:  # pragma: no cover
                log.warning("spot listener failed: %s", exc)
        return spot

    # ------------------------------------------------------------ connection
    def _set(self, state, error=""):
        with self.lock:
            self.state, self.error = state, error
            self.since = self.clock()

    def _run(self):
        backoff = 5
        failures_on_host = 0
        while not self.stop_event.is_set():
            try:
                config = load_dx_cluster_config(self.get_config())
            except Exception as exc:  # pragma: no cover
                config = None
                log.warning("cluster config: %s", exc)
            if not config or not is_valid_login_callsign(config["login_callsign"]):
                self._set("setup", "Configure Operator Callsign to enable live radio spots.")
                self.stop_event.wait(10)
                continue
            hosts = cluster_hosts(config, self.fallbacks)
            if self.host_index >= len(hosts):
                self.host_index = 0
            host, port = hosts[self.host_index]
            got_spots = False
            try:
                got_spots = self._session(config, host, port)
                backoff = 5
                failures_on_host = 0
                continue                       # settings changed: log in again at once
            except LoginRejected as exc:
                self._set("error", str(exc))
                self.stop_event.wait(300)
                continue
            except DuplicateLogin:
                # another device uses the same callsign on this node: take an SSID and go back at once
                self.ssid = device_ssid() if self.ssid is None else (self.ssid % 15) + 1
                if self.ssid == 1:
                    self.ssid = 2
                log.warning("cluster %s:%d: the callsign is in use on another device, logging in as %s-%d",
                            host, port, config["login_callsign"], self.ssid)
                self.stop_event.wait(2)
                continue
            except Exception as exc:
                got_spots = getattr(exc, "got_spots", False)
                self._set("error", "DX cluster %s unreachable: %s" % (host, str(exc)[:120] or exc.__class__.__name__))
                log.warning("cluster %s:%d session ended: %s", host, port, exc)
            # a node that was working gets one quick retry; otherwise move to the next node at once
            failures_on_host = 1 if got_spots else failures_on_host + 1
            if not got_spots or failures_on_host >= 2:
                self.host_index = (self.host_index + 1) % len(hosts)
                failures_on_host = 0
                if self.host_index != 0:
                    self.stop_event.wait(2)    # next node straight away
                    continue
            if got_spots:
                self.stop_event.wait(2)        # a working session dropped: straight back in
                continue
            self.stop_event.wait(backoff)
            backoff = min(60, backoff * 2)

    def _session(self, config, host, port):
        self._set("connecting")
        if self.login != config["login_callsign"]:
            self.ssid = None                     # new callsign in the settings: plain call first
        self.login = config["login_callsign"]
        self.login_as = self.login if self.ssid is None else "%s-%d" % (self.login, self.ssid)
        self.host = "%s:%d" % (host, port)
        got = [False]
        sock = self.connect((host, port), timeout=max(1, config["connect_timeout_seconds"]))
        try:
            sock.settimeout(1.0)
            enable_tcp_keepalive(sock)
            transcript = ""
            buffer = ""
            sock.sendall((self.login_as + "\n").encode("ascii", errors="ignore"))
            sock.sendall(("sh/dx/%d\n" % BACKLOG).encode("ascii"))
            start = self.clock()
            spots_before = self.spot_count
            while not self.stop_event.is_set():
                # operator callsign or node changed in the settings: log in again with the new one
                current = load_dx_cluster_config(self.get_config())
                if current["login_callsign"] != config["login_callsign"] or current["host"] != config["host"] \
                        or current["port"] != config["port"]:
                    self.host_index = 0
                    return got[0]
                now = self.clock()
                got[0] = self.spot_count > spots_before
                if not got[0] and now - start > FIRST_SPOT_TIMEOUT_SECONDS:
                    raise ConnectionError("no spots received after login")
                if got[0] and now - self.last_spot > SPOT_SILENCE_RECONNECT_SECONDS:
                    raise ConnectionError("no new spots for %d min" % (SPOT_SILENCE_RECONNECT_SECONDS // 60))
                try:
                    chunk = sock.recv(4096)
                except socket.timeout:
                    continue
                if not chunk:
                    if is_duplicate_notice(buffer):
                        raise DuplicateLogin(buffer.strip()[:120])
                    raise ConnectionError("cluster closed the connection")
                self.last_data = self.clock()
                text = chunk.decode("utf-8", errors="ignore")
                if len(transcript) < 4000:
                    transcript += text
                    if login_rejected(transcript):
                        raise LoginRejected("DX Cluster login rejected: invalid or unauthorized callsign")
                buffer += text
                lines = buffer.replace("\r", "\n").split("\n")
                buffer = lines.pop()
                for line in lines:
                    if is_duplicate_notice(line):
                        raise DuplicateLogin(line.strip()[:120])
                    if line.strip():
                        self.add_line(line)
            return got[0]
        except (LoginRejected, DuplicateLogin):
            raise
        except Exception as exc:
            exc.got_spots = got[0] or (self.spot_count > spots_before if "spots_before" in locals() else False)
            raise
        finally:
            try:
                sock.close()
            except OSError:  # pragma: no cover
                pass


class LoginRejected(Exception):
    pass


class DuplicateLogin(Exception):
    pass
