import re
import socket
import time

from services.cache import cache
from services.geo_service import locate, locate_dx


PREFIX_COUNTRY_MAP = [
    (("2E", "G", "GB", "GC", "GD", "GI", "GJ", "GM", "GN", "GP", "GS", "GT", "GU", "GW", "M", "MC", "MD", "MI", "MJ", "MM", "MP", "MS", "MT", "MU", "MW"), "United Kingdom", "Europe"),
    (("EI",), "Ireland", "Europe"),
    (("I", "IA", "IB", "IC", "ID", "IE", "IF", "IG", "IH", "II", "IJ", "IK", "IL", "IM", "IN", "IO", "IQ", "IR", "IS", "IT", "IU", "IW", "IZ"), "Italy", "Europe"),
    (("DL", "DA", "DB", "DC", "DD", "DF", "DG", "DH", "DJ", "DK", "DM", "DN", "DO", "DP", "DQ", "DR"), "Germany", "Europe"),
    (("F", "FA", "FB", "FC", "FD", "FE", "FF", "FG", "FH", "FI", "FJ", "FK", "FL", "FM", "FN", "FO", "FP", "FQ", "FR", "FS", "FT", "FU", "FV", "FW", "FY"), "France", "Europe"),
    (("EA", "EB", "EC", "ED", "EE", "EF", "EG", "EH", "AM", "AN", "AO"), "Spain", "Europe"),
    (("CT", "CQ", "CR", "CS", "CU"), "Portugal", "Europe"),
    (("PA", "PB", "PC", "PD", "PE", "PF", "PG", "PH", "PI"), "Netherlands", "Europe"),
    (("ON", "OO", "OP", "OQ", "OR", "OS", "OT"), "Belgium", "Europe"),
    (("HB", "HE"), "Switzerland", "Europe"),
    (("OE",), "Austria", "Europe"),
    (("SP", "SQ", "SN", "SO", "SR", "HF"), "Poland", "Europe"),
    (("OK", "OL"), "Czech Republic", "Europe"),
    (("OM",), "Slovakia", "Europe"),
    (("S5",), "Slovenia", "Europe"),
    (("9A",), "Croatia", "Europe"),
    (("YU", "YT"), "Serbia", "Europe"),
    (("LZ",), "Bulgaria", "Europe"),
    (("YO", "YP", "YQ", "YR"), "Romania", "Europe"),
    (("HA", "HG"), "Hungary", "Europe"),
    (("SV", "SX", "SY", "SZ", "J4"), "Greece", "Europe"),
    (("LA", "LB", "LC", "LD", "LE", "LF", "LG", "LH", "LI", "LJ", "LM", "LN"), "Norway", "Europe"),
    (("SM", "SA", "SB", "SC", "SD", "SE", "SF", "SG", "SH", "SI", "SJ", "SK", "SL"), "Sweden", "Europe"),
    (("OH", "OF", "OG", "OI", "OJ"), "Finland", "Europe"),
    (("OZ", "OU", "OV", "OW", "OX", "OY"), "Denmark", "Europe"),
    (("ES",), "Estonia", "Europe"),
    (("YL",), "Latvia", "Europe"),
    (("LY",), "Lithuania", "Europe"),
    (("UR", "US", "UT", "UU", "UV", "UW", "UX", "UY", "UZ", "EM", "EN", "EO"), "Ukraine", "Europe"),
    (("UA4", "R4"), "Russia", "European Russia"),
    (("R", "RA", "RK", "RL", "RM", "RN", "RO", "RP", "RQ", "RT", "RU", "RV", "RW", "RX", "RZ", "UA", "UB", "UC", "UD", "UE", "UF", "UG", "UH", "UI", "RC", "RD", "RE", "RF", "RG", "RJ", "RY"), "Russia", "Europe/Asia"),
    (("TA", "TB", "TC", "YM"), "Turkey", "Asia"),
    (("4X", "4Z"), "Israel", "Asia"),
    (("A4",), "Oman", "Asia"),
    (("A6",), "United Arab Emirates", "Asia"),
    (("A7",), "Qatar", "Asia"),
    (("A9",), "Bahrain", "Asia"),
    (("JA", "JE", "JF", "JG", "JH", "JI", "JJ", "JK", "JL", "JM", "JN", "JO", "JP", "JQ", "JR", "JS", "7J", "7K", "7L", "7M", "7N"), "Japan", "Asia"),
    (("HL", "DS", "DT", "D7", "D8", "D9"), "South Korea", "Asia"),
    (("BA", "BD", "BG", "BH", "BI", "BJ", "BL", "BM", "BN", "BO", "BP", "BQ", "BR", "BS", "BT", "BU", "BV", "BW", "BX", "BY", "BZ"), "China", "Asia"),
    (("VU", "AT", "AU", "AV", "AW", "VT", "VU2"), "India", "Asia"),
    (("HS", "E2"), "Thailand", "Asia"),
    (("YB", "YC", "YD", "YE", "YF", "YG", "YH"), "Indonesia", "Asia"),
    (("DU", "DV", "DW", "DX", "DY"), "Philippines", "Asia"),
    (("9M2", "9M6", "9M8"), "Malaysia", "Asia"),
    (("9V",), "Singapore", "Asia"),
    (("VK", "AX"), "Australia", "Oceania"),
    (("ZL", "ZM"), "New Zealand", "Oceania"),
    (("KH6", "NH6", "WH6"), "Hawaii", "North America"),
    (("KL", "NL", "WL"), "Alaska", "North America"),
    (("AA", "AB", "AC", "AD", "AE", "AF", "AG", "AI", "AJ", "AK", "AL", "K", "N", "W"), "United States", "North America"),
    (("VE", "VA", "VO", "VY", "CF", "CG", "CH", "CI", "CJ", "CK", "CY", "CZ"), "Canada", "North America"),
    (("XE", "XF"), "Mexico", "North America"),
    (("CO", "CM", "CL", "T4"), "Cuba", "Caribbean"),
    (("KP4", "NP4", "WP4"), "Puerto Rico", "Caribbean"),
    (("HI",), "Dominican Republic", "Caribbean"),
    (("PY", "PP", "PU", "PR", "PT", "PV", "PW", "PX", "ZV", "ZW", "ZX", "ZY", "ZZ"), "Brazil", "South America"),
    (("LU", "LW", "AY", "AZ"), "Argentina", "South America"),
    (("CE", "XQ", "XR", "3G"), "Chile", "South America"),
    (("CX",), "Uruguay", "South America"),
    (("HK", "HJ"), "Colombia", "South America"),
    (("YV", "YY", "4M"), "Venezuela", "South America"),
    (("OA", "OC"), "Peru", "South America"),
    (("ZS", "ZR", "ZU"), "South Africa", "Africa"),
    (("CN",), "Morocco", "Africa"),
    (("SU",), "Egypt", "Africa"),
    (("5Z",), "Kenya", "Africa"),
    (("5N",), "Nigeria", "Africa"),
    (("5H",), "Tanzania", "Africa"),
    (("7X",), "Algeria", "Africa"),
]

PREFIX_COUNTRY_ENTRIES = sorted(
    [
        {"prefix": prefix, "country": country, "region": region}
        for prefixes, country, region in PREFIX_COUNTRY_MAP
        for prefix in prefixes
    ],
    key=lambda entry: len(entry["prefix"]),
    reverse=True,
)

DX_LINE_RE = re.compile(
    r"DX\s+de\s+(?P<de>[A-Z0-9/]+):\s+"
    r"(?P<freq>[0-9]+(?:\.[0-9]+)?)\s+"
    r"(?P<dx>[A-Z0-9/]+)\s*"
    r"(?P<comment>.*)",
    re.IGNORECASE,
)
DXSPIDER_HISTORY_RE = re.compile(
    r"^\s*(?P<freq>[0-9]+(?:\.[0-9]+)?)\s+"
    r"(?P<dx>[A-Z0-9/\-]+)\s+"
    r"(?P<date>\d{1,2}-[A-Z][a-z]{2}-\d{4})\s+"
    r"(?P<time>[0-2][0-9][0-5][0-9]Z)\s*"
    r"(?P<comment>.*?)\s*"
    r"<(?P<de>[A-Z0-9/]+)>\s*$",
    re.IGNORECASE,
)
CALLSIGN_RE = re.compile(r"^[A-Z0-9/]{3,20}$")


def load_dx_cluster_config(config):
    dx_config = dict(config.get("dx_cluster", {}) or {})
    operator_config = dict(config.get("operator", {}) or {})
    refresh = config.get("refresh", {}) or {}
    configured_login = operator_config.get("callsign") or ""
    return {
        "enabled": True,
        "host": dx_config.get("host") or "dxc.hamserve.uk",
        "port": int(dx_config.get("port") or 7300),
        "login_callsign": normalize_login_callsign(configured_login),
        "connect_timeout_seconds": int(dx_config.get("connect_timeout_seconds") or 8),
        "read_seconds": int(dx_config.get("read_seconds") or 8),
        "max_spots": int(dx_config.get("max_spots") or 60),
        "cache_seconds": int(dx_config.get("cache_seconds") or refresh.get("dx_cache_seconds") or 15),
    }


def normalize_login_callsign(value):
    return str(value or "").strip().upper()


def is_valid_login_callsign(callsign):
    value = normalize_login_callsign(callsign)
    return bool(
        value
        and CALLSIGN_RE.fullmatch(value)
        and "//" not in value
        and not value.startswith("/")
        and not value.endswith("/")
    )


def get_dx_spots(config, setup_state=None, stream=None):
    dx_config = load_dx_cluster_config(config)
    if setup_state is not None and not setup_state.get("ready_for_live", False):
        reasons = setup_state.get("reasons") or ["Complete setup to enable live radio spots."]
        return {
            "ok": True,
            "source": "setup-required",
            "spots": [],
            "setupRequired": True,
            "message": reasons[0],
        }
    # live feed (one long-lived cluster session): spots arrive the moment they are posted
    if stream is not None and stream.running():
        snap = stream.snapshot(dx_config["max_spots"])
        same_login = snap["login"] == dx_config["login_callsign"]
        host = snap.get("host", "")
        if host and snap.get("loginAs") and snap.get("loginAs") != snap.get("login"):
            host += " · " + snap["loginAs"]       # logged in with an SSID (callsign in use on another device)
        extra = {"stream": snap["state"], "host": host, "lastSpotSeconds": snap.get("lastSpotSeconds")}
        # a short reconnect (a few seconds) is not worth a warning on screen
        brief = snap["state"] in ("connecting", "error") and (snap.get("stateSeconds") or 0) < 30
        if snap["spots"] and same_login and (snap["state"] == "live" or brief):
            return dict(extra, ok=True, source="dx-cluster-live", spots=snap["spots"])
        if snap["spots"] and same_login:
            # reconnecting (or moving to another node): keep showing what we have, clearly marked
            return dict(extra, ok=True, source="dx-cluster-live", stale=True, spots=snap["spots"],
                        message="Reconnecting to the DX cluster...")
        if snap["state"] in ("connecting", "live") and same_login:
            return dict(extra, ok=True, source="dx-cluster-live", spots=[], message="Connecting to the DX cluster...")
        # the live session is retrying by itself: do not open a second connection meanwhile
        return dict(extra, ok=True, source="offline", spots=[],
                    message=snap["error"] or "Live radio spots are temporarily unavailable.")
    cache_key = "dx_spots_live:" + dx_config["login_callsign"]
    cached = cache.get(cache_key)
    if cached:
        return cached

    if not is_valid_login_callsign(dx_config["login_callsign"]):
        return cache.set(cache_key, {
            "ok": True,
            "source": "setup-required",
            "setupRequired": True,
            "message": "Configure Operator Callsign to enable live radio spots.",
            "spots": [],
        }, dx_config["cache_seconds"])

    try:
        raw_spots = fetch_dx_cluster_telnet(dx_config)
        spots = [normalise_dx_spot(raw_spot) for raw_spot in raw_spots]
        spots = [spot for spot in spots if spot]
        if not spots:
            raise RuntimeError("No readable DX spots received")
        return cache.set(cache_key, {
            "ok": True,
            "source": "dx-cluster-telnet",
            "spots": spots[:dx_config["max_spots"]],
        }, dx_config["cache_seconds"])
    except Exception:
        return cache.set(cache_key, {
            "ok": True,
            "source": "offline",
            "spots": [],
            "message": "Live radio spots are temporarily unavailable.",
        }, dx_config["cache_seconds"])


def safe_error(exc):
    message = str(exc).strip() or exc.__class__.__name__
    return message[:160]


def fetch_dx_cluster_telnet(config):
    deadline = time.monotonic() + max(1, config["read_seconds"])
    spots = []
    buffer = ""
    transcript = ""
    with socket.create_connection(
        (config["host"], config["port"]),
        timeout=max(1, config["connect_timeout_seconds"]),
    ) as sock:
        sock.settimeout(1.0)
        transcript += _read_available(sock, deadline)
        sock.sendall((config["login_callsign"] + "\n").encode("ascii", errors="ignore"))
        # Read-only request for recent spots. If a cluster streams spots without it,
        # this is still harmless; no spots are sent and no TX command is used.
        try:
            sock.sendall(b"sh/dx/20\n")
        except OSError:
            pass

        while time.monotonic() < deadline and len(spots) < config["max_spots"]:
            try:
                chunk = sock.recv(4096)
            except socket.timeout:
                continue
            if not chunk:
                break
            buffer += chunk.decode("utf-8", errors="ignore")
            transcript += buffer
            if login_rejected(transcript):
                raise RuntimeError("DX Cluster login rejected: invalid or unauthorized callsign")
            lines = buffer.splitlines()
            if buffer and not buffer.endswith(("\n", "\r")):
                buffer = lines.pop() if lines else buffer
            else:
                buffer = ""
            for line in lines:
                parsed = parse_dx_cluster_line(line)
                if parsed:
                    spots.append(parsed)
                    if len(spots) >= config["max_spots"]:
                        break
    return spots


def _read_available(sock, deadline):
    chunks = []
    while time.monotonic() < deadline:
        try:
            chunk = sock.recv(4096)
        except socket.timeout:
            break
        if not chunk:
            break
        chunks.append(chunk)
        if b"\n" in chunk or b":" in chunk:
            break
    return b"".join(chunks).decode("utf-8", errors="ignore")


def login_rejected(text):
    lower = str(text or "").lower()
    return "invalid callsign" in lower or "login incorrect" in lower or "not authorized" in lower


def parse_dx_cluster_line(line):
    clean = " ".join(str(line or "").strip().split())
    if not clean:
        return None
    parsed = parse_standard_dx_line(clean)
    if parsed:
        return parsed
    return parse_dxspider_history_line(clean)


def parse_standard_dx_line(clean):
    match = DX_LINE_RE.search(clean)
    if not match:
        return None
    freq_mhz = parse_frequency_mhz(match.group("freq"))
    if not freq_mhz:
        return None
    raw_comment = match.group("comment") or ""
    comment = strip_time(raw_comment).strip()
    return {
        "de": match.group("de").upper(),
        "internal_dx": match.group("dx").upper(),
        "frequency_mhz": freq_mhz,
        "comment": comment,
        "time": spot_time(raw_comment),
        "raw": clean,
    }


def spot_time(text):
    match = re.search(r"\b([0-2][0-9])([0-5][0-9])Z\b", str(text or ""), re.IGNORECASE)
    return "%s:%sZ" % (match.group(1), match.group(2)) if match else ""


def parse_dxspider_history_line(clean):
    match = DXSPIDER_HISTORY_RE.search(clean)
    if not match:
        return None
    freq_mhz = parse_frequency_mhz(match.group("freq"))
    if not freq_mhz:
        return None
    comment = strip_time(match.group("comment") or "").strip()
    return {
        "de": match.group("de").upper(),
        "internal_dx": match.group("dx").upper(),
        "frequency_mhz": freq_mhz,
        "comment": comment,
        "time": spot_time(match.group("time")),
        "raw": clean,
    }


def parse_frequency_mhz(value):
    try:
        freq = float(value)
    except (TypeError, ValueError):
        return None
    if freq > 1000:
        return freq / 1000.0
    return freq


def strip_time(comment):
    return re.sub(r"\b[0-2][0-9][0-5][0-9]Z\b", "", comment, flags=re.IGNORECASE).strip()


def normalise_dx_spot(raw_spot):
    """One cluster spot: the DX station (who is transmitting, on that frequency) and the
    spotter (DE, who heard it). Each is placed with the best data available: a Maidenhead
    locator pair in the comment ("JN45 -> FN31": spotter -> DX) or the callsign prefix (cty.dat)."""
    freq_mhz = raw_spot.get("frequency_mhz")
    if not freq_mhz:
        return None
    comment = raw_spot.get("comment") or "DX cluster spot"
    de_call = normalize_spotter_callsign(raw_spot.get("de"))
    dx_call = str(raw_spot.get("internal_dx") or raw_spot.get("dx") or "").strip().upper()
    location = get_prefix_location(raw_spot.get("de"))
    de_geo = locate(de_call, comment, location["country"])
    dx_geo = locate_dx(dx_call, comment) if dx_call else None
    spot = {
        "de": raw_spot.get("de") or "DEMO",
        "dx": raw_spot.get("internal_dx") or raw_spot.get("dx") or "",
        "frequency": format_frequency(freq_mhz),
        "band": frequency_to_band(freq_mhz),
        "mode": detect_mode(comment, freq_mhz),
        "country": location["country"],
        "region": location["region"],
        "comment": public_comment(comment),
        "time": raw_spot.get("time", ""),
        "lastSeen": "Just now",
    }
    if de_geo:
        spot["country"] = de_geo["country"] or spot["country"]
        spot["region"] = de_geo["region"] or spot["region"]
        spot["lat"], spot["lon"], spot["precision"] = de_geo["lat"], de_geo["lon"], de_geo["precision"]
    if dx_geo:
        spot["dxCountry"] = dx_geo["country"]
        spot["dxRegion"] = dx_geo["region"]
        spot["dxLat"], spot["dxLon"], spot["dxPrecision"] = dx_geo["lat"], dx_geo["lon"], dx_geo["precision"]
    elif dx_call:
        dx_location = get_prefix_location(dx_call)
        spot["dxCountry"], spot["dxRegion"] = dx_location["country"], dx_location["region"]
    return spot


def normalize_spotter_callsign(callsign):
    raw = str(callsign or "").strip().upper().replace(" ", "")
    if not raw:
        return ""
    parts = [part for part in raw.split("/") if part]
    portable_suffixes = {"P", "M", "MM", "AM", "QRP", "QRPP", "PORTABLE", "MOBILE"}
    if len(parts) > 1 and parts[-1] in portable_suffixes:
        return "/".join(parts[:-1])
    return raw


def get_prefix_location(callsign):
    normalized = normalize_spotter_callsign(callsign)
    if not normalized:
        return {"country": "Unknown", "region": "Unmapped"}
    candidates = [part for part in normalized.split("/") if part]
    if normalized not in candidates:
        candidates.append(normalized)
    for candidate in candidates:
        for entry in PREFIX_COUNTRY_ENTRIES:
            if candidate.startswith(entry["prefix"]):
                return {"country": entry["country"], "region": entry["region"]}
    return {"country": "Unknown", "region": "Unmapped"}


def public_comment(comment):
    text = " ".join(str(comment or "").split())
    return text or "DX cluster spot"


def format_frequency(freq_mhz):
    return f"{freq_mhz:.3f} MHz"


def frequency_to_band(freq_mhz):
    try:
        freq = float(freq_mhz)
    except (TypeError, ValueError):
        return "Unknown"
    if 430.0 <= freq < 440.0:
        return "70cm"
    if 144.0 <= freq < 148.0:
        return "2m"
    if 70.0 <= freq < 70.5:
        return "4m"
    if 50.0 <= freq < 54.0:
        return "6m"
    if 28.0 <= freq < 30.0:
        return "10m"
    if 24.0 <= freq < 25.0:
        return "12m"
    if 21.0 <= freq < 22.0:
        return "15m"
    if 18.0 <= freq < 19.0:
        return "17m"
    if 14.0 <= freq < 15.0:
        return "20m"
    if 10.0 <= freq < 11.0:
        return "30m"
    if 7.0 <= freq < 8.0:
        return "40m"
    if 5.0 <= freq < 5.5:
        return "60m"
    if 3.5 <= freq < 4.0:
        return "80m"
    if 1.8 <= freq < 2.0:
        return "160m"
    return "Unknown"


def detect_mode(comment, frequency):
    text = str(comment or "").upper()
    try:
        freq = float(frequency)
    except (TypeError, ValueError):
        freq = 0.0

    if "FT4" in text:
        return "FT4"
    if "FT8" in text:
        return "FT8"
    if "RTTY" in text:
        return "RTTY"
    if "APRS" in text:
        return "APRS"
    if "FM" in text:
        return "FM"
    if "SSB" in text or "USB" in text or "LSB" in text or "VOICE" in text or "5+9" in text or re.search(r"\b59\b", text):
        return "SSB"
    if "CW" in text:
        return "CW"
    if is_likely_ft8_frequency(freq):
        return "FT8"
    if is_likely_cw_frequency(freq):
        return "CW"
    if is_likely_ssb_frequency(freq):
        return "SSB"
    return "Unknown"


def is_likely_ft8_frequency(freq):
    ft8_frequencies = (7.074, 10.136, 14.074, 18.100, 21.074, 28.074, 144.174)
    if any(abs(freq - ft8) <= 0.003 for ft8 in ft8_frequencies):
        return True
    return 50.313 <= freq <= 50.316


def is_likely_cw_frequency(freq):
    cw_ranges = (
        (1.800, 1.840),
        (3.500, 3.570),
        (7.000, 7.060),
        (10.100, 10.130),
        (14.000, 14.070),
        (18.068, 18.095),
        (21.000, 21.070),
        (24.890, 24.915),
        (28.000, 28.070),
    )
    return any(start <= freq <= end for start, end in cw_ranges)


def is_likely_ssb_frequency(freq):
    ssb_ranges = (
        (1.840, 2.000),
        (3.600, 4.000),
        (7.100, 7.300),
        (14.150, 14.350),
        (18.110, 18.168),
        (21.150, 21.450),
        (24.930, 24.990),
        (28.300, 29.000),
        (50.100, 50.300),
        (144.200, 144.400),
    )
    return any(start <= freq <= end for start, end in ssb_ranges)
