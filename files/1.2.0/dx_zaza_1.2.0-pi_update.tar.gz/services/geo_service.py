"""Geographic helpers for DX Zaza.

- Callsign -> country / continent / lat / lon using AD1C cty.dat (Country Files),
  downloaded and cached locally; falls back to a built-in country table.
- Maidenhead locator <-> lat/lon.
- Great-circle distance and bearing.

All longitudes returned by this module are EAST-positive (cty.dat uses WEST-positive
longitudes; they are converted on load).
"""

import os
import math
import re
import threading
import time
from pathlib import Path

import requests


CTY_URL = "https://www.country-files.com/cty/cty.dat"
CTY_MAX_AGE_SECONDS = 7 * 24 * 3600
CTY_RETRY_SECONDS = 6 * 3600
DATA_DIR_CANDIDATES = [Path("/var/lib/dx-zaza"), Path(__file__).resolve().parent.parent / "data"]

CONTINENT_NAMES = {
    "EU": "Europe",
    "NA": "North America",
    "SA": "South America",
    "AF": "Africa",
    "AS": "Asia",
    "OC": "Oceania",
    "AN": "Antarctica",
}

# Fallback: approximate centre (lat, lon east-positive) of the countries known by the
# built-in prefix table in dx_spots_service.py. Used only when cty.dat is unavailable.
COUNTRY_CENTROIDS = {
    "United Kingdom": (53.0, -1.8), "Ireland": (53.3, -7.9), "Italy": (42.8, 12.5),
    "Germany": (51.1, 10.4), "France": (46.6, 2.4), "Spain": (40.2, -3.6),
    "Portugal": (39.6, -8.1), "Netherlands": (52.2, 5.5), "Belgium": (50.6, 4.6),
    "Switzerland": (46.8, 8.2), "Austria": (47.6, 14.1), "Poland": (52.1, 19.4),
    "Czech Republic": (49.8, 15.5), "Slovakia": (48.7, 19.5), "Slovenia": (46.1, 14.9),
    "Croatia": (45.3, 15.9), "Serbia": (44.0, 20.8), "Bulgaria": (42.7, 25.3),
    "Romania": (45.9, 24.9), "Hungary": (47.2, 19.4), "Greece": (39.1, 22.0),
    "Norway": (61.5, 9.0), "Sweden": (62.0, 15.5), "Finland": (63.5, 26.0),
    "Denmark": (56.0, 9.8), "Estonia": (58.7, 25.5), "Latvia": (56.9, 24.6),
    "Lithuania": (55.3, 23.9), "Ukraine": (49.0, 31.4), "Russia": (56.0, 38.0),
    "Turkey": (39.0, 35.2), "Israel": (31.4, 35.0), "Oman": (21.0, 57.0),
    "United Arab Emirates": (24.3, 54.4), "Qatar": (25.3, 51.2), "Bahrain": (26.0, 50.6),
    "Japan": (36.2, 138.3), "South Korea": (36.5, 127.9), "China": (35.0, 105.0),
    "India": (21.0, 78.9), "Thailand": (15.1, 101.0), "Indonesia": (-2.5, 118.0),
    "Philippines": (12.9, 121.8), "Malaysia": (4.2, 102.0), "Singapore": (1.35, 103.8),
    "Australia": (-25.3, 133.8), "New Zealand": (-41.0, 174.0), "Hawaii": (20.8, -156.3),
    "Alaska": (64.2, -149.5), "United States": (39.5, -98.4), "Canada": (56.1, -106.3),
    "Mexico": (23.6, -102.5), "Cuba": (21.5, -77.8), "Puerto Rico": (18.2, -66.5),
    "Dominican Republic": (18.7, -70.2), "Brazil": (-14.2, -51.9), "Argentina": (-38.4, -63.6),
    "Chile": (-35.7, -71.5), "Uruguay": (-32.5, -55.8), "Colombia": (4.6, -74.3),
    "Venezuela": (6.4, -66.6), "Peru": (-9.2, -75.0), "South Africa": (-30.6, 22.9),
    "Morocco": (31.8, -7.1), "Egypt": (26.8, 30.8), "Kenya": (-0.0, 37.9),
    "Nigeria": (9.1, 8.7), "Tanzania": (-6.4, 34.9), "Algeria": (28.0, 1.7),
}

LOCATOR_RE = re.compile(r"^[A-R]{2}[0-9]{2}([A-X]{2}([0-9]{2})?)?$", re.IGNORECASE)
LOCATOR_PAIR_RE = re.compile(
    r"\b([A-R]{2}[0-9]{2}(?:[A-X]{2})?)\s*(?:<[A-Z]{2,3}>|<>|->|>|-|\s)\s*([A-R]{2}[0-9]{2}(?:[A-X]{2})?)\b",
    re.IGNORECASE,
)

_lock = threading.Lock()
_db = {"loaded_at": 0.0, "tried_at": 0.0, "prefixes": {}, "exact": {}, "max_len": 0, "source": "none"}


# ---------------------------------------------------------------- Maidenhead

def is_valid_locator(value):
    return bool(LOCATOR_RE.fullmatch(str(value or "").strip()))


def locator_to_latlon(locator):
    """Centre of a 4, 6 or 8 character Maidenhead square (lat, lon east-positive)."""
    loc = str(locator or "").strip()
    if not is_valid_locator(loc):
        raise ValueError("Invalid Maidenhead locator")
    loc = loc[:2].upper() + loc[2:4] + loc[4:6].lower() + loc[6:8]
    lon = (ord(loc[0]) - ord("A")) * 20 - 180
    lat = (ord(loc[1]) - ord("A")) * 10 - 90
    lon += int(loc[2]) * 2
    lat += int(loc[3]) * 1
    lon_size, lat_size = 2.0, 1.0
    if len(loc) >= 6:
        lon += (ord(loc[4]) - ord("a")) * (5.0 / 60)
        lat += (ord(loc[5]) - ord("a")) * (2.5 / 60)
        lon_size, lat_size = 5.0 / 60, 2.5 / 60
    if len(loc) >= 8:
        lon += int(loc[6]) * (0.5 / 60)
        lat += int(loc[7]) * (0.25 / 60)
        lon_size, lat_size = 0.5 / 60, 0.25 / 60
    return lat + lat_size / 2, lon + lon_size / 2


def latlon_to_locator(lat, lon, precision=6):
    lon = max(-180.0, min(179.9999, lon)) + 180
    lat = max(-90.0, min(89.9999, lat)) + 90
    out = chr(ord("A") + int(lon // 20)) + chr(ord("A") + int(lat // 10))
    lon %= 20
    lat %= 10
    out += str(int(lon // 2)) + str(int(lat // 1))
    if precision >= 6:
        lon = (lon % 2) * 60 / 5
        lat = (lat % 1) * 60 / 2.5
        out += chr(ord("a") + int(lon)) + chr(ord("a") + int(lat))
    return out


# ---------------------------------------------------------------- Great circle

def distance_bearing(lat1, lon1, lat2, lon2):
    """Great-circle distance (km) and initial bearing (deg) from point 1 to point 2."""
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lon2 - lon1)
    a = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    dist = 2 * r * math.asin(min(1.0, math.sqrt(a)))
    y = math.sin(dl) * math.cos(p2)
    x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    bearing = (math.degrees(math.atan2(y, x)) + 360) % 360
    return dist, bearing


# ---------------------------------------------------------------- cty.dat

def _data_dir():
    candidates = list(DATA_DIR_CANDIDATES)
    env = os.environ.get("DX_ZAZA_DATA_DIR", "").strip()
    if env:
        candidates.insert(0, Path(env).expanduser())
    for candidate in candidates:
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            probe = candidate / ".write_test"
            probe.write_text("ok")
            probe.unlink()
            return candidate
        except OSError:
            continue
    return DATA_DIR_CANDIDATES[-1]


def parse_cty(text):
    """Parse AD1C cty.dat. Returns (prefixes, exact) dicts of entity info."""
    prefixes, exact = {}, {}
    records = text.replace("\r", "").split(";")
    for record in records:
        record = record.strip()
        if not record or ":" not in record:
            continue
        head_parts = record.split(":")
        if len(head_parts) < 9:
            continue
        name = head_parts[0].strip()
        try:
            cq, itu = int(head_parts[1]), int(head_parts[2])
            cont = head_parts[3].strip()
            lat = float(head_parts[4])
            lon = -float(head_parts[5])  # cty.dat is west-positive
        except ValueError:
            continue
        primary = head_parts[7].strip().lstrip("*")
        base = {"country": name, "continent": cont, "lat": lat, "lon": lon, "cq": cq, "itu": itu}
        aliases = ":".join(head_parts[8:])
        for raw in aliases.replace("\n", " ").split(","):
            token = raw.strip()
            if not token:
                continue
            info = dict(base)
            m = re.search(r"<([-0-9.]+)/([-0-9.]+)>", token)
            if m:
                info["lat"], info["lon"] = float(m.group(1)), -float(m.group(2))
            m = re.search(r"\{([A-Z]{2})\}", token)
            if m:
                info["continent"] = m.group(1)
            call = re.sub(r"[\(\[<\{~].*$", "", token).strip().upper()
            if not call:
                continue
            if call.startswith("="):
                exact[call[1:]] = info
            else:
                prefixes[call] = info
        if primary and primary.upper() not in prefixes:
            prefixes[primary.upper()] = dict(base)
    return prefixes, exact


def _load_cty_locked():
    now = time.time()
    path = _data_dir() / "cty.dat"
    fresh = path.exists() and now - path.stat().st_mtime < CTY_MAX_AGE_SECONDS
    if not fresh and now - _db["tried_at"] > CTY_RETRY_SECONDS:
        _db["tried_at"] = now
        try:
            resp = requests.get(CTY_URL, timeout=8, headers={"User-Agent": "DX-Zaza/0.4"})
            if resp.ok and "Germany" in resp.text:
                path.write_text(resp.text, encoding="utf-8")
        except requests.RequestException:
            pass
    if path.exists() and (_db["loaded_at"] < path.stat().st_mtime or not _db["prefixes"]):
        try:
            prefixes, exact = parse_cty(path.read_text(encoding="utf-8", errors="ignore"))
            if prefixes:
                _db.update(prefixes=prefixes, exact=exact, loaded_at=now,
                           max_len=max(len(p) for p in prefixes), source="cty.dat")
        except OSError:
            pass


def cty_status():
    return {"source": _db["source"], "entities": len(_db["prefixes"])}


def lookup_callsign(callsign):
    """Return entity info for a callsign from cty.dat, or None."""
    call = str(callsign or "").strip().upper()
    if not call:
        return None
    with _lock:
        _load_cty_locked()
    if not _db["prefixes"]:
        return None
    if call in _db["exact"]:
        return _db["exact"][call]
    parts = [p for p in call.split("/") if p]
    skip = {"P", "M", "MM", "AM", "QRP", "QRPP", "A", "B", "LH"}
    candidates = []
    if len(parts) >= 2:
        # Prefer the explicit prefix part (e.g. EA8/G4ABC or G4ABC/EA8): the shorter, non-suffix part.
        others = [p for p in parts if p not in skip and not p.isdigit()]
        others.sort(key=len)
        candidates.extend(others)
    candidates.append(parts[0] if parts else call)
    for cand in candidates:
        for length in range(min(len(cand), _db["max_len"]), 0, -1):
            info = _db["prefixes"].get(cand[:length])
            if info:
                return info
    return None


# Approximate centre of the call area (the digit in the callsign) for large DXCC entities,
# so a station is placed in its region instead of the middle of the country.
CALL_AREAS = {
    "United States": {"1": (43.0, -71.6), "2": (41.4, -74.6), "3": (40.2, -77.0), "4": (33.8, -83.5),
                      "5": (32.4, -96.5), "6": (36.6, -119.6), "7": (44.5, -114.5), "8": (40.8, -83.2),
                      "9": (41.6, -88.4), "0": (41.6, -97.5)},
    "Canada": {"1": (45.0, -63.5), "2": (47.0, -72.0), "3": (44.2, -79.6), "4": (50.0, -97.8),
               "5": (52.1, -106.4), "6": (52.5, -113.8), "7": (49.6, -122.9), "8": (62.5, -114.4),
               "9": (46.2, -66.2), "VO1": (47.6, -53.0), "VO2": (53.4, -60.4), "VY0": (63.7, -68.5),
               "VY1": (60.7, -135.1), "VY2": (46.3, -63.2)},
    "Australia": {"1": (-35.3, 149.1), "2": (-33.2, 150.0), "3": (-37.6, 144.8), "4": (-26.5, 151.5),
                  "5": (-34.6, 138.6), "6": (-31.8, 116.0), "7": (-42.0, 146.8), "8": (-14.5, 132.5)},
    "Japan": {"1": (35.7, 139.6), "2": (35.0, 137.0), "3": (34.7, 135.4), "4": (34.4, 132.6),
              "5": (33.7, 133.5), "6": (32.8, 130.8), "7": (39.0, 140.9), "8": (43.1, 141.4),
              "9": (36.6, 136.7), "0": (36.5, 138.2)},
    "Brazil": {"1": (-22.6, -43.2), "2": (-23.3, -47.5), "3": (-30.0, -51.4), "4": (-19.9, -44.0),
               "5": (-26.0, -50.0), "6": (-12.9, -39.5), "7": (-7.5, -36.5), "8": (-2.5, -50.0),
               "9": (-16.0, -50.0)},
    "European Russia": {"1": (59.9, 31.5), "2": (54.7, 20.5), "3": (55.5, 38.0), "4": (53.8, 49.5),
                        "6": (45.5, 40.5)},
    "Asiatic Russia": {"8": (56.0, 84.0), "9": (56.0, 66.0), "0": (54.0, 110.0)},
    "China": {"1": (39.9, 116.4), "2": (44.0, 126.0), "3": (38.5, 114.5), "4": (31.5, 120.5),
              "5": (27.5, 118.5), "6": (31.0, 113.5), "7": (23.5, 112.5), "8": (29.5, 104.5),
              "9": (35.5, 106.0), "0": (42.0, 87.0)},
    "Spain": {"1": (42.4, -5.6), "2": (42.6, -1.5), "3": (41.6, 1.7), "4": (40.0, -4.0),
              "5": (39.0, -0.9), "7": (37.4, -4.6)},
    "Italy": {"1": (44.9, 8.0), "2": (45.6, 9.7), "3": (45.7, 12.1), "4": (44.5, 11.2), "5": (43.4, 11.1),
              "6": (42.9, 13.6), "7": (40.9, 16.6), "8": (40.4, 15.6), "0": (42.2, 12.6)},
    "Argentina": {"1": (-34.6, -58.6), "2": (-34.6, -58.6), "3": (-34.9, -60.0), "4": (-31.4, -64.2),
                  "5": (-31.0, -61.0), "6": (-32.9, -68.8), "7": (-27.5, -65.0), "8": (-38.9, -68.1),
                  "9": (-45.0, -68.0)},
}
SUFFIX_PARTS = {"P", "M", "MM", "AM", "QRP", "QRPP", "A", "B", "LH"}


def _area_part(call):
    """The part of the callsign that names the area: 'I3/DL1ABC' -> 'I3', 'IW4BLZ/P' -> 'IW4BLZ'."""
    parts = [p for p in call.split("/") if p]
    if len(parts) >= 2:
        others = sorted([p for p in parts if p not in SUFFIX_PARTS and not p.isdigit()], key=len)
        if others and len(others[0]) <= 4 and any(ch.isdigit() for ch in others[0]):
            return others[0]
        return parts[0]
    return parts[0] if parts else call


def call_area_position(callsign, country):
    table = CALL_AREAS.get(country)
    if not table:
        return None
    part = _area_part(str(callsign or "").upper())
    if part[:3] in table:
        return table[part[:3]]
    body = part[1:] if part[:1].isdigit() else part
    m = re.search(r"\d", body)
    return table.get(m.group(0)) if m else None


def _is_mobile_at_sea(callsign):
    parts = str(callsign or "").upper().split("/")
    return len(parts) > 1 and parts[-1] in ("MM", "AM")


def locate_dx(callsign, comment=""):
    """Position of the DX station (the one transmitting on the spotted frequency):
    second locator of a pair in the comment ('JN45 -> FN31'), else call area, else cty.dat."""
    if _is_mobile_at_sea(callsign):
        return None
    info = lookup_callsign(callsign)
    m = LOCATOR_PAIR_RE.search(str(comment or "").upper())
    if m:
        try:
            lat, lon = locator_to_latlon(m.group(2))
            return {"country": info["country"] if info else "Unknown",
                    "region": CONTINENT_NAMES.get(info["continent"], "") if info else "",
                    "lat": round(lat, 3), "lon": round(lon, 3), "precision": "locator"}
        except ValueError:
            pass
    if not info:
        return None
    exact = str(callsign or "").upper() in _db["exact"]
    area = None if exact else call_area_position(callsign, info["country"])
    lat, lon = area if area else (info["lat"], info["lon"])
    return {"country": info["country"], "region": CONTINENT_NAMES.get(info["continent"], info["continent"]),
            "lat": lat, "lon": lon, "precision": "call-area" if area else "country"}


def locate(callsign, comment="", fallback_country=None):
    """Best available position for a spotter: locator in comment > cty.dat > country table."""
    comment = str(comment or "")
    m = LOCATOR_PAIR_RE.search(comment.upper())
    info = lookup_callsign(callsign)
    if m:
        try:
            lat, lon = locator_to_latlon(m.group(1))
            return {
                "country": info["country"] if info else (fallback_country or "Unknown"),
                "region": CONTINENT_NAMES.get(info["continent"], "") if info else "",
                "lat": round(lat, 3), "lon": round(lon, 3), "precision": "locator",
            }
        except ValueError:
            pass
    if info:
        exact = str(callsign or "").upper() in _db["exact"]
        area = None if exact else call_area_position(callsign, info["country"])
        lat, lon = area if area else (info["lat"], info["lon"])
        return {
            "country": info["country"],
            "region": CONTINENT_NAMES.get(info["continent"], info["continent"]),
            "lat": lat, "lon": lon, "precision": "call-area" if area else "country",
        }
    if fallback_country and fallback_country in COUNTRY_CENTROIDS:
        lat, lon = COUNTRY_CENTROIDS[fallback_country]
        return {"country": fallback_country, "region": "", "lat": lat, "lon": lon, "precision": "country"}
    return None
