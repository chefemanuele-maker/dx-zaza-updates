"""ISS Live: NASA's official live video from the space station and the ARISS amateur radio
frequencies shown on the map.

Video: NASA's official "Live High-Definition Views from the International Space Station" stream,
played with the standard YouTube embedded player. NASA restarts the stream now and then with a
new video id, so the id is found automatically: candidates (config "iss_live.youtube_video_id",
the last good id, the ids listed on NASA's channel "live" page, a known id) are checked with
YouTube's public oEmbed endpoint and the first one published by NASA about the space station is
used. Checked again every 3 hours (10 minutes after a failure); the last good id is kept.

Radio: ARISS (Amateur Radio on the ISS), www.ariss.org "Contact the ISS" and
"Current Status of ISS Stations". The repeater/APRS status changes with crew and hardware:
keep RADIO["status_date"] and the "active" flags up to date (remote update).
"""

import logging
import re
import threading
import time

import requests

log = logging.getLogger("dxzaza.iss")

NASA_CHANNEL_ID = "UCLA_DiR1FfKNvjuUpBHmylQ"     # youtube.com/@NASA
WATCH_URL = "https://www.youtube.com/nasa/live"
LIVE_PAGE = "https://www.youtube.com/channel/%s/live" % NASA_CHANNEL_ID
OEMBED = "https://www.youtube.com/oembed"
KNOWN_IDS = ["ROboUHfPUrU"]                      # "Live High-Definition Views from the ISS" (Oct 2026)
RECHECK_OK = 3 * 3600
RECHECK_FAIL = 10 * 60
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15"
ID_RE = re.compile(r'"videoId":"([A-Za-z0-9_-]{11})"')


class StreamResolver:
    def __init__(self, http_get=None, clock=time.time):
        self.http_get = http_get or (lambda url, **kw: requests.get(url, timeout=10, **kw))
        self.clock = clock
        self.lock = threading.Lock()
        self.video_id = ""
        self.title = ""
        self.next = 0.0

    def is_iss_stream(self, video_id):
        """True when YouTube says this video is NASA's own space-station stream."""
        try:
            res = self.http_get(OEMBED, params={"url": "https://www.youtube.com/watch?v=" + video_id, "format": "json"})
            if res.status_code != 200:
                return None
            data = res.json()
        except Exception:
            return None
        author = str(data.get("author_name") or "")
        title = str(data.get("title") or "")
        if author.strip().upper() == "NASA" and "space station" in title.lower():
            return title
        return None

    def page_ids(self):
        try:
            res = self.http_get(LIVE_PAGE, headers={"User-Agent": UA, "Accept-Language": "en"})
            if res.status_code != 200:
                return []
            counts = {}
            for vid in ID_RE.findall(res.text):
                counts[vid] = counts.get(vid, 0) + 1
            return sorted(counts, key=lambda v: -counts[v])[:8]
        except Exception:
            return []

    def resolve(self, configured=""):
        with self.lock:
            now = self.clock()
            if self.video_id and now < self.next and not configured:
                return self.video_id, self.title
            candidates = []
            for vid in [configured, self.video_id] + KNOWN_IDS:
                if vid and vid not in candidates:
                    candidates.append(vid)
            checked = set()
            for group in (candidates, None):
                if group is None:
                    group = [v for v in self.page_ids() if v not in checked]
                for vid in group:
                    checked.add(vid)
                    title = self.is_iss_stream(vid)
                    if title:
                        if vid != self.video_id:
                            log.info("ISS live stream: %s (%s)", vid, title)
                        self.video_id, self.title, self.next = vid, title, now + RECHECK_OK
                        return vid, title
            log.warning("ISS live stream: no NASA space-station stream found, keeping %r", self.video_id)
            self.next = now + RECHECK_FAIL
            return self.video_id, self.title


resolver = StreamResolver()

RADIO = {
    "status_date": "2026-10-07",
    "source": "ARISS (ariss.org)",
    "callsigns": "NA1SS · RS0ISS",
    "items": [
        {"key": "voice_down", "label": {"en": "Voice downlink", "it": "Voce downlink"},
         "freq": "145.800 MHz", "mode": "FM", "active": True},
        {"key": "voice_up_r1", "label": {"en": "Voice uplink (Region 1)", "it": "Voce uplink (Regione 1)"},
         "freq": "145.200 MHz", "mode": "FM", "region": 1, "active": True},
        {"key": "voice_up_r23", "label": {"en": "Voice uplink (Regions 2-3)", "it": "Voce uplink (Regioni 2-3)"},
         "freq": "144.490 MHz", "mode": "FM", "region": 23, "active": True},
        {"key": "rpt_up", "label": {"en": "FM repeater uplink", "it": "Ripetitore FM uplink"},
         "freq": "145.990 MHz", "mode": "FM · CTCSS 67 Hz", "active": True},
        {"key": "rpt_down", "label": {"en": "FM repeater downlink", "it": "Ripetitore FM downlink"},
         "freq": "437.800 MHz", "mode": "FM", "active": True},
        {"key": "aprs", "label": {"en": "APRS / packet", "it": "APRS / packet"},
         "freq": "437.825 MHz", "mode": "1200 bd", "active": True},
        {"key": "packet_vhf", "label": {"en": "Packet (VHF)", "it": "Packet (VHF)"},
         "freq": "145.825 MHz", "mode": "1200 bd", "active": False},
        {"key": "sstv", "label": {"en": "SSTV events", "it": "Eventi SSTV"},
         "freq": "437.550 MHz", "mode": "Robot36", "active": False},
    ],
    "notes": {
        "en": "Activity depends on the crew schedule. Never transmit on a downlink frequency. "
              "Doppler: about ±3.5 kHz on 145 MHz and ±10 kHz on 437 MHz.",
        "it": "L'attività dipende dagli impegni dell'equipaggio. Non trasmettere mai su una frequenza di downlink. "
              "Doppler: circa ±3,5 kHz su 145 MHz e ±10 kHz su 437 MHz.",
    },
}


def itu_region(lat, lon):
    """ITU region (1, 2 or 3) of a position, good enough to pick the ISS voice uplink."""
    if lat is None or lon is None:
        return None
    lat, lon = float(lat), float(lon)
    if lon < -25:
        return 2                                    # the Americas, Greenland, Hawaii
    if lon < 60:
        return 1                                    # Europe, Africa, Middle East
    if lat >= 40:
        return 1                                    # Russia, Mongolia, north/central Asia
    return 3                                        # south/east Asia, Oceania


def stream_info(config, origin="", resolve=None):
    cfg = (config or {}).get("iss_live", {}) or {}
    configured = str(cfg.get("youtube_video_id") or "").strip()
    video, title = (resolve or resolver.resolve)(configured)
    # a clean player with only DX Zaza's own buttons (sound, reload, enlarge, close): no YouTube
    # control bar, no keyboard shortcuts, no annotations or captions, related videos only from NASA.
    # (YouTube's logo/title must stay visible: its terms do not allow hiding or covering them.)
    params = ("autoplay=1&mute=1&enablejsapi=1&playsinline=1&controls=0&rel=0&fs=0&disablekb=1"
              "&iv_load_policy=3&cc_load_policy=0")
    if origin:
        params += "&origin=" + origin.rstrip("/")
    if not video:
        return {"embedUrl": "", "watchUrl": WATCH_URL, "source": "NASA", "videoId": "", "title": ""}
    return {"embedUrl": "https://www.youtube.com/embed/%s?%s" % (video, params),
            "watchUrl": "https://www.youtube.com/watch?v=" + video, "source": "NASA", "videoId": video, "title": title}


def get_iss_info(config, home=None, lang="en", origin="", resolve=None):
    region = itu_region(*home) if home else None
    lang = "it" if lang == "it" else "en"
    items = []
    for item in RADIO["items"]:
        mine = None
        if "region" in item and region:
            mine = (item["region"] == 1) == (region == 1)
        items.append({"key": item["key"], "label": item["label"][lang], "freq": item["freq"], "mode": item["mode"],
                      "active": item["active"], "yourRegion": mine})
    return {
        "ok": True,
        "stream": stream_info(config, origin, resolve),
        "radio": {"items": items, "callsigns": RADIO["callsigns"], "statusDate": RADIO["status_date"],
                  "source": RADIO["source"], "note": RADIO["notes"][lang]},
        "region": region,
    }
