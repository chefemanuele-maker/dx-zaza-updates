"""Automatic operator position from the Internet connection (IP geolocation).

The public IP address gives the town of the Internet connection (typically within
10-50 km): plenty for a 4-character Maidenhead square (about 110 x 150 km), distances,
beam headings, grey line and satellite passes. With a VPN the VPN's town is found:
the operator can switch to a manual locator in Settings.

Providers are tried in order; the first answer wins. One request at start-up and then
every 6 hours at most (a laptop can move), cached in memory.
"""

import logging
import threading
import time

import requests

log = logging.getLogger("dxzaza.location")

TIMEOUT = 6
REFRESH_SECONDS = 6 * 3600
RETRY_SECONDS = 10 * 60


def _ipinfo(data):
    lat, lon = (float(v) for v in data["loc"].split(","))
    return lat, lon, data.get("city", ""), data.get("region", ""), data.get("country", "")


def _ipapi(data):
    return (float(data["latitude"]), float(data["longitude"]), data.get("city", ""), data.get("region", ""),
            data.get("country_name") or data.get("country", ""))


def _ipwho(data):
    if data.get("success") is False:
        raise ValueError(data.get("message", "failed"))
    return (float(data["latitude"]), float(data["longitude"]), data.get("city", ""), data.get("region", ""),
            data.get("country", ""))


def _freeipapi(data):
    return (float(data["latitude"]), float(data["longitude"]), data.get("cityName", ""),
            data.get("regionName", ""), data.get("countryName", ""))


PROVIDERS = [
    ("ipinfo.io", "https://ipinfo.io/json", _ipinfo),
    ("ipapi.co", "https://ipapi.co/json/", _ipapi),
    ("ipwho.is", "https://ipwho.is/", _ipwho),
    ("freeipapi.com", "https://freeipapi.com/api/json", _freeipapi),
]


def detect(providers=None, http_get=None):
    """Returns {lat, lon, city, region, country, provider} or raises RuntimeError."""
    http_get = http_get or (lambda url: requests.get(url, timeout=TIMEOUT, headers={"User-Agent": "DX-Zaza",
                                                                                    "Accept": "application/json"}))
    errors = []
    for name, url, parse in providers or PROVIDERS:
        try:
            resp = http_get(url)
            resp.raise_for_status()
            lat, lon, city, region, country = parse(resp.json())
            if not (-90 <= lat <= 90 and -180 <= lon <= 180) or (lat == 0 and lon == 0):
                raise ValueError("invalid position")
            return {"lat": round(lat, 4), "lon": round(lon, 4), "city": city or "", "region": region or "",
                    "country": country or "", "provider": name}
        except Exception as exc:  # network, quota, format: try the next one
            errors.append("%s: %s" % (name, type(exc).__name__))
    raise RuntimeError("; ".join(errors) or "no provider")


class AutoLocation:
    """Keeps the operator QTH up to date while the location mode is 'auto'."""

    def __init__(self, get_mode, apply, detector=detect):
        self.get_mode = get_mode        # -> "auto" | "manual"
        self.apply = apply              # (result dict) -> None, saves the locator
        self.detector = detector
        self.last = None
        self.last_error = ""
        self.checked_at = 0.0
        self._lock = threading.Lock()
        self._thread = None

    def refresh(self, force=False):
        with self._lock:
            now = time.time()
            wait = REFRESH_SECONDS if self.last else RETRY_SECONDS
            if not force and now - self.checked_at < wait:
                return self.last
            self.checked_at = now
            try:
                result = self.detector()
            except Exception as exc:
                self.last_error = str(exc)
                log.warning("automatic location failed: %s", exc)
                return self.last
            self.last, self.last_error = result, ""
        if self.get_mode() == "auto":
            self.apply(result)
            log.info("automatic location: %s, %s (%s)", result["city"], result["country"], result["provider"])
        return result

    def start(self):
        if self._thread:
            return

        def loop():
            while True:
                if self.get_mode() == "auto":
                    self.refresh()
                time.sleep(60)

        self._thread = threading.Thread(target=loop, name="auto-location", daemon=True)
        self._thread.start()
