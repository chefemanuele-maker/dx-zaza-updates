import json
import os
import re
import subprocess


COMMAND_TIMEOUT_SECONDS = 5
WIFI_CONNECT_TIMEOUT_SECONDS = 75
WIFI_CONNECT_HELPER = os.environ.get("DX_ZAZA_WIFI_HELPER", "/usr/local/sbin/dx-zaza-wifi-helper")
PUBLIC_CONNECT_REASONS = {
    "auth_failed",
    "network_not_found",
    "timeout",
    "no_ip",
    "no_gateway",
    "dns_failed",
    "internet_failed",
    "rollback_failed",
    "permission_error",
    "unknown_error",
}
SENSITIVE_KEYS = ("password", "psk", "wifi-sec.psk", "secrets")
READ_ONLY_COMMANDS = {
    "device_status": ["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device", "status"],
    "wifi_scan": ["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY,IN-USE", "dev", "wifi", "list"],
    "wlan_show": ["nmcli", "device", "show", "wlan0"],
    "route": ["ip", "route"],
}


def _run_read_only(name):
    command = READ_ONLY_COMMANDS[name]
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=COMMAND_TIMEOUT_SECONDS,
            check=False,
            shell=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return ""
    return result.stdout if result.returncode == 0 else ""


def redact_sensitive(value):
    if isinstance(value, dict):
        redacted = {}
        for key, item in value.items():
            lowered = str(key).lower()
            if any(secret in lowered for secret in SENSITIVE_KEYS):
                redacted[key] = "[redacted]"
            else:
                redacted[key] = redact_sensitive(item)
        return redacted
    if isinstance(value, list):
        return [redact_sensitive(item) for item in value]
    return value


def _split_terse(line):
    values = []
    current = []
    escaped = False
    for character in line.rstrip("\n"):
        if escaped:
            current.append(character)
            escaped = False
        elif character == "\\":
            escaped = True
        elif character == ":":
            values.append("".join(current))
            current = []
        else:
            current.append(character)
    if escaped:
        current.append("\\")
    values.append("".join(current))
    return values


def _device_rows(text):
    rows = []
    for line in text.splitlines():
        fields = _split_terse(line)
        if len(fields) >= 3:
            rows.append({"device": fields[0], "type": fields[1], "state": fields[2]})
    return rows


def _device_show_values(text):
    values = {}
    for line in text.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        values[key.strip()] = value.strip()
    return values


def _connected(row):
    return row.get("state", "").lower().startswith("connected")


def _clean_ip(value):
    match = re.match(r"^([^/\s]+)", value or "")
    return match.group(1) if match else ""


def get_network_status(internet_online=False):
    rows = _device_rows(_run_read_only("device_status"))
    wifi_row = next((row for row in rows if row["type"] == "wifi"), None)
    ethernet_row = next((row for row in rows if row["type"] == "ethernet"), None)
    wlan = _device_show_values(_run_read_only("wlan_show")) if wifi_row else {}
    _run_read_only("route")

    wifi_connected = bool(wifi_row and _connected(wifi_row))
    return {
        "ok": True,
        "network": {
            "online": bool(internet_online),
            "wifi": {
                "available": wifi_row is not None,
                "connected": wifi_connected,
                "ssid": wlan.get("GENERAL.CONNECTION", "") if wifi_connected else "",
                "ip": _clean_ip(wlan.get("IP4.ADDRESS[1]", "")) if wifi_connected else "",
                "signal": None,
            },
            "ethernet": {
                "available": ethernet_row is not None,
                "connected": bool(ethernet_row and _connected(ethernet_row)),
            },
            "internet": {"online": bool(internet_online)},
        },
    }


def scan_wifi_networks():
    networks_by_ssid = {}
    for line in _run_read_only("wifi_scan").splitlines():
        fields = _split_terse(line)
        if len(fields) < 4 or not fields[0]:
            continue
        ssid, signal, security, in_use = fields[:4]
        try:
            signal_value = max(0, min(100, int(signal)))
        except ValueError:
            signal_value = 0
        network = {
            "ssid": ssid,
            "signal": signal_value,
            "secured": bool(security and security != "--"),
            "connected": in_use == "*",
        }
        previous = networks_by_ssid.get(ssid)
        if previous is None or network["connected"] or network["signal"] > previous["signal"]:
            networks_by_ssid[ssid] = network
    networks = sorted(networks_by_ssid.values(), key=lambda item: (not item["connected"], -item["signal"], item["ssid"].lower()))
    return {"ok": True, "networks": networks}


def _customer_safe_connect_failure(reason="unknown_error"):
    public_reason = reason if reason in PUBLIC_CONNECT_REASONS else "unknown_error"
    return {
        "ok": False,
        "status": "failed",
        "message": "Unable to connect to this Wi-Fi network. The previous connection was restored.",
        "reason": public_reason,
    }


def _normalize_connect_timeout(value):
    try:
        timeout = int(value)
    except (TypeError, ValueError):
        timeout = 45
    return max(15, min(120, timeout))


def connect_wifi_network(ssid, password, timeout_seconds=45):
    ssid = str(ssid or "").strip()
    password = "" if password is None else str(password)
    timeout_seconds = _normalize_connect_timeout(timeout_seconds)
    if not ssid:
        return _customer_safe_connect_failure("network_not_found")
    if "\n" in ssid or "\r" in ssid or "\n" in password or "\r" in password:
        return _customer_safe_connect_failure("unknown_error")

    payload = {
        "ssid": ssid,
        "password": password,
        "timeout_seconds": timeout_seconds,
    }
    command = [WIFI_CONNECT_HELPER]
    if os.geteuid() != 0:
        command = ["sudo", "-n", WIFI_CONNECT_HELPER]
    try:
        result = subprocess.run(
            command,
            input=json.dumps(payload),
            capture_output=True,
            text=True,
            timeout=timeout_seconds + 30,
            check=False,
            shell=False,
        )
    except FileNotFoundError:
        return _customer_safe_connect_failure("permission_error")
    except subprocess.TimeoutExpired:
        return _customer_safe_connect_failure("timeout")
    except OSError:
        return _customer_safe_connect_failure("permission_error")

    try:
        helper_payload = json.loads(result.stdout or "{}")
    except json.JSONDecodeError:
        helper_payload = {}
    helper_payload = redact_sensitive(helper_payload)

    if result.returncode == 0 and helper_payload.get("ok") is True:
        checks = helper_payload.get("checks") if isinstance(helper_payload.get("checks"), dict) else {}
        return {
            "ok": True,
            "status": "connected",
            "ssid": ssid,
            "message": "Connected successfully",
            "checks": {
                "ip": checks.get("ip") is True,
                "gateway": checks.get("gateway") is True,
                "dns": checks.get("dns") is True,
                "internet": checks.get("internet") is True,
            },
        }
    return _customer_safe_connect_failure(helper_payload.get("reason", "unknown_error"))
