"""Where DX Zaza is running and what it can do there.

  pi       Raspberry Pi appliance (kiosk, Wi-Fi setup, BlueDV Radio)
  desktop  macOS / Windows / Linux desktop app (built-in voice engine)

DX_ZAZA_PLATFORM forces one of them. The desktop launcher sets it, together
with DX_ZAZA_DATA_DIR and DX_ZAZA_CONFIG pointing to the user's own folder.
"""

import os
import platform
import sys
from pathlib import Path

APP_NAME = "DX Zaza"


def os_name():
    if sys.platform == "darwin":
        return "macos"
    if sys.platform.startswith("win"):
        return "windows"
    return "linux"


def is_raspberry_pi():
    try:
        model = Path("/proc/device-tree/model").read_text(errors="ignore")
        return "raspberry pi" in model.lower()
    except OSError:
        return False


def detect_platform():
    forced = os.environ.get("DX_ZAZA_PLATFORM", "").strip().lower()
    if forced in ("pi", "desktop"):
        return forced
    if os_name() == "linux" and (is_raspberry_pi() or Path("/etc/dx-zaza").is_dir()):
        return "pi"
    return "desktop"


def user_data_dir():
    """Per-user folder for config, caches and logs on the desktop."""
    env = os.environ.get("DX_ZAZA_DATA_DIR", "").strip()
    if env:
        return Path(env).expanduser()
    home = Path.home()
    system = os_name()
    if system == "macos":
        return home / "Library" / "Application Support" / APP_NAME
    if system == "windows":
        base = os.environ.get("APPDATA") or str(home / "AppData" / "Roaming")
        return Path(base) / APP_NAME
    base = os.environ.get("XDG_DATA_HOME") or str(home / ".local" / "share")
    return Path(base) / "dx-zaza"


def log_dir():
    system = os_name()
    if system == "macos" and not os.environ.get("DX_ZAZA_DATA_DIR"):
        return Path.home() / "Library" / "Logs" / APP_NAME
    return user_data_dir() / "logs"


def features(kind=None):
    kind = kind or detect_platform()
    pi = kind == "pi"
    return {
        "platform": kind,
        "os": os_name(),
        "arch": platform.machine(),
        "wifiSetup": pi,          # the desktop OS manages its own network
        "systemControls": pi,
        "bluedvRadio": pi,        # BlueDV Radio (PA7LIM) is published for the Pi
        "voiceEngine": True,      # built-in DVstick engine
        "touchKeyboard": pi,
    }
