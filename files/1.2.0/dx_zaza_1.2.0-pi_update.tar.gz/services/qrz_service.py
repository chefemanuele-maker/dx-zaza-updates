"""QRZ.com callsign lookup (official QRZ XML Logbook Data service).

Each operator logs in with their own QRZ.com account; full data (photo, name, address)
needs their "XML Logbook Data" subscription, without it QRZ returns a reduced record.

  * login -> session key, cached and reused (re-login only on a session error)
  * each callsign is looked up once and kept 24 h (not found: 1 h), so a station that
    keeps transmitting does not cause repeated requests
  * the password is kept only in the local config file, never logged, never returned
  * shown on screen: photo, name, city, country, grid. The street address is not
    returned to the screen (the full record stays on qrz.com)
"""

import contextlib
import logging
import re
import threading
import time
import xml.etree.ElementTree as ET

import requests

log = logging.getLogger("dxzaza.qrz")

API_URL = "https://xmldata.qrz.com/xml/current/"
AGENT = "DXZaza"
FOUND_TTL = 24 * 3600
MISSING_TTL = 3600
PHOTO_MAX_BYTES = 3 * 1024 * 1024
LOGIN_RETRY_SECONDS = 600
CALL_RE = re.compile(r"^[A-Z0-9/]{3,15}$")

# fields passed to the screen (no street address, no e-mail)
SHOW_FIELDS = ("call", "fname", "name", "nickname", "name_fmt", "addr2", "state", "country", "grid",
               "lat", "lon", "image", "qslmgr", "class", "born", "lotw", "eqsl", "mqsl")


class QRZError(Exception):
    pass


_IPV4_LOCK = threading.Lock()


@contextlib.contextmanager
def ipv4_only():
    """Resolve names to IPv4 addresses only, for the duration of one request."""
    import socket
    import urllib3.util.connection as urllib3_connection
    with _IPV4_LOCK:
        original = urllib3_connection.allowed_gai_family
        urllib3_connection.allowed_gai_family = lambda: socket.AF_INET
        try:
            yield
        finally:
            urllib3_connection.allowed_gai_family = original


def _strip_ns(root):
    for el in root.iter():
        if "}" in el.tag:
            el.tag = el.tag.split("}", 1)[1]
    return root


def parse_response(text):
    """-> (session dict, callsign dict or None). Raises QRZError on bad XML."""
    try:
        root = _strip_ns(ET.fromstring(text))
    except ET.ParseError as exc:
        raise QRZError("QRZ answered with something that is not XML") from exc
    node_s = root.find("Session")
    session = {child.tag: (child.text or "").strip() for child in node_s} if node_s is not None else {}
    node = root.find("Callsign")
    callsign = {child.tag: (child.text or "").strip() for child in node} if node is not None else None
    return session, callsign


def base_callsign(call):
    """D-STAR / cluster calls can carry prefixes and suffixes (EA8/G4ABC/P): QRZ knows the
    main one. Returns the candidates to try, the full call first."""
    call = (call or "").strip().upper().replace(" ", "")
    call = call.split("-")[0]
    if not call:
        return []
    parts = [p for p in call.split("/") if p]
    out = [call]
    if len(parts) > 1:
        with_digit = [p for p in parts if re.search(r"\d", p) and re.search(r"[A-Z]", p) and len(p) >= 3]
        if with_digit:
            out.append(max(with_digit, key=len))
    return list(dict.fromkeys(out))


class QRZClient:
    def __init__(self, get_credentials, session=None, clock=time.time, agent=AGENT):
        self.get_credentials = get_credentials        # -> (username, password) or ("", "")
        self.http = session or requests.Session()
        self.clock = clock
        self.agent = agent
        self.lock = threading.Lock()
        self.key = ""
        self.key_user = ""
        self.sub_exp = ""
        self.last_error = ""
        self.cache = {}                                 # CALL -> (expires, record or None)
        self.photos = {}                                # CALL -> (expires, bytes, type)
        self.photo_error = ""
        self.failed_login = None
        self.login_blocked_until = 0

    # ------------------------------------------------------------ status
    def configured(self):
        user, password = self.get_credentials()
        return bool(user and password)

    def status(self):
        user, _ = self.get_credentials()
        return {
            "configured": self.configured(),
            "username": user or "",
            "loggedIn": bool(self.key) and self.key_user == user,
            "subscription": self.sub_exp,
            "fullData": bool(self.sub_exp) and self.sub_exp.lower() != "non-subscriber",
            "error": self.last_error,
            "photoError": self.photo_error,
        }

    # ------------------------------------------------------------ session
    def _get(self, params):
        try:
            res = self.http.get(API_URL, params=params, timeout=(6, 15))
            res.raise_for_status()
        except (requests.ConnectionError, requests.Timeout):
            # many home networks announce IPv6 but do not route it: the connection then hangs.
            # Try once more over IPv4 only.
            try:
                with ipv4_only():
                    res = self.http.get(API_URL, params=params, timeout=(6, 15))
                res.raise_for_status()
            except requests.RequestException as exc:
                raise QRZError("QRZ.com not reachable: %s" % exc.__class__.__name__) from exc
        except requests.RequestException as exc:
            raise QRZError("QRZ.com not reachable: %s" % exc.__class__.__name__) from exc
        return parse_response(res.text)

    def login(self, username=None, password=None):
        if username is None:
            username, password = self.get_credentials()
        if not username or not password:
            raise QRZError("Enter your QRZ.com username and password in Settings.")
        if self.login_blocked_until > self.clock() and (username, password) == self.failed_login:
            raise QRZError(self.last_error or "QRZ.com login failed: retry in a few minutes")
        session, _ = self._get({"username": username, "password": password, "agent": self.agent})
        if not session.get("Key"):
            message = session.get("Error") or "QRZ.com login failed"
            self.last_error = message
            # the same wrong password is not sent again for 10 minutes (QRZ locks out repeated failures)
            self.failed_login = (username, password)
            self.login_blocked_until = self.clock() + LOGIN_RETRY_SECONDS
            raise QRZError(message)
        self.failed_login = None
        self.login_blocked_until = 0
        self.key, self.key_user = session["Key"], username
        self.sub_exp = session.get("SubExp", "")
        self.last_error = ""
        return self.status()

    def logout(self):
        with self.lock:
            self.key = self.key_user = self.sub_exp = self.last_error = ""
            self.cache.clear()
            self.photos.clear()

    # ------------------------------------------------------------ lookup
    def lookup(self, call):
        candidates = base_callsign(call)
        if not candidates or not CALL_RE.match(candidates[0]):
            raise QRZError("invalid callsign")
        with self.lock:
            now = self.clock()
            for cand in candidates:
                hit = self.cache.get(cand)
                if hit and hit[0] > now and hit[1] is not None:
                    return hit[1]
            if all((self.cache.get(c) or (0, None))[0] > now for c in candidates):
                return None                             # recently not found
            for cand in candidates:
                record = self._lookup_one(cand)
                self.cache[cand] = (now + (FOUND_TTL if record else MISSING_TTL), record)
                if record:
                    return record
            return None

    def _lookup_one(self, call):
        user, _ = self.get_credentials()
        if not self.key or self.key_user != user:
            self.login()
        for attempt in (1, 2):
            session, record = self._get({"s": self.key, "callsign": call})
            if session.get("SubExp"):
                self.sub_exp = session["SubExp"]
            if record:
                return self._public(record)
            error = session.get("Error", "")
            if "not found" in error.lower():
                return None
            if attempt == 1 and (not session.get("Key") or "session" in error.lower() or "timeout" in error.lower()):
                self.login()                            # session expired: once more
                continue
            if error:
                self.last_error = error
                raise QRZError(error)
            return None
        return None

    def _public(self, record):
        out = {k: record[k] for k in SHOW_FIELDS if record.get(k)}
        out["call"] = (record.get("call") or "").upper()
        full_name = record.get("name_fmt") or " ".join(x for x in (record.get("fname"), record.get("name")) if x)
        out["displayName"] = full_name.strip()
        out["city"] = record.get("addr2", "")
        out["hasPhoto"] = bool(record.get("image"))
        out["qrzUrl"] = "https://www.qrz.com/db/%s" % out["call"]
        out["limited"] = self.sub_exp.lower() == "non-subscriber"
        return out

    def photo(self, call):
        key = (call or "").upper()
        hit = self.photos.get(key)
        if hit and hit[0] > self.clock():
            return hit[1], hit[2]
        record = self.lookup(call)
        if not record or not record.get("image"):
            return None, None
        data, kind = self._download_photo(record["image"])
        if data:
            if len(self.photos) > 60:
                self.photos.clear()
            self.photos[key] = (self.clock() + FOUND_TTL, data, kind)
        return data, kind

    def _download_photo(self, url):
        # the QRZ picture server answers browsers: ask like one, and say who we are
        url = url.replace("http://", "https://", 1)
        headers = {"User-Agent": "Mozilla/5.0 (compatible; %s; QRZ XML Logbook client)" % self.agent,
                   "Referer": "https://www.qrz.com/", "Accept": "image/avif,image/webp,image/*,*/*;q=0.8"}
        try:
            try:
                res = self.http.get(url, timeout=(6, 15), stream=True, headers=headers)
            except (requests.ConnectionError, requests.Timeout):
                with ipv4_only():
                    res = self.http.get(url, timeout=(6, 15), stream=True, headers=headers)
            if res.status_code >= 400:
                self.photo_error = "photo HTTP %d" % res.status_code
                log.info("QRZ photo %s: HTTP %d", url.split("/")[2], res.status_code)
                return None, None
            res.raise_for_status()
            kind = res.headers.get("Content-Type", "image/jpeg").split(";")[0]
            if not kind.startswith("image/"):
                self.photo_error = "photo is %s" % kind
                return None, None
            data = b""
            for chunk in res.iter_content(65536):
                data += chunk
                if len(data) > PHOTO_MAX_BYTES:
                    return None, None
            return data, kind
        except requests.RequestException as exc:
            self.photo_error = "photo: %s" % exc.__class__.__name__
            return None, None
