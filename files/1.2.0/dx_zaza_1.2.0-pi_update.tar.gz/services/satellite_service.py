"""Legacy /api/satellite-passes endpoint.

Real passes over the operator QTH are computed from CelesTrak TLEs in space_service
(/api/satellites, shown on the map and the propagation page). This endpoint used to return
a fixed demo list: it now answers "see /api/satellites" and never invents passes.
"""


def get_satellite_passes(config):
    return {"ok": False, "source": "unavailable", "passes": [],
            "message": "Satellite passes are computed live: see /api/satellites."}
