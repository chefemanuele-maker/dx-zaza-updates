from datetime import datetime, timezone
import json
import time

import requests

from services.cache import cache


SWPC_BASE = "https://services.swpc.noaa.gov/json"
TIMEOUT_SECONDS = 4


# Never invented numbers: when NOAA cannot be read we show the last real values (marked stale,
# up to LAST_GOOD_MAX_AGE) or "unavailable", and try again after RETRY_SECONDS.
RETRY_SECONDS = 60
LAST_GOOD_MAX_AGE = 6 * 3600
_LAST_GOOD = {}

PRODUCTS = "https://services.swpc.noaa.gov/products"


def _merge_json_values(values):
    if not values:
        return []
    if len(values) == 1:
        return values[0]
    merged = []
    for value in values:
        if isinstance(value, list):
            merged.extend(value)
        elif isinstance(value, dict):
            merged.append(value)
    return merged if merged else values[-1]


def _parse_json_payload(text):
    payload = text.strip()
    if not payload:
        return []
    try:
        return json.loads(payload)
    except json.JSONDecodeError as first_error:
        line_values = []
        for line in payload.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                line_values.append(json.loads(line))
            except json.JSONDecodeError:
                line_values = []
                break
        if line_values:
            return _merge_json_values(line_values)

        decoder = json.JSONDecoder()
        values = []
        index = 0
        length = len(payload)
        while index < length:
            while index < length and payload[index].isspace():
                index += 1
            if index >= length:
                break
            try:
                value, end = decoder.raw_decode(payload, index)
            except json.JSONDecodeError:
                if values:
                    break
                raise first_error
            values.append(value)
            index = end
            while index < length and payload[index].isspace():
                index += 1
            if index < length and payload[index] == ",":
                index += 1
        if values:
            return _merge_json_values(values)
        raise first_error


def _get_json(path):
    response = requests.get(f"{SWPC_BASE}/{path}", timeout=TIMEOUT_SECONDS)
    response.raise_for_status()
    return _parse_json_payload(response.text)


def _last_row(rows):
    if isinstance(rows, list) and rows:
        return rows[-1]
    return {}


def _read_number(row, *keys):
    if not isinstance(row, dict):
        return None
    for key in keys:
        value = row.get(key)
        if value not in (None, ""):
            return value
    return None


def _fmt_signed(value, suffix=""):
    if value is None:
        return "N/A"
    try:
        number = float(value)
        sign = "+" if number > 0 else ""
        return f"{sign}{number:.1f}{suffix}"
    except (TypeError, ValueError):
        return str(value)


def _storm_from_kp(kp_value):
    try:
        kp = float(kp_value)
    except (TypeError, ValueError):
        return "Quiet"
    if kp >= 6:
        return "Storm"
    if kp >= 4:
        return "Active"
    return "Quiet"


def _hf_impact(kp_value, sfi_value):
    try:
        kp = float(kp_value)
    except (TypeError, ValueError):
        kp = 2
    try:
        sfi = float(sfi_value)
    except (TypeError, ValueError):
        sfi = 120
    if kp >= 5:
        return "Poor"
    if sfi >= 150 and kp <= 3:
        return "Good"
    return "Fair"


def _has_live_primary_value(*values):
    for value in values:
        if value not in (None, "", "N/A"):
            return True
    return False


def _rows_from_table(rows):
    """NOAA 'products' endpoints return [header, row, row...] lists; convert to dicts."""
    if isinstance(rows, list) and rows and isinstance(rows[0], list):
        header = rows[0]
        return [dict(zip(header, r)) for r in rows[1:] if isinstance(r, list)]
    return rows if isinstance(rows, list) else []


def _latest(rows, *required):
    """Most recent row (by time_tag) that has all required keys filled."""
    best = None
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        if any(row.get(k) in (None, "", "null") for k in required):
            continue
        if best is None or str(row.get("time_tag", "")) >= str(best.get("time_tag", "")):
            best = row
    return best or {}


def xray_class(flux):
    """GOES 0.1-0.8 nm flux (W/m2) -> flare class string, e.g. 1.2e-6 -> C1.2."""
    try:
        value = float(flux)
    except (TypeError, ValueError):
        return "N/A"
    if value <= 0:
        return "N/A"
    for letter, base in (("X", 1e-4), ("M", 1e-5), ("C", 1e-6), ("B", 1e-7), ("A", 1e-8)):
        if value >= base:
            return f"{letter}{value / base:.1f}"
    return f"A{value / 1e-8:.1f}"


def _try(func, *args):
    try:
        return func(*args)
    except Exception:
        return None


HAMQSL_URL = "https://www.hamqsl.com/solarxml.php"


def get_band_conditions(config=None):
    """N0NBH calculated HF band conditions and VHF phenomena (credit: N0NBH, hamqsl.com).

    Switched by config data_sources.n0nbh_band_conditions. N0NBH data is free for personal
    use with credit; units sold commercially need N0NBH's permission (as ShackComs obtained).
    """
    sources = ((config or {}).get("data_sources", {}) or {})
    if not sources.get("n0nbh_band_conditions", False):
        return {"ok": False, "source": "disabled", "bands": {}, "vhf": []}
    cached = cache.get("bands")
    if cached:
        return cached
    import xml.etree.ElementTree as ET
    try:
        resp = requests.get(HAMQSL_URL, timeout=TIMEOUT_SECONDS, headers={"User-Agent": "DX-Zaza/0.4"})
        resp.raise_for_status()
        root = ET.fromstring(resp.content)
        sd = root.find("solardata")
        bands = {}
        for b in sd.findall("calculatedconditions/band"):
            bands.setdefault(b.get("name"), {})[b.get("time")] = (b.text or "").strip()
        vhf = [{"name": p.get("name"), "location": p.get("location"), "value": (p.text or "").strip()}
               for p in sd.findall("calculatedvhfconditions/phenomenon")]
        result = {
            "ok": True,
            "source": "N0NBH (hamqsl.com)",
            "updated": (sd.findtext("updated") or "").strip(),
            "bands": bands,
            "vhf": vhf,
            "signalNoise": (sd.findtext("signalnoise") or "").strip(),
            "geomagField": (sd.findtext("geomagfield") or "").strip(),
            "muf": (sd.findtext("muf") or "").strip(),
        }
        _LAST_GOOD["bands"] = (result, time.time())
        return cache.set("bands", result, 1800)
    except Exception as exc:
        last = _LAST_GOOD.get("bands")
        if last and time.time() - last[1] < LAST_GOOD_MAX_AGE:
            return cache.set("bands", dict(last[0], stale=True), RETRY_SECONDS * 5)
        return cache.set("bands", {"ok": False, "source": "unavailable", "bands": {}, "vhf": [],
                                    "error": type(exc).__name__}, 300)


def _get_product(path):
    response = requests.get(f"{PRODUCTS}/{path}", timeout=TIMEOUT_SECONDS)
    response.raise_for_status()
    return _parse_json_payload(response.text)


def _fetch_all():
    """All NOAA feeds in parallel (one slow feed no longer delays the others)."""
    from concurrent.futures import ThreadPoolExecutor
    jobs = {
        "kp_rows": (_get_json, "planetary_k_index_1m.json"),
        "kp3_rows": (_get_product, "noaa-planetary-k-index.json"),
        # NOAA retired products/solar-wind/*-5-minute.json (404 since 2026): ACE hourly averages are
        # small and steady; the large real-time (RTSW) files are only read if ACE has no data
        "plasma_rows": (_get_json, "ace/swepam/ace_swepam_1h.json"),
        "mag_rows": (_get_json, "ace/mag/ace_mag_1h.json"),
        "flux_rows": (_get_json, "f107_cm_flux.json"),
        "xray_rows": (_get_json, "goes/primary/xrays-1-day.json"),
    }
    with ThreadPoolExecutor(max_workers=len(jobs)) as pool:
        futures = {key: pool.submit(_try, func, arg) for key, (func, arg) in jobs.items()}
        rows = {key: (future.result() or []) for key, future in futures.items()}
    for key in ("kp3_rows", "plasma_rows", "mag_rows"):
        rows[key] = _clean_rows(_rows_from_table(rows[key]))
    if not _latest(rows["plasma_rows"], "speed") and not _latest(rows["plasma_rows"], "proton_speed"):
        rows["plasma_rows"] = _clean_rows([r for r in (_try(_get_json, "rtsw/rtsw_wind_1m.json") or [])
                                           if isinstance(r, dict) and r.get("active")])
    if not _latest(rows["mag_rows"], "gsm_bz") and not _latest(rows["mag_rows"], "bz_gsm"):
        rows["mag_rows"] = _clean_rows([r for r in (_try(_get_json, "rtsw/rtsw_mag_1m.json") or [])
                                        if isinstance(r, dict) and r.get("active")])
    return rows


def _clean_rows(rows):
    """Drop NOAA fill values (-9999.9, -1e5...) so they are never shown as data."""
    out = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        clean = {}
        for k, v in row.items():
            if isinstance(v, (int, float)) and not isinstance(v, bool) and v <= -9999:
                v = None
            clean[k] = v
        out.append(clean)
    return out


def get_solar_conditions(config):
    ttl = (config.get("refresh", {}) or {}).get("solar_cache_seconds", 300)
    cached = cache.get("solar")
    if cached:
        return cached

    try:
        rows = _fetch_all()
        kp_rows, kp3_rows, plasma_rows = rows["kp_rows"], rows["kp3_rows"], rows["plasma_rows"]
        mag_rows, flux_rows, xray_rows = rows["mag_rows"], rows["flux_rows"], rows["xray_rows"]
        kp_row = _latest(kp_rows, "kp_index") or _latest(kp_rows, "estimated_kp")
        kp = _read_number(kp_row, "kp_index", "estimated_kp", "kp")
        kp3_row = _latest(kp3_rows, "Kp")
        a_index = _read_number(kp3_row, "a_running")
        if kp is None:
            kp = _read_number(kp3_row, "Kp")
        flux_row = _latest([r for r in flux_rows if isinstance(r, dict) and r.get("frequency") in (None, 2800, "2800")], "flux")
        sfi = _read_number(flux_row, "flux", "observed_flux", "f107")
        plasma_row = (_latest(plasma_rows, "speed") or _latest(plasma_rows, "proton_speed")
                      or _latest(plasma_rows, "bulk_speed"))
        wind = _read_number(plasma_row, "speed", "proton_speed", "bulk_speed")
        density = _read_number(plasma_row, "dens", "density", "proton_density")
        mag_row = _latest(mag_rows, "gsm_bz") or _latest(mag_rows, "bz_gsm") or _latest(mag_rows, "bz")
        bz = _read_number(mag_row, "gsm_bz", "bz_gsm", "bz")
        bt = _read_number(mag_row, "bt")
        long_band = [r for r in xray_rows if isinstance(r, dict) and r.get("energy") == "0.1-0.8nm"]
        xray = _read_number(_latest(long_band or xray_rows, "flux"), "flux")

        if not _has_live_primary_value(kp, sfi, wind, xray):
            raise ValueError("No readable live solar values")

        storm = _storm_from_kp(kp)
        hf_impact = _hf_impact(kp, sfi)
        try:
            kp_f = float(kp)
        except (TypeError, ValueError):
            kp_f = 0
        try:
            bz_f = float(bz)
        except (TypeError, ValueError):
            bz_f = 0
        aurora = "High" if kp_f >= 6 else "Moderate" if kp_f >= 4 or (kp_f >= 3 and bz_f <= -5) else "Low"
        history = []
        for row in kp3_rows[-8:]:
            try:
                history.append({"time": str(row.get("time_tag")), "kp": round(float(row.get("Kp")), 1)})
            except (TypeError, ValueError):
                continue
        data = {
            "ok": True,
            "source": "NOAA/SWPC",
            "sfi": "N/A" if sfi is None else str(round(float(sfi))),
            "kp": "N/A" if kp is None else str(round(float(kp), 1)),
            "aIndex": "N/A" if a_index is None else str(round(float(a_index))),
            "xray": xray_class(xray),
            "solarWind": "N/A" if wind is None else f"{round(float(wind))} km/s",
            "density": "N/A" if density is None else f"{float(density):.1f} p/cm3",
            "bz": _fmt_signed(bz, " nT"),
            "bt": "N/A" if bt is None else f"{float(bt):.1f} nT",
            "storm": storm,
            "auroraRisk": aurora,
            "hfImpact": hf_impact,
            "kpHistory": history,
            "summary": f"NOAA/SWPC live data read at {datetime.now(timezone.utc).strftime('%H:%M UTC')}.",
        }
        _LAST_GOOD.update(data=data, at=time.time())
        return cache.set("solar", data, ttl)
    except Exception as exc:
        last = _LAST_GOOD.get("data")
        age = time.time() - _LAST_GOOD.get("at", 0)
        if last and age < LAST_GOOD_MAX_AGE:
            data = dict(last, stale=True, staleMinutes=int(age // 60), error=str(exc)[:180])
            return cache.set("solar", data, RETRY_SECONDS)
        return cache.set("solar", {"ok": False, "source": "unavailable", "error": str(exc)[:180]}, RETRY_SECONDS)
