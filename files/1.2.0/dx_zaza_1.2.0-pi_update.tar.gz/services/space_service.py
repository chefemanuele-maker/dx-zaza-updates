"""Space-weather map layers and satellites for DX Zaza.

- Aurora: NOAA SWPC OVATION nowcast (public domain).
- Satellites: CelesTrak TLEs + SGP4 propagation (ISS and amateur satellites),
  current positions, ISS ground track and next passes over the operator QTH.
"""

import math
import time
from datetime import datetime, timedelta, timezone

import requests

from services.cache import cache
from services.geo_service import _data_dir

try:
    from sgp4.api import Satrec, jday
    SGP4_AVAILABLE = True
except ImportError:  # pragma: no cover - optional dependency
    SGP4_AVAILABLE = False


OVATION_URL = "https://services.swpc.noaa.gov/json/ovation_aurora_latest.json"
TLE_URLS = [
    "https://celestrak.org/NORAD/elements/gp.php?GROUP=amateur&FORMAT=tle",
    "https://celestrak.org/NORAD/elements/gp.php?CATNR=25544&FORMAT=tle",
]
TLE_MAX_AGE_SECONDS = 12 * 3600
TIMEOUT_SECONDS = 8

# NORAD id -> label shown on the map (popular FM / linear amateur satellites).
TRACKED_SATELLITES = {
    25544: "ISS",
    27607: "SO-50",
    43017: "AO-91",
    24278: "FO-29",
    44909: "RS-44",
    7530: "AO-7",
    43678: "PO-101",
    53106: "IO-117",
}


# ---------------------------------------------------------------- Aurora

_AURORA_LAST = {}


def get_aurora(min_value=8):
    cached = cache.get("aurora")
    if cached:
        return cached
    try:
        resp = requests.get(OVATION_URL, timeout=TIMEOUT_SECONDS)
        resp.raise_for_status()
        data = resp.json()
        points = []
        for lon, lat, value in data.get("coordinates", []):
            if value >= min_value and abs(lat) >= 35:
                lon_e = lon - 360 if lon > 180 else lon
                points.append([lon_e, lat, value])
        result = {
            "ok": True,
            "source": "NOAA SWPC OVATION",
            "observed": data.get("Observation Time"),
            "forecast": data.get("Forecast Time"),
            "points": points,
        }
        cache.set("aurora", result, 600)
        _AURORA_LAST.update(result=result, at=time.time())
        return result
    except (requests.RequestException, ValueError, TypeError) as exc:
        if _AURORA_LAST and time.time() - _AURORA_LAST["at"] < 3 * 3600:
            return cache.set("aurora", dict(_AURORA_LAST["result"], stale=True), 120)
        result = {"ok": False, "source": "unavailable", "points": [], "error": type(exc).__name__}
        cache.set("aurora", result, 120)
        return result


# ---------------------------------------------------------------- TLE handling

def _tle_path():
    return _data_dir() / "amateur_tle.txt"


def _download_tles():
    blocks = []
    for url in TLE_URLS:
        try:
            resp = requests.get(url, timeout=TIMEOUT_SECONDS, headers={"User-Agent": "DX-Zaza/0.4"})
            if resp.ok and "1 " in resp.text:
                blocks.append(resp.text.strip())
        except requests.RequestException:
            continue
    if blocks:
        _tle_path().write_text("\n".join(blocks) + "\n", encoding="utf-8")


def parse_tles(text):
    lines = [line.rstrip() for line in text.splitlines() if line.strip()]
    sats = {}
    i = 0
    while i < len(lines) - 2:
        name, l1, l2 = lines[i], lines[i + 1], lines[i + 2]
        if l1.startswith("1 ") and l2.startswith("2 "):
            try:
                norad = int(l1[2:7])
            except ValueError:
                i += 1
                continue
            sats[norad] = (name.strip(), l1, l2)
            i += 3
        else:
            i += 1
    return sats


def load_tles():
    path = _tle_path()
    if not path.exists() or time.time() - path.stat().st_mtime > TLE_MAX_AGE_SECONDS:
        if not cache.get("tle_retry"):
            cache.set("tle_retry", True, 1800)
            _download_tles()
    if path.exists():
        return parse_tles(path.read_text(encoding="utf-8", errors="ignore")), path.stat().st_mtime
    return {}, None


# ---------------------------------------------------------------- Orbit maths

def _gmst(jd_ut1):
    t = (jd_ut1 - 2451545.0) / 36525.0
    g = 67310.54841 + (876600.0 * 3600 + 8640184.812866) * t + 0.093104 * t * t - 6.2e-6 * t ** 3
    return math.radians((g % 86400) / 240.0)


def _teme_to_geodetic(r, jd):
    theta = _gmst(jd)
    x = r[0] * math.cos(theta) + r[1] * math.sin(theta)
    y = -r[0] * math.sin(theta) + r[1] * math.cos(theta)
    z = r[2]
    a, f = 6378.137, 1 / 298.257223563
    e2 = f * (2 - f)
    lon = math.atan2(y, x)
    p = math.hypot(x, y)
    lat = math.atan2(z, p * (1 - e2))
    for _ in range(5):
        n = a / math.sqrt(1 - e2 * math.sin(lat) ** 2)
        h = p / math.cos(lat) - n
        lat = math.atan2(z, p * (1 - e2 * n / (n + h)))
    n = a / math.sqrt(1 - e2 * math.sin(lat) ** 2)
    alt = p / math.cos(lat) - n
    return math.degrees(lat), (math.degrees(lon) + 540) % 360 - 180, alt, (x, y, z)


def _observer_ecef(lat, lon, alt_km=0.0):
    a, f = 6378.137, 1 / 298.257223563
    e2 = f * (2 - f)
    la, lo = math.radians(lat), math.radians(lon)
    n = a / math.sqrt(1 - e2 * math.sin(la) ** 2)
    return ((n + alt_km) * math.cos(la) * math.cos(lo),
            (n + alt_km) * math.cos(la) * math.sin(lo),
            (n * (1 - e2) + alt_km) * math.sin(la))


def _elevation(obs_lat, obs_lon, obs_ecef, sat_ecef):
    dx = [sat_ecef[i] - obs_ecef[i] for i in range(3)]
    la, lo = math.radians(obs_lat), math.radians(obs_lon)
    up = (math.cos(la) * math.cos(lo), math.cos(la) * math.sin(lo), math.sin(la))
    east = (-math.sin(lo), math.cos(lo), 0.0)
    north = (-math.sin(la) * math.cos(lo), -math.sin(la) * math.sin(lo), math.cos(la))
    rng = math.sqrt(sum(c * c for c in dx))
    el = math.degrees(math.asin(sum(dx[i] * up[i] for i in range(3)) / rng))
    az = (math.degrees(math.atan2(sum(dx[i] * east[i] for i in range(3)),
                                  sum(dx[i] * north[i] for i in range(3)))) + 360) % 360
    return el, az


def _propagate(sat, when):
    jd, fr = jday(when.year, when.month, when.day, when.hour, when.minute,
                  when.second + when.microsecond / 1e6)
    err, r, _v = sat.sgp4(jd, fr)
    if err != 0:
        return None
    return _teme_to_geodetic(r, jd + fr)


def next_passes(sat, obs_lat, obs_lon, start, hours=24, min_el=10.0, limit=3):
    obs = _observer_ecef(obs_lat, obs_lon)
    passes, current = [], None
    step = timedelta(seconds=30)
    t = start
    end = start + timedelta(hours=hours)
    while t < end and len(passes) < limit:
        p = _propagate(sat, t)
        if p:
            el, az = _elevation(obs_lat, obs_lon, obs, p[3])
            if el > 0:
                if current is None:
                    current = {"aos": t, "aos_az": az, "max_el": el, "max_t": t}
                if el > current["max_el"]:
                    current.update(max_el=el, max_t=t)
                current["los"], current["los_az"] = t, az
            elif current is not None:
                if current["max_el"] >= min_el:
                    passes.append(current)
                current = None
        t += step
    return [{
        "aos": p["aos"].strftime("%Y-%m-%dT%H:%M:%SZ"),
        "los": p["los"].strftime("%Y-%m-%dT%H:%M:%SZ"),
        "maxEl": round(p["max_el"]),
        "aosAz": round(p["aos_az"]),
        "losAz": round(p["los_az"]),
        "durationMin": round((p["los"] - p["aos"]).total_seconds() / 60, 1),
    } for p in passes]


def get_satellites(home=None, with_passes=True):
    if not SGP4_AVAILABLE:
        return {"ok": False, "source": "sgp4 not installed", "satellites": [], "issTrack": []}
    key = "satellites:%s" % (home and "%.2f,%.2f" % home)
    cached = cache.get(key)
    if cached:
        return cached
    tles, tle_time = load_tles()
    if not tles:
        result = {"ok": False, "source": "TLE unavailable", "satellites": [], "issTrack": []}
        cache.set(key, result, 120)
        return result
    now = datetime.now(timezone.utc)
    sats_out, iss_track = [], []
    for norad, label in TRACKED_SATELLITES.items():
        if norad not in tles:
            continue
        name, l1, l2 = tles[norad]
        sat = Satrec.twoline2rv(l1, l2)
        pos = _propagate(sat, now)
        if not pos:
            continue
        item = {"id": norad, "name": label, "lat": round(pos[0], 3), "lon": round(pos[1], 3),
                "altKm": round(pos[2])}
        if home:
            obs = _observer_ecef(home[0], home[1])
            el, az = _elevation(home[0], home[1], obs, pos[3])
            item.update(elevation=round(el, 1), azimuth=round(az), visible=el > 0)
            if with_passes:
                pkey = "passes:%d:%.2f,%.2f" % (norad, home[0], home[1])
                passes = cache.get(pkey)
                if passes is None:
                    passes = cache.set(pkey, next_passes(sat, home[0], home[1], now), 600)
                item["passes"] = [p for p in passes if p["los"] >= now.strftime("%Y-%m-%dT%H:%M:%SZ")]
        sats_out.append(item)
        if norad == 25544:
            for minutes in range(-45, 91, 1):
                p = _propagate(sat, now + timedelta(minutes=minutes))
                if p:
                    iss_track.append([round(p[1], 2), round(p[0], 2)])
    result = {
        "ok": True,
        "source": "CelesTrak TLE + SGP4",
        "tleUpdated": datetime.fromtimestamp(tle_time, timezone.utc).strftime("%Y-%m-%dT%H:%MZ") if tle_time else None,
        "satellites": sats_out,
        "issTrack": iss_track,
    }
    cache.set(key, result, 20)
    return result
