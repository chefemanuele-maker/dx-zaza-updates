"""DX Zaza start-up sound: "DX" in Morse code (the radio amateur's call for long distance)
followed by a soft rising chord. Synthesised here (no audio files, no third-party sounds) and
played on the computer's speaker by the backend, so it works even where the web view does not
allow sound before a click."""

import logging
import threading
import time

import numpy as np

log = logging.getLogger("dxzaza.ui")

RATE = 48000
_last_played = [0.0]
_lock = threading.Lock()


def _tone(freq, seconds, volume=0.3, attack=0.004, release=0.012, harmonics=((1, 1.0),)):
    n = int(RATE * seconds)
    t = np.arange(n) / RATE
    wave = sum(a * np.sin(2 * np.pi * freq * k * t) for k, a in harmonics)
    env = np.ones(n)
    a, r = int(RATE * attack), int(RATE * release)
    if a:
        env[:a] = np.linspace(0, 1, a)
    if r:
        env[-r:] = np.minimum(env[-r:], np.linspace(1, 0, r))
    return (wave * env * volume).astype(np.float32)


def _silence(seconds):
    return np.zeros(int(RATE * seconds), dtype=np.float32)


def chime():
    """-> float32 mono samples at 48 kHz (about 2.6 s)."""
    dit, cw = 0.065, 760.0
    parts = []
    for code in ("-..", "-..-"):               # D  X
        for i, sym in enumerate(code):
            parts.append(_tone(cw, dit * (3 if sym == "-" else 1), volume=0.22))
            parts.append(_silence(dit))
        parts.append(_silence(dit * 2))
    parts.append(_silence(0.12))
    # a soft "power on" chord: A major add9, notes entering one after the other, long tail
    total = 1.7
    n = int(RATE * total)
    chord = np.zeros(n, dtype=np.float32)
    t = np.arange(n) / RATE
    for i, f in enumerate((220.0, 329.63, 440.0, 554.37, 659.26, 987.77)):
        start = int(RATE * 0.07 * i)
        tt = t[: n - start]
        env = (1 - np.exp(-tt / 0.02)) * np.exp(-tt / 0.55)
        voice = (np.sin(2 * np.pi * f * tt) + 0.25 * np.sin(2 * np.pi * 2 * f * tt + 0.3)) * env
        chord[start:] += (0.11 * voice).astype(np.float32)
    # a gentle upward "sweep" like a receiver locking on
    sweep_t = np.arange(int(RATE * 0.35)) / RATE
    sweep = np.sin(2 * np.pi * (600 * sweep_t + 900 * sweep_t ** 2)) * np.exp(-sweep_t / 0.12) * 0.05
    chord[: len(sweep)] += sweep.astype(np.float32)
    parts.append(chord)
    out = np.concatenate(parts)
    peak = float(np.max(np.abs(out))) or 1.0
    return (out / peak * 0.5).astype(np.float32)


def play_chime(volume=1.0, player=None):
    """Play once (ignored if it played less than 20 s ago). Returns True when started."""
    with _lock:
        if time.monotonic() - _last_played[0] < 20:
            return False
        _last_played[0] = time.monotonic()
    samples = chime() * float(max(0.0, min(1.0, volume)))

    def run():
        try:
            if player is not None:
                player(samples, RATE)
                return
            import sounddevice as sd
            sd.play(samples, RATE, blocking=True)
        except Exception as exc:  # no speaker, device busy...: the start-up must go on
            log.info("start-up sound not played: %s", exc)
    threading.Thread(target=run, name="startup-chime", daemon=True).start()
    return True
