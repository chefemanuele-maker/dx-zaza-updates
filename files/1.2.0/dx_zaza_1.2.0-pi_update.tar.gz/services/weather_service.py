"""Local weather at the operator's QTH, for the top bar (temperature + sky).

Source: MET Norway Locationforecast 2.0 (api.met.no), open data under CC BY 4.0
(attribution: "Weather data: MET Norway"). Their terms, followed here:
  * identifying User-Agent (application name + contact, see config weather.contact)
  * coordinates truncated (we use 2 decimals, about 1 km: also kinder to privacy)
  * one shared cache in the backend, honour "Expires", use If-Modified-Since
  * low traffic: one request per location per ~30 min at most
"""

import email.utils
import math
from datetime import datetime, timezone
import threading
import time

import logging

import requests

log = logging.getLogger("dxzaza.weather")

API_URL = "https://api.met.no/weatherapi/locationforecast/2.0/compact"
MIN_REFRESH = 10 * 60
MAX_REFRESH = 60 * 60
ATTRIBUTION = "Weather data: MET Norway (CC BY 4.0)"

# MET Norway symbol_code (without _day/_night/_polartwilight) -> short text
SYMBOL_TEXT = {
    "en": {"clearsky": "Clear", "fair": "Fair", "partlycloudy": "Partly cloudy", "cloudy": "Cloudy", "fog": "Fog",
           "rain": "Rain", "lightrain": "Light rain", "heavyrain": "Heavy rain",
           "rainshowers": "Showers", "lightrainshowers": "Light showers", "heavyrainshowers": "Heavy showers",
           "sleet": "Sleet", "lightsleet": "Light sleet", "heavysleet": "Heavy sleet",
           "sleetshowers": "Sleet showers", "lightsleetshowers": "Sleet showers", "heavysleetshowers": "Sleet showers",
           "snow": "Snow", "lightsnow": "Light snow", "heavysnow": "Heavy snow",
           "snowshowers": "Snow showers", "lightsnowshowers": "Snow showers", "heavysnowshowers": "Snow showers",
           "thunder": "Thunder"},
    "it": {"clearsky": "Sereno", "fair": "Poco nuvoloso", "partlycloudy": "Parz. nuvoloso", "cloudy": "Nuvoloso",
           "fog": "Nebbia", "rain": "Pioggia", "lightrain": "Pioggia debole", "heavyrain": "Pioggia forte",
           "rainshowers": "Rovesci", "lightrainshowers": "Rovesci deboli", "heavyrainshowers": "Rovesci forti",
           "sleet": "Nevischio", "lightsleet": "Nevischio", "heavysleet": "Nevischio",
           "sleetshowers": "Nevischio", "lightsleetshowers": "Nevischio", "heavysleetshowers": "Nevischio",
           "snow": "Neve", "lightsnow": "Neve debole", "heavysnow": "Neve forte",
           "snowshowers": "Rovesci di neve", "lightsnowshowers": "Rovesci di neve", "heavysnowshowers": "Rovesci di neve",
           "thunder": "Temporale"},
}


def sky_kind(symbol):
    """Icon family for the front end: clear, partly, cloudy, fog, rain, sleet, snow, thunder."""
    base = (symbol or "").split("_")[0]
    if "thunder" in base:
        return "thunder"
    for kind in ("snow", "sleet", "rain", "fog"):
        if kind in base:
            return kind
    if base in ("clearsky", "fair"):
        return "clear" if base == "clearsky" else "partly"
    if base == "partlycloudy":
        return "partly"
    return "cloudy"


def describe(symbol, lang="en"):
    base = (symbol or "").split("_")[0]
    for name in sorted(SYMBOL_TEXT["en"], key=len, reverse=True):
        if base.startswith(name):
            return SYMBOL_TEXT.get(lang, SYMBOL_TEXT["en"]).get(name, SYMBOL_TEXT["en"][name])
    return ""


def sun_altitude(lat, lon, when=None):
    """Sun altitude in degrees above the horizon (NOAA approximation, good to ~0.5 deg)."""
    when = when or datetime.now(timezone.utc)
    day = when.timetuple().tm_yday
    hours = when.hour + when.minute / 60 + when.second / 3600
    g = 2 * math.pi / 365 * (day - 1 + (hours - 12) / 24)
    decl = (0.006918 - 0.399912 * math.cos(g) + 0.070257 * math.sin(g) - 0.006758 * math.cos(2 * g)
            + 0.000907 * math.sin(2 * g) - 0.002697 * math.cos(3 * g) + 0.00148 * math.sin(3 * g))
    eqtime = 229.18 * (0.000075 + 0.001868 * math.cos(g) - 0.032077 * math.sin(g)
                       - 0.014615 * math.cos(2 * g) - 0.040849 * math.sin(2 * g))
    solar_minutes = hours * 60 + eqtime + 4 * lon
    ha = math.radians(solar_minutes / 4 - 180)
    la = math.radians(lat)
    cos_zen = math.sin(la) * math.sin(decl) + math.cos(la) * math.cos(decl) * math.cos(ha)
    return 90 - math.degrees(math.acos(max(-1.0, min(1.0, cos_zen))))


def current_entry(series, now=None):
    """The forecast step for now: the last one that has already started (MET lists hourly steps)."""
    now = now or datetime.now(timezone.utc)
    best = series[0]
    for item in series:
        try:
            t = datetime.strptime(item.get("time", ""), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        if t <= now:
            best = item
        else:
            break
    return best


def parse_forecast(data, now=None):
    series = (data.get("properties") or {}).get("timeseries") or []
    if not series:
        raise ValueError("empty forecast")
    first = current_entry(series, now)
    details = ((first.get("data") or {}).get("instant") or {}).get("details") or {}
    symbol = ""
    for key in ("next_1_hours", "next_6_hours", "next_12_hours"):
        symbol = (((first.get("data") or {}).get(key) or {}).get("summary") or {}).get("symbol_code", "")
        if symbol:
            break
    return {
        "tempC": details.get("air_temperature"),
        "windMs": details.get("wind_speed"),
        "humidity": details.get("relative_humidity"),
        "symbol": symbol,
        "time": first.get("time", ""),
    }


def _expires_in(headers):
    value = headers.get("Expires")
    if not value:
        return MIN_REFRESH
    try:
        when = email.utils.parsedate_to_datetime(value).timestamp()
    except (TypeError, ValueError):
        return MIN_REFRESH
    return max(MIN_REFRESH, min(MAX_REFRESH, when - time.time()))


class WeatherService:
    """One shared cache per QTH. Robust against a slow or unreachable api.met.no:
    a timed-out request is retried at once, then again after 30 s, 1, 2, 4 min (max 5),
    and the last good forecast is kept (also on disk, so it survives a restart) and shown
    marked as "stale" until fresh data arrives. Forecasts older than MAX_KEEP are dropped."""

    RETRY_FIRST = 30
    RETRY_MAX = 5 * 60
    STALE_AFTER = 2 * 3600
    MAX_KEEP = 12 * 3600

    def __init__(self, user_agent, session=None, clock=time.time, store_path=None, sleep=time.sleep):
        self.user_agent = user_agent
        self.session = session or requests.Session()
        self.clock = clock
        self.sleep = sleep
        self.store_path = store_path
        self.lock = threading.Lock()
        self.cache = {}   # (lat, lon) -> {"data", "next", "modified", "fetched", "fails", "error"}
        self._load_store()

    # ------------------------------------------------------------ disk copy of the last good data
    def _load_store(self):
        if not self.store_path:
            return
        try:
            import json
            with open(self.store_path, "r", encoding="utf-8") as fh:
                saved = json.load(fh)
            key = (float(saved["lat"]), float(saved["lon"]))
            parse_forecast(saved["data"])
            # refresh at once: the copy on disk is only a safety net
            self.cache[key] = {"data": saved["data"], "next": 0, "modified": "",
                               "fetched": float(saved.get("fetched") or 0), "fails": 0}
        except Exception:
            pass

    def _save_store(self, key, entry):
        if not self.store_path:
            return
        try:
            import json
            import os
            tmp = str(self.store_path) + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"lat": key[0], "lon": key[1], "fetched": entry["fetched"], "data": entry["data"]}, fh)
            os.replace(tmp, self.store_path)
        except Exception:
            pass

    # ------------------------------------------------------------ public
    def get(self, lat, lon, lang="en", place=""):
        key = (round(float(lat), 2), round(float(lon), 2))
        with self.lock:
            entry = self.cache.get(key)
            now = self.clock()
            if not entry or now >= entry["next"]:
                entry = self._fetch(key, entry)
                self.cache[key] = entry
            now = self.clock()
        raw = entry.get("data")
        age = now - float(entry.get("fetched") or 0)
        retry_in = max(1, int(entry["next"] - now))
        if raw and age > self.MAX_KEEP:
            raw = None
        if not raw:
            return {"ok": False, "error": entry.get("error", "Weather unavailable"), "retryIn": retry_in,
                    "attribution": ATTRIBUTION}
        data = parse_forecast(raw, datetime.fromtimestamp(now, timezone.utc))
        # day or night from the real sun at the QTH (MET's symbol of the current hour can still say
        # "day" just after sunset): below -0.83 deg the sun has set
        night = sun_altitude(float(lat), float(lon)) < -0.83
        stale = bool(entry.get("error")) and age > self.STALE_AFTER
        return {
            "ok": True,
            "tempC": data["tempC"],
            "windMs": data["windMs"],
            "humidity": data["humidity"],
            "symbol": data["symbol"],
            "sky": sky_kind(data["symbol"]),
            "text": describe(data["symbol"], lang),
            "night": night,
            "place": place,
            "updated": data["time"],
            "fetchedAgoMin": int(age // 60),
            "stale": stale,
            "retrying": bool(entry.get("error")),
            "retryIn": retry_in,
            "source": "MET Norway",
            "attribution": ATTRIBUTION,
        }

    def _request(self, key, headers):
        last = None
        for attempt in range(2):                       # one immediate retry: most failures are a slow answer
            try:
                return self.session.get(API_URL, params={"lat": "%.2f" % key[0], "lon": "%.2f" % key[1]},
                                        headers=headers, timeout=(6, 15))
            except Exception as exc:
                last = exc
                if attempt == 0:
                    self.sleep(1.5)
        raise last

    def _fetch(self, key, previous):
        headers = {"User-Agent": self.user_agent, "Accept-Encoding": "gzip"}
        if previous and previous.get("modified") and previous.get("data"):
            headers["If-Modified-Since"] = previous["modified"]
        try:
            res = self._request(key, headers)
            if res.status_code == 304 and previous and previous.get("data"):
                return dict(previous, next=self.clock() + _expires_in(res.headers), fetched=self.clock(),
                            fails=0, error="")
            if res.status_code == 429:
                return dict(previous or {}, next=self.clock() + MAX_REFRESH, error="Weather service busy")
            res.raise_for_status()
            raw = res.json()
            parse_forecast(raw)                          # validate now
            entry = {"data": raw, "next": self.clock() + _expires_in(res.headers),
                     "modified": res.headers.get("Last-Modified", ""), "fetched": self.clock(), "fails": 0}
            self._save_store(key, entry)
            return entry
        except Exception as exc:
            keep = dict(previous or {})
            fails = int(keep.get("fails") or 0) + 1
            wait = min(self.RETRY_MAX, self.RETRY_FIRST * 2 ** (fails - 1))
            keep.update(next=self.clock() + wait, fails=fails,
                        error="Weather unavailable: %s" % (str(exc)[:80] or exc.__class__.__name__))
            log.warning("weather: %s (retry in %d s)", keep["error"], wait)
            return keep
