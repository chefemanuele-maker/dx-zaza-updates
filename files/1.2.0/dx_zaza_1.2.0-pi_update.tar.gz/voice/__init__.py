"""DX Zaza voice: DVstick (AMBE-3000) digital voice for desktop and Raspberry Pi."""
