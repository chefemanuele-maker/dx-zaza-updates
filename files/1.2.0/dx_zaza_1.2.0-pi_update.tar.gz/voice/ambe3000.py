"""Driver for the AMBE-3000 vocoder chip inside the DVMEGA DVstick 30 (and
compatible USB AMBE sticks such as ThumbDV / DV3000U).

The stick is a plain USB serial device (FTDI) running the AMBE-3000 "packet
interface": every message starts with 0x61, a 2-byte big-endian length (bytes
after the 4-byte header), a type byte and then one or more fields.

  type 0x00 control   (rate, init, product id, version...)
  type 0x01 channel   (compressed AMBE bits)    field 0x01 CHAND
  type 0x02 speech    (16-bit PCM, 8 kHz)       field 0x00 SPEECHD

This module only talks to the chip: it never touches the network or audio.
"""

import collections
import concurrent.futures
import struct
import threading
import time

try:  # numpy is optional for the driver itself (used for convenience)
    import numpy as np
except ImportError:  # pragma: no cover
    np = None

START = 0x61
TYPE_CONTROL = 0x00
TYPE_CHANNEL = 0x01
TYPE_SPEECH = 0x02

PKT_CHANNEL0 = 0x40
PKT_RATET = 0x09
PKT_RATEP = 0x0A
PKT_INIT = 0x0B
PKT_GAIN = 0x4B
PKT_PRODID = 0x30
PKT_VERSTRING = 0x31
PKT_RESET = 0x33
PKT_READY = 0x39
PKT_PARITYMODE = 0x3F
PKT_PARITY = 0x2F

FIELD_SPEECHD = 0x00
FIELD_CHAND = 0x01

SAMPLES_PER_FRAME = 160          # 20 ms at 8 kHz
DEFAULT_BAUD = 460800

# Rate words for D-STAR (AMBE 2400 voice + 1200 FEC = 3600 bit/s, 72 bits/frame)
DSTAR_RATEP = (0x0130, 0x0763, 0x4000, 0x0000, 0x0000, 0x0048)
# Rate table index 33: AMBE+2 2450 voice + 1150 FEC (DMR, YSF DN, NXDN) 72 bits/frame
DMR_RATET = 33

# USB ids of known AMBE sticks: (vid, pid, label)
KNOWN_USB_IDS = (
    (0x0403, 0x6015, "FTDI FT230X/FT231X (DVstick 30, ThumbDV)"),
    (0x0403, 0x6001, "FTDI FT232R (DV3000U / older sticks)"),
)


class AmbeError(Exception):
    pass


def build_packet(ptype, payload):
    payload = bytes(payload)
    return bytes([START]) + struct.pack(">H", len(payload)) + bytes([ptype]) + payload


def parity_byte(packet_without_parity):
    """XOR of every byte after the start byte, including the 0x2F field id."""
    value = 0
    for b in packet_without_parity[1:]:
        value ^= b
    return value


class PacketReader:
    """Accumulates serial bytes and splits them into AMBE packets."""

    def __init__(self):
        self.buffer = bytearray()
        self.parity = False  # strip a trailing 0x2F parity field when True

    def feed(self, data):
        self.buffer.extend(data)
        packets = []
        while True:
            start = self.buffer.find(bytes([START]))
            if start < 0:
                self.buffer.clear()
                break
            if start:
                del self.buffer[:start]
            if len(self.buffer) < 4:
                break
            length = (self.buffer[1] << 8) | self.buffer[2]
            if length == 0 or length > 400:
                del self.buffer[0]   # not a real header: resync
                continue
            if len(self.buffer) < 4 + length:
                break
            ptype = self.buffer[3]
            payload = bytes(self.buffer[4:4 + length])
            del self.buffer[:4 + length]
            if self.parity and len(payload) >= 2 and payload[-2] == PKT_PARITY:
                payload = payload[:-2]
            packets.append((ptype, payload))
        return packets


def _cstring(data):
    return data.split(b"\x00", 1)[0].decode("ascii", "replace").strip()


class SerialTransport:
    """pyserial wrapper: exclusive access, short read timeout."""

    def __init__(self, port, baud=DEFAULT_BAUD):
        import serial  # pyserial
        self.port = port
        self.ser = serial.Serial()
        self.ser.port = port
        self.ser.baudrate = baud
        self.ser.timeout = 0.05
        self.ser.write_timeout = 1.0
        self.ser.rtscts = False
        self.ser.dsrdtr = False
        try:
            self.ser.exclusive = True   # one owner of the DVstick at a time
        except (AttributeError, ValueError):  # pragma: no cover - Windows
            pass
        self.ser.open()
        self.ser.reset_input_buffer()

    def write(self, data):
        self.ser.write(data)

    def read(self):
        waiting = self.ser.in_waiting
        return self.ser.read(waiting or 1)

    def close(self):
        try:
            self.ser.close()
        except Exception:  # pragma: no cover
            pass


class Ambe3000:
    """Access to the AMBE-3000 chip.

    Requests are pipelined: a reader thread matches answers to requests in
    order (the chip answers in FIFO order per packet type). This matters
    because the FTDI USB chip holds short answers for its latency timer
    (~16 ms on macOS), so waiting for every answer before sending the next
    request would not keep up with real time (one frame every 20 ms).
    """

    MAX_IN_FLIGHT = 4

    def __init__(self, transport, timeout=1.0):
        self.transport = transport
        self.timeout = timeout
        self.reader = PacketReader()
        self.write_lock = threading.Lock()
        self.pending = {TYPE_CONTROL: collections.deque(), TYPE_CHANNEL: collections.deque(),
                        TYPE_SPEECH: collections.deque()}
        self.pending_lock = threading.Lock()
        self.window = threading.BoundedSemaphore(self.MAX_IN_FLIGHT)
        self.product = ""
        self.version = ""
        self.mode = None
        self.stats = {"encoded": 0, "decoded": 0, "errors": 0}
        self._closed = threading.Event()
        self._thread = threading.Thread(target=self._read_loop, name="ambe-reader", daemon=True)
        self._thread.start()

    # ----------------------------------------------------------- plumbing
    def _read_loop(self):
        while not self._closed.is_set():
            try:
                data = self.transport.read()
            except Exception:
                if self._closed.is_set():
                    break
                time.sleep(0.05)
                continue
            if not data:
                continue
            for ptype, payload in self.reader.feed(data):
                with self.pending_lock:
                    queue_ = self.pending.get(ptype)
                    future = queue_.popleft() if queue_ else None
                if future is None:
                    continue           # unsolicited packet (e.g. READY after reset)
                self.window.release()
                if not future.done():
                    future.set_result(payload)
        with self.pending_lock:
            for queue_ in self.pending.values():
                while queue_:
                    future = queue_.popleft()
                    if not future.done():
                        future.set_exception(AmbeError("DVstick closed"))

    def submit(self, ptype, payload, answer_type=None):
        """Send one packet; returns a Future resolved with the answer payload."""
        if self._closed.is_set():
            raise AmbeError("DVstick closed")
        if not self.window.acquire(timeout=self.timeout):
            self._expire_stale()
            raise AmbeError("no answer from the DVstick")
        future = concurrent.futures.Future()
        future.sent_at = time.monotonic()
        answer_type = ptype if answer_type is None else answer_type
        with self.write_lock:
            with self.pending_lock:
                self.pending[answer_type].append(future)
            try:
                self.transport.write(build_packet(ptype, payload))
            except Exception as exc:
                with self.pending_lock:
                    if future in self.pending[answer_type]:
                        self.pending[answer_type].remove(future)
                self.window.release()
                raise AmbeError("cannot write to the DVstick: %s" % exc)
        return future

    def _expire_stale(self):
        """Drop requests the chip never answered so the pipeline cannot jam."""
        now = time.monotonic()
        with self.pending_lock:
            for queue_ in self.pending.values():
                while queue_ and now - queue_[0].sent_at > self.timeout:
                    future = queue_.popleft()
                    self.window.release()
                    self.stats["errors"] += 1
                    if not future.done():
                        future.set_exception(AmbeError("no answer from the DVstick"))

    def _wait(self, future):
        try:
            return future.result(timeout=self.timeout)
        except concurrent.futures.TimeoutError:
            self._expire_stale()
            raise AmbeError("no answer from the DVstick")

    def _control(self, payload):
        answer = self._wait(self.submit(TYPE_CONTROL, payload))
        if not answer or answer[0] != payload[0]:
            raise AmbeError("unexpected DVstick answer %s" % answer.hex())
        return answer

    # ----------------------------------------------------------- identity
    def product_id(self):
        return _cstring(self._control(bytes([PKT_PRODID]))[1:])

    def version_string(self):
        return _cstring(self._control(bytes([PKT_VERSTRING]))[1:])

    def probe(self):
        """Read-only identification: returns (product, version)."""
        self.product = self.product_id()
        if not self.product.upper().startswith("AMBE"):
            raise AmbeError("device answered but is not an AMBE vocoder: %r" % self.product)
        self.version = self.version_string()
        return self.product, self.version

    # ----------------------------------------------------------- configuration
    def _check_status(self, answer, name):
        if len(answer) < 2 or answer[1] != 0x00:
            raise AmbeError("DVstick refused %s (%s)" % (name, answer.hex()))

    def set_parity(self, enabled):
        answer = self._control(bytes([PKT_PARITYMODE, 1 if enabled else 0]))
        self._check_status(answer, "parity mode")
        self.reader.parity = bool(enabled)

    def set_rate_dstar(self):
        payload = bytes([PKT_RATEP]) + struct.pack(">6H", *DSTAR_RATEP)
        self._check_status(self._control(payload), "D-STAR rate")
        self._init_codec()
        self.mode = "dstar"

    def set_rate_dmr(self):
        self._check_status(self._control(bytes([PKT_RATET, DMR_RATET])), "DMR rate")
        self._init_codec()
        self.mode = "dmr"

    def _init_codec(self):
        self._check_status(self._control(bytes([PKT_INIT, 0x03])), "codec init")

    def set_gain(self, input_db=0, output_db=0):
        input_db = max(-90, min(90, int(input_db)))
        output_db = max(-90, min(90, int(output_db)))
        payload = bytes([PKT_GAIN, input_db & 0xFF, output_db & 0xFF])
        self._check_status(self._control(payload), "gain")

    def open_dstar(self):
        self.probe()
        try:
            self.set_parity(False)
        except AmbeError:
            pass  # some firmwares do not support the parity command
        self.set_rate_dstar()
        return self

    # ----------------------------------------------------------- vocoder
    def submit_encode(self, pcm):
        samples = _to_int16_list(pcm)
        if len(samples) != SAMPLES_PER_FRAME:
            raise ValueError("encode needs exactly 160 samples")
        payload = bytes([FIELD_SPEECHD, SAMPLES_PER_FRAME]) + struct.pack(">160h", *samples)
        future = self.submit(TYPE_SPEECH, payload, answer_type=TYPE_CHANNEL)
        return _chain(future, self._parse_channel)

    def submit_decode(self, ambe):
        ambe = bytes(ambe)
        payload = bytes([FIELD_CHAND, len(ambe) * 8]) + ambe
        future = self.submit(TYPE_CHANNEL, payload, answer_type=TYPE_SPEECH)
        return _chain(future, self._parse_speech)

    def _parse_channel(self, answer):
        if len(answer) < 2 or answer[0] != FIELD_CHAND:
            self.stats["errors"] += 1
            raise AmbeError("bad encoder answer")
        self.stats["encoded"] += 1
        return answer[2:2 + (answer[1] + 7) // 8]

    def _parse_speech(self, answer):
        if len(answer) < 2 + 2 * SAMPLES_PER_FRAME or answer[0] != FIELD_SPEECHD:
            self.stats["errors"] += 1
            raise AmbeError("bad decoder answer")
        count = answer[1]
        self.stats["decoded"] += 1
        raw = answer[2:2 + 2 * count]
        if np is not None:
            return np.frombuffer(raw, dtype=">i2").astype(np.int16)
        return list(struct.unpack(">%dh" % count, raw))

    def encode(self, pcm):
        """160 signed 16-bit samples (8 kHz) -> 9 bytes of AMBE (72 bits)."""
        return self._wait(self.submit_encode(pcm))

    def decode(self, ambe):
        """9 bytes of AMBE (72 bits) -> 160 int16 samples."""
        return self._wait(self.submit_decode(ambe))

    def close(self):
        self._closed.set()
        self.transport.close()
        if self._thread is not threading.current_thread():
            self._thread.join(timeout=1)


def _chain(future, parse):
    """Future that resolves with parse(result of future)."""
    out = concurrent.futures.Future()

    def done(src):
        try:
            out.set_result(parse(src.result()))
        except Exception as exc:  # parse error or upstream failure
            out.set_exception(exc)

    future.add_done_callback(done)
    return out


def _to_int16_list(pcm):
    if np is not None and isinstance(pcm, np.ndarray):
        return [int(v) for v in np.clip(pcm, -32768, 32767).astype(np.int16)]
    return [max(-32768, min(32767, int(v))) for v in pcm]


# ----------------------------------------------------------------- discovery

def list_candidate_ports():
    """Serial ports that look like an AMBE stick, best first. Never opens them."""
    try:
        from serial.tools import list_ports
    except ImportError:  # pragma: no cover
        return []
    found = []
    for info in list_ports.comports():
        vid, pid = info.vid, info.pid
        label = next((name for v, p, name in KNOWN_USB_IDS if v == vid and p == pid), None)
        if label is None:
            continue
        device = info.device
        # macOS: prefer the call-out device (cu.*) over the dial-in one (tty.*)
        if device.startswith("/dev/tty.") :
            device = device.replace("/dev/tty.", "/dev/cu.", 1)
        found.append({
            "device": device,
            "description": info.description or label,
            "serial": info.serial_number or "",
            "vid": "%04x" % vid,
            "pid": "%04x" % pid,
            "label": label,
        })
    # stable udev name on the Raspberry Pi first
    import os
    if os.path.exists("/dev/dvmega-ambestick"):
        found.insert(0, {"device": "/dev/dvmega-ambestick", "description": "DVMEGA DVstick (udev)",
                         "serial": "", "vid": "0403", "pid": "6015", "label": "DVstick"})
    unique, seen = [], set()
    for item in found:
        if item["device"] not in seen:
            seen.add(item["device"])
            unique.append(item)
    return unique


def open_stick(port, baud=DEFAULT_BAUD):
    transport = SerialTransport(port, baud)
    try:
        return Ambe3000(transport).open_dstar()
    except Exception:
        transport.close()
        raise
