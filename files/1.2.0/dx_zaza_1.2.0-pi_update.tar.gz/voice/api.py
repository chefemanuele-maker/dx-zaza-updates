"""Flask endpoints for the DX Zaza voice engine (/api/voice/*)."""

import logging
import os
import threading
import time

from flask import Blueprint, jsonify, request

from voice.engine import VoiceEngine, VoiceError, clean_message, clean_suffix
from voice.dmr_directory import TALKGROUPS as DMR_TALKGROUPS, DMRDirectory
from voice.echolink import Directory as EchoLinkDirectory, EchoLinkError
from voice.echolink_proxy import ProxyDirectory, ProxyError
from voice.reflectors import ReflectorDirectory
from voice.ysf_directory import YSFDirectory

log = logging.getLogger("dxzaza.voice")

DEFAULTS = {
    "suffix": "DXZA",
    "message": "DX Zaza",
    "local_module": "B",
    "tx_enabled": False,
    "input_device": "",
    "output_device": "",
    "volume": 1.0,
    "mic_gain": 1.0,
    "favorites": [],
    "last": {},
    "last_mode": "dstar",
    "dmr_id": "",
    "dmr_essid": "",
    "dmr_password": "",
    "dmr_favorites": [],
    "dmr_last": {},
    "ysf_favorites": [],
    "ysf_last": {},
    "echolink_callsign": "",
    "echolink_password": "",
    "echolink_name": "",
    "echolink_location": "",
    "echolink_favorites": [],
    "echolink_last": {},
}

ECHOLINK_SUGGESTED = [
    {"callsign": "*ECHOTEST*", "node": 9999, "note": "Echo test: hear yourself"},
]


def create_voice_blueprint(get_config, save_voice, get_callsign, data_dir, locate=None, busy_check=None,
                           audio_factory=None, engine=None, resume_on_start=False):
    bp = Blueprint("voice", __name__)

    def settings():
        voice = dict(DEFAULTS)
        voice.update((get_config().get("voice") or {}))
        voice["callsign"] = get_callsign() or ""
        return voice

    def default_audio():
        from voice.audio import SoundDeviceAudio
        s = settings()
        return SoundDeviceAudio(s.get("input_device", ""), s.get("output_device", ""),
                                float(s.get("volume", 1.0)), float(s.get("mic_gain", 1.0)))

    state = {"engine": engine}
    lock = threading.Lock()
    directory = ReflectorDirectory(data_dir)
    dmr_dir = DMRDirectory(data_dir)
    ysf_dir = YSFDirectory(data_dir)

    def echolink_credentials():
        s = settings()
        return ((s.get("echolink_callsign") or s.get("callsign") or "").upper(), s.get("echolink_password", ""),
                s.get("echolink_location", ""))

    el_dir = EchoLinkDirectory(echolink_credentials)
    el_direct_connector = el_dir.connector
    el_proxies = ProxyDirectory()

    def echolink_via_proxy():
        """Open a public proxy and log in to the directory through it (the station sees the proxy)."""
        link = el_proxies.open_link(echolink_credentials()[0])
        el_dir.connector = link.tcp_connector
        try:
            el_dir.set_status("online")
        except EchoLinkError:
            el_dir.connector = el_direct_connector
            link.close()
            raise
        return link

    def echolink_direct():
        el_dir.connector = el_direct_connector

    def get_engine():
        with lock:
            if state["engine"] is None:
                state["engine"] = VoiceEngine(settings, audio_factory or default_audio,
                                              busy_check=busy_check, locate=locate,
                                              dmr_lookup=dmr_dir.callsign_for)
            return state["engine"]

    def ok(payload=None, code=200):
        body = {"ok": True}
        body.update(payload or {})
        return jsonify(body), code

    def fail(message, code=400):
        return jsonify({"ok": False, "error": str(message)}), code

    def public_settings():
        s = settings()
        return {
            "callsignConfigured": bool(s["callsign"]),
            "suffix": s["suffix"],
            "message": s["message"],
            "txEnabled": bool(s["tx_enabled"]),
            "inputDevice": s["input_device"],
            "outputDevice": s["output_device"],
            "volume": s["volume"],
            "micGain": s["mic_gain"],
            "favorites": s["favorites"],
            "last": s["last"],
            "lastMode": s.get("last_mode", "dstar"),
            "dmrId": s.get("dmr_id", ""),
            "dmrEssid": s.get("dmr_essid", ""),
            "dmrPasswordSet": bool(s.get("dmr_password")),   # the password itself never leaves the device
            "dmrFavorites": s.get("dmr_favorites", []),
            "dmrLast": s.get("dmr_last", {}),
            "ysfFavorites": s.get("ysf_favorites", []),
            "ysfLast": s.get("ysf_last", {}),
            "echolinkCallsign": s.get("echolink_callsign", ""),
            "echolinkPasswordSet": bool(s.get("echolink_password")),   # never sent back
            "echolinkName": s.get("echolink_name", ""),
            "echolinkLocation": s.get("echolink_location", ""),
            "echolinkFavorites": s.get("echolink_favorites", []),
            "echolinkLast": s.get("echolink_last", {}),
        }

    @bp.get("/api/voice/status")
    def status():
        engine_ = get_engine()
        body = engine_.status()
        body["settings"] = public_settings()
        return ok(body)

    @bp.get("/api/voice/ports")
    def ports():
        return ok({"ports": get_engine().devices()})

    @bp.get("/api/voice/audio-devices")
    def audio_devices():
        from voice.audio import list_devices
        return ok(list_devices())

    @bp.post("/api/voice/device/open")
    def device_open():
        payload = request.get_json(silent=True) or {}
        try:
            return ok({"device": get_engine().open_device(payload.get("port", ""))})
        except VoiceError as exc:
            return fail(exc)

    @bp.post("/api/voice/device/close")
    def device_close():
        get_engine().close_device()
        return ok()

    @bp.post("/api/voice/link")
    def link():
        payload = request.get_json(silent=True) or {}
        host = str(payload.get("host", "")).strip()
        module = str(payload.get("module", "")).strip().upper()[:1]
        name = str(payload.get("name", "")).strip().upper()[:8]
        try:
            port = int(payload.get("port") or 0) or None
        except (TypeError, ValueError):
            return fail("invalid port")
        protocol = str(payload.get("protocol", "")).lower()[:8]
        if not host or not module.isalpha():
            return fail("Choose a reflector and a module (A-Z).")
        try:
            result = get_engine().link(host, module, name=name, port=port, protocol=protocol)
        except VoiceError as exc:
            return fail(exc)
        save_voice({"last": {"name": name, "host": host, "module": module, "port": result.get("port", port),
                             "protocol": result.get("protocol", "")}, "last_mode": "dstar", "resume": True})
        return ok({"link": result})

    # ------------------------------------------------------------ DMR
    @bp.get("/api/voice/dmr/masters")
    def dmr_masters():
        data = dmr_dir.masters(force=request.args.get("refresh") == "1")
        masters = [{k: m[k] for k in ("name", "host", "port", "family")} for m in data["masters"]]
        return ok({"masters": masters, "updated": data.get("updated", 0), "warning": data.get("error", ""),
                   "talkgroups": {str(k): v for k, v in sorted(DMR_TALKGROUPS.items())}})

    @bp.get("/api/voice/dmr/id")
    def dmr_id_lookup():
        call = request.args.get("callsign") or settings().get("callsign", "")
        try:
            return ok({"ids": dmr_dir.ids_for(call)})
        except Exception as exc:
            return fail("RadioID.net not reachable: %s" % exc.__class__.__name__)

    def _dmr_password_for(host, family):
        if family == "BrandMeister":
            return settings().get("dmr_password", "")
        for m in dmr_dir.masters()["masters"]:
            if m["host"] == host:
                return m.get("password") or "passw0rd"
        return "passw0rd"

    @bp.post("/api/voice/dmr/link")
    def dmr_link():
        payload = request.get_json(silent=True) or {}
        host = str(payload.get("host", "")).strip()[:100]
        name = str(payload.get("name", "")).strip()[:40]
        family = str(payload.get("family", "")).strip()[:20] or "Other"
        try:
            port = int(payload.get("port") or 62031)
            talkgroup = int(payload.get("talkgroup"))
        except (TypeError, ValueError):
            return fail("Choose a network and a talkgroup number.")
        if not host:
            return fail("Choose a DMR network.")
        password = _dmr_password_for(host, family)
        if family == "BrandMeister" and not password:
            return fail("BrandMeister needs your hotspot password: set it in BrandMeister SelfCare, "
                        "then enter it in DMR settings.")
        try:
            result = get_engine().link_dmr(host, talkgroup, name=name, port=port, network={"password": password})
        except VoiceError as exc:
            return fail(exc)
        save_voice({"dmr_last": {"name": name, "host": host, "port": port, "talkgroup": talkgroup, "family": family},
                    "last_mode": "dmr", "resume": True})
        return ok({"link": result})

    @bp.post("/api/voice/dmr/listen")
    def dmr_listen():
        try:
            return ok({"link": get_engine().listen_talkgroup()})
        except VoiceError as exc:
            return fail(exc)

    # ------------------------------------------------------------ C4FM (YSF rooms)
    @bp.get("/api/voice/ysf/rooms")
    def ysf_rooms():
        data = ysf_dir.rooms(force=request.args.get("refresh") == "1")
        return ok({"rooms": data["rooms"], "updated": data.get("updated", 0), "warning": data.get("error", ""),
                   "source": data.get("source", "")})

    @bp.post("/api/voice/ysf/link")
    def ysf_link():
        payload = request.get_json(silent=True) or {}
        room_id = str(payload.get("id", "")).strip()[:8]
        host = str(payload.get("host", "")).strip()[:100]
        name = str(payload.get("name", "")).strip()[:30]
        try:
            port = int(payload.get("port") or 42000)
        except (TypeError, ValueError):
            return fail("invalid port")
        if room_id and not host:
            room = ysf_dir.find(room_id)
            if room is None:
                return fail("C4FM room %s not found in the list." % room_id)
            host, port, name = room["host"], room["port"], name or room["name"]
        if not host:
            return fail("Choose a C4FM room.")
        if not 1 <= port <= 65535:
            return fail("invalid port")
        try:
            result = get_engine().link_ysf(host, port=port, name=name, room_id=room_id)
        except VoiceError as exc:
            return fail(exc)
        save_voice({"ysf_last": {"id": room_id, "name": name, "host": host, "port": port}, "last_mode": "ysf",
                    "resume": True})
        return ok({"link": result})

    # ------------------------------------------------------------ EchoLink
    @bp.get("/api/voice/echolink/stations")
    def echolink_stations():
        query = str(request.args.get("q", "")).strip().upper()[:30]
        kind = str(request.args.get("kind", "")).strip().lower()
        if not settings().get("echolink_password"):
            return fail("Enter your EchoLink callsign and password in EchoLink settings and press Save: "
                        "the directory only shows the stations to logged-in users.", 400)
        try:
            # the directory sends the station list only to an address that is logged in:
            # log in as "busy" to browse (nobody calls us), "online" only when connecting
            if el_dir.status not in ("online", "busy"):
                el_dir.set_status("busy")
                force = True
            else:
                el_dir.refresh_if_due()
                force = request.args.get("refresh") == "1"
            stations = el_dir.stations(force=force)
            if not stations:
                time.sleep(1.5)                       # the login may need a moment to reach the list
                stations = el_dir.stations(force=True)
        except EchoLinkError as exc:
            return fail(exc, 502)
        out = []
        for st in stations:
            if kind and st["kind"] != kind:
                continue
            if query and query not in st["callsign"] and query not in st["description"].upper() \
                    and query != str(st["node"]):
                continue
            out.append({k: st[k] for k in ("callsign", "description", "status", "since", "node", "kind")})
        out.sort(key=lambda st: (st["status"] != "ON", st["callsign"]))
        return ok({"stations": out[:300], "total": len(stations), "matches": len(out),
                   "suggested": ECHOLINK_SUGGESTED, "directory": {"status": el_dir.status, "error": el_dir.error},
                   "serverMessage": el_dir.message[:600]})

    @bp.post("/api/voice/echolink/connect")
    def echolink_connect():
        payload = request.get_json(silent=True) or {}
        target = str(payload.get("target", "")).strip().upper()[:20]
        if not target:
            return fail("Type a callsign or a node number.")
        s = settings()
        if not s.get("echolink_password"):
            return fail("Enter your EchoLink password first (EchoLink settings).")
        try:
            station = el_dir.find(target)
        except EchoLinkError as exc:
            return fail(exc, 502)
        if station is None:
            return fail("%s is not on line in the EchoLink directory now." % target)
        if station["status"] == "BUSY":
            return fail("%s is busy now." % station["callsign"])
        info = "DX Zaza\n%s %s\n%s" % (echolink_credentials()[0], s.get("echolink_name", ""),
                                         s.get("echolink_location", ""))
        engine_ = get_engine()
        # Automatic route: straight (works when the router lets the answers in) or, when the station
        # cannot answer us, through a public EchoLink proxy (one outgoing TCP connection, no router setup).
        routes = ["proxy", "direct"] if s.get("echolink_route") == "proxy" else ["direct", "proxy"]
        result, errors = None, []
        for route in routes:
            proxy = None
            try:
                if route == "direct":
                    echolink_direct()
                    el_dir.set_status("online")       # the station checks we are logged in with this IP
                else:
                    proxy = echolink_via_proxy()
                result = engine_.link_echolink(station["ip"], station["callsign"], node=station["node"], info=info,
                                               proxy=proxy)
                if s.get("echolink_route") != route:
                    save_voice({"echolink_route": route})
                break
            except (VoiceError, EchoLinkError, ProxyError) as exc:
                errors.append(str(exc))
                if proxy is not None:
                    proxy.close()
                echolink_direct()
                if "password" in str(exc).lower() or "validated" in str(exc).lower():
                    break                             # same answer whatever the route
        if result is None:
            return fail(" · ".join(dict.fromkeys(errors)) if errors else "EchoLink connection failed")
        save_voice({"echolink_last": {"callsign": station["callsign"], "node": station["node"]},
                    "last_mode": "echolink", "resume": True})
        return ok({"link": result, "station": {k: station[k] for k in ("callsign", "description", "node", "kind")}})

    @bp.post("/api/voice/echolink/capture")
    def echolink_capture():
        """Diagnostics: record 40 s of EchoLink traffic and speaker audio to the data folder."""
        payload = request.get_json(silent=True) or {}
        folder = data_dir / "echolink_capture" / time.strftime("%Y%m%d-%H%M%S")
        try:
            return ok({"capture": get_engine().start_capture(folder, payload.get("seconds", 40))})
        except VoiceError as exc:
            return fail(exc)

    @bp.post("/api/voice/echolink/text")
    def echolink_text():
        payload = request.get_json(silent=True) or {}
        text = str(payload.get("text", "")).strip()[:200]
        if not text:
            return fail("Empty message.")
        try:
            return ok({"link": get_engine().send_text(text)})
        except VoiceError as exc:
            return fail(exc)

    def _echolink_keepalive():
        """Stay registered in the EchoLink directory while connected (every 5 minutes)."""
        while True:
            time.sleep(30)
            engine_ = state["engine"]
            if engine_ is not None and engine_.link_status().get("mode") == "echolink" \
                    and engine_.link_status().get("state") in ("linked", "lost"):
                el_dir.refresh_if_due()

    threading.Thread(target=_echolink_keepalive, name="echolink-directory", daemon=True).start()

    @bp.post("/api/voice/unlink")
    def unlink():
        engine_ = get_engine()
        was_echolink = engine_.link_status().get("mode") == "echolink"
        engine_.unlink()
        echolink_direct()
        save_voice({"resume": False})
        if was_echolink and el_dir.status in ("online", "busy"):
            def offline():
                try:
                    el_dir.set_status("offline")
                except EchoLinkError:
                    pass
            threading.Thread(target=offline, name="echolink-offline", daemon=True).start()
        return ok()

    @bp.post("/api/voice/ptt")
    def ptt():
        payload = request.get_json(silent=True) or {}
        try:
            return ok({"tx": get_engine().ptt(bool(payload.get("on")))})
        except VoiceError as exc:
            return fail(exc)

    @bp.post("/api/voice/selftest")
    def selftest():
        try:
            return ok({"result": get_engine().self_test()})
        except VoiceError as exc:
            return fail(exc)
        except Exception as exc:  # serial problems during the test
            return fail("DVstick test failed: %s" % exc)

    @bp.post("/api/voice/looptest")
    def looptest():
        payload = request.get_json(silent=True) or {}
        try:
            return ok({"test": get_engine().loop_test(payload.get("seconds", 4))})
        except VoiceError as exc:
            return fail(exc)

    @bp.get("/api/voice/reflectors")
    def reflectors():
        result = directory.get(force=request.args.get("refresh") == "1")
        return ok({"reflectors": result["reflectors"], "updated": result["updated"],
                   "warning": result.get("error", "")})

    @bp.post("/api/voice/settings")
    def save_settings():
        payload = request.get_json(silent=True) or {}
        changes = {}
        if "suffix" in payload:
            changes["suffix"] = clean_suffix(payload["suffix"])
        if "message" in payload:
            changes["message"] = clean_message(payload["message"])
        if "txEnabled" in payload:
            changes["tx_enabled"] = bool(payload["txEnabled"])
        for key, name in (("inputDevice", "input_device"), ("outputDevice", "output_device")):
            if key in payload:
                changes[name] = str(payload[key] or "")[:120]
        for key, name, low, high in (("volume", "volume", 0.0, 3.0), ("micGain", "mic_gain", 0.2, 4.0)):
            if key in payload:
                try:
                    changes[name] = max(low, min(high, float(payload[key])))
                except (TypeError, ValueError):
                    return fail("invalid %s" % key)
        if "dmrId" in payload:
            value = "".join(ch for ch in str(payload["dmrId"] or "") if ch.isdigit())
            if value and not 6 <= len(value) <= 7:
                return fail("A DMR ID has 7 digits.")
            changes["dmr_id"] = value
        if "dmrEssid" in payload:
            value = "".join(ch for ch in str(payload["dmrEssid"] or "") if ch.isdigit())[:2]
            changes["dmr_essid"] = value.zfill(2) if value else ""
        if "dmrPassword" in payload and payload["dmrPassword"] is not None:
            changes["dmr_password"] = str(payload["dmrPassword"])[:64]
        if "dmrFavorites" in payload and isinstance(payload["dmrFavorites"], list):
            favs = []
            for item in payload["dmrFavorites"][:30]:
                try:
                    favs.append({"name": str(item.get("name", ""))[:40], "host": str(item["host"])[:100],
                                 "port": int(item.get("port") or 62031), "talkgroup": int(item["talkgroup"]),
                                 "family": str(item.get("family", ""))[:20]})
                except (KeyError, TypeError, ValueError, AttributeError):
                    continue
            changes["dmr_favorites"] = favs
        if "ysfFavorites" in payload and isinstance(payload["ysfFavorites"], list):
            favs = []
            for item in payload["ysfFavorites"][:30]:
                try:
                    favs.append({"id": str(item.get("id", ""))[:8], "name": str(item.get("name", ""))[:30],
                                 "host": str(item["host"])[:100], "port": int(item.get("port") or 42000)})
                except (KeyError, TypeError, ValueError, AttributeError):
                    continue
            changes["ysf_favorites"] = favs
        if "echolinkCallsign" in payload:
            value = "".join(ch for ch in str(payload["echolinkCallsign"] or "").upper() if ch.isalnum() or ch == "-")
            changes["echolink_callsign"] = value[:12]
        if "echolinkPassword" in payload and payload["echolinkPassword"] is not None:
            changes["echolink_password"] = str(payload["echolinkPassword"])[:64]
        for key, name, limit in (("echolinkName", "echolink_name", 30), ("echolinkLocation", "echolink_location", 27)):
            if key in payload:
                changes[name] = "".join(ch for ch in str(payload[key] or "") if 32 <= ord(ch) < 127)[:limit]
        if "echolinkFavorites" in payload and isinstance(payload["echolinkFavorites"], list):
            favs = []
            for item in payload["echolinkFavorites"][:30]:
                try:
                    favs.append({"callsign": str(item["callsign"]).upper()[:20], "node": int(item.get("node") or 0)})
                except (KeyError, TypeError, ValueError, AttributeError):
                    continue
            changes["echolink_favorites"] = favs
        if "favorites" in payload and isinstance(payload["favorites"], list):
            favs = []
            for item in payload["favorites"][:30]:
                if isinstance(item, dict) and item.get("host") and str(item.get("module", "")).isalpha():
                    favs.append({"name": str(item.get("name", ""))[:8].upper(), "host": str(item["host"])[:100],
                                 "module": str(item["module"])[:1].upper(), "port": int(item.get("port") or 0),
                                 "protocol": str(item.get("protocol", ""))[:8].lower()})
            changes["favorites"] = favs
        save_voice(changes)
        audio_keys = {"input_device", "output_device", "mic_gain"}
        engine_ = state["engine"]
        if engine_ is not None:
            if audio_keys & set(changes):
                engine_.reset_audio()
            elif "volume" in changes:
                engine_.set_volume(changes["volume"])  # live, no audio restart
        return ok({"settings": public_settings()})

    def resume_last_link():
        """Appliance mode (Raspberry Pi): after a restart or a power cut, go back to the
        reflector that was linked. A user's Unlink clears this."""
        for attempt in range(6):
            time.sleep(5 if attempt == 0 else 15)
            s = settings()
            mode = s.get("last_mode") or "dstar"
            dmr_mode = mode == "dmr"
            last = (s.get({"dmr": "dmr_last", "ysf": "ysf_last", "echolink": "echolink_last"}.get(mode, "last")))
            last = last or {}
            if mode == "echolink":
                if not s.get("resume") or not last.get("callsign") or not s.get("echolink_password"):
                    return
                try:
                    if get_engine().link_status().get("state") == "linked":
                        return
                    el_dir.set_status("online")
                    station = el_dir.find(last["callsign"])
                    if station is not None:
                        get_engine().link_echolink(station["ip"], station["callsign"], node=station["node"])
                    return
                except Exception as exc:
                    log.info("resume EchoLink attempt %d: %s", attempt + 1, exc)
                    continue
            if not s.get("resume") or not last.get("host") or not s.get("callsign"):
                return
            try:
                if get_engine().link_status().get("state") == "linked":
                    return
                if mode == "ysf":
                    get_engine().link_ysf(last["host"], port=last.get("port"), name=last.get("name", ""),
                                          room_id=last.get("id", ""))
                elif dmr_mode:
                    get_engine().link_dmr(last["host"], last.get("talkgroup"), name=last.get("name", ""),
                                          port=last.get("port"),
                                          network={"password": _dmr_password_for(last["host"], last.get("family", ""))})
                else:
                    get_engine().link(last["host"], last.get("module", "A"), name=last.get("name", ""),
                                      port=last.get("port") or None, protocol=last.get("protocol", ""))
                return
            except Exception as exc:  # DVstick not ready yet, network not up yet...
                log.info("resume link attempt %d: %s", attempt + 1, exc)

    if resume_on_start:
        threading.Thread(target=resume_last_link, name="voice-resume", daemon=True).start()

    def shutdown():
        if state["engine"] is not None:
            state["engine"].shutdown()

    bp.voice_engine = get_engine
    bp.echolink_directory = el_dir
    bp.echolink_proxies = el_proxies
    bp.voice_shutdown = shutdown
    def engine_status():
        """Voice engine status without starting the engine (None when it never ran)."""
        engine_ = state["engine"]
        return engine_.status() if engine_ is not None else None

    bp.engine_status = engine_status
    return bp


def pi_busy_check():
    """On the Raspberry Pi: refuse when BlueDV / AMBE Server owns the DVstick."""
    try:
        from services.dvstick_ownership_service import get_dvstick_ownership
        ownership = get_dvstick_ownership()
    except Exception:  # pragma: no cover
        return None
    if ownership.get("hardware_in_use") and ownership.get("pid") != os.getpid():
        owner = ownership.get("owner", "another program")
        names = {"bluedv": "BlueDV", "ambe_server": "the AMBE Server"}
        return "The DVstick is in use by %s. Stop it first." % names.get(owner, owner)
    return None
