"""Audio for the voice engine: microphone capture and speaker playout at the
sound card's own sample rate, converted to/from the 8 kHz used by AMBE.

The engine talks to an AudioBackend; SoundDeviceAudio uses PortAudio through
the `sounddevice` package (CoreAudio on macOS, WASAPI/MME on Windows, ALSA or
PulseAudio/PipeWire on Linux). FakeAudio is used by the tests.
"""

import collections
import logging
import math
import sys
import threading
import time

import numpy as np

VOICE_RATE = 8000
FRAME = 160
log = logging.getLogger("dxzaza.audio")


# ----------------------------------------------------------------- macOS: system default devices
class _CoreAudio:
    """Reads the current system default input/output device (macOS) without PortAudio,
    whose device list is fixed when it starts. Used to follow headphones being connected
    or the user changing the output in Control Centre."""

    def __init__(self):
        self.ok = False
        if sys.platform != "darwin":
            return
        try:
            import ctypes
            import ctypes.util
            self.ctypes = ctypes
            self.lib = ctypes.cdll.LoadLibrary(ctypes.util.find_library("CoreAudio"))

            class Address(ctypes.Structure):
                _fields_ = [("selector", ctypes.c_uint32), ("scope", ctypes.c_uint32), ("element", ctypes.c_uint32)]
            self.Address = Address
            self.ok = True
        except Exception:  # pragma: no cover
            self.ok = False

    @staticmethod
    def _fourcc(code):
        return int.from_bytes(code.encode("ascii"), "big")

    def _get_u32(self, obj, selector, scope="glob"):
        c = self.ctypes
        addr = self.Address(self._fourcc(selector), self._fourcc(scope), 0)
        value, size = c.c_uint32(0), c.c_uint32(4)
        err = self.lib.AudioObjectGetPropertyData(c.c_uint32(obj), c.byref(addr), 0, None, c.byref(size), c.byref(value))
        return value.value if err == 0 else None

    def default_device(self, kind):
        if not self.ok:
            return None
        return self._get_u32(1, "dOut" if kind == "output" else "dIn ")

    def is_bluetooth(self, device_id):
        if not self.ok or not device_id:
            return False
        transport = self._get_u32(device_id, "tran")
        return transport in (self._fourcc("blue"), self._fourcc("bleo"))


COREAUDIO = _CoreAudio()


def refresh_portaudio():
    """PortAudio only sees the devices present when it started: start it again."""
    import sounddevice as sd
    try:
        sd._terminate()
    except Exception:  # pragma: no cover
        pass
    sd._initialize()


_PA_SEEN = [None]          # system default devices (CoreAudio ids) when PortAudio last started


def sync_portaudio_with_system():
    """macOS: Bluetooth headphones connected (or the output changed in Control Centre) after
    PortAudio started are invisible to it, and its "default" is still the old speaker.
    Restart PortAudio when the system default changed. Only call with no stream open."""
    if not COREAUDIO.ok:
        return False
    current = (COREAUDIO.default_device("output"), COREAUDIO.default_device("input"))
    if current == _PA_SEEN[0]:
        return False
    if not _wait_streams_closed():
        return False
    try:
        refresh_portaudio()
    except Exception as exc:  # pragma: no cover
        log.warning("PortAudio restart failed: %s", exc)
        return False
    _PA_SEEN[0] = current
    log.info("audio devices re-read (system default changed)")
    return True


# ----------------------------------------------------------------- resampling

def _lowpass(cutoff, rate, taps=95):
    n = np.arange(taps) - (taps - 1) / 2.0
    h = np.sinc(2 * cutoff / rate * n) * np.hamming(taps)
    return (h / h.sum()).astype(np.float32)


class StreamResampler:
    """Streaming sample-rate converter (FIR low-pass + linear interpolation).

    Good enough for 8 kHz speech: the low-pass sits at 3.6 kHz on the higher
    rate, removing aliases (down) and interpolation images (up).
    """

    def __init__(self, rate_in, rate_out):
        self.rate_in = float(rate_in)
        self.rate_out = float(rate_out)
        self.step = self.rate_in / self.rate_out      # input samples per output sample
        high = max(rate_in, rate_out)
        self.taps = _lowpass(3600.0, high) if rate_in != rate_out else None
        self.fir_state = np.zeros(0 if self.taps is None else len(self.taps) - 1, dtype=np.float32)
        self.pos = 0.0           # fractional read position into pending input
        self.pending = np.zeros(1, dtype=np.float32)  # keeps the previous sample for interpolation

    def _fir(self, x):
        if self.taps is None:
            return x
        buf = np.concatenate([self.fir_state, x])
        y = np.convolve(buf, self.taps, mode="valid").astype(np.float32)
        self.fir_state = buf[-(len(self.taps) - 1):]
        return y

    def _interp(self, x):
        if self.rate_in == self.rate_out:
            return x
        data = np.concatenate([self.pending, x])
        last = len(data) - 1
        if self.pos > last:
            self.pending = data[-1:]
            self.pos -= last
            return np.zeros(0, dtype=np.float32)
        count = int(math.floor((last - self.pos) / self.step + 1e-9)) + 1
        idx = self.pos + self.step * np.arange(count)
        y = np.interp(idx, np.arange(len(data)), data).astype(np.float32)
        self.pos = idx[-1] + self.step - last
        self.pending = data[-1:]
        return y

    def process(self, x):
        x = np.asarray(x, dtype=np.float32)
        if self.rate_out < self.rate_in:
            return self._interp(self._fir(x))
        return self._fir(self._interp(x))


# ----------------------------------------------------------------- buffers

# Room for the Python threads (EchoLink's GSM codec runs in Python): with "low" latency a busy
# moment of the interpreter leaves the sound card without samples and the audio crackles.
OUTPUT_LATENCY = 0.12
INPUT_LATENCY = 0.08


_CLOSING = []


def _wait_streams_closed(timeout=2.0):
    """PortAudio must not be restarted while a stream is still being closed."""
    deadline = time.monotonic() + timeout
    for thread in list(_CLOSING):
        thread.join(max(0.0, deadline - time.monotonic()))
    _CLOSING[:] = [t for t in _CLOSING if t.is_alive()]
    return not _CLOSING


def _close_in_background(stream):
    def run():
        try:
            stream.abort()
        except Exception:  # pragma: no cover
            pass
        try:
            stream.close()
        except Exception:  # pragma: no cover
            pass
    thread = threading.Thread(target=run, name="audio-close", daemon=True)
    _CLOSING.append(thread)
    thread.start()


class PlayoutBuffer:
    """Jitter buffer for decoded speech (float32 at the output rate)."""

    def __init__(self, rate, prebuffer_ms=80, max_ms=1500):
        self.rate = rate
        self.prebuffer = int(rate * prebuffer_ms / 1000)
        self.max = int(rate * max_ms / 1000)
        self.chunks = collections.deque()
        self.size = 0
        self.playing = False
        self.lock = threading.Lock()
        self.underruns = 0
        self.level = 0.0
        self.max_prebuffer = self.prebuffer          # > prebuffer: grows after each real gap (jittery network / busy CPU)
        self.dry_at = None                           # when the buffer last ran dry while playing

    GAP_SECONDS = 0.6

    def push(self, samples):
        with self.lock:
            # audio arriving shortly after the buffer ran dry = an audible gap inside an over
            # (the end of an over also empties the buffer, but then nothing follows: not a gap)
            if self.dry_at is not None:
                if time.monotonic() - self.dry_at < self.GAP_SECONDS:
                    self.underruns += 1
                    if self.prebuffer < self.max_prebuffer:   # wait a little more from now on
                        self.prebuffer = min(self.max_prebuffer, self.prebuffer + int(self.rate * 0.04))
                self.dry_at = None
            self.chunks.append(samples)
            self.size += len(samples)
            while self.size > self.max and self.chunks:
                dropped = self.chunks.popleft()
                self.size -= len(dropped)

    def clear(self):
        with self.lock:
            self.chunks.clear()
            self.size = 0
            self.playing = False

    def pull(self, count):
        out = np.zeros(count, dtype=np.float32)
        with self.lock:
            if not self.playing:
                if self.size < self.prebuffer:
                    return out
                self.playing = True
            filled = 0
            while filled < count and self.chunks:
                chunk = self.chunks[0]
                take = min(count - filled, len(chunk))
                out[filled:filled + take] = chunk[:take]
                filled += take
                if take == len(chunk):
                    self.chunks.popleft()
                else:
                    self.chunks[0] = chunk[take:]
                self.size -= take
            if filled < count:
                self.playing = False
                self.dry_at = time.monotonic()
        return out


class FrameAssembler:
    """Turns resampled microphone audio into 160-sample int16 frames."""

    def __init__(self):
        self.buf = np.zeros(0, dtype=np.float32)

    def push(self, samples):
        self.buf = np.concatenate([self.buf, samples])
        frames = []
        while len(self.buf) >= FRAME:
            frames.append(self.buf[:FRAME])
            self.buf = self.buf[FRAME:]
        return [np.clip(f * 32767.0, -32768, 32767).astype(np.int16) for f in frames]


def rms_dbfs(samples):
    samples = np.asarray(samples, dtype=np.float32)
    if samples.size == 0:
        return -90.0
    if samples.dtype != np.float32 or np.max(np.abs(samples)) > 1.5:
        samples = samples / 32768.0
    value = float(np.sqrt(np.mean(samples * samples)))
    return max(-90.0, 20 * math.log10(value + 1e-9))


# ----------------------------------------------------------------- backends

class AudioBackend:
    """Interface used by the engine."""

    def start_output(self):
        raise NotImplementedError

    def stop_output(self):
        raise NotImplementedError

    def play_frame(self, pcm8k):
        raise NotImplementedError

    def start_input(self, on_frame):
        raise NotImplementedError

    def stop_input(self):
        raise NotImplementedError

    def close(self):
        self.stop_input()
        self.stop_output()


class FakeAudio(AudioBackend):
    def __init__(self):
        self.played = []
        self.on_frame = None
        self.output_running = False
        self.volume = 1.0

    def start_output(self):
        self.output_running = True

    def stop_output(self):
        self.output_running = False

    def play_frame(self, pcm8k):
        self.played.append(np.asarray(pcm8k))

    def start_input(self, on_frame):
        self.on_frame = on_frame

    def stop_input(self):
        self.on_frame = None

    def speak(self, frames):
        for frame in frames:
            if self.on_frame:
                self.on_frame(frame)


def list_devices():
    try:
        import sounddevice as sd
    except Exception as exc:  # pragma: no cover - PortAudio missing
        return {"ok": False, "error": str(exc), "inputs": [], "outputs": []}
    try:
        devices = sd.query_devices()
        default_in, default_out = sd.default.device
    except Exception as exc:  # pragma: no cover
        return {"ok": False, "error": str(exc), "inputs": [], "outputs": []}
    inputs, outputs = [], []
    for index, dev in enumerate(devices):
        item = {"name": dev["name"], "rate": int(dev["default_samplerate"])}
        if dev["max_input_channels"] > 0:
            inputs.append(dict(item, default=index == default_in))
        if dev["max_output_channels"] > 0:
            outputs.append(dict(item, default=index == default_out))
    return {"ok": True, "inputs": inputs, "outputs": outputs}


# ----------------------------------------------------------------- Raspberry Pi: HDMI screen audio
PI_ALSA_MARK = "# DX Zaza: default audio = screen speakers (HDMI)"


def _pi_hdmi_card():
    """vc4hdmi0 / vc4hdmi1: the HDMI port with a screen connected, or None."""
    import glob
    for path in sorted(glob.glob("/sys/class/drm/card*-HDMI-A-*/status")):
        try:
            with open(path) as handle:
                if handle.read().strip() == "connected":
                    return "vc4hdmi%d" % (int(path.rsplit("HDMI-A-", 1)[1].split("/")[0]) - 1)
        except (OSError, ValueError):
            continue
    return None


def ensure_pi_hdmi_audio():
    """On the Raspberry Pi the voice goes to the screen speakers through the ALSA "hdmi:" device
    (the raw HDMI device needs a special format and plays nothing). The desktop's own audio tools
    can remove ~/.asoundrc, so it is checked - and written again if needed - every time the
    speaker opens. A second copy lives in ~/.config/alsa/asoundrc. Returns True if it changed."""
    import os
    try:
        with open("/proc/device-tree/model") as handle:
            if "raspberry pi" not in handle.read().lower():
                return False
    except OSError:
        return False
    card = _pi_hdmi_card()
    if not card:
        return False
    text = (PI_ALSA_MARK + "\n"
            'pcm.!default { type plug; slave.pcm "hdmi:CARD=%s,DEV=0" }\n'
            "ctl.!default { type hw; card %s }\n") % (card, card)
    home = os.path.expanduser("~")
    changed = False
    for path in (os.path.join(home, ".asoundrc"), os.path.join(home, ".config", "alsa", "asoundrc")):
        try:
            current = open(path).read() if os.path.exists(path) else None
            if current is not None and PI_ALSA_MARK not in current:
                continue                     # the owner set up audio by hand: leave it
            if current != text:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "w") as handle:
                    handle.write(text)
                changed = True
                log.info("HDMI screen audio configured in %s (%s)", path, card)
        except OSError as exc:
            log.warning("cannot write %s: %s", path, exc)
    return changed


def _find_device(name, kind):
    if not name:
        return None
    import sounddevice as sd
    for index, dev in enumerate(sd.query_devices()):
        channels = dev["max_input_channels"] if kind == "input" else dev["max_output_channels"]
        if channels > 0 and dev["name"] == name:
            return index
    return None


def _builtin_mic_if_bluetooth_default():
    """With Bluetooth headphones as the system microphone, macOS switches them to the
    low-quality telephone profile and the speaker stream stops. Use the computer's own
    microphone instead (the headphones keep playing in high quality)."""
    if not COREAUDIO.is_bluetooth(COREAUDIO.default_device("input")):
        return None
    import sounddevice as sd
    for index, dev in enumerate(sd.query_devices()):
        name = dev["name"].lower()
        if dev["max_input_channels"] > 0 and ("macbook" in name or "built-in" in name or "imac" in name
                                               or "mac mini" in name or "mac studio" in name):
            log.info("Bluetooth microphone is the default: using %s instead", dev["name"])
            return index
    return None


class SoundDeviceAudio(AudioBackend):
    def __init__(self, input_device="", output_device="", volume=1.0, mic_gain=1.0):
        import sounddevice  # noqa: F401  (fail early if PortAudio is missing)
        self.input_device = input_device
        self.output_device = output_device
        self.volume = float(volume)
        self.mic_gain = float(mic_gain)
        self.out_stream = None
        self.in_stream = None
        self.playout = None
        self.up = None
        self.down = None
        self.assembler = None
        self.on_frame = None
        self.in_level = -90.0
        self.out_level = -90.0
        self.lock = threading.Lock()
        self.last_error = ""
        self.out_callback_at = 0.0
        self.out_started_at = 0.0
        self.out_device_name = ""
        self.in_device_name = ""
        self.out_default_id = None
        self.last_check = 0.0
        self.capture_out = None                      # diagnostics: blocks sent to the speaker
        self.xruns = 0                               # times the sound card was not fed in time
        self.out_rate = 0

    # keep the output alive ------------------------------------------
    def maintain(self):
        """Called about once a second by the engine. Restarts the speaker stream when the
        system output changed (headphones on/off, Bluetooth profile switch after using the
        Bluetooth microphone) or when the stream stopped calling back."""
        now = time.monotonic()
        if now - self.last_check < 1.0:
            return
        self.last_check = now
        if self.out_stream is None or self.in_stream is not None:
            return                                   # not playing, or talking: leave it alone
        reason = ""
        if not self.output_device and COREAUDIO.ok:
            current = COREAUDIO.default_device("output")
            if current and self.out_default_id and current != self.out_default_id:
                reason = "system output changed"
        try:
            active = bool(self.out_stream.active)
        except Exception:
            active = False
        if not active:
            reason = reason or "output stream stopped"
        elif now - max(self.out_callback_at, self.out_started_at) > 1.5:
            reason = reason or "output stream stalled"
        if reason:
            log.warning("restarting the speaker: %s", reason)
            self.restart_output()

    def restart_output(self):
        self.stop_output()
        try:
            if _wait_streams_closed():
                refresh_portaudio()
                if COREAUDIO.ok:
                    _PA_SEEN[0] = (COREAUDIO.default_device("output"), COREAUDIO.default_device("input"))
        except Exception as exc:  # pragma: no cover
            log.warning("PortAudio restart failed: %s", exc)
        try:
            self.start_output()
        except Exception as exc:
            self.last_error = str(exc)
            log.error("speaker not available: %s", exc)

    # output ---------------------------------------------------------
    def start_output(self):
        import sounddevice as sd
        with self.lock:
            if self.out_stream is not None:
                return
            if sys.platform.startswith("linux") and not self.output_device and ensure_pi_hdmi_audio():
                refresh_portaudio()          # PortAudio must re-read the ALSA configuration
            if self.in_stream is None:
                sync_portaudio_with_system()  # headphones connected after the app started
            device = _find_device(self.output_device, "output")
            info = sd.query_devices(device, "output")
            rate = int(info["default_samplerate"]) or 48000
            self.playout = PlayoutBuffer(rate, prebuffer_ms=getattr(self, "prebuffer_ms", 80))
            self.playout.max_prebuffer = max(self.playout.prebuffer,
                                             int(rate * getattr(self, "max_prebuffer_ms", 80) / 1000))
            self.up = StreamResampler(VOICE_RATE, rate)

            def callback(outdata, frames, _time, status):
                self.out_callback_at = time.monotonic()
                if status:
                    self.xruns += 1
                block = np.clip(self.playout.pull(frames) * self.volume, -1.0, 1.0)
                cap = self.capture_out
                if cap is not None:
                    cap.append(block.copy())
                peak = float(np.max(np.abs(block))) if len(block) else 0.0
                self.out_level = rms_dbfs(block) if peak > 1e-4 else -90.0
                outdata[:, 0] = block
                if outdata.shape[1] > 1:
                    outdata[:, 1:] = block[:, None]

            channels = min(2, max(1, int(info["max_output_channels"])))
            self.out_stream = sd.OutputStream(device=device, samplerate=rate, channels=channels,
                                              dtype="float32", callback=callback, latency=OUTPUT_LATENCY)
            self.out_started_at = time.monotonic()
            self.out_stream.start()
            self.out_device_name = info.get("name", "")
            self.out_rate = rate
            self.out_default_id = COREAUDIO.default_device("output")
            log.info("speaker: %s (%d Hz)", self.out_device_name, rate)

    def stop_output(self):
        with self.lock:
            stream, self.out_stream = self.out_stream, None
        if stream is not None:
            _close_in_background(stream)

    def play_frame(self, pcm8k):
        if self.playout is None:
            return
        samples = np.asarray(pcm8k, dtype=np.float32) / 32768.0
        self.playout.push(self.up.process(samples))

    def set_prebuffer(self, ms, max_ms=None):
        """More buffering for audio that crosses the internet as sound (EchoLink); with max_ms the
        buffer grows by itself after each gap, up to max_ms."""
        self.prebuffer_ms = int(ms)
        self.max_prebuffer_ms = int(max_ms or ms)
        playout = self.playout
        if playout is not None:
            playout.prebuffer = int(playout.rate * self.prebuffer_ms / 1000)
            playout.max_prebuffer = max(playout.prebuffer, int(playout.rate * self.max_prebuffer_ms / 1000))

    @property
    def underruns(self):
        return self.playout.underruns if self.playout is not None else 0

    @property
    def buffer_ms(self):
        p = self.playout
        return int(p.prebuffer * 1000 / p.rate) if p is not None else 0

    def flush_output(self):
        if self.playout is not None:
            self.playout.clear()

    # input ----------------------------------------------------------
    def start_input(self, on_frame):
        import sounddevice as sd
        with self.lock:
            self.on_frame = on_frame
            if self.in_stream is not None:
                return
            device = _find_device(self.input_device, "input")
            if device is None and not self.input_device:
                device = _builtin_mic_if_bluetooth_default()
            info = sd.query_devices(device, "input")
            self.in_device_name = info.get("name", "")
            log.info("microphone: %s", self.in_device_name)
            rate = int(info["default_samplerate"]) or 48000
            self.down = StreamResampler(rate, VOICE_RATE)
            self.assembler = FrameAssembler()

            def callback(indata, frames, _time, _status):
                mono = indata[:, 0].astype(np.float32) * self.mic_gain
                for frame in self.assembler.push(self.down.process(mono)):
                    self.in_level = rms_dbfs(frame)
                    handler = self.on_frame
                    if handler:
                        handler(frame)

            self.in_stream = sd.InputStream(device=device, samplerate=rate, channels=1,
                                            dtype="float32", callback=callback, latency=INPUT_LATENCY)
            self.in_stream.start()

    def stop_input(self):
        """Never blocks the caller: CoreAudio can take a long time (or hang) to stop a stream,
        so the stream is aborted and closed in the background."""
        with self.lock:
            self.on_frame = None
            stream, self.in_stream = self.in_stream, None
            self.in_level = -90.0
        if stream is not None:
            _close_in_background(stream)
