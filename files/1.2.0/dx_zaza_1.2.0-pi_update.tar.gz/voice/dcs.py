"""DCS client (UDP 30051) for DCS reflectors (and XLX, which also speaks DCS).

Link:       callsign+module(8) + local module + reflector module + 0x00 + reflector(8) + HTML  (519 bytes)
Unlink:     same first 19 bytes with ' ' as reflector module
Answer:     callsign(8) + modules(2) + 'ACK'/'NAK' + 0x00                               (14 bytes)
Keep-alive: callsign+module(8) + 0x00 + reflector+module(8)                              (17 bytes)
Voice:      one 100-byte packet per frame: "0001" + radio header (39, no CRC) + stream id (2)
            + sequence (1) + AMBE (9) + slow data (3) + counter (3) + 01 00 21 + text (20)
"""

import struct

from voice import dstar
from voice.linkbase import ReflectorClient

DEFAULT_PORT = 30051
VOICE_LEN = 100
HTML = ('<table border="0" width="95%%"><tr><td width="4%%"><img border="0" src="hotspot.jpg"></td>'
        '<td width="96%%"><font size="2"><b>%s</b> DX Zaza</font></td></tr></table>')


def _repeater(callsign, module):
    return dstar.field(callsign, 7) + dstar.field(module, 1)


def link_packet(callsign, local_module, reflector, module):
    head = (_repeater(callsign, local_module) + dstar.field(local_module, 1) + dstar.field(module, 1) + b"\x00"
            + dstar.field(reflector, 7) + dstar.field(module, 1))
    html = (HTML % "DX ZAZA").encode("ascii")
    return (head + html).ljust(519, b"\x00")[:519]


def unlink_packet(callsign, local_module, reflector):
    return (_repeater(callsign, local_module) + dstar.field(local_module, 1) + b" \x00"
            + dstar.field(reflector, 7) + b" ")


def keepalive_packet(callsign, local_module, reflector, module):
    return _repeater(callsign, local_module) + b"\x00" + dstar.field(reflector, 7) + dstar.field(module, 1)


def build_voice(stream_id, seq, header41, ambe, slow, counter, text="", last=False):
    seq_byte = (seq % dstar.FRAMES_PER_SUPERFRAME) | (0x40 if last else 0)
    if last:
        ambe, slow = dstar.END_AMBE, dstar.END_SLOW_DATA
    packet = (b"0001" + bytes(header41)[:39] + struct.pack("<H", stream_id) + bytes([seq_byte])
              + bytes(ambe)[:9].ljust(9, b"\x00") + bytes(slow)[:3].ljust(3, b"\x00")
              + struct.pack("<I", counter & 0xFFFFFF)[:3] + bytes((0x01, 0x00, 0x21))
              + str(text or "").encode("ascii", "replace")[:20].ljust(20, b" "))
    return packet.ljust(VOICE_LEN, b"\x00")


def parse_voice(packet):
    """Returns (header_info, voice_info) for a DCS voice packet, else None."""
    packet = bytes(packet)
    if len(packet) < 61 or packet[:4] != b"0001":
        return None
    header = dstar.parse_header(packet[4:43] + struct.pack("<H", dstar.crc_x25(packet[4:43])))
    stream_id = struct.unpack("<H", packet[43:45])[0]
    seq = packet[45]
    header.update(type="header", stream_id=stream_id, raw_header=packet[4:43])
    voice = {"type": "voice", "stream_id": stream_id, "seq": seq & 0x1F, "last": bool(seq & 0x40),
             "ambe": packet[46:55], "slow": packet[55:58]}
    return header, voice


def classify(packet):
    if len(packet) == 14 and packet[10:13] == b"ACK":
        return "ack"
    if len(packet) == 14 and packet[10:13] == b"NAK":
        return "nak"
    if len(packet) >= 61 and packet[:4] == b"0001":
        return "voice"
    if len(packet) in (17, 22):
        return "keepalive"
    if len(packet) == 19 and packet[9:10] == b" ":
        return "unlink"
    return "unknown"


class DCSClient(ReflectorClient):
    protocol = "dcs"
    default_port = DEFAULT_PORT
    keepalive_seconds = 2.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._rx_stream = None
        self._tx_header = b""
        self._counter = 0

    def _name(self):
        return (self.reflector or "DCS000")[:7]

    def _login(self, deadline):
        self._send_until_ack(link_packet(self.callsign, self.local_module, self._name(), self.module), deadline)

    def _keepalive_packet(self):
        return keepalive_packet(self.callsign, self.local_module, self._name(), self.module)

    def _unlink_packets(self):
        return [unlink_packet(self.callsign, self.local_module, self._name())]

    def _handle(self, data):
        kind = classify(data)
        if kind == "ack":
            self._ack.set()
        elif kind == "nak":
            self._nak = "NAK"
            self._ack.set()
        elif kind == "unlink":
            self._remote_unlinked()
        elif kind == "voice":
            parsed = parse_voice(data)
            if not parsed:
                return
            header, voice = parsed
            if header["stream_id"] != self._rx_stream:
                self._rx_stream = header["stream_id"]
                self._deliver(header)
            self._deliver(voice)
            if voice["last"]:
                self._rx_stream = None

    def send_header(self, stream_id, header):
        self._tx_header = bytes(header)      # DCS repeats the header inside every voice packet

    def send_voice(self, stream_id, seq, ambe, slow, last=False):
        self._counter += 1
        self._send(build_voice(stream_id, seq, self._tx_header, ambe, slow, self._counter, last=last))
