"""DExtra client (UDP 30001) for D-STAR reflectors: XLX and XRF.

Link:       callsign(8) + local module + reflector module + 0x00   (11 bytes)
Unlink:     callsign(8) + local module + ' '              + 0x00   (11 bytes)
Keep-alive: callsign(8) + 0x00                                       (9 bytes), both ways
Answer:     ... 'ACK' 0x00 / 'NAK' 0x00                              (14 bytes)
Voice:      DSVT header (56 bytes) and DSVT voice frames (27 bytes)
"""

from voice import dstar
from voice.linkbase import ACK_WAIT_SECONDS, LINK_TIMEOUT_SECONDS, LinkError, ReflectorClient  # noqa: F401

DEFAULT_PORT = 30001
KEEPALIVE_SECONDS = 3.0
DExtraError = LinkError


def link_packet(callsign, local_module, reflector_module):
    return dstar.field(callsign, 8) + dstar.field(local_module, 1) + dstar.field(reflector_module, 1) + b"\x00"


def unlink_packet(callsign, local_module):
    return dstar.field(callsign, 8) + dstar.field(local_module, 1) + b" \x00"


def keepalive_packet(callsign):
    return dstar.field(callsign, 8) + b"\x00"


def classify(packet):
    if len(packet) == 9:
        return "keepalive"
    if len(packet) == 14 and packet[10:13] == b"ACK":
        return "ack"
    if len(packet) == 14 and packet[10:13] == b"NAK":
        return "nak"
    if len(packet) == 11:
        return "link-echo"
    if packet[:4] == dstar.DSVT_TAG:
        return "dsvt"
    return "unknown"


class DExtraClient(ReflectorClient):
    protocol = "dextra"
    default_port = DEFAULT_PORT
    keepalive_seconds = KEEPALIVE_SECONDS
    keepalive_while_linking = True

    def _login(self, deadline):
        self._send_until_ack(link_packet(self.callsign, self.local_module, self.module), deadline)

    def _keepalive_packet(self):
        return keepalive_packet(self.callsign)

    def _unlink_packets(self):
        return [unlink_packet(self.callsign, self.local_module)]

    def _handle(self, data):
        kind = classify(data)
        if kind == "ack":
            self._ack.set()
        elif kind == "nak":
            self._nak = "NAK"
            self._ack.set()
        elif kind == "link-echo" and self.state == "linking":
            self._ack.set()       # older XRF software echoes the link request
        elif kind == "keepalive":
            if self.state == "linking":
                self._ack.set()   # some XRF reflectors answer with keep-alives only
        elif kind == "dsvt":
            self._deliver(dstar.parse_dsvt(data))

    def send_header(self, stream_id, header):
        self._send(dstar.build_dsvt_header(stream_id, header))

    def send_voice(self, stream_id, seq, ambe, slow, last=False):
        self._send(dstar.build_dsvt_voice(stream_id, seq, ambe, slow, last))
