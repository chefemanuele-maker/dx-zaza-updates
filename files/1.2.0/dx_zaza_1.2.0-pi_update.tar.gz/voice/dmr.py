"""DMR (ETSI TS 102 361-1) air-interface pieces needed by a network hotspot.

A DMR burst is 264 bits (33 bytes):
    voice:  AMBE 108 bits | SYNC or EMB+embedded 48 bits | AMBE 108 bits
            three 72-bit AMBE+2 frames (rate 33, FEC included: the DVstick handles it):
            frame 1 = bits 0-71, frame 2 = bits 72-107 + 156-191, frame 3 = bits 192-263
    data:   info 98 bits | slot type 10 | SYNC 48 | slot type 10 | info 98 bits
            (voice LC header, terminator with LC: BPTC(196,96) coded full LC + RS(12,9))

Everything here is written from the ETSI specification; it is checked against itself
(encode -> decode, syndromes, Reed-Solomon roots) and against bursts received from the
networks (decoders report whether a received burst passes every check).
"""

# ----------------------------------------------------------------- sync patterns (48 bits)
BS_VOICE_SYNC = 0x755FD7DF75F7
BS_DATA_SYNC = 0xDFF57D75DF5D
MS_VOICE_SYNC = 0x7F7D5DD57DFD
MS_DATA_SYNC = 0xD5D7F77FD757

DT_VOICE_LC_HEADER = 1
DT_TERMINATOR_WITH_LC = 2

FLCO_GROUP = 0x00
FLCO_PRIVATE = 0x03

RS_MASK_HEADER = 0x96
RS_MASK_TERMINATOR = 0x99

# silence (AMBE+2 rate 33, 72 bits): what MMDVM-style hotspots send for a lost frame
SILENCE_AMBE = bytes.fromhex("b9e881526173002a6b")


# ----------------------------------------------------------------- bit helpers
def bytes_to_bits(data):
    return [(byte >> (7 - i)) & 1 for byte in data for i in range(8)]


def bits_to_bytes(bits):
    out = bytearray((len(bits) + 7) // 8)
    for i, bit in enumerate(bits):
        if bit:
            out[i // 8] |= 0x80 >> (i % 8)
    return bytes(out)


def int_to_bits(value, count):
    return [(value >> (count - 1 - i)) & 1 for i in range(count)]


def bits_to_int(bits):
    value = 0
    for bit in bits:
        value = (value << 1) | (bit & 1)
    return value


# ----------------------------------------------------------------- Reed-Solomon (12,9) over GF(2^8)
_GF_EXP = [0] * 512
_GF_LOG = [0] * 256
_x = 1
for _i in range(255):
    _GF_EXP[_i] = _x
    _GF_LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D           # x^8 + x^4 + x^3 + x^2 + 1
for _i in range(255, 512):
    _GF_EXP[_i] = _GF_EXP[_i - 255]


def gf_mul(a, b):
    if a == 0 or b == 0:
        return 0
    return _GF_EXP[_GF_LOG[a] + _GF_LOG[b]]


# generator (x + a)(x + a^2)(x + a^3) = x^3 + 14 x^2 + 56 x + 64
_RS_GEN = (14, 56, 64)


def rs129_parity(data9):
    """Systematic RS(12,9): the 3 parity bytes for 9 data bytes (first byte = highest degree)."""
    p = [0, 0, 0]
    for byte in data9:
        feedback = byte ^ p[0]
        p[0] = p[1] ^ gf_mul(_RS_GEN[0], feedback)
        p[1] = p[2] ^ gf_mul(_RS_GEN[1], feedback)
        p[2] = gf_mul(_RS_GEN[2], feedback)
    return bytes(p)


def rs129_syndromes(codeword12):
    """All zero for a valid codeword (roots a, a^2, a^3)."""
    out = []
    for root_pow in (1, 2, 3):
        acc = 0
        root = _GF_EXP[root_pow]
        for byte in codeword12:
            acc = gf_mul(acc, root) ^ byte
        out.append(acc)
    return out


# ----------------------------------------------------------------- Golay (20,8) - slot type
_GOLAY_GEN = 0xC75      # x^11 + x^10 + x^6 + x^5 + x^4 + x^2 + 1


def _golay_rem(data8):
    value = data8 << 11
    for bit in range(18, 10, -1):
        if value & (1 << bit):
            value ^= _GOLAY_GEN << (bit - 11)
    return value & 0x7FF


def golay2087_encode(data8):
    """8 data bits -> 20-bit codeword: data | 11 Golay parity bits | overall parity."""
    rem = _golay_rem(data8 & 0xFF)
    word19 = ((data8 & 0xFF) << 11) | rem
    overall = bin(word19).count("1") & 1
    return (word19 << 1) | overall


_GOLAY_CODEWORDS = None


def golay2087_decode(word20):
    """-> (data8, errors) using the nearest codeword (256 candidates); errors > 3 = unreliable."""
    global _GOLAY_CODEWORDS
    if _GOLAY_CODEWORDS is None:
        _GOLAY_CODEWORDS = [golay2087_encode(d) for d in range(256)]
    best, best_dist = 0, 99
    for data, cw in enumerate(_GOLAY_CODEWORDS):
        dist = bin(cw ^ word20).count("1")
        if dist < best_dist:
            best, best_dist = data, dist
    return best, best_dist


# ----------------------------------------------------------------- Quadratic residue (16,7) - EMB
_QR_GEN = 0x139         # x^8 + x^5 + x^4 + x^3 + 1 (cyclic (15,7) code, plus overall parity)


def qr1676_encode(data7):
    value = (data7 & 0x7F) << 8
    rem = value
    for bit in range(14, 7, -1):
        if rem & (1 << bit):
            rem ^= _QR_GEN << (bit - 8)
    word15 = value | (rem & 0xFF)
    return (word15 << 1) | (bin(word15).count("1") & 1)


_QR_CODEWORDS = None


def qr1676_decode(word16):
    global _QR_CODEWORDS
    if _QR_CODEWORDS is None:
        _QR_CODEWORDS = [qr1676_encode(d) for d in range(128)]
    best, best_dist = 0, 99
    for data, cw in enumerate(_QR_CODEWORDS):
        dist = bin(cw ^ word16).count("1")
        if dist < best_dist:
            best, best_dist = data, dist
    return best, best_dist


# ----------------------------------------------------------------- Hamming codes (BPTC rows/columns)
def hamming15113(d):
    """11 data bits -> 4 parity bits (DMR Hamming(15,11,3))."""
    return [d[0] ^ d[1] ^ d[2] ^ d[3] ^ d[5] ^ d[7] ^ d[8],
            d[1] ^ d[2] ^ d[3] ^ d[4] ^ d[6] ^ d[8] ^ d[9],
            d[2] ^ d[3] ^ d[4] ^ d[5] ^ d[7] ^ d[9] ^ d[10],
            d[0] ^ d[1] ^ d[2] ^ d[4] ^ d[6] ^ d[7] ^ d[10]]


def hamming1393(d):
    """9 data bits -> 4 parity bits (DMR Hamming(13,9,3))."""
    return [d[0] ^ d[1] ^ d[3] ^ d[5] ^ d[6],
            d[0] ^ d[1] ^ d[2] ^ d[4] ^ d[6] ^ d[7],
            d[0] ^ d[1] ^ d[2] ^ d[3] ^ d[5] ^ d[7] ^ d[8],
            d[0] ^ d[2] ^ d[4] ^ d[5] ^ d[8]]


def hamming16114(d):
    """11 data bits -> 5 parity bits (DMR Hamming(16,11,4), embedded LC)."""
    return hamming15113(d) + [d[0] ^ d[2] ^ d[5] ^ d[6] ^ d[8] ^ d[9] ^ d[10]]


# ----------------------------------------------------------------- BPTC (196,96)
def _bptc_rows_positions():
    """Indices (0..195, index 0 unused) of the 96 data bits, in order."""
    pos = list(range(4, 12))                  # row 0: 3 reserved bits, then 8 data bits
    for row in range(1, 9):
        start = 1 + 15 * row
        pos.extend(range(start, start + 11))
    return pos


_BPTC_DATA_POS = _bptc_rows_positions()


def bptc19696_encode(data96):
    """96 bits (full LC + RS parity) -> 196 interleaved bits."""
    m = [0] * 196
    for bit, pos in zip(data96, _BPTC_DATA_POS):
        m[pos] = bit
    for row in range(9):                      # Hamming(15,11) on each data row
        start = 1 + 15 * row
        m[start + 11:start + 15] = hamming15113(m[start:start + 11])
    for col in range(15):                     # Hamming(13,9) down each column
        column = [m[1 + col + 15 * row] for row in range(9)]
        for i, bit in enumerate(hamming1393(column)):
            m[1 + col + 15 * (9 + i)] = bit
    out = [0] * 196
    for a in range(196):
        out[(a * 181) % 196] = m[a]
    return out


def bptc19696_decode(bits196):
    """196 interleaved bits -> (96 data bits, ok). ok = every row and column checks."""
    m = [bits196[(a * 181) % 196] for a in range(196)]
    ok = True
    for row in range(9):
        start = 1 + 15 * row
        if hamming15113(m[start:start + 11]) != m[start + 11:start + 15]:
            ok = False
    for col in range(15):
        column = [m[1 + col + 15 * row] for row in range(9)]
        if hamming1393(column) != [m[1 + col + 15 * (9 + i)] for i in range(4)]:
            ok = False
    return [m[pos] for pos in _BPTC_DATA_POS], ok


# ----------------------------------------------------------------- full link control
def build_lc(src_id, dst_id, group=True, service_options=0):
    """Full LC, 9 bytes: FLCO, FID, service options, destination, source."""
    flco = FLCO_GROUP if group else FLCO_PRIVATE
    return bytes([flco, 0x00, service_options & 0xFF]) + int(dst_id).to_bytes(3, "big") + int(src_id).to_bytes(3, "big")


def parse_lc(lc9):
    return {"group": (lc9[0] & 0x3F) == FLCO_GROUP, "flco": lc9[0] & 0x3F, "fid": lc9[1],
            "dst": int.from_bytes(lc9[3:6], "big"), "src": int.from_bytes(lc9[6:9], "big")}


def _with_rs(lc9, mask):
    parity = rs129_parity(lc9)
    return bytes(lc9) + bytes(p ^ mask for p in parity)


# ----------------------------------------------------------------- data bursts (header / terminator)
def build_data_burst(lc9, data_type, color_code=1, sync=BS_DATA_SYNC):
    mask = RS_MASK_HEADER if data_type == DT_VOICE_LC_HEADER else RS_MASK_TERMINATOR
    info = bptc19696_encode(bytes_to_bits(_with_rs(lc9, mask)))
    slot = int_to_bits(golay2087_encode(((color_code & 0xF) << 4) | (data_type & 0xF)), 20)
    bits = info[:98] + slot[:10] + int_to_bits(sync, 48) + slot[10:] + info[98:]
    return bits_to_bytes(bits)


def parse_data_burst(burst33):
    """-> dict(color_code, data_type, lc, lc_ok, slot_errors)."""
    bits = bytes_to_bits(burst33)
    slot_word = bits_to_int(bits[98:108] + bits[156:166])
    slot_data, slot_err = golay2087_decode(slot_word)
    data_type = slot_data & 0xF
    data, bptc_ok = bptc19696_decode(bits[:98] + bits[166:])
    raw = bits_to_bytes(data)
    lc9, parity = raw[:9], raw[9:12]
    mask = RS_MASK_HEADER if data_type == DT_VOICE_LC_HEADER else RS_MASK_TERMINATOR
    rs_ok = all(s == 0 for s in rs129_syndromes(lc9 + bytes(p ^ mask for p in parity)))
    out = {"color_code": slot_data >> 4, "data_type": data_type, "slot_errors": slot_err,
           "bptc_ok": bptc_ok, "rs_ok": rs_ok, "lc": lc9}
    out.update(parse_lc(lc9))
    return out


# ----------------------------------------------------------------- embedded LC (bursts B-E)
def embedded_lc_fragments(lc9):
    """Full LC + 5-bit checksum -> BPTC(128,77) -> four 32-bit fragments (bursts B, C, D, E)."""
    checksum = sum(lc9) % 31
    lc_bits = bytes_to_bits(lc9)
    cs_bits = int_to_bits(checksum, 5)
    m = [[0] * 16 for _ in range(8)]
    idx = 0
    for row in range(7):
        count = 11 if row < 2 else 10
        for col in range(count):
            m[row][col] = lc_bits[idx]
            idx += 1
        if row >= 2:
            m[row][10] = cs_bits[row - 2]
        m[row][11:16] = hamming16114(m[row][:11])
    for col in range(16):                      # row 7: even parity of each column
        m[7][col] = sum(m[row][col] for row in range(7)) & 1
    stream = [m[k % 8][k // 8] for k in range(128)]
    return [stream[i * 32:(i + 1) * 32] for i in range(4)]


def embedded_lc_decode(fragments):
    """Four 32-bit fragments -> (lc9, ok)."""
    stream = [b for frag in fragments for b in frag]
    m = [[0] * 16 for _ in range(8)]
    for k in range(128):
        m[k % 8][k // 8] = stream[k]
    ok = all(hamming16114(m[row][:11]) == m[row][11:16] for row in range(7))
    ok = ok and all(m[7][col] == (sum(m[row][col] for row in range(7)) & 1) for col in range(16))
    lc_bits, cs_bits = [], []
    for row in range(7):
        count = 11 if row < 2 else 10
        lc_bits.extend(m[row][:count])
        if row >= 2:
            cs_bits.append(m[row][10])
    lc9 = bits_to_bytes(lc_bits)
    ok = ok and bits_to_int(cs_bits) == sum(lc9) % 31
    return lc9, ok


# ----------------------------------------------------------------- voice bursts
LCSS_SINGLE, LCSS_FIRST, LCSS_LAST, LCSS_CONTINUE = 0, 1, 2, 3


def build_voice_burst(ambe3, voice_seq, lc9, color_code=1, sync=BS_VOICE_SYNC):
    """Three 9-byte AMBE frames -> 33-byte burst. voice_seq 0 = A (sync), 1..5 = B..F (EMB)."""
    f = [bytes_to_bits(a) for a in ambe3]
    left = f[0] + f[1][:36]
    right = f[1][36:] + f[2]
    if voice_seq == 0:
        middle = int_to_bits(sync, 48)
    else:
        if 1 <= voice_seq <= 4:
            fragment = embedded_lc_fragments(lc9)[voice_seq - 1]
            lcss = (LCSS_FIRST, LCSS_CONTINUE, LCSS_CONTINUE, LCSS_LAST)[voice_seq - 1]
        else:
            fragment = [0] * 32                   # burst F: no embedded signalling
            lcss = LCSS_SINGLE
        emb = int_to_bits(qr1676_encode(((color_code & 0xF) << 3) | lcss), 16)
        middle = emb[:8] + fragment + emb[8:]
    return bits_to_bytes(left + middle + right)


def voice_ambe(burst33):
    """The three 72-bit AMBE frames of a voice burst (9 bytes each)."""
    bits = bytes_to_bits(burst33)
    return [bits_to_bytes(bits[0:72]), bits_to_bytes(bits[72:108] + bits[156:192]), bits_to_bytes(bits[192:264])]


def parse_voice_emb(burst33):
    """-> (color_code, lcss, fragment32 bits, qr errors) of a burst B-F."""
    bits = bytes_to_bits(burst33)
    word = bits_to_int(bits[108:116] + bits[148:156])
    data, err = qr1676_decode(word)
    return data >> 3, data & 0x3, bits[116:148], err
