"""DMR directory: networks (masters), talkgroup names and DMR ID -> callsign.

  * masters: the public Pi-Star host list (DMR_Hosts.txt, "NAME ID HOST PASSWORD PORT"), cached
    24 h, plus a few built-in ones so DMR works even when the list cannot be downloaded;
  * DMR ID <-> callsign: RadioID.net public API, cached on disk for 30 days (one request per
    new station, never in bulk);
  * talkgroup names: built-in list of the common ones.
"""

import json
import logging
import re
import threading
import time

import requests

log = logging.getLogger("dxzaza.dmr")

DMR_HOSTS_URL = "http://www.pistar.uk/downloads/DMR_Hosts.txt"
RADIOID_URL = "https://radioid.net/api/dmr/user/"
CACHE_SECONDS = 24 * 3600
ID_CACHE_SECONDS = 30 * 24 * 3600
TIMEOUT = 8

BUILTIN_MASTERS = [
    {"name": "BM_2341_United_Kingdom", "host": "2341.master.brandmeister.network", "password": "", "port": 62031},
    {"name": "BM_2222_Italy", "host": "2222.master.brandmeister.network", "password": "", "port": 62031},
    {"name": "BM_2621_Germany", "host": "2621.master.brandmeister.network", "password": "", "port": 62031},
    {"name": "BM_3102_United_States", "host": "3102.master.brandmeister.network", "password": "", "port": 62031},
    {"name": "TGIF_Network", "host": "tgif.network", "password": "passw0rd", "port": 62031},
]

TALKGROUPS = {
    91: "Worldwide", 92: "Europe", 93: "North America", 9990: "Parrot (echo test)", 4000: "Disconnect",
    235: "United Kingdom", 2350: "UK Call", 23526: "UK Chat", 2351: "England", 2352: "Scotland",
    2355: "Wales", 222: "Italia", 2222: "Italia regionale", 22251: "Italia Chat", 262: "Deutschland",
    208: "France", 214: "España", 310: "USA Nationwide", 3100: "USA Bridge", 302: "Canada",
    505: "Australia", 530: "New Zealand", 440: "Japan", 98003: "DMR+ Bridge", 113: "English 1",
    123: "English 2", 2340: "UK Chat (2340)",
}


def family_of(name):
    n = name.upper()
    if n.startswith("BM_") or "BRANDMEISTER" in n:
        return "BrandMeister"
    if n.startswith("TGIF"):
        return "TGIF"
    if n.startswith("FREEDMR") or n.startswith("FDMR"):
        return "FreeDMR"
    if n.startswith("DMR+") or n.startswith("DMRPLUS"):
        return "DMR+"
    if n.startswith("SYSTEMX") or n.startswith("SYSX"):
        return "SystemX"
    return "Other"


def parse_dmr_hosts(text):
    out = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = re.split(r"\s+", line)
        if len(parts) < 5:
            continue
        name, _id, host, password, port = parts[:5]
        try:
            port = int(port)
        except ValueError:
            continue
        out.append({"name": name[:40], "host": host, "password": password, "port": port, "family": family_of(name)})
    return out


class DMRDirectory:
    def __init__(self, data_dir, fetch=None):
        self.path = data_dir / "dmr_masters.json"
        self.id_path = data_dir / "dmr_ids.json"
        self.fetch = fetch or self._fetch
        self.lock = threading.Lock()
        self.ids = self._load_ids()
        self.failed = {}

    # ------------------------------------------------------------ masters
    def _fetch(self, url, params=None):
        res = requests.get(url, params=params, timeout=TIMEOUT, headers={"User-Agent": "DXZaza"})
        res.raise_for_status()
        return res

    def masters(self, force=False):
        try:
            cached = json.loads(self.path.read_text())
            if not force and time.time() - cached.get("updated", 0) < CACHE_SECONDS and cached.get("masters"):
                return cached
        except (OSError, ValueError):
            cached = {}
        try:
            masters = parse_dmr_hosts(self.fetch(DMR_HOSTS_URL).text)
            if not masters:
                raise ValueError("empty host list")
            data = {"updated": time.time(), "masters": masters}
            try:
                self.path.write_text(json.dumps(data))
            except OSError:
                pass
            return data
        except Exception as exc:
            if cached.get("masters"):
                return dict(cached, error="list not updated: %s" % exc.__class__.__name__)
            return {"updated": 0, "masters": [dict(m, family=family_of(m["name"])) for m in BUILTIN_MASTERS],
                    "error": "using the built-in list (%s)" % exc.__class__.__name__}

    @staticmethod
    def talkgroup_name(tg):
        try:
            return TALKGROUPS.get(int(tg), "")
        except (TypeError, ValueError):
            return ""

    # ------------------------------------------------------------ DMR ID -> callsign
    def _load_ids(self):
        try:
            data = json.loads(self.id_path.read_text())
            now = time.time()
            return {int(k): v for k, v in data.items() if now - v[1] < ID_CACHE_SECONDS}
        except (OSError, ValueError, TypeError, IndexError):
            return {}

    def _save_ids(self):
        try:
            self.id_path.write_text(json.dumps({str(k): v for k, v in self.ids.items()}))
        except OSError:
            pass

    def callsign_for(self, dmr_id, wait=True):
        """'' when unknown. wait=False: only what is already known (no network)."""
        try:
            dmr_id = int(dmr_id)
        except (TypeError, ValueError):
            return ""
        with self.lock:
            hit = self.ids.get(dmr_id)
            if hit:
                return hit[0]
            if not wait or time.time() - self.failed.get(dmr_id, 0) < 3600:
                return ""
        call = ""
        for candidate in ([dmr_id] + ([dmr_id // 100] if dmr_id > 9999999 else [])):
            try:
                results = self.fetch(RADIOID_URL, params={"id": candidate}).json().get("results") or []
                if results:
                    call = str(results[0].get("callsign", "")).upper()
                    break
            except Exception as exc:
                log.info("RadioID lookup %s: %s", candidate, exc)
                break
        with self.lock:
            if call:
                self.ids[dmr_id] = [call, time.time()]
                self._save_ids()
            else:
                self.failed[dmr_id] = time.time()
        return call

    def ids_for(self, callsign):
        """DMR IDs registered for a callsign (RadioID.net)."""
        callsign = str(callsign or "").strip().upper()
        if not re.match(r"^[A-Z0-9/]{3,12}$", callsign):
            return []
        res = self.fetch(RADIOID_URL, params={"callsign": callsign}).json()
        out = []
        for r in res.get("results") or []:
            out.append({"id": int(r.get("id")), "callsign": str(r.get("callsign", "")).upper(),
                        "name": " ".join(x for x in (r.get("fname"), r.get("surname")) if x),
                        "country": r.get("country", "")})
        return out
