"""DMR network client: the "Homebrew" / MMDVM protocol spoken by BrandMeister, TGIF, FreeDMR
and other DMR masters (UDP, default port 62031). DX Zaza acts as a network-only hotspot.

Login                RPTL id  ->  RPTACK salt
                     RPTK id sha256(salt + password)  ->  RPTACK
                     RPTC id configuration (302 bytes)  ->  RPTACK
                     RPTO id options (TGIF / FreeDMR, optional)  ->  RPTACK
Keep-alive           RPTPING id  ->  MSTPONG id      (every 5 s)
Voice / data         DMRD seq src dst repeater bits stream payload(33)
Leaving              RPTCL id
Refusal              MSTNAK id        Master closing   MSTCL id

The engine sees the same events as with a D-STAR reflector:
  {"type": "header", "stream_id", "my", "ur", ...}, {"type": "voice", "ambe", "seq", "last"},
  {"type": "caller", "stream_id", "my"} when the callsign of a DMR ID becomes known.
"""

import hashlib
import logging
import random
import threading
import time

from voice import dmr
from voice.linkbase import LinkError, ReflectorClient

log = logging.getLogger("dxzaza.dmr")

DEFAULT_PORT = 62031
FT_VOICE, FT_VOICE_SYNC, FT_DATA_SYNC = 0, 1, 2


def parse_dmrd(data):
    if len(data) < 53 or data[:4] != b"DMRD":
        return None
    bits = data[15]
    return {
        "seq": data[4],
        "src": int.from_bytes(data[5:8], "big"),
        "dst": int.from_bytes(data[8:11], "big"),
        "repeater": int.from_bytes(data[11:15], "big"),
        "slot": 2 if bits & 0x80 else 1,
        "group": not (bits & 0x40),
        "frame_type": (bits >> 4) & 0x3,
        "dtype": bits & 0x0F,
        "stream": int.from_bytes(data[16:20], "big"),
        "payload": data[20:53],
    }


def build_dmrd(seq, src, dst, repeater, slot, group, frame_type, dtype, stream, payload):
    bits = (0x80 if slot == 2 else 0) | (0 if group else 0x40) | ((frame_type & 3) << 4) | (dtype & 0x0F)
    return (b"DMRD" + bytes([seq & 0xFF]) + int(src).to_bytes(3, "big") + int(dst).to_bytes(3, "big")
            + int(repeater).to_bytes(4, "big") + bytes([bits]) + int(stream).to_bytes(4, "big") + bytes(payload))


def config_packet(repeater_id, callsign, latitude=0.0, longitude=0.0, location="", description="DX Zaza",
                  url="", software="DXZaza", package="DXZaza"):
    """RPTC: the hotspot description shown by the master (302 bytes)."""
    body = "%-8.8s%09u%09u%02u%02u%8.8s%9.9s%03d%-20.20s%-19.19s%c%-124.124s%-40.40s%-40.40s" % (
        callsign.upper(), 0, 0, 1, 1,
        ("%+08.4f" % latitude)[:8], ("%+09.4f" % longitude)[:9], 0,
        location, description, "4", url, software, package)
    return b"RPTC" + int(repeater_id).to_bytes(4, "big") + body.encode("ascii", errors="replace")


class DMRClient(ReflectorClient):
    protocol = "dmr"
    default_port = DEFAULT_PORT
    keepalive_seconds = 5.0

    def __init__(self, callsign, dmr_id, password, talkgroup, repeater_id=None, slot=2, color_code=1,
                 options="", latitude=0.0, longitude=0.0, id_lookup=None, on_dsvt=None, on_state=None,
                 sock=None, software="DXZaza"):
        super().__init__(callsign, "B", on_dsvt=on_dsvt, on_state=on_state, sock=sock)
        self.dmr_id = int(dmr_id)
        self.repeater_id = int(repeater_id or dmr_id)
        self.password = password or ""
        self.talkgroup = int(talkgroup or 0)
        self.slot = 2 if int(slot or 2) == 2 else 1
        self.color_code = int(color_code or 1)
        self.options = options or ""
        self.latitude, self.longitude = latitude or 0.0, longitude or 0.0
        self.id_lookup = id_lookup or (lambda dmr_id: "")
        self.software = software
        self._salt = None
        self._step = ""
        self._step_ack = threading.Event()
        self._rx_stream = None
        self._rx_seq = 0
        self._tx = None
        self._pkt_seq = 0
        self._relogin = threading.Lock()
        # received bursts checked with our own decoders: proves our encoders follow the standard
        self.checks = {"header_ok": 0, "header_bad": 0, "terminator_ok": 0, "terminator_bad": 0,
                       "embedded_ok": 0, "embedded_bad": 0, "emb_ok": 0, "emb_bad": 0}
        self._frags = []

    # ------------------------------------------------------------ link control
    def connect(self, host, module="", reflector="", port=None, wait=8.0):
        import socket
        port = int(port or self.default_port)
        try:
            infos = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_DGRAM)
        except (socket.gaierror, OSError) as exc:
            raise LinkError("cannot resolve %s (%s)" % (host, exc))
        self.addr = infos[0][4]
        self.host = host
        if self.sock is None:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.bind(("0.0.0.0", 0))
        self.sock.settimeout(0.5)
        self.reflector = (reflector or host).upper()
        self.module = "TG%d" % self.talkgroup if self.talkgroup else ""
        self._stop.clear()
        self._nak = ""
        self._set_state("linking", self.reflector)
        self._thread = threading.Thread(target=self._run, name="dmr-rx", daemon=True)
        self._thread.start()
        try:
            self._login(time.monotonic() + wait)
        except LinkError:
            self.close()
            raise
        self._ack.set()
        self.linked_at = time.time()
        self._set_state("linked", "%s %s" % (self.reflector, self.module))

    def _rid(self):
        return self.repeater_id.to_bytes(4, "big")

    def _step_send(self, name, packet, deadline):
        self._step = name
        self._step_ack.clear()
        self._nak = ""
        while time.monotonic() < deadline and not self._step_ack.is_set() and not self._nak:
            self._send(packet)
            self._step_ack.wait(1.0)
        if self._nak:
            raise LinkError(self._nak)
        if not self._step_ack.is_set():
            raise LinkError("no answer from %s: check the address and that UDP %s is not blocked"
                            % (self.host, self.addr[1] if self.addr else DEFAULT_PORT))

    def _login(self, deadline):
        self._salt = None
        self._step_send("login", b"RPTL" + self._rid(), deadline)
        digest = hashlib.sha256(self._salt + self.password.encode("utf-8")).digest()
        try:
            self._step_send("auth", b"RPTK" + self._rid() + digest, deadline)
        except LinkError as exc:
            raise LinkError("the DMR network refused the password for ID %d (%s)" % (self.repeater_id, exc))
        self._step_send("config", config_packet(self.repeater_id, self.callsign, self.latitude, self.longitude,
                                                description="DX Zaza", software=self.software,
                                                package=self.software), deadline)
        if self.options:
            try:
                self._step_send("options", b"RPTO" + self._rid() + self.options.encode("ascii", "replace"),
                                min(deadline, time.monotonic() + 3))
            except LinkError:
                log.info("DMR master ignored the options")
        self._step = ""

    def _keepalive_packet(self):
        return b"RPTPING" + self._rid()

    def _unlink_packets(self):
        return [b"RPTCL" + self._rid()]

    def _relogin_async(self, reason):
        if not self._relogin.acquire(blocking=False):
            return

        def run():
            try:
                self._set_state("lost", reason)
                for attempt in range(10):
                    if self._stop.is_set():
                        return
                    try:
                        self._login(time.monotonic() + 8)
                        self._set_state("linked", "%s %s" % (self.reflector, self.module))
                        return
                    except LinkError as exc:
                        log.info("DMR re-login %d failed: %s", attempt + 1, exc)
                        self._stop.wait(min(60, 5 * (attempt + 1)))
            finally:
                self._relogin.release()
        threading.Thread(target=run, name="dmr-relogin", daemon=True).start()

    # ------------------------------------------------------------ receive
    def _handle(self, data):
        if data.startswith(b"RPTACK"):
            if self._step == "login":
                self._salt = data[6:10]
            self._step_ack.set()
            return
        if data.startswith(b"MSTNAK"):
            if self._step:
                self._nak = "refused (MSTNAK)"
                self._step_ack.set()
            elif self.state == "linked":
                self._relogin_async("the DMR network asked to log in again")
            return
        if data.startswith(b"MSTPONG"):
            return
        if data.startswith(b"MSTCL"):
            self._relogin_async("the DMR network closed the connection")
            return
        if data.startswith(b"DMRD"):
            self._on_dmrd(parse_dmrd(data))

    def _on_dmrd(self, p):
        if p is None or p["slot"] != self.slot:
            return
        stream = p["stream"]
        if self._rx_stream != stream:
            if p["frame_type"] == FT_DATA_SYNC and p["dtype"] == dmr.DT_TERMINATOR_WITH_LC:
                return                                 # tail of a stream we never saw
            self._rx_stream = stream
            self._rx_seq = 0
            self._start_stream(p)
        self._check(p)
        if p["frame_type"] == FT_DATA_SYNC:
            if p["dtype"] == dmr.DT_TERMINATOR_WITH_LC:
                self._deliver({"type": "voice", "stream_id": stream, "seq": self._rx_seq, "ambe": b"",
                               "slow": b"", "last": True})
                self._rx_stream = None
            return
        for frame in dmr.voice_ambe(p["payload"]):
            self._deliver({"type": "voice", "stream_id": stream, "seq": self._rx_seq % 21, "ambe": frame,
                           "slow": b"", "last": False})
            self._rx_seq += 1

    def _check(self, p):
        try:
            if p["frame_type"] == FT_DATA_SYNC and p["dtype"] in (dmr.DT_VOICE_LC_HEADER, dmr.DT_TERMINATOR_WITH_LC):
                info = dmr.parse_data_burst(p["payload"])
                good = info["bptc_ok"] and info["rs_ok"] and info["slot_errors"] == 0 and info["src"] == p["src"]
                kind = "header" if p["dtype"] == dmr.DT_VOICE_LC_HEADER else "terminator"
                self.checks[kind + ("_ok" if good else "_bad")] += 1
                if not good:
                    log.info("DMR %s check failed: %s", kind, {k: info[k] for k in ("bptc_ok", "rs_ok", "slot_errors", "src")})
            elif p["frame_type"] == FT_VOICE and 1 <= p["dtype"] <= 5:
                cc, lcss, frag, err = dmr.parse_voice_emb(p["payload"])
                self.checks["emb_ok" if err == 0 else "emb_bad"] += 1
                if lcss == dmr.LCSS_FIRST:
                    self._frags = [frag]
                elif lcss in (dmr.LCSS_CONTINUE, dmr.LCSS_LAST) and self._frags:
                    self._frags.append(frag)
                    if lcss == dmr.LCSS_LAST:
                        if len(self._frags) == 4:
                            lc9, good = dmr.embedded_lc_decode(self._frags)
                            good = good and int.from_bytes(lc9[6:9], "big") == p["src"]
                            self.checks["embedded_ok" if good else "embedded_bad"] += 1
                        self._frags = []
        except Exception as exc:  # pragma: no cover - diagnostics must never stop the audio
            log.debug("DMR check error: %s", exc)

    def _start_stream(self, p):
        src, dst = p["src"], p["dst"]
        known = self.id_lookup(src, wait=False) if _accepts_wait(self.id_lookup) else ""
        target = ("TG %d" % dst) if p["group"] else ("Private %d" % dst)
        self._deliver({"type": "header", "stream_id": p["stream"], "my": known or str(src), "suffix": "",
                       "ur": target, "rpt1": "", "rpt2": "", "dmr": {"src": src, "dst": dst, "group": p["group"]}})
        if not known:
            def resolve(stream=p["stream"]):
                call = self.id_lookup(src)
                if call:
                    self._deliver({"type": "caller", "stream_id": stream, "my": call, "dmr_id": src})
            threading.Thread(target=resolve, name="dmr-id", daemon=True).start()

    # ------------------------------------------------------------ transmit
    def _next_seq(self):
        self._pkt_seq = (self._pkt_seq + 1) & 0xFF
        return self._pkt_seq

    def _send_dmrd(self, tx, frame_type, dtype, payload):
        self._send(build_dmrd(self._next_seq(), self.dmr_id, tx["dst"], self.repeater_id, self.slot, tx["group"],
                              frame_type, dtype, tx["stream"], payload))

    def send_header(self, stream_id, header=None):
        """Start a transmission to the selected talkgroup (header is the D-STAR one: ignored)."""
        if self._tx is not None and self._tx["engine_stream"] == stream_id:
            return                                         # the engine sends the header twice
        tx = {"engine_stream": stream_id, "stream": random.randint(1, 0xFFFFFFFF), "dst": self.talkgroup,
              "group": True, "frames": [], "vseq": 0}
        tx["lc"] = dmr.build_lc(self.dmr_id, tx["dst"], group=True)
        self._tx = tx
        burst = dmr.build_data_burst(tx["lc"], dmr.DT_VOICE_LC_HEADER, self.color_code)
        for _ in range(3):
            self._send_dmrd(tx, FT_DATA_SYNC, dmr.DT_VOICE_LC_HEADER, burst)

    def send_voice(self, stream_id, seq, ambe, slow, last=False):
        tx = self._tx
        if tx is None:
            return
        if ambe:
            tx["frames"].append(bytes(ambe))
        if len(tx["frames"]) >= 3 or (last and tx["frames"]):
            while len(tx["frames"]) < 3:
                tx["frames"].append(dmr.SILENCE_AMBE)
            frames, tx["frames"] = tx["frames"][:3], tx["frames"][3:]
            vseq = tx["vseq"]
            burst = dmr.build_voice_burst(frames, vseq, tx["lc"], self.color_code)
            self._send_dmrd(tx, FT_VOICE_SYNC if vseq == 0 else FT_VOICE, vseq, burst)
            tx["vseq"] = (vseq + 1) % 6
        if last:
            burst = dmr.build_data_burst(tx["lc"], dmr.DT_TERMINATOR_WITH_LC, self.color_code)
            for _ in range(2):
                self._send_dmrd(tx, FT_DATA_SYNC, dmr.DT_TERMINATOR_WITH_LC, burst)
            self._tx = None

    def kerchunk(self):
        """A one-second empty transmission: subscribes the talkgroup on BrandMeister (dynamic group)."""
        self.send_header(-1)
        for i in range(6 * 3):
            self.send_voice(-1, i, dmr.SILENCE_AMBE, b"")
            time.sleep(0.02)
        self.send_voice(-1, 0, b"", b"", last=True)


def _accepts_wait(func):
    try:
        import inspect
        return "wait" in inspect.signature(func).parameters
    except (TypeError, ValueError):
        return False
