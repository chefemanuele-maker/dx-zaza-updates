"""DPlus client (UDP 20001) for REF reflectors (and XLX, which also speaks DPlus).

REF reflectors only accept callsigns registered on the D-STAR network (US Trust). Like the
DV Dongle software, the client first logs in to the D-STAR authentication server
(TCP auth.dstargateway.org:20001) so the network knows the operator's callsign and address;
the answer also contains the current list of REF reflectors.

Link step 1:  05 00 18 00 01            -> reflector echoes it
Link step 2:  1C C0 04 00 + callsign (16, zero padded) + "DV019999"  (28 bytes)
              -> 08 C0 04 00 "OKRW" (accepted) / "BUSY" or "FAIL" (refused)
Keep-alive:   03 60 00   (both ways, every second)
Unlink:       05 00 18 00 00
Voice:        3A 80 + DSVT header (58 bytes), 1D 80 + DSVT voice (29 bytes), 20 80 + end (32 bytes)
"""

import collections
import logging
import socket
import threading
import time

from voice import dstar
from voice.linkbase import LinkError, ReflectorClient

log = logging.getLogger("dxzaza.voice")

DEFAULT_PORT = 20001
AUTH_HOST = "auth.dstargateway.org"
AUTH_PORT = 20001
AUTH_EVERY_SECONDS = 6 * 3600

LINK1 = bytes((0x05, 0x00, 0x18, 0x00, 0x01))
UNLINK = bytes((0x05, 0x00, 0x18, 0x00, 0x00))
KEEPALIVE = bytes((0x03, 0x60, 0x00))


def login_packet(callsign):
    call = str(callsign).upper().strip().encode("ascii", "replace")[:16]
    return bytes((0x1C, 0xC0, 0x04, 0x00)) + call.ljust(16, b"\x00") + b"DV019999"


def wrap_header(dsvt):
    return bytes((0x3A, 0x80)) + dsvt


def wrap_voice(dsvt, last=False):
    if last:
        return bytes((0x20, 0x80)) + dsvt + bytes((0x55, 0x55, 0x55))
    return bytes((0x1D, 0x80)) + dsvt


def classify(packet):
    if len(packet) == 3 and packet == KEEPALIVE:
        return "keepalive"
    if len(packet) == 5 and packet[:4] == LINK1[:4]:
        return "link1" if packet[4] == 0x01 else "unlink"
    if len(packet) == 8 and packet[:4] == bytes((0x08, 0xC0, 0x04, 0x00)):
        return "ok" if packet[4:8] == b"OKRW" else "refused"
    if len(packet) >= 29 and packet[2:6] == dstar.DSVT_TAG:
        return "dsvt"
    return "unknown"


# ------------------------------------------------------------------ authentication
def auth_packet(callsign, client_id="?"):
    buf = bytearray(b" " * 56)
    buf[0:4] = bytes((0x38, 0xC0, 0x01, 0x00))
    call = str(callsign).upper().strip().encode("ascii", "replace")[:8]
    buf[4:4 + len(call)] = call
    buf[12:20] = b"DV019999"
    buf[28:32] = b"W7IB"
    buf[32] = ord(client_id[:1] or "?")
    buf[40:47] = b"DHS0257"
    return bytes(buf)


def parse_auth_reply(stream):
    """Parses the server answer: blocks of (2-byte length, 0xC0 type) with 26-byte records
    (address 16, name 8, unused 1, flags 1). Returns [{'name','host','active'}]."""
    out, pos = [], 0
    while pos + 2 <= len(stream):
        length = (stream[pos + 1] & 0x0F) * 256 + stream[pos]
        if length < 3 or pos + length > len(stream):
            break
        block = stream[pos:pos + length]
        pos += length
        if (block[1] & 0xC0) != 0xC0 or block[2] != 0x01:
            continue
        i = 8
        while i + 25 < length:
            host = block[i:i + 16].split(b"\x00")[0].decode("ascii", "replace").strip()
            name = block[i + 16:i + 24].split(b"\x00")[0].decode("ascii", "replace").strip().upper()
            active = bool(block[i + 25] & 0x80)
            if name.startswith("REF") and host:
                out.append({"name": name[:6], "host": host, "active": active})
            i += 26
    return out


_auth_state = {"call": "", "at": 0.0, "reflectors": [], "error": ""}
_auth_lock = threading.Lock()


def authenticate(callsign, host=AUTH_HOST, port=AUTH_PORT, timeout=8.0, force=False, connector=None):
    """Logs the callsign in to the D-STAR authentication server (cached 6 hours)."""
    with _auth_lock:
        call = str(callsign).upper().strip()
        if (not force and _auth_state["call"] == call and time.time() - _auth_state["at"] < AUTH_EVERY_SECONDS
                and not _auth_state["error"]):
            return dict(_auth_state)
        data = b""
        try:
            sock = (connector or socket.create_connection)((host, port), timeout)
            try:
                sock.settimeout(timeout)
                sock.sendall(auth_packet(call))
                while True:
                    chunk = sock.recv(4096)
                    if not chunk:
                        break
                    data += chunk
                    if len(data) > 1_000_000:
                        break
            finally:
                sock.close()
            reflectors = parse_auth_reply(data)
            _auth_state.update(call=call, at=time.time(), reflectors=reflectors, error="")
            log.info("D-STAR authentication OK for %s (%d REF reflectors)", call, len(reflectors))
        except (OSError, socket.timeout) as exc:
            if data:
                _auth_state.update(call=call, at=time.time(), reflectors=parse_auth_reply(data), error="")
            else:
                _auth_state.update(call=call, at=time.time(), error=str(exc))
                log.warning("D-STAR authentication failed: %s", exc)
        return dict(_auth_state)


class DPlusClient(ReflectorClient):
    protocol = "dplus"
    default_port = DEFAULT_PORT
    keepalive_seconds = 1.0
    authenticator = staticmethod(authenticate)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._link1 = threading.Event()
        self._streams = collections.OrderedDict()   # stream id -> True (our module) / False

    def _accept(self, info):
        """A DPlus link carries every module of the REF reflector: keep only the streams whose
        header is addressed to our module (RPT2 'REF030 C'), like ircDDBGateway does."""
        sid = info["stream_id"]
        if info["type"] == "header":
            rpt2 = info.get("rpt2", "").strip()
            module = rpt2[7:8].strip() if len(rpt2) >= 8 else ""
            ours = not module or module == self.module
            self._streams[sid] = ours
            self._streams.move_to_end(sid)
            while len(self._streams) > 32:
                self._streams.popitem(last=False)
            return ours
        return self._streams.get(sid, False)

    def _login(self, deadline):
        try:
            self.authenticator(self.callsign)
        except Exception as exc:  # the link may still work if the network already knows us
            log.warning("D-STAR authentication: %s", exc)
        self._link1.clear()
        if not self._send_until_ack(LINK1, deadline, event=self._link1):
            return
        self._send_until_ack(login_packet(self.callsign), deadline)
        if self._nak:
            raise LinkError("the REF reflector refused %s (%s): the callsign must be registered on the "
                            "D-STAR network" % (self.callsign, self._nak))

    def _keepalive_packet(self):
        return KEEPALIVE

    def _unlink_packets(self):
        return [UNLINK]

    def _handle(self, data):
        kind = classify(data)
        if kind == "link1":
            self._link1.set()
        elif kind == "ok":
            self._ack.set()
        elif kind == "refused":
            self._nak = data[4:8].decode("ascii", "replace").strip() or "refused"
            self._ack.set()
        elif kind == "unlink":
            if self.state == "linked":
                self._remote_unlinked()
        elif kind == "dsvt":
            info = dstar.parse_dsvt(data[2:])
            if info and self._accept(info):
                self._deliver(info)

    def send_header(self, stream_id, header):
        self._send(wrap_header(dstar.build_dsvt_header(stream_id, header)))

    def send_voice(self, stream_id, seq, ambe, slow, last=False):
        self._send(wrap_voice(dstar.build_dsvt_voice(stream_id, seq, ambe, slow, last), last))
