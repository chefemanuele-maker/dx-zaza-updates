"""D-STAR framing used on the network (DSVT packets): radio header, voice
frames and slow data (short text message).

References: JARL D-STAR specification (header layout, CRC, slow data
scrambler) and the public DSVT network format used by reflectors.
"""

import struct

HEADER_LEN = 41
AMBE_LEN = 9
SLOW_LEN = 3
FRAMES_PER_SUPERFRAME = 21

SYNC_SLOW_DATA = bytes((0x55, 0x2D, 0x16))
SCRAMBLER = bytes((0x70, 0x4F, 0x93))
FILLER_SLOW_DATA = bytes((0x16, 0x29, 0xF5))      # 0x66 0x66 0x66 scrambled
SILENCE_AMBE = bytes((0x9E, 0x8D, 0x32, 0x88, 0x26, 0x1A, 0x3F, 0x61, 0xE8))
END_AMBE = bytes((0x55, 0xC8, 0x7A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00))
END_SLOW_DATA = bytes((0x25, 0x1A, 0xC6))

DSVT_TAG = b"DSVT"
DSVT_HEADER_TYPE = 0x10
DSVT_VOICE_TYPE = 0x20


def crc_x25(data):
    """CRC-CCITT as used by D-STAR (reflected 0x8408, init 0xFFFF, inverted)."""
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = (crc >> 1) ^ 0x8408 if crc & 1 else crc >> 1
    return crc ^ 0xFFFF


def field(text, length):
    if isinstance(text, (bytes, bytearray)):
        text = bytes(text).decode("ascii", "replace")
    value = str(text or "").upper().encode("ascii", "replace")[:length]
    return value.ljust(length, b" ")


def module_call(callsign, module):
    """'IU0ABC' + 'B' -> 'IU0ABC B' (8 chars, module in the last position)."""
    return (field(callsign, 7) + field(module or " ", 1)).decode("ascii")


def build_header(my, suffix="", ur="CQCQCQ", rpt1="", rpt2="", flags=(0, 0, 0)):
    body = bytes(flags) + field(rpt2, 8) + field(rpt1, 8) + field(ur, 8) + field(my, 8) + field(suffix, 4)
    return body + struct.pack("<H", crc_x25(body))


def _text(raw):
    return raw.decode("ascii", "replace").rstrip()


def parse_header(raw):
    raw = bytes(raw)
    if len(raw) < HEADER_LEN:
        raise ValueError("D-STAR header too short")
    body, crc = raw[:39], struct.unpack("<H", raw[39:41])[0]
    return {
        "flags": list(raw[0:3]),
        "rpt2": _text(raw[3:11]),
        "rpt1": _text(raw[11:19]),
        "ur": _text(raw[19:27]),
        "my": _text(raw[27:35]),
        "suffix": _text(raw[35:39]),
        "crc_ok": crc_x25(body) == crc,
    }


def scramble(three):
    return bytes(a ^ b for a, b in zip(three, SCRAMBLER))


class SlowDataEncoder:
    """Slow data for one superframe (21 frames): sync, 20-char text, filler."""

    def __init__(self, message=""):
        self.set_message(message)

    def set_message(self, message):
        text = str(message or "").encode("ascii", "replace")[:20].ljust(20, b" ")
        blocks = []
        for index in range(4):
            block = bytes([0x40 | index]) + text[index * 5:index * 5 + 5]
            blocks.append(block[:3])
            blocks.append(block[3:])
        self.frames = [SYNC_SLOW_DATA]
        self.frames += [scramble(b) for b in blocks] if message else [FILLER_SLOW_DATA] * 8
        self.frames += [FILLER_SLOW_DATA] * (FRAMES_PER_SUPERFRAME - len(self.frames))

    def for_sequence(self, seq):
        return self.frames[seq % FRAMES_PER_SUPERFRAME]


class SlowDataDecoder:
    """Collects the 20-character text message from incoming slow data."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.half = None
        self.blocks = {}
        self.message = ""

    def feed(self, seq, slow):
        seq %= FRAMES_PER_SUPERFRAME
        if seq == 0:
            self.half = None
            return self.message
        data = scramble(slow)
        if seq % 2 == 1:
            self.half = data
            return self.message
        if self.half is None:
            return self.message
        block, self.half = self.half + data, None
        if block[0] & 0xF0 == 0x40:
            self.blocks[block[0] & 0x03] = block[1:6]
            if len(self.blocks) == 4:
                raw = b"".join(self.blocks[i] for i in range(4))
                self.message = raw.decode("ascii", "replace").strip()
        return self.message


# ------------------------------------------------------------------ DSVT packets

def _dsvt_prefix(kind):
    return DSVT_TAG + bytes((kind, 0x00, 0x00, 0x00, 0x20, 0x00, 0x01, 0x02))


def build_dsvt_header(stream_id, header):
    return _dsvt_prefix(DSVT_HEADER_TYPE) + struct.pack("<H", stream_id) + b"\x80" + bytes(header)[:HEADER_LEN]


def build_dsvt_voice(stream_id, seq, ambe, slow, last=False):
    seq_byte = (seq % FRAMES_PER_SUPERFRAME) | (0x40 if last else 0)
    if last:
        ambe, slow = END_AMBE, END_SLOW_DATA
    return _dsvt_prefix(DSVT_VOICE_TYPE) + struct.pack("<H", stream_id) + bytes([seq_byte]) + bytes(ambe) + bytes(slow)


def parse_dsvt(packet):
    """Returns a dict for a DSVT header/voice packet, or None for anything else."""
    packet = bytes(packet)
    if len(packet) < 27 or packet[:4] != DSVT_TAG:
        return None
    kind = packet[4]
    stream_id = struct.unpack("<H", packet[12:14])[0]
    if kind == DSVT_HEADER_TYPE and len(packet) >= 56:
        info = parse_header(packet[15:56])
        info.update(type="header", stream_id=stream_id, raw_header=packet[15:56])
        return info
    if kind == DSVT_VOICE_TYPE:
        seq = packet[14]
        return {
            "type": "voice",
            "stream_id": stream_id,
            "seq": seq & 0x1F,
            "last": bool(seq & 0x40),
            "ambe": packet[15:24],
            "slow": packet[24:27],
        }
    return None
