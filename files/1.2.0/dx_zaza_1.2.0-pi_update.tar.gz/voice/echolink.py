"""EchoLink: directory (who is on line) and station-to-station / conference connections.

EchoLink(R) is a registered trademark of Synergenics, LLC. DX Zaza talks the public protocol
used by independent EchoLink-compatible software (Qtel, SvxLink, thebridge); written from its
public description, no third-party code copied. Every operator uses their own validated
EchoLink callsign and password: they are kept on this computer only.

Directory          TCP 5200 to servers.echolink.org
   log in          "l" CALL 0xAC 0xAC PASSWORD CR "ONLINE3.38(hh:mm)" CR LOCATION CR   -> "OK"
   log off         ... "OFF-V3.40" ...
   station list    "s"  ->  "@@@\\n" count\\n  (callsign\\n description\\n node\\n ip\\n)* "+++"
Connection         UDP 5199 (RTCP-like control) and UDP 5198 (RTP audio) to the station's IP
   connect / keep-alive   SDES packet with "CALL  Name" every 10 s, answered with the station's SDES
   leave           BYE
   audio           RTP (first byte 0xC0, payload type 3) with 4 GSM 06.10 frames = 80 ms
   text            "oNDATA" CR info / "oNDATA" CALL ">" message (chat)
"""

import logging
import random
import socket
import struct
import threading
import time

from voice import gsm610
from voice.linkbase import LinkError

log = logging.getLogger("dxzaza.echolink")

DIRECTORY_SERVERS = ("servers.echolink.org", "naeast.echolink.org", "nasouth.echolink.org",
                     "backup.echolink.org")
DIRECTORY_PORT = 5200
AUDIO_PORT = 5198
CONTROL_PORT = 5199
KEEPALIVE_SECONDS = 10.0
CONNECTION_TIMEOUT = 50.0
REGISTRATION_REFRESH = 5 * 60
LIST_CACHE_SECONDS = 4 * 60
FRAMES_PER_PACKET = 4
RTP_VERSION = 3                                  # EchoLink's own value in the RTCP packets
NEW_OVER_GAP = 1.0                               # seconds of silence that start a new "over"


class EchoLinkError(LinkError):
    pass


def _clean(text, limit):
    return "".join(ch for ch in str(text or "") if 32 <= ord(ch) < 127)[:limit]


# ================================================================= directory
def kind_of(callsign):
    call = callsign.upper()
    if call.startswith("*"):
        return "conference"
    if call.endswith("-L"):
        return "link"
    if call.endswith("-R"):
        return "repeater"
    return "user"


def parse_station_list(text):
    """-> (stations, server_message). Lines: '@@@', count, then 4 lines per entry, '+++'."""
    lines = text.split("\n")
    if not lines or lines[0].strip() != "@@@":
        raise EchoLinkError("unexpected answer from the EchoLink directory")
    try:
        count = int(lines[1].strip())
    except (IndexError, ValueError):
        raise EchoLinkError("unexpected answer from the EchoLink directory")
    stations, message = [], []
    pos = 2
    while count > 0 and pos + 3 < len(lines):
        call, data, node, ip = (lines[pos], lines[pos + 1], lines[pos + 2].strip(), lines[pos + 3].strip())
        pos += 4
        if call == ".":
            continue
        count -= 1
        if call == " " or not call.strip():
            message.append(data.rstrip())
            continue
        desc, status, since = data, "", ""
        if "[" in data and data.rstrip().endswith("]"):
            cut = data.rfind("[")
            desc, tag = data[:cut].rstrip(), data[cut + 1:].rstrip()[:-1]
            parts = tag.split()
            status = parts[0] if parts else ""
            since = parts[1] if len(parts) > 1 else ""
        try:
            node_id = int(node)
        except ValueError:
            node_id = 0
        stations.append({"callsign": call.strip().upper(), "description": desc.strip(), "status": status,
                         "since": since, "node": node_id, "ip": ip, "kind": kind_of(call.strip())})
    return stations, "\n".join(m for m in message if m.strip())


class Directory:
    def __init__(self, get_credentials, servers=DIRECTORY_SERVERS, connector=None, clock=time.time):
        self.get_credentials = get_credentials       # -> (callsign, password, location)
        self.servers = list(servers)
        self.connector = connector or self._connect
        self.clock = clock
        self.lock = threading.Lock()
        self.status = "offline"
        self.error = ""
        self.logged_at = 0.0
        self.list_cache = None
        self.list_at = 0.0
        self.message = ""

    @staticmethod
    def _connect(host, port, timeout):
        return socket.create_connection((host, port), timeout=timeout)

    def _exchange(self, payload, until=None, timeout=12.0):
        last = None
        for host in self.servers:
            try:
                sock = self.connector(host, DIRECTORY_PORT, timeout)
            except OSError as exc:
                last = exc
                continue
            try:
                sock.settimeout(timeout)
                sock.sendall(payload)
                chunks = []
                while True:
                    try:
                        data = sock.recv(65536)
                    except socket.timeout:
                        break
                    if not data:
                        break
                    chunks.append(data)
                    if until and until(b"".join(chunks[-2:])):
                        break
                return b"".join(chunks)
            except OSError as exc:
                last = exc
            finally:
                try:
                    sock.close()
                except OSError:
                    pass
        raise EchoLinkError("EchoLink directory not reachable (TCP 5200): %s" % (last or "no server"))

    def _login_packet(self, status):
        callsign, password, location = self.get_credentials()
        if not callsign or not password:
            raise EchoLinkError("Enter your EchoLink password first (Digital Voice > EchoLink settings).")
        stamp = time.strftime("%H:%M", time.localtime(self.clock()))
        state = {"online": "ONLINE3.38(%s)" % stamp, "busy": "BUSY3.40(%s)" % stamp, "offline": "OFF-V3.40"}[status]
        text = "l%s\xac\xac%s\r%s\r%s\r" % (callsign.upper(), password, state, _clean(location, 27) or "DX Zaza")
        return text.encode("latin-1", "replace")

    def set_status(self, status="online"):
        with self.lock:
            answer = self._exchange(self._login_packet(status), until=lambda b: b.startswith(b"OK") or len(b) > 2,
                                    timeout=10.0)
            if answer.startswith(b"OK"):
                self.status = status
                self.error = ""
                self.logged_at = self.clock()
                return True
            self.status = "unknown"
            self.error = ("EchoLink refused the login: check your callsign, the EchoLink password and that "
                          "the callsign has been validated (%s)" % _clean(answer.decode("latin-1"), 40))
            raise EchoLinkError(self.error)

    def refresh_if_due(self):
        if self.status in ("online", "busy") and self.clock() - self.logged_at > REGISTRATION_REFRESH:
            try:
                self.set_status(self.status)
            except EchoLinkError as exc:
                log.info("EchoLink registration refresh failed: %s", exc)

    def stations(self, force=False):
        with self.lock:
            if not force and self.list_cache is not None and self.clock() - self.list_at < LIST_CACHE_SECONDS:
                return self.list_cache
            raw = self._exchange(b"s", until=lambda b: b.rstrip().endswith(b"+++"), timeout=20.0)
            stations, message = parse_station_list(raw.decode("latin-1", "replace"))
            if "INCORRECT PASSWORD" in message.upper():
                self.error = "EchoLink: incorrect password"
            self.list_cache, self.list_at, self.message = stations, self.clock(), message
            return stations

    def find(self, target):
        """Callsign (W1AW, *ECHOTEST*) or node number -> station dict or None."""
        target = str(target or "").strip().upper()
        if not target:
            return None
        stations = self.stations()
        for st in stations:
            if (target.isdigit() and st["node"] == int(target)) or st["callsign"] == target:
                return st
        return None


# ================================================================= RTCP / RTP packets
def _sdes_item(kind, text):
    data = text.encode("latin-1", "replace")[:255]
    return bytes([kind, len(data)]) + data


def build_sdes(callsign, name, priv=None):
    rr = bytes([RTP_VERSION << 6, 201, 0, 1, 0, 0, 0, 0])
    items = (_sdes_item(1, "CALLSIGN") + _sdes_item(2, "%-15s%s" % (callsign.upper(), name))
             + _sdes_item(3, "CALLSIGN") + _sdes_item(4, "08:30"))
    if priv:
        items += _sdes_item(8, priv)
    items += b"\x00\x00"
    body = bytes(4) + items                      # SSRC 0
    while (len(body) + 4) % 4:
        body += b"\x00"
    length = (len(body) + 4) // 4 - 1
    head = struct.pack(">HH", (RTP_VERSION << 14) | 202 | (1 << 8), length)
    return rr + head + body


def build_bye():
    rr = bytes([RTP_VERSION << 6, 201, 0, 1, 0, 0, 0, 0])
    text = b"\x07jan2002"
    body = bytes(4) + text
    while (len(body) + 4) % 4:
        body += b"\x00"
    length = (len(body) + 4) // 4 - 1
    return rr + struct.pack(">HH", (RTP_VERSION << 14) | 203 | (1 << 8), length) + body


def _rtcp_parts(data):
    """Yield (packet type, part bytes) of a compound RTCP packet."""
    pos = 0
    while pos + 4 <= len(data):
        version = data[pos] >> 6
        if version not in (RTP_VERSION, 1, 2):
            return
        length = (struct.unpack(">H", data[pos + 2:pos + 4])[0] + 1) * 4
        if length <= 0 or pos + length > len(data):
            yield data[pos + 1], data[pos:]
            return
        yield data[pos + 1], data[pos:pos + length]
        pos += length


def parse_rtcp(data):
    """-> {"bye": bool, "sdes": {item type: text}}"""
    out = {"bye": False, "sdes": {}}
    if len(data) < 4 or data[1] not in (200, 201):
        return out
    for ptype, part in _rtcp_parts(data):
        if ptype == 203:
            out["bye"] = True
        elif ptype == 202 and len(part) > 8:
            pos, end = 8, len(part)
            while pos + 2 <= end:
                kind, size = part[pos], part[pos + 1]
                if kind == 0 or pos + 2 + size > end:
                    break
                out["sdes"].setdefault(kind, part[pos + 2:pos + 2 + size].decode("latin-1", "replace"))
                pos += 2 + size
    return out


def build_audio(seq, frames33):
    return struct.pack(">BBHII", 0xC0, 3, seq & 0xFFFF, 0, 0) + b"".join(frames33)


def build_info(text):
    return b"oNDATA\r" + text.replace("\n", "\r").encode("latin-1", "replace") + b"\x00"


def build_chat(callsign, text):
    return b"oNDATA" + ("%s>%s\r\n" % (callsign.upper(), _clean(text, 200))).encode("latin-1", "replace") + b"\x00"


# ================================================================= connection to a station
class EchoLinkClient:
    """One EchoLink connection. Speaks PCM with the engine: {"type": "voice", "pcm": [160 samples]}."""

    protocol = "echolink"

    def __init__(self, callsign, name="", info="", on_dsvt=None, on_state=None, socket_factory=None,
                 ports=(AUDIO_PORT, CONTROL_PORT), remote_ports=(AUDIO_PORT, CONTROL_PORT)):
        self.callsign = callsign.upper().strip()
        self.name = _clean(name, 30) or "DX Zaza"
        self.info = info
        self.on_dsvt = on_dsvt or (lambda info: None)
        self.on_state = on_state or (lambda state, detail="": None)
        self.socket_factory = socket_factory or self._udp
        self.ports = ports
        self.remote_ports = remote_ports
        self.proxy = None                            # set when the connection goes through a public proxy
        self.state = "unlinked"
        self.detail = ""
        self.remote_ip = ""
        self.remote_call = ""
        self.remote_name = ""
        self.room_name = ""
        self.messages = []                           # last info / chat texts from the station
        self.audio_sock = None
        self.ctrl_sock = None
        self._stop = threading.Event()
        self._threads = []
        self._connected = threading.Event()
        self.last_rx = 0.0
        self._last_audio = 0.0
        self._stream = 0
        self._decoder = gsm610.Decoder()
        self._encoder = gsm610.Encoder()
        self._tx = None
        self._seq = random.randint(0, 0xFFFF)
        self.tx_lock = threading.Lock()
        self.checks = {"audio_packets": 0, "lost": 0, "late": 0, "gsm_bad": 0, "sdes": 0, "info": 0, "chat": 0,
                       "refused": 0}
        self._last_seq = None
        self.capture = None                          # diagnostics: {"rx": [(t, packet)], "tx": [...]}

    @staticmethod
    def _udp(port):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("0.0.0.0", port))
        sock.settimeout(0.5)
        return sock

    def _set_state(self, state, detail=""):
        if state != self.state:
            self.state, self.detail = state, detail
            try:
                self.on_state(state, detail)
            except Exception:  # pragma: no cover
                pass

    # ------------------------------------------------------------ link control
    def connect(self, ip, remote_call="", wait=8.0):
        try:
            self.audio_sock = self.socket_factory(self.ports[0])
            self.ctrl_sock = self.socket_factory(self.ports[1])
        except OSError as exc:
            self.close()
            raise EchoLinkError("UDP ports 5198/5199 are busy (is another EchoLink program open?): %s" % exc)
        self.remote_ip = ip
        self.remote_call = (remote_call or ip).upper()
        self.room_name = self.remote_call
        self._stop.clear()
        self._connected.clear()
        self._set_state("linking", self.remote_call)
        for target, name in ((self._ctrl_loop, "echolink-ctrl"), (self._audio_loop, "echolink-audio"),
                             (self._keepalive_loop, "echolink-keepalive")):
            thread = threading.Thread(target=target, name=name, daemon=True)
            thread.start()
            self._threads.append(thread)
        deadline = time.monotonic() + wait
        while time.monotonic() < deadline and not self._connected.is_set():
            self._send_ctrl(build_sdes(self.callsign, self.name))
            self._connected.wait(2.0)
        if not self._connected.is_set():
            self.close()
            raise EchoLinkError("%s did not answer (the station may be busy or off line)." % self.remote_call)
        self.last_rx = time.monotonic()
        self._set_state("linked", self.remote_call)
        if self.info:
            self._send_audio(build_info(self.info))

    def disconnect(self):
        if self.state in ("linked", "linking", "lost") and self.ctrl_sock is not None:
            for _ in range(2):
                self._send_ctrl(build_bye())
        self.close()

    def close(self):
        self._stop.set()
        for thread in self._threads:
            if thread is not threading.current_thread():
                thread.join(timeout=2)
        self._threads = []
        for sock in (self.audio_sock, self.ctrl_sock):
            if sock is not None:
                try:
                    sock.close()
                except OSError:
                    pass
        self.audio_sock = self.ctrl_sock = None
        proxy, self.proxy = getattr(self, "proxy", None), None
        if proxy is not None:
            proxy.close()
        self._set_state("unlinked", "")

    # ------------------------------------------------------------ sockets
    def _send_ctrl(self, data):
        sock = self.ctrl_sock
        if sock is not None:
            try:
                sock.sendto(data, (self.remote_ip, self.remote_ports[1]))
            except OSError:
                pass

    def _send_audio(self, data):
        sock = self.audio_sock
        if sock is not None:
            try:
                with self.tx_lock:
                    sock.sendto(data, (self.remote_ip, self.remote_ports[0]))
            except OSError:
                pass

    def _keepalive_loop(self):
        while not self._stop.wait(KEEPALIVE_SECONDS):
            if self.state in ("linked", "lost"):
                self._send_ctrl(build_sdes(self.callsign, self.name))
                if time.monotonic() - self.last_rx > CONNECTION_TIMEOUT:
                    self._set_state("lost", "no answer from %s" % self.remote_call)

    def _ctrl_loop(self):
        while not self._stop.is_set():
            sock = self.ctrl_sock
            if sock is None:
                break
            try:
                data, addr = sock.recvfrom(2048)
            except socket.timeout:
                continue
            except OSError:
                break
            info = parse_rtcp(data)
            if addr[0] != self.remote_ip:
                # someone else calling us: we take one station at a time
                if info["sdes"] and not info["bye"]:
                    self.checks["refused"] += 1
                    try:
                        sock.sendto(build_bye(), (addr[0], CONTROL_PORT))
                    except OSError:
                        pass
                continue
            self.last_rx = time.monotonic()
            if info["bye"]:
                if self.state == "linked":
                    self._set_state("lost", "%s closed the connection" % self.remote_call)
                continue
            if info["sdes"]:
                self.checks["sdes"] += 1
                ident = info["sdes"].get(2, "")
                parts = ident.split(None, 1)
                if parts:
                    self.remote_call = _clean(parts[0], 32).upper() or self.remote_call
                    self.remote_name = _clean(parts[1], 40) if len(parts) > 1 else ""
                if self.state == "lost":
                    self._set_state("linked", self.remote_call)
                self._connected.set()

    def _audio_loop(self):
        while not self._stop.is_set():
            sock = self.audio_sock
            if sock is None:
                break
            try:
                data, addr = sock.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                break
            if addr[0] != self.remote_ip or not data:
                continue
            self.last_rx = time.monotonic()
            cap = self.capture
            if cap is not None and data[0] == 0xC0:
                cap["rx"].append((self.last_rx, bytes(data)))
            if data[0] == 0xC0:
                self._on_audio(data)
            elif data[1:6] == b"NDATA":
                self._on_text(data)

    def _on_text(self, data):
        end = data.find(b"\x00")
        body = data[6:end if end > 0 else len(data)].decode("latin-1", "replace")
        if body.startswith("\r"):
            self.checks["info"] += 1
            text = body[1:].replace("\r", "\n").strip()
            kind = "info"
        else:
            self.checks["chat"] += 1
            text = body.replace("\r", "\n").strip()
            kind = "chat"
        if text:
            self.messages.append({"kind": kind, "text": text[:600], "time": time.time()})
            del self.messages[:-8]

    def _on_audio(self, data):
        if len(data) < 12 + 33 or self._tx is not None:
            return
        if data[1] != 3:                             # we never offer Speex: only GSM is expected
            return
        seq = struct.unpack(">H", data[2:4])[0]
        if self._last_seq is not None:
            delta = (seq - self._last_seq) & 0xFFFF
            if delta == 0 or delta > 0x8000:          # duplicate or late (arrived after a newer one)
                self.checks["late"] += 1
                return
            if delta > 1 and delta < 50:
                self.checks["lost"] += delta - 1
        self._last_seq = seq
        self.checks["audio_packets"] += 1
        now = time.monotonic()
        if now - self._last_audio > NEW_OVER_GAP:
            self._decoder = gsm610.Decoder()         # each over starts clean
            self._stream = (self._stream + 1) & 0xFFFF or 1
            self._deliver({"type": "header", "stream_id": self._stream, "my": self.remote_call, "suffix": "",
                           "ur": "", "rpt1": "", "rpt2": "", "mode": "echolink"})
        self._last_audio = now
        payload = data[12:]
        for i in range(min(FRAMES_PER_PACKET, len(payload) // 33)):
            try:
                pcm = self._decoder.decode(payload[33 * i:33 * i + 33])
            except ValueError:
                self.checks["gsm_bad"] += 1
                continue
            self._deliver({"type": "voice", "stream_id": self._stream, "seq": 0, "ambe": b"", "slow": b"",
                           "last": False, "pcm": pcm})

    def _deliver(self, info):
        try:
            self.on_dsvt(info)
        except Exception:  # pragma: no cover - callbacks must not kill the link
            pass

    # ------------------------------------------------------------ transmit
    def send_header(self, stream_id, header=None):
        if self._tx is not None and self._tx["engine_stream"] == stream_id:
            return
        self._tx = {"engine_stream": stream_id, "frames": []}

    def send_pcm(self, stream_id, pcm, last=False):
        tx = self._tx
        if tx is None:
            return
        if pcm is not None:
            tx["frames"].append(self._encoder.encode([int(v) for v in pcm]))
        while len(tx["frames"]) >= FRAMES_PER_PACKET or (last and tx["frames"]):
            while len(tx["frames"]) < FRAMES_PER_PACKET:
                tx["frames"].append(self._encoder.encode([0] * 160))
            frames, tx["frames"] = tx["frames"][:FRAMES_PER_PACKET], tx["frames"][FRAMES_PER_PACKET:]
            self._seq = (self._seq + 1) & 0xFFFF
            packet = build_audio(self._seq, frames)
            cap = self.capture
            if cap is not None:
                cap["tx"].append((time.monotonic(), packet))
            self._send_audio(packet)
        if last:
            self._tx = None

    def send_voice(self, stream_id, seq, ambe, slow, last=False):
        """Engine compatibility (AMBE paths): EchoLink only takes PCM."""
        if last:
            self.send_pcm(stream_id, None, last=True)

    def send_chat(self, text):
        self._send_audio(build_chat(self.callsign, text))
