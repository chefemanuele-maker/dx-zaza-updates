"""EchoLink public proxies: EchoLink without touching the router.

A home router lets answers in only for traffic the computer started, and EchoLink stations call
back on UDP 5198/5199. When that does not work, DX Zaza goes through one of the public EchoLink
proxies (volunteer servers listed on echolink.org, password "PUBLIC"): ONE outgoing TCP connection
to the proxy (port 8100) carries the directory login and all the audio, so nothing has to be
opened on the router.

Proxy protocol (public description, as used by EchoLink-compatible software):
  proxy -> 8-byte nonce;  client -> CALLSIGN "\\n" md5(PASSWORD + nonce)   (16 raw bytes)
  then message blocks:   type(1) ip(4, dotted order) length(4, little endian) payload
     1 TCP_OPEN (ip: directory server, port 5200)   2 TCP_DATA   3 TCP_CLOSE   4 TCP_STATUS (u32, 0 = ok)
     5 UDP_DATA (audio port)   6 UDP_CONTROL (control port)   7 SYSTEM (1 = bad password, 2 = denied)
"""

import hashlib
import logging
import queue
import random
import re
import socket
import struct
import threading
import time

import requests

log = logging.getLogger("dxzaza.echolink")

PROXY_LIST_URL = "https://www.echolink.org/proxylist.jsp"
PUBLIC_PASSWORD = "PUBLIC"
TCP_OPEN, TCP_DATA, TCP_CLOSE, TCP_STATUS, UDP_DATA, UDP_CONTROL, SYSTEM = 1, 2, 3, 4, 5, 6, 7
SYSTEM_TEXT = {1: "bad proxy password", 2: "access denied by the proxy"}
LIST_CACHE_SECONDS = 10 * 60

_ROW = re.compile(r"([A-Z0-9][A-Z0-9#/\-]*)\s+([A-Za-z0-9.\-]+\.[A-Za-z0-9.\-]+)\s+(\d{2,5})\s+(\d{1,2}:\d{2})\s+(Ready|Busy|Off)",
                  re.IGNORECASE)


def parse_proxy_list(html):
    text = re.sub(r"<[^>]+>", " ", html)
    text = text.replace("&nbsp;", " ")
    out = []
    for m in _ROW.finditer(text):
        name, host, port, _time, status = m.groups()
        out.append({"name": name, "host": host, "port": int(port), "status": status.capitalize()})
    return out


class ProxyError(OSError):
    pass


class ProxyLink:
    def __init__(self, callsign, password=PUBLIC_PASSWORD, sock_factory=None):
        self.callsign = callsign.upper().strip()
        self.password = (password or PUBLIC_PASSWORD).upper()
        self.sock_factory = sock_factory or (lambda host, port, timeout: socket.create_connection((host, port), timeout))
        self.sock = None
        self.name = ""
        self.host = ""
        self.error = ""
        self.closed = threading.Event()
        self.write_lock = threading.Lock()
        self.udp = {UDP_DATA: queue.Queue(maxsize=400), UDP_CONTROL: queue.Queue(maxsize=100)}
        self.tcp_status = queue.Queue()
        self.tcp_data = queue.Queue()
        self.tcp_open = False
        self._thread = None

    # ------------------------------------------------------------ connection
    def connect(self, host, port=8100, timeout=6.0, name=""):
        self.host, self.name = host, name or host
        try:
            sock = self.sock_factory(host, port, timeout)
            sock.settimeout(timeout)
            nonce = b""
            while len(nonce) < 8:
                chunk = sock.recv(8 - len(nonce))
                if not chunk:
                    raise ProxyError("the proxy closed the connection")
                nonce += chunk
            digest = hashlib.md5(self.password.encode("latin-1") + nonce).digest()
            sock.sendall(self.callsign.encode("latin-1") + b"\n" + digest)
        except (OSError, socket.timeout) as exc:
            raise ProxyError("proxy %s not available: %s" % (host, exc))
        self.sock = sock
        sock.settimeout(0.5)
        self._thread = threading.Thread(target=self._reader, name="echolink-proxy", daemon=True)
        self._thread.start()
        # a refused login comes back as a SYSTEM message right away
        self.closed.wait(1.2)
        if self.closed.is_set():
            raise ProxyError("proxy %s refused: %s" % (host, self.error or "closed"))
        return self

    def close(self):
        if self.closed.is_set() and self.sock is None:
            return
        self.closed.set()
        sock, self.sock = self.sock, None
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass

    def _send_block(self, kind, ip, payload=b""):
        sock = self.sock
        if sock is None or self.closed.is_set():
            raise ProxyError("proxy connection closed")
        octets = socket.inet_aton(ip) if ip else bytes(4)
        block = bytes([kind]) + octets + struct.pack("<I", len(payload)) + payload
        with self.write_lock:
            try:
                sock.sendall(block)
            except OSError as exc:
                self.error = str(exc)
                self.close()
                raise ProxyError("proxy connection lost")

    def _reader(self):
        buf = b""
        while not self.closed.is_set():
            sock = self.sock
            if sock is None:
                break
            try:
                data = sock.recv(65536)
            except socket.timeout:
                continue
            except OSError as exc:
                self.error = self.error or str(exc)
                break
            if not data:
                self.error = self.error or "the proxy closed the connection"
                break
            buf += data
            while len(buf) >= 9:
                kind = buf[0]
                ip = socket.inet_ntoa(buf[1:5])
                size = struct.unpack("<I", buf[5:9])[0]
                if len(buf) < 9 + size:
                    break
                payload, buf = buf[9:9 + size], buf[9 + size:]
                self._dispatch(kind, ip, payload)
        self.close()
        self.tcp_data.put(None)

    def _dispatch(self, kind, ip, payload):
        if kind in self.udp:
            try:
                self.udp[kind].put_nowait((ip, payload))
            except queue.Full:
                pass
        elif kind == TCP_STATUS and len(payload) == 4:
            self.tcp_status.put(struct.unpack("<I", payload)[0])
        elif kind == TCP_DATA:
            self.tcp_data.put(payload)
        elif kind == TCP_CLOSE:
            self.tcp_open = False
            self.tcp_data.put(None)
        elif kind == SYSTEM and payload:
            self.error = SYSTEM_TEXT.get(payload[0], "proxy error %d" % payload[0])
            log.info("EchoLink proxy %s: %s", self.host, self.error)
            self.close()

    # ------------------------------------------------------------ directory over the proxy (TCP 5200)
    def tcp_connector(self, host, port, timeout):
        return _ProxyTCP(self, host, timeout)

    # ------------------------------------------------------------ station traffic over the proxy (UDP)
    def socket_factory(self, port):
        return _ProxyUDP(self, UDP_DATA if port == 5198 else UDP_CONTROL)


class _ProxyTCP:
    def __init__(self, link, host, timeout):
        self.link = link
        self.timeout = timeout
        try:
            ip = socket.gethostbyname(host)
        except OSError as exc:
            raise ProxyError("cannot resolve %s: %s" % (host, exc))
        while not link.tcp_status.empty():
            link.tcp_status.get_nowait()
        while not link.tcp_data.empty():
            link.tcp_data.get_nowait()
        link._send_block(TCP_OPEN, ip)
        try:
            status = link.tcp_status.get(timeout=timeout)
        except queue.Empty:
            raise ProxyError("the proxy did not open the directory connection")
        if status != 0:
            raise ProxyError("the proxy could not reach the directory (%d)" % status)
        link.tcp_open = True

    def settimeout(self, timeout):
        self.timeout = timeout

    def sendall(self, data):
        self.link._send_block(TCP_DATA, "", bytes(data))

    def recv(self, n):
        try:
            data = self.link.tcp_data.get(timeout=self.timeout)
        except queue.Empty:
            raise socket.timeout("timed out")
        return data or b""

    def close(self):
        if self.link.tcp_open:
            self.link.tcp_open = False
            try:
                self.link._send_block(TCP_CLOSE, "")
            except ProxyError:
                pass


class _ProxyUDP:
    def __init__(self, link, kind):
        self.link, self.kind = link, kind
        self.port = 5198 if kind == UDP_DATA else 5199
        self.timeout = 0.5

    def settimeout(self, timeout):
        self.timeout = timeout

    def setsockopt(self, *args):
        pass

    def sendto(self, data, addr):
        self.link._send_block(self.kind, addr[0], bytes(data))

    def recvfrom(self, n):
        if self.link.closed.is_set():
            raise OSError("proxy closed")
        try:
            ip, payload = self.link.udp[self.kind].get(timeout=self.timeout)
        except queue.Empty:
            raise socket.timeout("timed out")
        return payload, (ip, self.port)

    def close(self):
        pass


class ProxyDirectory:
    """The public proxy list, cached; open_link() tries a few ready proxies."""

    def __init__(self, fetch=None, link_factory=ProxyLink, clock=time.time):
        self.fetch = fetch or self._fetch
        self.link_factory = link_factory
        self.clock = clock
        self.cache, self.cached_at = None, 0.0
        self.bad = {}

    @staticmethod
    def _fetch(url):
        res = requests.get(url, timeout=10, headers={"User-Agent": "DXZaza"})
        res.raise_for_status()
        return res.text

    def proxies(self):
        if self.cache is None or self.clock() - self.cached_at > LIST_CACHE_SECONDS:
            self.cache = parse_proxy_list(self.fetch(PROXY_LIST_URL))
            self.cached_at = self.clock()
        return self.cache

    def open_link(self, callsign, attempts=6):
        try:
            ready = [p for p in self.proxies() if p["status"] == "Ready"]
        except Exception as exc:
            raise ProxyError("EchoLink proxy list not available: %s" % exc.__class__.__name__)
        now = self.clock()
        ready = [p for p in ready if now - self.bad.get(p["host"], 0) > 1800]
        random.shuffle(ready)
        last = None
        for p in ready[:attempts]:
            link = self.link_factory(callsign)
            try:
                return link.connect(p["host"], p["port"], name=p["name"])
            except ProxyError as exc:
                self.bad[p["host"]] = now
                last = exc
                link.close()
        raise ProxyError("no public EchoLink proxy free right now (%s)" % (last or "none ready"))
