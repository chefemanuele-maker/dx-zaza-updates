"""DX Zaza voice engine: DVstick + D-STAR reflectors (DExtra / DPlus / DCS) or DMR networks + audio.

One VoiceEngine owns the DVstick while it is open ("one owner at a time").
All public methods are thread-safe and return quickly; the work happens in
background threads:

  network rx thread  -> rx queue -> decoder thread (DVstick decode) -> speaker
  microphone callback -> tx queue -> encoder thread (DVstick encode) -> network
"""

import collections
import logging
import math
import queue
import random
import sys
import threading
import time
from datetime import datetime, timezone

import numpy as np

from voice import ambe3000, dmr, dstar
from voice.dmr_network import DMRClient
from voice.ysf_network import WIDE_NOTE, YSFClient
from voice.echolink import EchoLinkClient
from voice.linkbase import LinkError
from voice.protocols import PORTS, make_client, protocol_for

log = logging.getLogger("dxzaza.voice")

# let the sound-card callbacks get the interpreter quickly while the codec threads work
sys.setswitchinterval(0.002)

RX_END_SILENCE_SECONDS = 0.6
TX_TIMEOUT_SECONDS = 180
LAST_HEARD_MAX = 40
SUFFIX_RE_CHARS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 /-")


class VoiceError(Exception):
    pass


def clean_suffix(value):
    text = "".join(ch for ch in str(value or "").upper() if ch in SUFFIX_RE_CHARS)
    return text[:4]


def clean_message(value):
    text = "".join(ch for ch in str(value or "") if 32 <= ord(ch) < 127)
    return text[:20]


def _now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class VoiceEngine:
    def __init__(self, get_settings, audio_factory, stick_opener=None, client_factory=None,
                 port_lister=None, busy_check=None, locate=None, dmr_lookup=None, dmr_client_factory=None,
                 ysf_client_factory=None, echolink_factory=None):
        self.get_settings = get_settings            # -> dict (callsign, suffix, message, ...)
        self.audio_factory = audio_factory          # -> AudioBackend
        self.stick_opener = stick_opener or ambe3000.open_stick
        self.client_factory = client_factory
        self.port_lister = port_lister or ambe3000.list_candidate_ports
        self.busy_check = busy_check or (lambda: None)
        self.locate = locate or (lambda call: {})
        self.dmr_lookup = dmr_lookup or (lambda dmr_id, wait=True: "")
        self.dmr_client_factory = dmr_client_factory or DMRClient
        self.ysf_client_factory = ysf_client_factory or YSFClient
        self.echolink_factory = echolink_factory or EchoLinkClient
        self.mode = "dstar"

        self.lock = threading.RLock()
        self.stick = None
        self.stick_port = ""
        self.audio = None
        self.client = None
        self.device_error = ""
        self.link_error = ""
        self.link_info = {}

        self.rx = None
        self.rx_queue = queue.Queue(maxsize=200)
        self.last_heard = collections.deque(maxlen=LAST_HEARD_MAX)
        self.tx = None
        self.tx_queue = queue.Queue(maxsize=100)
        self.test = {"state": "idle"}

        self._stop = threading.Event()
        self._capture_mic = None
        self._capture_net = None
        self.capture = {"state": "idle"}
        self._decoder = None
        self._watchdog = None

    # ================================================================= device
    def devices(self):
        return self.port_lister()

    def open_device(self, port=""):
        with self.lock:
            if self.stick is not None:
                return self.device_status()
            busy = self.busy_check()
            if busy:
                raise VoiceError(busy)
            candidates = [port] if port else [p["device"] for p in self.port_lister()]
            if not candidates:
                self.device_error = "DVstick not found: connect it to a USB port."
                raise VoiceError(self.device_error)
            last = None
            for candidate in candidates:
                try:
                    self.stick = self.stick_opener(candidate)
                    self.stick_port = candidate
                    break
                except Exception as exc:  # serial busy, not an AMBE device...
                    last = exc
                    log.warning("DVstick open failed on %s: %s", candidate, exc)
            if self.stick is None:
                self.device_error = _friendly_serial_error(last)
                raise VoiceError(self.device_error)
            self.device_error = ""
            self._apply_gain()
            self._stop.clear()
            self._decoder = threading.Thread(target=self._decoder_loop, name="voice-decoder", daemon=True)
            self._decoder.start()
            self._ensure_watchdog()
            log.info("DVstick open on %s: %s %s", self.stick_port, self.stick.product, self.stick.version)
            return self.device_status()

    SPEAKER_ERROR = "Audio output not available: "

    def _speaker_failed(self, exc):
        """The speaker could not open (e.g. on the Raspberry the browser's video still holds the HDMI
        sound for a few seconds): keep the link, say so, and let the watchdog try again."""
        self.link_error = self.SPEAKER_ERROR + str(exc)
        self._speaker_retry_at = time.monotonic() + 1.5
        log.warning(self.link_error + " - retrying")
        self._ensure_watchdog()

    def _retry_speaker(self):
        if not self.link_error.startswith(self.SPEAKER_ERROR) or self.client is None or self.tx is not None:
            return
        if time.monotonic() < getattr(self, "_speaker_retry_at", 0):
            return
        self._speaker_retry_at = time.monotonic() + 2.0
        try:
            self._ensure_audio().start_output()
        except Exception as exc:
            self.link_error = self.SPEAKER_ERROR + str(exc)
            return
        self.link_error = ""
        log.info("speaker available again")

    def _ensure_watchdog(self):
        if self._watchdog is None or not self._watchdog.is_alive():
            self._stop.clear()
            self._watchdog = threading.Thread(target=self._watchdog_loop, name="voice-watchdog", daemon=True)
            self._watchdog.start()

    def close_device(self):
        self.unlink()
        with self.lock:
            self._stop.set()
            stick, self.stick = self.stick, None
            if self.audio is not None:
                self.audio.close()
                self.audio = None
        if stick is not None:
            stick.close()
        for thread in (self._decoder, self._watchdog):
            if thread is not None and thread is not threading.current_thread():
                thread.join(timeout=2)
        self._decoder = self._watchdog = None

    def device_status(self):
        stick = self.stick
        return {
            "open": stick is not None,
            "port": self.stick_port if stick else "",
            "product": stick.product if stick else "",
            "version": stick.version if stick else "",
            "mode": stick.mode if stick else "",
            "error": self.device_error,
            "stats": dict(stick.stats) if stick else {},
        }

    def _apply_gain(self):
        settings = self.get_settings()
        try:
            if self.stick is not None:
                self.stick.set_gain(settings.get("ambe_input_gain_db", 0), settings.get("ambe_output_gain_db", 0))
        except Exception as exc:  # gain is optional
            log.info("gain not applied: %s", exc)

    def _ensure_audio(self):
        if self.audio is None:
            self.audio = self.audio_factory()
        return self.audio

    def set_volume(self, volume):
        """Change the speaker volume at once, without restarting the audio."""
        with self.lock:
            if self.audio is not None and hasattr(self.audio, "volume"):
                self.audio.volume = float(volume)

    def reset_audio(self):
        """Re-create the audio backend (new devices / volume)."""
        with self.lock:
            if self.audio is not None:
                self.audio.close()
                self.audio = None
            if self.client is not None:
                self._ensure_audio().start_output()

    # ================================================================= link
    def _set_stick_mode(self, mode):
        """The DVstick speaks one vocoder at a time: AMBE (D-STAR) or AMBE+2 (DMR / C4FM DN)."""
        audio = self.audio
        if audio is not None and hasattr(audio, "set_prebuffer"):
            # 80 ms to start; grows up to 240 ms only if gaps are heard (busy Raspberry, jittery net)
            audio.set_prebuffer(80, 240)
        stick = self.stick
        if stick is None or getattr(stick, "mode", mode) == mode:
            return
        if mode == "dmr" and hasattr(stick, "set_rate_dmr"):
            stick.set_rate_dmr()
        elif mode == "dstar" and hasattr(stick, "set_rate_dstar"):
            stick.set_rate_dstar()
        self._apply_gain()

    def link_dmr(self, host, talkgroup, name="", port=None, network=None):
        """Join a DMR network (BrandMeister, TGIF, FreeDMR...) and listen to a talkgroup."""
        settings = self.get_settings()
        callsign = settings.get("callsign", "")
        if not callsign:
            raise VoiceError("Save your callsign first (Settings > Operator).")
        network = network or {}
        dmr_id = int(settings.get("dmr_id") or 0)
        if not dmr_id:
            raise VoiceError("Enter your DMR ID first (Digital Voice > DMR settings).")
        try:
            talkgroup = int(talkgroup)
        except (TypeError, ValueError):
            raise VoiceError("Choose a talkgroup number.")
        if self.stick is None:
            self.open_device()
        self.unlink()
        self._set_stick_mode("dmr")
        essid = settings.get("dmr_essid")
        repeater_id = dmr_id * 100 + int(essid) if str(essid or "").isdigit() and len(str(dmr_id)) == 7 else dmr_id
        client = self.dmr_client_factory(
            callsign, dmr_id, network.get("password") or settings.get("dmr_password") or "passw0rd",
            talkgroup, repeater_id=repeater_id, slot=2, color_code=1,
            options=network.get("options", ""), latitude=network.get("lat", 0.0), longitude=network.get("lon", 0.0),
            id_lookup=self.dmr_lookup, on_dsvt=self._on_dsvt, on_state=self._on_link_state)
        self.link_error = ""
        self.mode = "dmr"
        self.link_info = {"name": (name or host).upper(), "host": host, "module": "TG%d" % talkgroup,
                          "port": int(port or 62031), "protocol": "dmr", "mode": "dmr", "talkgroup": talkgroup}
        try:
            client.connect(host, reflector=name, port=port)
        except LinkError as exc:
            self.link_error = str(exc)
            self.link_info = {}
            raise VoiceError(str(exc))
        with self.lock:
            self.client = client
            self.link_info["since"] = _now_iso()
            try:
                self._ensure_audio().start_output()
            except Exception as exc:
                self._speaker_failed(exc)
        log.info("DMR linked to %s TG %d (%s), ID %d", self.link_info["name"], talkgroup, host, repeater_id)
        return self.link_status()

    def link_ysf(self, host, port=None, name="", room_id=""):
        """Join a C4FM (YSF) room. DN voice goes through the DVstick in its AMBE+2 (DMR) mode."""
        settings = self.get_settings()
        callsign = settings.get("callsign", "")
        if not callsign:
            raise VoiceError("Save your callsign first (Settings > Operator).")
        if not host:
            raise VoiceError("Choose a C4FM room.")
        if self.stick is None:
            self.open_device()
        self.unlink()
        self._set_stick_mode("dmr")
        client = self.ysf_client_factory(callsign, on_dsvt=self._on_dsvt, on_state=self._on_link_state)
        self.link_error = ""
        self.mode = "ysf"
        port = int(port or 42000)
        self.link_info = {"name": (name or host).upper(), "host": host, "module": str(room_id or ""),
                          "port": port, "protocol": "ysf", "mode": "ysf", "room": str(room_id or "")}
        try:
            client.connect(host, reflector=name, port=port)
        except LinkError as exc:
            self.link_error = str(exc)
            self.link_info = {}
            raise VoiceError(str(exc))
        with self.lock:
            self.client = client
            self.link_info["since"] = _now_iso()
            try:
                self._ensure_audio().start_output()
            except Exception as exc:
                self._speaker_failed(exc)
        log.info("C4FM linked to %s (%s:%d)", self.link_info["name"], host, port)
        return self.link_status()

    def link_echolink(self, ip, remote_call, node=0, info="", proxy=None):
        """Connect to an EchoLink station, link, repeater or conference. Software GSM: no DVstick needed."""
        settings = self.get_settings()
        callsign = (settings.get("echolink_callsign") or settings.get("callsign") or "").upper()
        if not callsign:
            raise VoiceError("Save your callsign first (Settings > Operator).")
        self.unlink()
        self._ensure_watchdog()
        extra = {"socket_factory": proxy.socket_factory} if proxy is not None else {}
        client = self.echolink_factory(callsign, name=settings.get("echolink_name", ""), info=info,
                                       on_dsvt=self._on_dsvt, on_state=self._on_link_state, **extra)
        client.proxy = proxy
        if getattr(self, "_capture_net", None) is not None:
            client.capture = self._capture_net        # a recording keeps going across reconnections
        self.link_error = ""
        self.mode = "echolink"
        self.link_info = {"name": remote_call.upper(), "host": ip, "module": str(node or ""), "port": 5198,
                          "protocol": "echolink", "mode": "echolink", "node": int(node or 0)}
        try:
            client.connect(ip, remote_call)
        except LinkError as exc:
            self.link_error = str(exc)
            self.link_info = {}
            raise VoiceError(str(exc))
        with self.lock:
            self.client = client
            self.link_info["since"] = _now_iso()
            try:
                audio = self._ensure_audio()
                if hasattr(audio, "set_prebuffer"):
                    audio.set_prebuffer(300, 900)     # internet audio: more buffer, growing if the net is jittery
                audio.start_output()
            except Exception as exc:
                self._speaker_failed(exc)
        log.info("EchoLink connected to %s (node %s)", remote_call, node)
        return self.link_status()

    def start_capture(self, folder, seconds=40):
        """Diagnostics: record what arrives (packets with their arrival time), what goes out and what
        the speaker plays, for `seconds`; then write it to `folder`."""
        client = self.client
        if client is None or not hasattr(client, "capture") or client.state != "linked":
            raise VoiceError("Connect to an EchoLink station first.")
        if self.capture.get("state") == "recording":
            return dict(self.capture)
        seconds = max(1, min(120, int(seconds)))
        audio = self.audio
        self._capture_net = client.capture = {"rx": [], "tx": []}
        self._capture_mic = []
        if audio is not None and hasattr(audio, "capture_out"):
            audio.capture_out = []
        started = time.monotonic()
        self.capture = {"state": "recording", "seconds": seconds, "folder": str(folder)}

        def finish():
            time.sleep(seconds)
            cap, self._capture_net = self._capture_net, None
            current = self.client
            for c in (client, current):
                if c is not None and hasattr(c, "capture"):
                    c.capture = None
            mic, self._capture_mic = self._capture_mic, None
            out = None
            if audio is not None and hasattr(audio, "capture_out"):
                out, audio.capture_out = audio.capture_out, None
            try:
                _write_capture(folder, started, cap or {"rx": [], "tx": []}, mic or [], out or [],
                               getattr(audio, "out_rate", 0) if audio else 0,
                               {"link": self.link_status(), "audio": self.status().get("audio")})
                self.capture = {"state": "done", "folder": str(folder)}
            except Exception as exc:  # pragma: no cover
                self.capture = {"state": "error", "error": str(exc)}
        threading.Thread(target=finish, name="echolink-capture", daemon=True).start()
        return dict(self.capture)

    def send_text(self, text):
        client = self.client
        if client is None or not hasattr(client, "send_chat") or client.state != "linked":
            raise VoiceError("Connect to an EchoLink station first.")
        client.send_chat(text)
        return self.link_status()

    def listen_talkgroup(self):
        """BrandMeister subscribes a talkgroup when you key up on it: a short empty transmission."""
        settings = self.get_settings()
        if not settings.get("tx_enabled"):
            raise VoiceError("Transmit is locked: confirm you hold an amateur radio licence in Settings.")
        client = self.client
        if client is None or not hasattr(client, "kerchunk") or client.state != "linked":
            raise VoiceError("Join a DMR talkgroup first.")
        if self.rx is not None or self.tx is not None:
            raise VoiceError("The channel is busy.")
        threading.Thread(target=client.kerchunk, name="dmr-kerchunk", daemon=True).start()
        return self.link_status()

    def link(self, host, module, name="", port=None, protocol=""):
        settings = self.get_settings()
        callsign = settings.get("callsign", "")
        if not callsign:
            raise VoiceError("Save your callsign first (Settings > Operator).")
        if self.stick is None:
            self.open_device()
        self.unlink()
        self._set_stick_mode("dstar")
        self.mode = "dstar"
        protocol = protocol_for(name or host, protocol)
        port = int(port or PORTS[protocol])
        if self.client_factory is not None:
            client = self.client_factory(callsign, settings.get("local_module", "B"),
                                         on_dsvt=self._on_dsvt, on_state=self._on_link_state)
        else:
            client = make_client(protocol, callsign, settings.get("local_module", "B"),
                                 on_dsvt=self._on_dsvt, on_state=self._on_link_state)
        self.link_error = ""
        self.link_info = {"name": (name or host).upper(), "host": host, "module": module.upper(),
                          "port": port, "protocol": protocol, "mode": "dstar"}
        try:
            client.connect(host, module, reflector=name, port=port)
        except LinkError as exc:
            self.link_error = str(exc)
            self.link_info = {}
            raise VoiceError(str(exc))
        with self.lock:
            self.client = client
            self.link_info["since"] = _now_iso()
            try:
                self._ensure_audio().start_output()
            except Exception as exc:
                self._speaker_failed(exc)
        log.info("linked to %s %s (%s)", self.link_info["name"], module, host)
        return self.link_status()

    def unlink(self):
        self.ptt(False)
        with self.lock:
            client, self.client = self.client, None
        if client is not None:
            client.disconnect()
            log.info("unlinked")
        self._end_rx()
        # free the speaker when nothing is linked: on the Raspberry the HDMI sound output is exclusive,
        # and the browser (ISS Live with sound) can only play when DX Zaza is not holding it
        self.link_error = "" if self.link_error.startswith(self.SPEAKER_ERROR) else self.link_error
        audio = self.audio
        if audio is not None and hasattr(audio, "stop_output") and self.test.get("state") not in ("recording", "playing"):
            try:
                audio.stop_output()
            except Exception as exc:  # pragma: no cover
                log.warning("speaker close failed: %s", exc)

    def _on_link_state(self, state, detail):
        log.info("link state %s %s", state, detail)

    def link_status(self):
        client = self.client
        return {
            "state": client.state if client else "unlinked",
            "reflector": self.link_info.get("name", "") if client else "",
            "module": self.link_info.get("module", "") if client else "",
            "host": self.link_info.get("host", "") if client else "",
            "since": self.link_info.get("since", "") if client else "",
            "protocol": self.link_info.get("protocol", "") if client else "",
            "port": self.link_info.get("port", 0) if client else 0,
            "mode": self.link_info.get("mode", "dstar") if client else self.mode,
            "checks": dict(getattr(client, "checks", {}) or {}) if client else {},
            "talkgroup": self.link_info.get("talkgroup", 0) if client else 0,
            "room": self.link_info.get("room", "") if client else "",
            "roomName": getattr(client, "room_name", "") if client else "",
            "node": self.link_info.get("node", 0) if client else 0,
            "via": getattr(getattr(client, "proxy", None), "name", "") if client else "",
            "remoteName": getattr(client, "remote_name", "") if client else "",
            "messages": list(getattr(client, "messages", []) or [])[-5:] if client else [],
            "error": self.link_error,
        }

    # ================================================================= receive
    def _on_dsvt(self, info):
        with self.lock:
            if self.tx is not None:
                return                       # half duplex: we are talking
            rx = self.rx
            if info["type"] == "caller":                # DMR: callsign of the ID now known
                if rx is not None and rx["stream_id"] == info["stream_id"]:
                    self._set_caller(rx, info["my"])
                    if info.get("note"):
                        rx["note"] = info["note"]
                return
            if info["type"] == "header":
                if rx is None or rx["stream_id"] != info["stream_id"]:
                    if rx is not None:
                        self._end_rx_locked()
                    self.rx = self._new_rx(info["stream_id"], info)
                return
            if rx is None or rx["stream_id"] != info["stream_id"]:
                if rx is not None:
                    self._end_rx_locked()
                rx = self.rx = self._new_rx(info["stream_id"], None)
            rx["frames"] += 5 if info.get("silent") else 1      # a C4FM VW frame lasts 100 ms
            rx["last_frame"] = time.monotonic()
            if info.get("slow"):
                rx["message"] = rx["slow"].feed(info["seq"], info["slow"])
            last = info["last"]
        if not last and info.get("pcm") is not None:
            audio = self.audio
            if audio is not None and self.tx is None:
                audio.play_frame(np.asarray(info["pcm"], dtype=np.int16))
            return
        if not last:
            if not info.get("ambe"):
                return                       # C4FM wide voice: who is talking, but no audio for us
            try:
                self.rx_queue.put_nowait(info["ambe"])
            except queue.Full:
                pass
        else:
            with self.lock:
                self._end_rx_locked()

    def _set_caller(self, rx, my):
        call = my.split(" ")[0]
        rx["my"], rx["callsign"] = my, call
        try:
            rx["country"] = (self.locate(call) or {}).get("country", "") or rx["country"]
        except Exception:
            pass

    def _new_rx(self, stream_id, header):
        header = header or {}
        my = header.get("my", "")
        call = my.split(" ")[0] if my else ""
        where = {}
        if call and not call.isdigit():
            try:
                where = self.locate(call) or {}
            except Exception:
                where = {}
        if header and self.audio is not None and hasattr(self.audio, "flush_output"):
            self.audio.flush_output()               # a new over: drop leftovers (not on a mere gap)
        log.info("rx start %s/%s ur=%s rpt1=%s rpt2=%s", my, header.get("suffix", ""),
                 header.get("ur", ""), header.get("rpt1", ""), header.get("rpt2", ""))
        return {
            "stream_id": stream_id,
            "my": my or "?",
            "callsign": call or "?",
            "suffix": header.get("suffix", ""),
            "ur": header.get("ur", ""),
            "rpt1": header.get("rpt1", ""),
            "rpt2": header.get("rpt2", ""),
            "country": where.get("country", ""),
            "message": "",
            "started": time.monotonic(),
            "started_at": _now_iso(),
            "last_frame": time.monotonic(),
            "frames": 0,
            "slow": dstar.SlowDataDecoder(),
            "mode": header.get("mode") or ("dmr" if header.get("dmr") else "dstar"),
            "note": WIDE_NOTE if (header.get("ysf") or {}).get("wide") else "",
            "dmr_id": (header.get("dmr") or {}).get("src", 0),
        }

    def _end_rx(self):
        with self.lock:
            self._end_rx_locked()

    def _end_rx_locked(self):
        rx, self.rx = self.rx, None
        if rx is None:
            return
        seconds = round(rx["frames"] * 0.02, 1)
        if rx["frames"] >= 5 or rx["my"] != "?":
            self.last_heard.appendleft({
                "callsign": rx["callsign"],
                "my": rx["my"],
                "suffix": rx["suffix"],
                "message": rx["message"],
                "country": rx["country"],
                "time": rx["started_at"],
                "seconds": seconds,
                "reflector": rx["ur"] if rx.get("mode") == "dmr" else self.link_info.get("name", "")
                             if rx.get("mode") in ("ysf", "echolink") else
                             "%s %s" % (self.link_info.get("name", ""), self.link_info.get("module", "")),
                "direction": "rx",
                "mode": rx.get("mode", "dstar"),
                "dmrId": rx.get("dmr_id", 0),
            })
        log.info("rx end %s %.1fs", rx["my"], seconds)

    def _decoder_loop(self):
        while not self._stop.is_set():
            try:
                ambe = self.rx_queue.get(timeout=0.2)
            except queue.Empty:
                continue
            stick = self.stick
            if stick is None:
                continue
            try:
                future = stick.submit_decode(ambe)
            except Exception as exc:
                log.warning("decode failed: %s", exc)
                continue
            future.add_done_callback(self._play_decoded)

    def _play_decoded(self, future):
        try:
            pcm = future.result()
        except Exception as exc:
            log.warning("decode failed: %s", exc)
            return
        audio = self.audio
        if audio is not None and self.tx is None:
            audio.play_frame(pcm)

    def _watchdog_loop(self):
        while not self._stop.wait(0.2):
            audio = self.audio
            if audio is not None and hasattr(audio, "maintain") and self.tx is None:
                try:
                    audio.maintain()
                except Exception as exc:  # pragma: no cover
                    log.warning("audio check failed: %s", exc)
            try:
                self._retry_speaker()
            except Exception as exc:  # pragma: no cover
                log.warning("speaker retry failed: %s", exc)
            with self.lock:
                rx = self.rx
                end_after = 1.5 if self.mode == "echolink" else RX_END_SILENCE_SECONDS
                if rx is not None and time.monotonic() - rx["last_frame"] > end_after:
                    self._end_rx_locked()
                tx = self.tx
            if tx is not None and time.monotonic() - tx["started"] > TX_TIMEOUT_SECONDS:
                log.warning("TX time-out")
                self.ptt(False, reason="timeout")

    # ================================================================= transmit
    def ptt(self, on, reason=""):
        if not on:
            with self.lock:
                tx = self.tx
                if tx is None:
                    return self.tx_status()
                tx["stopping"] = True
                audio = self.audio
                tx["end_reason"] = reason
            if audio is not None:
                audio.stop_input()                   # outside the engine lock: the sound card may be slow
            tx["thread"].join(timeout=2)
            return self.tx_status()
        settings = self.get_settings()
        with self.lock:
            if self.tx is not None:
                return self.tx_status()
            if not settings.get("tx_enabled"):
                raise VoiceError("Transmit is locked: confirm you hold an amateur radio licence in Settings.")
            if self.client is None or self.client.state != "linked":
                raise VoiceError("Link to a reflector first.")
            if self.stick is None and self.mode != "echolink":
                raise VoiceError("DVstick not open.")
            if self.rx is not None:
                raise VoiceError("Channel busy: %s is talking." % self.rx["my"])
            callsign = settings["callsign"]
            stream_id = random.randint(1, 0xFFFF)
            header = None if self.mode in ("dmr", "ysf", "echolink") else dstar.build_header(
                my=callsign,
                suffix=clean_suffix(settings.get("suffix", "")),
                ur="CQCQCQ",
                rpt1=dstar.module_call(callsign, settings.get("local_module", "B")),
                rpt2=dstar.module_call(self.link_info.get("name", ""), self.link_info.get("module", "")),
            )
            while not self.tx_queue.empty():
                self.tx_queue.get_nowait()
            self.tx = {
                "stream_id": stream_id,
                "header": header,
                "started": time.monotonic(),
                "started_at": _now_iso(),
                "frames": 0,
                "stopping": False,
                "slow": dstar.SlowDataEncoder(clean_message(settings.get("message", ""))),
                "level": -90.0,
            }
            client = self.client
            for _ in range(2):
                client.send_header(stream_id, header)
            loop = self._pcm_sender_loop if self.mode == "echolink" else self._encoder_loop
            thread = threading.Thread(target=loop, args=(self.tx, client), name="voice-encoder", daemon=True)
            self.tx["thread"] = thread
            audio = self._ensure_audio()
            try:
                audio.start_input(self._on_mic_frame)
            except Exception as exc:
                self.tx = None
                raise VoiceError("Microphone not available: %s" % exc)
            thread.start()
            log.info("tx start %s via %s %s", callsign, self.link_info.get("name"), self.link_info.get("module"))
            return self.tx_status()

    def _on_mic_frame(self, frame):
        cap = self._capture_mic
        if cap is not None:
            cap.append(np.asarray(frame, dtype=np.int16).copy())
        try:
            self.tx_queue.put_nowait(frame)
        except queue.Full:
            pass

    def _encoder_loop(self, tx, client):
        state = {"seq": 0}
        send_lock = threading.Lock()
        last_future = None

        def send(future):
            try:
                ambe = future.result()
            except Exception as exc:
                log.warning("encode failed: %s", exc)
                ambe = dmr.SILENCE_AMBE if self.mode in ("dmr", "ysf") else dstar.SILENCE_AMBE
            with send_lock:
                seq = state["seq"]
                client.send_voice(tx["stream_id"], seq, ambe, tx["slow"].for_sequence(seq))
                state["seq"] = (seq + 1) % dstar.FRAMES_PER_SUPERFRAME
                tx["frames"] += 1

        while True:
            try:
                frame = self.tx_queue.get(timeout=0.1)
            except queue.Empty:
                if tx["stopping"]:
                    break
                continue
            tx["level"] = _level(frame)
            try:
                last_future = self.stick.submit_encode(frame)
            except Exception as exc:
                log.warning("encode failed: %s", exc)
                continue
            last_future.add_done_callback(send)
        if last_future is not None:
            try:
                last_future.result(timeout=1.0)
            except Exception:
                pass
            time.sleep(0.01)   # let the last callback finish
        with send_lock:
            client.send_voice(tx["stream_id"], state["seq"], b"", b"", last=True)
        self._finish_tx(tx)

    def _pcm_sender_loop(self, tx, client):
        """EchoLink: the microphone frames go out as GSM (encoded by the client), no DVstick."""
        while True:
            try:
                frame = self.tx_queue.get(timeout=0.1)
            except queue.Empty:
                if tx["stopping"]:
                    break
                continue
            tx["level"] = _level(frame)
            client.send_pcm(tx["stream_id"], frame)
            tx["frames"] += 1
        client.send_pcm(tx["stream_id"], None, last=True)
        self._finish_tx(tx)

    def _finish_tx(self, tx):
        seconds = round(tx["frames"] * 0.02, 1)
        settings = self.get_settings()
        with self.lock:
            self.last_heard.appendleft({
                "callsign": settings.get("callsign", ""),
                "my": settings.get("callsign", ""),
                "suffix": clean_suffix(settings.get("suffix", "")),
                "message": clean_message(settings.get("message", "")),
                "country": "",
                "time": tx["started_at"],
                "seconds": seconds,
                "reflector": ("TG %s" % self.link_info.get("talkgroup")) if self.mode == "dmr" else
                             self.link_info.get("name", "") if self.mode in ("ysf", "echolink") else
                             "%s %s" % (self.link_info.get("name", ""), self.link_info.get("module", "")),
                "direction": "tx",
                "mode": self.mode,
            })
            if self.tx is tx:
                self.tx = None
        log.info("tx end %.1fs", seconds)

    def tx_status(self):
        tx = self.tx
        return {
            "active": tx is not None,
            "seconds": round(time.monotonic() - tx["started"], 1) if tx else 0,
            "level": round(tx["level"], 1) if tx else -90.0,
        }

    # ================================================================= tests
    def self_test(self):
        """Encode a synthetic voiced sound with the DVstick and decode it back.

        Checks the whole vocoder path without microphone, speaker or network.
        """
        if self.stick is None:
            self.open_device()
        if self.tx is not None or self.rx is not None:
            raise VoiceError("Busy: wait for the end of the current transmission.")
        rate = ambe3000.SAMPLES_PER_FRAME * 50
        t = np.arange(rate) / 8000.0
        f0 = 200.0
        signal = sum((0.5 / k) * np.sin(2 * np.pi * f0 * k * t) for k in range(1, 15))
        signal = signal / np.max(np.abs(signal)) * 0.4 * 32767
        frames = signal.reshape(50, ambe3000.SAMPLES_PER_FRAME).astype(np.int16)
        started = time.monotonic()
        single = self.stick.encode(frames[0])
        latency_ms = (time.monotonic() - started) * 1000
        started = time.monotonic()
        encoded = [f.result(timeout=2) for f in [self.stick.submit_encode(fr) for fr in frames]]
        encode_ms = (time.monotonic() - started) * 1000 / len(frames)
        started = time.monotonic()
        futures = [self.stick.submit_decode(a) for a in encoded]
        decoded = np.concatenate([np.asarray(f.result(timeout=2), dtype=np.float32) for f in futures])
        decode_ms = (time.monotonic() - started) * 1000 / len(frames)
        del single
        tail = decoded[len(decoded) // 3:]
        level = 20 * math.log10(float(np.sqrt(np.mean((tail / 32768.0) ** 2))) + 1e-9)
        spectrum = np.abs(np.fft.rfft(tail * np.hanning(len(tail))))
        freqs = np.fft.rfftfreq(len(tail), 1 / 8000.0)
        band = (freqs > 80) & (freqs < 400)
        peak = float(freqs[band][np.argmax(spectrum[band])])
        ok = level > -35 and abs(peak - f0) < 25
        result = {
            "ok": bool(ok),
            "product": self.stick.product,
            "version": self.stick.version,
            "frames": len(frames),
            "ambe_bytes": len(encoded[0]) if encoded else 0,
            "output_level_dbfs": round(level, 1),
            "pitch_in_hz": f0,
            "pitch_out_hz": round(peak, 1),
            "latency_ms": round(latency_ms, 1),
            "encode_ms_per_frame": round(encode_ms, 2),
            "decode_ms_per_frame": round(decode_ms, 2),
            "realtime_ok": encode_ms + decode_ms < 20,
        }
        log.info("self test %s", result)
        return result

    def loop_test(self, seconds=4):
        """Record from the microphone, pass it through the DVstick, play it back."""
        if self.stick is None:
            self.open_device()
        if self.test.get("state") in ("recording", "playing"):
            return dict(self.test)
        if self.tx is not None or self.rx is not None:
            raise VoiceError("Busy: wait for the end of the current transmission.")
        seconds = max(2, min(10, int(seconds)))
        recorded = []
        self.test = {"state": "recording", "seconds": seconds, "level": -90.0}
        audio = self._ensure_audio()

        def on_frame(frame):
            recorded.append(frame)
            self.test["level"] = _level(frame)

        def run():
            try:
                audio.start_input(on_frame)
                time.sleep(seconds)
                audio.stop_input()
                self.test["state"] = "playing"
                audio.start_output()
                peak = -90.0
                encoded = [f.result(timeout=2) for f in [self.stick.submit_encode(fr) for fr in recorded]]
                for frame in recorded:
                    peak = max(peak, _level(frame))
                for future in [self.stick.submit_decode(a) for a in encoded]:
                    audio.play_frame(future.result(timeout=2))
                time.sleep(0.3)
                self.test = {"state": "done", "frames": len(recorded), "peak_input_dbfs": round(peak, 1),
                             "ok": peak > -45}
                if self.client is None:
                    audio.stop_output()
            except Exception as exc:
                log.error("loop test failed: %s", exc)
                self.test = {"state": "error", "error": str(exc)}

        threading.Thread(target=run, name="voice-looptest", daemon=True).start()
        return dict(self.test)

    # ================================================================= status
    def status(self):
        with self.lock:
            rx = self.rx
            rx_view = None
            if rx is not None:
                rx_view = {k: rx[k] for k in ("my", "callsign", "suffix", "ur", "rpt1", "rpt2", "country", "message",
                                              "started_at", "mode", "dmr_id", "note")}
                rx_view["seconds"] = round(time.monotonic() - rx["started"], 1)
            audio = self.audio
            return {
                "device": self.device_status(),
                "link": self.link_status(),
                "rx": rx_view,
                "tx": self.tx_status(),
                "test": dict(self.test),
                "lastHeard": list(self.last_heard),
                "capture": dict(self.capture),
                "levels": {
                    "input": round(getattr(audio, "in_level", -90.0), 1) if audio else -90.0,
                    "output": round(getattr(audio, "out_level", -90.0), 1) if audio else -90.0,
                },
                "audio": {
                    "speaker": getattr(audio, "out_device_name", "") if audio else "",
                    "microphone": getattr(audio, "in_device_name", "") if audio else "",
                    "error": getattr(audio, "last_error", "") if audio else "",
                    "underruns": getattr(audio, "underruns", 0) if audio else 0,
                    "bufferMs": getattr(audio, "buffer_ms", 0) if audio else 0,
                    "xruns": getattr(audio, "xruns", 0) if audio else 0,
                },
            }

    def shutdown(self):
        # say goodbye to the reflector first: otherwise it keeps our slot and refuses the
        # next link ("BUSY") until its own timeout
        try:
            self.unlink()
        except Exception:  # pragma: no cover
            pass
        try:
            self.close_device()
        except Exception:  # pragma: no cover
            pass


def _write_capture(folder, started, cap, mic, out, out_rate, info):
    import json
    import struct
    import wave
    from pathlib import Path
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    for name in ("rx", "tx"):
        with open(folder / ("%s_packets.bin" % name), "wb") as fh:
            for t, packet in cap.get(name, []):
                fh.write(struct.pack("<dH", t - started, len(packet)) + packet)

    def wav(path, rate, samples):
        with wave.open(str(path), "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(rate)
            w.writeframes(samples.astype("<i2").tobytes())
    if mic:
        wav(folder / "mic_8k.wav", 8000, np.concatenate(mic))
    if out and out_rate:
        wav(folder / "speaker.wav", out_rate, (np.clip(np.concatenate(out), -1, 1) * 32767).astype(np.int16))
    info = dict(info, rxPackets=len(cap.get("rx", [])), txPackets=len(cap.get("tx", [])), speakerRate=out_rate)
    (folder / "info.json").write_text(json.dumps(info, indent=1, default=str))


def _level(frame):
    samples = np.asarray(frame, dtype=np.float32) / 32768.0
    return 20 * math.log10(float(np.sqrt(np.mean(samples * samples))) + 1e-9)


def _friendly_serial_error(exc):
    text = str(exc or "")
    low = text.lower()
    if "busy" in low or "resource temporarily unavailable" in low or "exclusive" in low or "errno 16" in low:
        return "The DVstick is in use by another program. Close it and try again."
    if "permission" in low or "access is denied" in low:
        return "No permission to open the DVstick serial port."
    if "no answer" in low or "not an ambe" in low:
        return "A USB serial device was found but it does not answer like a DVstick (AMBE)."
    return "DVstick not available: %s" % (text or "unknown error")
