"""GSM 06.10 full-rate speech codec (13 kbit/s), the codec EchoLink uses.

A Python port of the reference fixed-point implementation "libgsm" by Jutta Degener and
Carsten Bormann (bit exact with it). Licence of the original, kept as it asks:

    Copyright 1992, 1993, 1994 by Jutta Degener and Carsten Bormann,
    Technische Universitaet Berlin

    Any use of this software is permitted provided that this notice is not
    removed and that neither the authors nor the Technische Universitaet Berlin
    are deemed to have made any representations as to the suitability of this
    software for any purpose nor are held responsible for any defects of
    this software.  THERE IS ABSOLUTELY NO WARRANTY FOR THIS SOFTWARE.

    Permission to use, copy, modify, and distribute this software for any purpose
    with or without fee is hereby granted, provided that this notice is not removed
    and that neither the authors nor the Technische Universitaet Berlin are deemed to
    have made any representations as to the suitability of this software for any
    purpose nor are held responsible for any defects of this software.
    THERE IS ABSOLUTELY NO WARRANTY FOR THIS SOFTWARE.   (Berkeley/Bremen, 05.04.2009)

One frame: 160 signed 16-bit samples at 8 kHz (20 ms) <-> 33 bytes.
"""

import numpy as _np

MIN_WORD = -32768
MAX_WORD = 32767
FRAME_BYTES = 33
FRAME_SAMPLES = 160

A = (20480, 20480, 20480, 20480, 13964, 15360, 8534, 9036)
B = (0, 0, 2048, -2560, 94, -1792, -341, -1144)
MIC = (-32, -32, -16, -16, -8, -8, -4, -4)
MAC = (31, 31, 15, 15, 7, 7, 3, 3)
INVA = (13107, 13107, 13107, 13107, 19223, 17476, 31454, 29708)
DLB = (6554, 16384, 26214, 32767)
QLB = (3277, 11469, 21299, 32767)
NRFAC = (29128, 26215, 23832, 21846, 20165, 18725, 17476, 16384)
FAC = (18431, 20479, 22527, 24575, 26623, 28671, 30719, 32767)
LAR_BITS = (6, 6, 5, 5, 4, 4, 3, 3)


# ----------------------------------------------------------------- fixed-point helpers
def w16(x):
    """Store into a C 'short' (16-bit wrap)."""
    return ((x + 0x8000) & 0xFFFF) - 0x8000


def sat(x):
    return MAX_WORD if x > MAX_WORD else (MIN_WORD if x < MIN_WORD else x)


def mult_r(a, b):
    return (a * b + 16384) >> 15


def gsm_mult(a, b):
    if a == MIN_WORD and b == MIN_WORD:
        return MAX_WORD
    return (a * b) >> 15


def gsm_abs(a):
    return (MAX_WORD if a == MIN_WORD else -a) if a < 0 else a


def gsm_norm(a):
    if a < 0:
        if a <= -1073741824:
            return 0
        a = ~a
    return 31 - a.bit_length()


def gsm_div(num, denum):
    if num == 0:
        return 0
    div = 0
    for _ in range(15):
        div <<= 1
        num <<= 1
        if num >= denum:
            num -= denum
            div += 1
    return div


def gsm_asr(a, n):
    if n >= 16:
        return -(a < 0)
    if n <= -16:
        return 0
    if n < 0:
        return w16(a << -n)
    return a >> n


def gsm_asl(a, n):
    if n >= 16:
        return 0
    if n <= -16:
        return -(a < 0)
    if n < 0:
        return gsm_asr(a, -n)
    return w16(a << n)


L_MAX = 2147483647
L_MIN = -2147483648


def l_add(a, b):
    s = a + b
    return L_MAX if s > L_MAX else (L_MIN if s < L_MIN else s)


# ----------------------------------------------------------------- short term (LPC) section
def _decode_lars(larc, larpp):
    for i in range(8):
        temp1 = w16(sat(larc[i] + MIC[i]) << 10)
        temp1 = sat(temp1 - B[i] * 2)
        temp1 = mult_r(INVA[i], temp1)
        larpp[i] = sat(temp1 + temp1)


def _lar_to_rp(larp):
    for i in range(8):
        v = larp[i]
        if v < 0:
            temp = MAX_WORD if v == MIN_WORD else -v
            larp[i] = -((temp << 1) if temp < 11059 else (temp + 11059 if temp < 20070 else sat((temp >> 2) + 26112)))
        else:
            temp = v
            larp[i] = (temp << 1) if temp < 11059 else (temp + 11059 if temp < 20070 else sat((temp >> 2) + 26112))


def _interpolated(larpp_j_1, larpp_j):
    """The four LAR sets of a frame: samples 0-12, 13-26, 27-39, 40-159."""
    s0 = [sat(sat((a >> 2) + (b >> 2)) + (a >> 1)) for a, b in zip(larpp_j_1, larpp_j)]
    s1 = [sat((a >> 1) + (b >> 1)) for a, b in zip(larpp_j_1, larpp_j)]
    s2 = [sat(sat((a >> 2) + (b >> 2)) + (b >> 1)) for a, b in zip(larpp_j_1, larpp_j)]
    s3 = list(larpp_j)
    out = []
    for s in (s0, s1, s2, s3):
        _lar_to_rp(s)
        out.append(s)
    return out


SEGMENTS = ((0, 13), (13, 27), (27, 40), (40, 160))


class _State:
    def __init__(self):
        self.dp0 = [0] * 280
        self.e = [0] * 50
        self.z1 = 0
        self.L_z2 = 0
        self.mp = 0
        self.u = [0] * 8
        self.LARpp = [[0] * 8, [0] * 8]
        self.j = 0
        self.nrp = 40
        self.v = [0] * 9
        self.msr = 0

    def lar_sets(self, larc):
        larpp_j = self.LARpp[self.j]
        self.j ^= 1
        larpp_j_1 = self.LARpp[self.j]
        _decode_lars(larc, larpp_j)
        return _interpolated(larpp_j_1, larpp_j)


# ----------------------------------------------------------------- encoder
class Encoder:
    def __init__(self):
        self.S = _State()

    def _preprocess(self, s):
        S = self.S
        z1, L_z2, mp = S.z1, S.L_z2, S.mp
        so = [0] * 160
        for k in range(160):
            SO = (s[k] >> 3) << 2
            s1 = SO - z1
            z1 = SO
            L_s2 = s1 << 15
            msp = w16(L_z2 >> 15)
            lsp = w16(L_z2 - (msp << 15))
            L_s2 += mult_r(lsp, 32735)
            L_temp = msp * 32735
            L_z2 = l_add(L_temp, L_s2)
            L_temp = l_add(L_z2, 16384)
            msp = mult_r(mp, -28180)
            mp = w16(L_temp >> 15)
            so[k] = sat(mp + msp)
        S.z1, S.L_z2, S.mp = z1, L_z2, mp
        return so

    @staticmethod
    def _autocorrelation(s):
        smax = 0
        for v in s:
            t = gsm_abs(v)
            if t > smax:
                smax = t
        scalauto = 0 if smax == 0 else 4 - gsm_norm(smax << 16)
        if scalauto > 0:
            f = 16384 >> (scalauto - 1)
            for k in range(160):
                s[k] = mult_r(s[k], f)
        arr = _np.asarray(s, dtype=_np.int64)
        acf = [int(_np.dot(arr[k:], arr[:160 - k])) << 1 for k in range(9)]
        if scalauto > 0:
            for k in range(160):
                s[k] = w16(s[k] << scalauto)
        return acf

    @staticmethod
    def _reflection(acf):
        r = [0] * 8
        if acf[0] == 0:
            return r
        temp = gsm_norm(acf[0])
        ACF = [w16((a << temp) >> 16) for a in acf]
        K = [0] * 9
        for i in range(1, 8):
            K[i] = ACF[i]
        P = list(ACF)
        for n in range(1, 9):
            temp = gsm_abs(P[1])
            if P[0] < temp:
                return r
            rn = gsm_div(temp, P[0])
            if P[1] > 0:
                rn = -rn
            r[n - 1] = rn
            if n == 8:
                return r
            temp = mult_r(P[1], rn)
            P[0] = sat(P[0] + temp)
            for m in range(1, 9 - n):
                temp = mult_r(K[m], rn)
                P[m] = sat(P[m + 1] + temp)
                temp = mult_r(P[m + 1], rn)
                K[m] = sat(K[m] + temp)
        return r

    @staticmethod
    def _lars(r):
        lar = []
        for v in r:
            temp = gsm_abs(v)
            if temp < 22118:
                temp >>= 1
            elif temp < 31130:
                temp -= 11059
            else:
                temp = (temp - 26112) << 2
            lar.append(-temp if v < 0 else temp)
        larc = []
        for i in range(8):
            temp = gsm_mult(A[i], lar[i])
            temp = sat(temp + B[i])
            temp = sat(temp + 256)
            temp >>= 9
            larc.append(MAC[i] - MIC[i] if temp > MAC[i] else (0 if temp < MIC[i] else temp - MIC[i]))
        return larc

    def _short_term_analysis(self, larc, s):
        u = self.S.u
        for rp, (lo, hi) in zip(self.S.lar_sets(larc), SEGMENTS):
            for k in range(lo, hi):
                di = sav = s[k]
                for i in range(8):
                    ui = u[i]
                    rpi = rp[i]
                    u[i] = sav
                    sav = sat(ui + mult_r(rpi, di))
                    di = sat(di + mult_r(rpi, ui))
                s[k] = di

    @staticmethod
    def _ltp_parameters(d, dp, dbase):
        dmax = 0
        for v in d:
            t = gsm_abs(v)
            if t > dmax:
                dmax = t
        temp = 0 if dmax == 0 else gsm_norm(dmax << 16)
        scal = 0 if temp > 6 else 6 - temp
        wt = [v >> scal for v in d]
        L_max, Nc = 0, 40
        # cross-correlation for the lags 40..120 at once (exact integer arithmetic)
        seg = _np.asarray(dp[dbase - 120:dbase + 40 - 40], dtype=_np.int64)      # dp[dbase-120 .. dbase-1]
        corr = _np.correlate(seg, _np.asarray(wt, dtype=_np.int64), mode="valid")  # index i -> lag 120 - i
        for i in range(len(corr) - 1, -1, -1):                                  # lags 40, 41, ... 120
            acc = int(corr[i])
            if acc > L_max:
                Nc, L_max = 120 - i, acc
        L_max <<= 1
        L_max >>= (6 - scal)
        L_power = 0
        base = dbase - Nc
        for k in range(40):
            t = dp[base + k] >> 3
            L_power += t * t
        L_power <<= 1
        if L_max <= 0:
            return Nc, 0
        if L_max >= L_power:
            return Nc, 3
        temp = gsm_norm(L_power)
        R = w16((L_max << temp) >> 16)
        S = w16((L_power << temp) >> 16)
        for bc in range(3):
            if R <= gsm_mult(S, DLB[bc]):
                return Nc, bc
        return Nc, 3

    @staticmethod
    def _rpe_encoding(e):
        """e: list of 50 (e[5:45] = residual). Returns xmaxc, Mc, xMc and writes ep into e[5:45]."""
        x = [0] * 40
        for k in range(40):
            L = 4096 + (e[k] * -134 + e[k + 1] * -374 + e[k + 3] * 2054 + e[k + 4] * 5741 + e[k + 5] * 8192
                        + e[k + 6] * 5741 + e[k + 7] * 2054 + e[k + 9] * -374 + e[k + 10] * -134)
            x[k] = sat(L >> 13)
        best, Mc = -1, 0
        for m in range(4):
            acc = 0
            for i in range(13):
                t = x[m + 3 * i] >> 2
                acc += t * t
            acc <<= 1
            if acc > best:
                best, Mc = acc, m
        xM = [x[Mc + 3 * i] for i in range(13)]
        xmax = 0
        for v in xM:
            t = gsm_abs(v)
            if t > xmax:
                xmax = t
        exp = 0
        temp = xmax >> 9
        itest = 0
        for _ in range(6):
            itest |= (temp <= 0)
            temp >>= 1
            if itest == 0:
                exp += 1
        temp = exp + 5
        xmaxc = sat((xmax >> temp) + (exp << 3))
        exp, mant = _xmaxc_to_exp_mant(xmaxc)
        temp1 = 6 - exp
        temp2 = NRFAC[mant]
        xMc = []
        for v in xM:
            t = w16(v * (1 << temp1))
            t = w16((t * temp2) >> 15)
            t >>= 12
            xMc.append(t + 4)
        xMp = _apcm_inverse(xMc, mant, exp)
        ep = _grid_positioning(Mc, xMp)
        e[5:45] = ep
        return xmaxc, Mc, xMc

    def encode_params(self, samples):
        S = self.S
        so = self._preprocess([int(v) for v in samples])
        acf = self._autocorrelation(so)
        larc = self._lars(self._reflection(acf))
        self._short_term_analysis(larc, so)
        dp0 = S.dp0
        e = S.e
        sub = []
        for k in range(4):
            d = so[k * 40:k * 40 + 40]
            dbase = 120 + 40 * k                     # dp = dp0 + 120 (+40 per subframe)
            Nc, bc = self._ltp_parameters(d, dp0, dbase)
            g = QLB[bc]
            dpp = [0] * 40
            for i in range(40):
                dpp[i] = mult_r(g, dp0[dbase - Nc + i])
                e[5 + i] = sat(d[i] - dpp[i])
            xmaxc, Mc, xMc = self._rpe_encoding(e)
            for i in range(40):
                dp0[dbase + i] = sat(e[5 + i] + dpp[i])
            sub.append((Nc, bc, Mc, xmaxc, xMc))
        S.dp0 = dp0[160:280] + dp0[120:280]          # keep the last 120 reconstructed samples
        return larc, sub

    def encode(self, samples):
        """160 int16 samples -> 33 bytes."""
        larc, sub = self.encode_params(samples)
        return pack(larc, sub)


# ----------------------------------------------------------------- shared RPE pieces
def _xmaxc_to_exp_mant(xmaxc):
    exp = 0
    if xmaxc > 15:
        exp = (xmaxc >> 3) - 1
    mant = xmaxc - (exp << 3)
    if mant == 0:
        return -4, 7
    while mant <= 7:
        mant = mant << 1 | 1
        exp -= 1
    return exp, mant - 8


def _apcm_inverse(xMc, mant, exp):
    temp1 = FAC[mant]
    temp2 = sat(6 - exp)
    temp3 = gsm_asl(1, sat(temp2 - 1))
    out = []
    for v in xMc:
        temp = w16((v << 1) - 7)
        temp = w16(temp << 12)
        temp = mult_r(temp1, temp)
        temp = sat(temp + temp3)
        out.append(gsm_asr(temp, temp2))
    return out


def _grid_positioning(Mc, xMp):
    ep = [0] * 40
    for i in range(13):
        ep[Mc + 3 * i] = xMp[i]
    return ep


# ----------------------------------------------------------------- decoder
class Decoder:
    def __init__(self):
        self.S = _State()

    def decode_params(self, larc, sub):
        S = self.S
        drp = S.dp0                                  # drp[k] = dp0[120 + k]
        wt = [0] * 160
        for j, (Ncr, bcr, Mcr, xmaxcr, xMcr) in enumerate(sub):
            exp, mant = _xmaxc_to_exp_mant(xmaxcr)
            erp = _grid_positioning(Mcr, _apcm_inverse(xMcr, mant, exp))
            Nr = S.nrp if (Ncr < 40 or Ncr > 120) else Ncr
            S.nrp = Nr
            brp = QLB[bcr]
            for k in range(40):
                drpp = mult_r(brp, drp[120 + k - Nr])
                drp[120 + k] = sat(erp[k] + drpp)
            drp[0:120] = drp[40:160]
            for k in range(40):
                wt[j * 40 + k] = drp[120 + k]
        s = [0] * 160
        v = S.v
        for rrp, (lo, hi) in zip(S.lar_sets(larc), SEGMENTS):
            for k in range(lo, hi):
                sri = wt[k]
                for i in range(7, -1, -1):
                    tmp1 = rrp[i]
                    tmp2 = v[i]
                    tmp2 = MAX_WORD if (tmp1 == MIN_WORD and tmp2 == MIN_WORD) else w16((tmp1 * tmp2 + 16384) >> 15)
                    sri = sat(sri - tmp2)
                    tmp1 = MAX_WORD if (tmp1 == MIN_WORD and sri == MIN_WORD) else w16((tmp1 * sri + 16384) >> 15)
                    v[i + 1] = sat(v[i] + tmp1)
                s[k] = v[0] = sri
        msr = S.msr
        for k in range(160):
            tmp = mult_r(msr, 28180)
            msr = sat(s[k] + tmp)
            s[k] = w16(sat(msr + msr) & 0xFFF8)
        S.msr = msr
        return s

    def decode(self, frame):
        """33 bytes -> 160 int16 samples (list). Raises ValueError on a bad frame."""
        larc, sub = unpack(frame)
        return self.decode_params(larc, sub)


# ----------------------------------------------------------------- bit packing (33 bytes, 0xD signature)
def pack(larc, sub):
    fields = [(0xD, 4)] + list(zip(larc, LAR_BITS))
    for Nc, bc, Mc, xmaxc, xMc in sub:
        fields += [(Nc, 7), (bc, 2), (Mc, 2), (xmaxc, 6)] + [(x, 3) for x in xMc]
    acc, nbits = 0, 0
    for value, width in fields:
        acc = (acc << width) | (value & ((1 << width) - 1))
        nbits += width
    return acc.to_bytes(nbits // 8, "big")


def unpack(frame):
    if len(frame) < FRAME_BYTES or (frame[0] >> 4) != 0xD:
        raise ValueError("not a GSM 06.10 frame")
    acc = int.from_bytes(frame[:FRAME_BYTES], "big")
    pos = 264 - 4

    def take(width):
        nonlocal pos
        pos -= width
        return (acc >> pos) & ((1 << width) - 1)

    larc = [take(w) for w in LAR_BITS]
    sub = []
    for _ in range(4):
        Nc, bc, Mc, xmaxc = take(7), take(2), take(2), take(6)
        sub.append((Nc, bc, Mc, xmaxc, [take(3) for _ in range(13)]))
    return larc, sub


SILENCE_FRAME = None


def silence_frame():
    global SILENCE_FRAME
    if SILENCE_FRAME is None:
        SILENCE_FRAME = Encoder().encode([0] * 160)
    return SILENCE_FRAME
