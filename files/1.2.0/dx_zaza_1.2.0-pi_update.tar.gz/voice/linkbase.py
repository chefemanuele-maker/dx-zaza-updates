"""Common UDP link logic for D-STAR reflector protocols (DExtra, DPlus, DCS).

A protocol subclass provides:
  _login(deadline)        link handshake (raise LinkError on refusal / no answer)
  _handle(data)           one received datagram
  _keepalive_packet()     what to send every KEEPALIVE seconds
  _unlink_packets()       what to send when leaving
  send_header / send_voice in its own framing
"""

import socket
import threading
import time

LINK_TIMEOUT_SECONDS = 30.0
ACK_WAIT_SECONDS = 5.0


class LinkError(Exception):
    pass


class ReflectorClient:
    protocol = "base"
    default_port = 0
    keepalive_seconds = 3.0
    keepalive_while_linking = False

    def __init__(self, callsign, local_module="B", on_dsvt=None, on_state=None, sock=None):
        self.callsign = callsign.upper().strip()
        self.local_module = (local_module or "B").upper()[:1]
        self.on_dsvt = on_dsvt or (lambda info: None)
        self.on_state = on_state or (lambda state, detail="": None)
        self.sock = sock
        self.addr = None
        self.host = ""
        self.reflector = ""
        self.module = ""
        self.state = "unlinked"
        self.detail = ""
        self.last_rx = 0.0
        self.linked_at = 0.0
        self._stop = threading.Event()
        self._thread = None
        self._ack = threading.Event()
        self._nak = ""
        self.tx_lock = threading.Lock()

    # ------------------------------------------------------------ link control
    def connect(self, host, module, reflector="", port=None, wait=ACK_WAIT_SECONDS):
        module = (module or "").upper()[:1]
        if not module.isalpha():
            raise LinkError("choose a reflector module A-Z")
        port = int(port or self.default_port)
        try:
            infos = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_DGRAM)
        except (socket.gaierror, OSError) as exc:
            raise LinkError("cannot resolve %s (%s)" % (host, exc))
        self.addr = infos[0][4]
        self.host = host
        if self.sock is None:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.bind(("0.0.0.0", 0))
        self.sock.settimeout(0.5)
        self.reflector = (reflector or host).upper()
        self.module = module
        self._stop.clear()
        self._ack.clear()
        self._nak = ""
        self._set_state("linking", "%s %s" % (self.reflector, module))
        self._thread = threading.Thread(target=self._run, name="%s-rx" % self.protocol, daemon=True)
        self._thread.start()
        try:
            self._login(time.monotonic() + wait)
        except LinkError:
            self.close()
            raise
        if self._nak:
            self.close()
            raise LinkError("the reflector refused the link (%s)" % self._nak)
        if not self._ack.is_set():
            self.close()
            raise LinkError("no answer from %s: check the address and that UDP %s is not blocked" % (host, port))
        self.linked_at = time.time()
        self._set_state("linked", "%s %s" % (self.reflector, module))

    def _send_until_ack(self, packet, deadline, event=None, every=1.0):
        event = event or self._ack
        while time.monotonic() < deadline and not event.is_set():
            self._send(packet)
            event.wait(every)
        return event.is_set()

    def disconnect(self):
        if self.addr and self.state in ("linked", "linking", "lost"):
            for packet in self._unlink_packets():
                for _ in range(2):
                    self._send(packet)
        self.close()

    def close(self):
        self._stop.set()
        if self._thread and self._thread is not threading.current_thread():
            self._thread.join(timeout=2)
        self._thread = None
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass
        self.sock = None
        self._set_state("unlinked", "")

    # ------------------------------------------------------------ hooks
    def _login(self, deadline):
        raise NotImplementedError

    def _handle(self, data):
        raise NotImplementedError

    def _keepalive_packet(self):
        return b""

    def _unlink_packets(self):
        return []

    def send_header(self, stream_id, header):
        raise NotImplementedError

    def send_voice(self, stream_id, seq, ambe, slow, last=False):
        raise NotImplementedError

    # ------------------------------------------------------------ helpers
    def _deliver(self, info):
        if info:
            try:
                self.on_dsvt(info)
            except Exception:  # pragma: no cover - callbacks must not kill the link
                pass

    def _send(self, data):
        sock = self.sock
        if sock is None or self.addr is None or not data:
            return
        try:
            with self.tx_lock:
                sock.sendto(data, self.addr)
        except OSError:
            pass

    def _set_state(self, state, detail=""):
        if state != self.state:
            self.state = state
            self.detail = detail
            try:
                self.on_state(state, detail)
            except Exception:  # pragma: no cover
                pass

    def _remote_unlinked(self, reason="unlinked by the reflector"):
        if self.state == "linked":
            self._set_state("lost", reason)

    def _run(self):
        next_keepalive = time.monotonic() + self.keepalive_seconds
        self.last_rx = time.monotonic()
        while not self._stop.is_set():
            now = time.monotonic()
            if now >= next_keepalive:
                if self.state in ("linked", "lost") or (self.keepalive_while_linking and self.state == "linking"):
                    self._send(self._keepalive_packet())
                next_keepalive = now + self.keepalive_seconds
            if self.state == "linked" and now - self.last_rx > LINK_TIMEOUT_SECONDS:
                self._set_state("lost", "no keep-alive from the reflector")
            sock = self.sock
            if sock is None:
                break
            try:
                data, addr = sock.recvfrom(2048)
            except socket.timeout:
                continue
            except OSError:
                break
            if self.addr and addr[0] != self.addr[0]:
                continue
            self.last_rx = time.monotonic()
            if self.state == "lost" and self.detail == "no keep-alive from the reflector":
                self._set_state("linked", "%s %s" % (self.reflector, self.module))
            try:
                self._handle(data)
            except Exception:  # pragma: no cover - malformed packets are ignored
                pass
