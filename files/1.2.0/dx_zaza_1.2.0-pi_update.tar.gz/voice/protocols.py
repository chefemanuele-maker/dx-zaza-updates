"""Which link protocol a D-STAR reflector uses."""

from voice.dcs import DCSClient
from voice.dextra import DExtraClient
from voice.dplus import DPlusClient

CLIENTS = {"dextra": DExtraClient, "dplus": DPlusClient, "dcs": DCSClient}
PORTS = {name: cls.default_port for name, cls in CLIENTS.items()}
LABELS = {"dextra": "DExtra", "dplus": "DPlus", "dcs": "DCS"}


def protocol_for(name, requested=""):
    requested = str(requested or "").lower()
    if requested in CLIENTS:
        return requested
    prefix = str(name or "").upper()[:3]
    if prefix == "REF":
        return "dplus"
    if prefix == "DCS":
        return "dcs"
    return "dextra"


def make_client(protocol, callsign, local_module="B", on_dsvt=None, on_state=None):
    return CLIENTS[protocol](callsign, local_module, on_dsvt=on_dsvt, on_state=on_state)
