"""Directory of D-STAR reflectors: XLX and XRF (DExtra), REF (DPlus), DCS (DCS).

Sources (cached for 24 hours in the DX Zaza data folder):
  1. the public XLX reflector registry (xlxapi.rlx.lu), XML;
  2. the public DExtra, DPlus and DCS host lists (Pi-Star format "NAME  HOST").
The operator can always add a reflector by hand (name + address).
"""

import json
import re
import time
import xml.etree.ElementTree as ET

import requests

XLX_API_URL = "http://xlxapi.rlx.lu/api.php?do=GetReflectorList"
DEXTRA_HOSTS_URL = "http://www.pistar.uk/downloads/DExtra_Hosts.txt"
DPLUS_HOSTS_URL = "http://www.pistar.uk/downloads/DPlus_Hosts.txt"
DCS_HOSTS_URL = "http://www.pistar.uk/downloads/DCS_Hosts.txt"
PROTOCOL_PORTS = {"dextra": 30001, "dplus": 20001, "dcs": 30051}
CACHE_SECONDS = 24 * 3600
TIMEOUT = 10
NAME_RE = re.compile(r"^(XLX|XRF|REF|DCS)[0-9A-Z]{3}$")
XLX_NAME_RE = re.compile(r"^(XLX|XRF)[0-9A-Z]{3}$")


def protocol_of(name):
    prefix = name[:3]
    return "dplus" if prefix == "REF" else "dcs" if prefix == "DCS" else "dextra"


_BLOCK_RE = re.compile(r"<reflector>(.*?)</reflector>", re.S | re.I)
_TAG_RE = re.compile(r"<([a-zA-Z_]+)>(.*?)</\1>", re.S)


def _unescape(text):
    text = re.sub(r"<!\[CDATA\[(.*?)\]\]>", r"\1", text, flags=re.S)
    return (text.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"')
            .replace("&apos;", "'").replace("&amp;", "&").strip())


def _xlx_entry(children):
    name = children.get("name", "").upper().strip()
    host = (children.get("lastip") or children.get("ip") or "").strip()
    if not name or not host or not XLX_NAME_RE.match(name):
        return None
    try:
        last_contact = int(float(children.get("lastcontact") or 0))
    except ValueError:
        last_contact = 0
    return {
        "name": name,
        "host": host,
        "port": 30001,
        "protocol": "dextra",
        "country": children.get("country", ""),
        "comment": children.get("comment", "")[:60],
        "dashboard": children.get("dashboardurl", ""),
        "lastContact": last_contact,
        "source": "XLX registry",
    }


def parse_xlx_xml(text):
    """The registry XML is not always well formed (stray '&' in comments),
    so it is read block by block instead of with a strict XML parser."""
    out = []
    for block in _BLOCK_RE.findall(text or ""):
        children = {tag.lower(): _unescape(value) for tag, value in _TAG_RE.findall(block)}
        entry = _xlx_entry(children)
        if entry:
            out.append(entry)
    if not out:
        try:
            root = ET.fromstring(text)
            for node in root.iter():
                entry = _xlx_entry({c.tag.lower(): (c.text or "").strip() for c in node})
                if entry:
                    out.append(entry)
        except ET.ParseError:
            pass
    if not out:
        raise ValueError("no reflectors in the XLX registry answer")
    return out


def active_first(reflectors, now=None):
    """Recently seen XLX reflectors first, then the others."""
    now = now or time.time()
    def key(r):
        age = now - r.get("lastContact", 0) if r.get("lastContact") else 10 ** 9
        return (0 if age < 3600 else 1, r["name"])
    return sorted(reflectors, key=key)


def parse_hosts_text(text, source="host list"):
    out = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        name = parts[0].upper()
        if not NAME_RE.match(name):
            continue
        protocol = protocol_of(name)
        out.append({"name": name, "host": parts[1], "port": PROTOCOL_PORTS[protocol], "protocol": protocol,
                    "country": "", "comment": "", "dashboard": "", "source": source})
    return out


def _merge(*lists):
    seen, merged = set(), []
    for items in lists:
        for item in items:
            if item["name"] in seen:
                continue
            seen.add(item["name"])
            merged.append(item)
    merged.sort(key=lambda r: r["name"])
    return merged


class ReflectorDirectory:
    def __init__(self, data_dir, fetch=None):
        self.path = data_dir / "dstar_reflectors_v2.json"
        self.fetch = fetch or self._http_get
        self.last_error = ""

    @staticmethod
    def _http_get(url):
        resp = requests.get(url, timeout=TIMEOUT, headers={"User-Agent": "DX-Zaza"})
        resp.raise_for_status()
        return resp.text

    def _load_cache(self):
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return data.get("updated", 0), data.get("reflectors", [])
        except (OSError, ValueError):
            return 0, []

    def refresh(self):
        lists, errors = [], []
        try:
            lists.append(parse_xlx_xml(self.fetch(XLX_API_URL)))
        except Exception as exc:  # network or XML problems
            errors.append("XLX registry: %s" % type(exc).__name__)
        for label, url in (("DExtra", DEXTRA_HOSTS_URL), ("DPlus", DPLUS_HOSTS_URL), ("DCS", DCS_HOSTS_URL)):
            try:
                lists.append(parse_hosts_text(self.fetch(url), source="%s host list" % label))
            except Exception as exc:
                errors.append("%s list: %s" % (label, type(exc).__name__))
        merged = _merge(*lists)
        self.last_error = "; ".join(errors)
        if merged:
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                self.path.write_text(json.dumps({"updated": time.time(), "reflectors": merged}), encoding="utf-8")
            except OSError:
                pass
        return merged

    def get(self, force=False):
        updated, cached = self._load_cache()
        if force or not cached or time.time() - updated > CACHE_SECONDS:
            fresh = self.refresh()
            if fresh:
                return {"ok": True, "updated": time.time(), "reflectors": fresh, "error": self.last_error}
        return {"ok": bool(cached), "updated": updated, "reflectors": cached,
                "error": self.last_error if not cached else ""}
