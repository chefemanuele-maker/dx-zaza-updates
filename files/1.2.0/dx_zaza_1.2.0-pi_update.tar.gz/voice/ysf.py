"""Yaesu System Fusion (C4FM) frames, written from the public description of the air interface
(as used by MMDVM hotspots and YSF reflectors).

A YSF frame is 120 bytes (100 ms):
    sync (5 bytes) | FICH (25 bytes) | 5 blocks of 18 bytes
The FICH says what the frame is (header / voice / terminator, data type, frame number).
In V/D mode 2 ("DN", the common one) each 18-byte block is
    DCH (40 bits of callsign data) | VCH (104 bits = one 20 ms AMBE+2 voice frame)

The voice in DN mode is the same AMBE+2 vocoder as DMR, only protected differently: the 49 voice
bits (a 12 | b 12 | c 25) are sent with the first 27 bits repeated three times. The DVstick works
in DMR mode (72-bit frames with Golay + PRNG), so this module converts between the two layouts:
no audio quality is lost, only the error protection changes.
"""

from voice.dmr import bits_to_bytes, bits_to_int, bytes_to_bits, int_to_bits

SYNC = bytes([0xD4, 0x71, 0xC9, 0x63, 0x4D])
FRAME_BYTES = 120
CALL_LEN = 10

FI_HEADER, FI_COMMUNICATIONS, FI_TERMINATOR, FI_TEST = 0, 1, 2, 3
DT_VD_MODE1, DT_DATA_FR, DT_VD_MODE2, DT_VOICE_FR = 0, 1, 2, 3
DT_NAMES = {DT_VD_MODE1: "DN (V/D 1)", DT_DATA_FR: "data", DT_VD_MODE2: "DN", DT_VOICE_FR: "VW (wide)"}
FRAME_TOTAL = 6          # fn 0..6, as MMDVM based gateways send

WHITENING = bytes([0x93, 0xD7, 0x51, 0x21, 0x9C, 0x2F, 0x6C, 0xD0, 0xEF, 0x0F,
                   0xF8, 0x3D, 0xF1, 0x73, 0x20, 0x94, 0xED, 0x1E, 0x7C, 0xD8])

# interleavers: dibits in a rows x 20 matrix (FICH / DCH), bits in a 26 x 4 matrix (VCH)
INTERLEAVE_5_20 = [(i % 5) * 40 + (i // 5) * 2 for i in range(100)]
INTERLEAVE_9_20 = [(i % 9) * 40 + (i // 9) * 2 for i in range(180)]
INTERLEAVE_26_4 = [(i % 26) * 4 + (i // 26) for i in range(104)]

# DMR AMBE+2 72-bit frame: where the a / b / c bits sit (on-air order, as the DVstick wants them)
DMR_A_POS = [0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64, 68, 1, 5, 9, 13, 17, 21]
DMR_B_POS = [25, 29, 33, 37, 41, 45, 49, 53, 57, 61, 65, 69, 2, 6, 10, 14, 18, 22, 26, 30, 34, 38, 42]
DMR_C_POS = [46, 50, 54, 58, 62, 66, 70, 3, 7, 11, 15, 19, 23, 27, 31, 35, 39, 43, 47, 51, 55, 59, 63, 67, 71]


# ----------------------------------------------------------------- CRC-16 CCITT (YSF flavour)
def crc16(data):
    crc = 0
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) if crc & 0x8000 else (crc << 1)
            crc &= 0xFFFF
    return crc ^ 0xFFFF


def add_crc(data):
    crc = crc16(data)
    return bytes(data) + bytes([crc >> 8, crc & 0xFF])


def check_crc(data):
    return len(data) >= 3 and crc16(data[:-2]) == (data[-2] << 8 | data[-1])


# ----------------------------------------------------------------- Golay (23,12) / (24,12)
_GOLAY_GEN = 0xC75


def golay23_encode(data12):
    value = (data12 & 0xFFF) << 11
    rem = value
    for bit in range(22, 10, -1):
        if rem & (1 << bit):
            rem ^= _GOLAY_GEN << (bit - 11)
    return value | (rem & 0x7FF)


def golay24_encode(data12):
    word = golay23_encode(data12)
    return (word << 1) | (bin(word).count("1") & 1)


def _syndrome23(word23):
    rem = word23 & 0x7FFFFF
    for bit in range(22, 10, -1):
        if rem & (1 << bit):
            rem ^= _GOLAY_GEN << (bit - 11)
    return rem & 0x7FF


_SYNDROME_TABLE = None


def _syndromes():
    """Golay(23,12) is perfect: each of the 2048 syndromes is one pattern of up to 3 errors."""
    global _SYNDROME_TABLE
    if _SYNDROME_TABLE is None:
        table = {0: 0}
        for i in range(23):
            table.setdefault(_syndrome23(1 << i), 1 << i)
            for j in range(i + 1, 23):
                table.setdefault(_syndrome23((1 << i) | (1 << j)), (1 << i) | (1 << j))
                for k in range(j + 1, 23):
                    p = (1 << i) | (1 << j) | (1 << k)
                    table.setdefault(_syndrome23(p), p)
        _SYNDROME_TABLE = table
    return _SYNDROME_TABLE


def golay23_decode(word23):
    """-> (data12, errors corrected)."""
    pattern = _syndromes().get(_syndrome23(word23), 0)
    fixed = (word23 ^ pattern) & 0x7FFFFF
    return fixed >> 11, bin(pattern).count("1")


def golay24_decode(word24):
    """-> (data12, errors, ok). ok is False when 4 errors are detected (overall parity)."""
    data, errors = golay23_decode(word24 >> 1)
    ok = (bin(golay24_encode(data) ^ word24).count("1")) <= 3
    return data, errors, ok


# ----------------------------------------------------------------- AMBE+2 PRNG (b scrambling)
def _prng(a12):
    p = 16 * a12
    mask = 0
    for _ in range(23):
        p = (173 * p + 13849) % 65536
        mask = (mask << 1) | (p >> 15)
    return mask


PRNG = [_prng(a) for a in range(4096)]


def dmr_to_abc(frame9):
    """72-bit DMR AMBE+2 frame -> (a12, b12, c25, errors)."""
    bits = bytes_to_bits(frame9)
    a24 = bits_to_int([bits[p] for p in DMR_A_POS])
    b23 = bits_to_int([bits[p] for p in DMR_B_POS])
    c25 = bits_to_int([bits[p] for p in DMR_C_POS])
    a12, err_a, _ = golay24_decode(a24)
    b12, err_b = golay23_decode(b23 ^ PRNG[a12])
    return a12, b12, c25, err_a + err_b


def abc_to_dmr(a12, b12, c25):
    a24 = golay24_encode(a12)
    b23 = golay23_encode(b12) ^ PRNG[a12]
    bits = [0] * 72
    for pos, bit in zip(DMR_A_POS, int_to_bits(a24, 24)):
        bits[pos] = bit
    for pos, bit in zip(DMR_B_POS, int_to_bits(b23, 23)):
        bits[pos] = bit
    for pos, bit in zip(DMR_C_POS, int_to_bits(c25, 25)):
        bits[pos] = bit
    return bits_to_bytes(bits)


# ----------------------------------------------------------------- VCH (V/D mode 2 voice channel)
def vch_encode(a12, b12, c25):
    """-> 104 interleaved, whitened bits."""
    first27 = int_to_bits(a12, 12) + int_to_bits(b12, 12) + int_to_bits(c25 >> 22, 3)
    plain = [bit for bit in first27 for _ in range(3)] + int_to_bits(c25 & 0x3FFFFF, 22) + [0]
    white = bytes_to_bits(WHITENING[:13])
    plain = [b ^ w for b, w in zip(plain, white)]
    out = [0] * 104
    for i, bit in enumerate(plain):
        out[INTERLEAVE_26_4[i]] = bit
    return out


def vch_decode(bits104):
    """-> (a12, b12, c25, triplets corrected)."""
    plain = [bits104[INTERLEAVE_26_4[i]] for i in range(104)]
    white = bytes_to_bits(WHITENING[:13])
    plain = [b ^ w for b, w in zip(plain, white)]
    voted, errors = [], 0
    for i in range(0, 81, 3):
        s = plain[i] + plain[i + 1] + plain[i + 2]
        voted.append(1 if s >= 2 else 0)
        errors += s in (1, 2)
    a12 = bits_to_int(voted[0:12])
    b12 = bits_to_int(voted[12:24])
    c25 = (bits_to_int(voted[24:27]) << 22) | bits_to_int(plain[81:103])
    return a12, b12, c25, errors


# ----------------------------------------------------------------- convolutional code (K=5, rate 1/2)
def conv_encode(bits):
    d1 = d2 = d3 = d4 = 0
    out = []
    for d in bits:
        out.append(d ^ d3 ^ d4)
        out.append(d ^ d1 ^ d2 ^ d4)
        d1, d2, d3, d4 = d, d1, d2, d3
    return out


_TRELLIS = None


def _trellis():
    """state = (d1, d2, d3, d4) as 4 bits (d1 = MSB); next state and output for input bit d."""
    global _TRELLIS
    if _TRELLIS is None:
        table = []
        for state in range(16):
            d1, d2, d3, d4 = (state >> 3) & 1, (state >> 2) & 1, (state >> 1) & 1, state & 1
            row = []
            for d in (0, 1):
                nxt = (d << 3) | (d1 << 2) | (d2 << 1) | d3
                row.append((nxt, d ^ d3 ^ d4, d ^ d1 ^ d2 ^ d4))
            table.append(row)
        _TRELLIS = table
    return _TRELLIS


def viterbi_decode(pairs):
    """Hard-decision Viterbi: list of (s0, s1) -> input bits (the encoder starts at state 0)."""
    trellis = _trellis()
    inf = 1 << 30
    metric = [0] + [inf] * 15
    history = []
    for s0, s1 in pairs:
        new = [inf] * 16
        back = [0] * 16
        for state in range(16):
            m = metric[state]
            if m >= inf:
                continue
            for d in (0, 1):
                nxt, o0, o1 = trellis[state][d]
                cost = m + (o0 != s0) + (o1 != s1)
                if cost < new[nxt]:
                    new[nxt] = cost
                    back[nxt] = state
        metric = new
        history.append(back)
    state = min(range(16), key=lambda s: metric[s])
    errors = metric[state]
    out = []
    for back in reversed(history):
        out.append(state >> 3)
        state = back[state]
    out.reverse()
    return out, errors


def _place_dibits(conv_bits, table, total_bits):
    out = [0] * total_bits
    for i, n in enumerate(table):
        out[n] = conv_bits[2 * i]
        out[n + 1] = conv_bits[2 * i + 1]
    return out


def _take_dibits(bits, table):
    return [(bits[n], bits[n + 1]) for n in table]


# ----------------------------------------------------------------- FICH
def fich_bytes(fi, fn=0, ft=FRAME_TOTAL, dt=DT_VD_MODE2, cm=0, cs=2, bn=0, bt=0, mr=0, voip=False,
               dev=False, dgid=0):
    b0 = ((fi & 3) << 6) | ((cs & 3) << 4) | ((cm & 3) << 2) | (bn & 3)
    b1 = ((bt & 3) << 6) | ((fn & 7) << 3) | (ft & 7)
    b2 = (0x40 if dev else 0) | ((mr & 7) << 3) | (0x04 if voip else 0) | (dt & 3)
    b3 = dgid & 0x7F
    return bytes([b0, b1, b2, b3])


def fich_encode(fich4):
    data = add_crc(fich4)
    words = [(data[0] << 4) | (data[1] >> 4), ((data[1] & 0x0F) << 8) | data[2],
             (data[3] << 4) | (data[4] >> 4), ((data[4] & 0x0F) << 8) | data[5]]
    bits = []
    for w in words:
        bits += int_to_bits(golay24_encode(w), 24)
    bits += [0] * 4
    return _place_dibits(conv_encode(bits), INTERLEAVE_5_20, 200)


def fich_decode(bits200):
    """-> dict or None when the FICH is not valid."""
    decoded, _ = viterbi_decode(_take_dibits(bits200, INTERLEAVE_5_20))
    words = []
    for i in range(4):
        data, _err, ok = golay24_decode(bits_to_int(decoded[24 * i:24 * i + 24]))
        if not ok:
            return None
        words.append(data)
    raw = bytes([words[0] >> 4, ((words[0] & 0x0F) << 4) | (words[1] >> 8), words[1] & 0xFF,
                 words[2] >> 4, ((words[2] & 0x0F) << 4) | (words[3] >> 8), words[3] & 0xFF])
    if not check_crc(raw):
        return None
    b0, b1, b2, b3 = raw[:4]
    return {"fi": b0 >> 6, "cs": (b0 >> 4) & 3, "cm": (b0 >> 2) & 3, "bn": b0 & 3, "bt": b1 >> 6,
            "fn": (b1 >> 3) & 7, "ft": b1 & 7, "dev": bool(b2 & 0x40), "mr": (b2 >> 3) & 7,
            "voip": bool(b2 & 0x04), "dt": b2 & 3, "dgid": b3 & 0x7F}


# ----------------------------------------------------------------- DCH (callsign data)
def _dch_encode(data, nbits, table, total):
    plain = bytes(b ^ w for b, w in zip(data, WHITENING))
    plain = add_crc(plain) + b"\x00"
    return _place_dibits(conv_encode(bytes_to_bits(plain)[:nbits]), table, total)


def _dch_decode(bits, table, nbytes):
    decoded, _ = viterbi_decode(_take_dibits(bits, table))
    raw = bits_to_bytes(decoded[:(nbytes + 2) * 8])
    if not check_crc(raw):
        return None
    return bytes(b ^ w for b, w in zip(raw[:nbytes], WHITENING))


def dch10_encode(data10):        # V/D mode 2: 10 bytes, 100 conv steps -> 200 bits
    return _dch_encode(data10, 100, INTERLEAVE_5_20, 200)


def dch10_decode(bits200):
    return _dch_decode(bits200, INTERLEAVE_5_20, 10)


def dch20_encode(data20):        # header / terminator: 20 bytes, 180 conv steps -> 360 bits
    return _dch_encode(data20, 180, INTERLEAVE_9_20, 360)


def dch20_decode(bits360):
    return _dch_decode(bits360, INTERLEAVE_9_20, 20)


# ----------------------------------------------------------------- whole frames
def callsign_field(text):
    text = "".join(ch for ch in str(text or "").upper() if 32 <= ord(ch) < 127)
    return text[:CALL_LEN].ljust(CALL_LEN).encode("ascii")


def _assemble(fich_bits, blocks):
    """blocks: 5 x 144 bits."""
    bits = bytes_to_bits(SYNC) + fich_bits
    for block in blocks:
        bits += block
    return bits_to_bytes(bits)


def build_header(source, dest="ALL", downlink="", uplink="", terminator=False, ft=FRAME_TOTAL):
    """Header (or terminator) frame: CSD1 = dest + source, CSD2 = downlink + uplink."""
    fi = FI_TERMINATOR if terminator else FI_HEADER
    csd1 = dch20_encode(callsign_field(dest) + callsign_field(source))
    csd2 = dch20_encode(callsign_field(downlink) + callsign_field(uplink))
    blocks = []
    for i in range(5):
        blocks.append(csd1[72 * i:72 * i + 72] + csd2[72 * i:72 * i + 72])
    return _assemble(fich_encode(fich_bytes(fi, 0, ft, DT_VD_MODE2)), blocks)


def build_voice(fn, dch10, voice_frames, ft=FRAME_TOTAL):
    """V/D mode 2 frame: dch10 (10 bytes) + five 72-bit DMR AMBE+2 frames from the DVstick."""
    dch = dch10_encode(dch10)
    blocks = []
    for i in range(5):
        a, b, c, _ = dmr_to_abc(voice_frames[i])
        blocks.append(dch[40 * i:40 * i + 40] + vch_encode(a, b, c))
    return _assemble(fich_encode(fich_bytes(FI_COMMUNICATIONS, fn, ft, DT_VD_MODE2)), blocks)


def vd2_dch_for(fn, source, dest="ALL", downlink="", uplink=""):
    """What V/D mode 2 frame number fn carries in its DCH."""
    return {0: callsign_field(dest), 1: callsign_field(source), 2: callsign_field(downlink),
            3: callsign_field(uplink)}.get(fn, b" " * CALL_LEN)


def parse_frame(frame):
    """120-byte frame -> dict: fich, voice (list of 72-bit DMR frames), dch text, errors."""
    if len(frame) < FRAME_BYTES:
        return None
    bits = bytes_to_bits(frame[:FRAME_BYTES])
    fich = fich_decode(bits[40:240])
    out = {"fich": fich, "voice": [], "dch": None, "errors": 0, "sync": frame[:5] == SYNC}
    if fich is None:
        return out
    payload = bits[240:]
    blocks = [payload[144 * i:144 * i + 144] for i in range(5)]
    if fich["fi"] in (FI_HEADER, FI_TERMINATOR):
        csd1 = dch20_decode(sum((blk[0:72] for blk in blocks), []))
        if csd1:
            out["dch"] = csd1
    elif fich["dt"] == DT_VD_MODE2:
        out["dch"] = dch10_decode(sum((blk[0:40] for blk in blocks), []))
        for blk in blocks:
            a, b, c, err = vch_decode(blk[40:144])
            out["errors"] += err
            out["voice"].append(abc_to_dmr(a, b, c))
    return out


SILENCE_DMR = bytes.fromhex("b9e881526173002a6b")
