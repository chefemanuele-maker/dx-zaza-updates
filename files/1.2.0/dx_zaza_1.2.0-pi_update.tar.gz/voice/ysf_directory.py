"""C4FM rooms: the public YSF reflector list (Pi-Star host file, data from DVRef), cached 24 h,
plus a few built-in rooms so C4FM works even when the list cannot be downloaded."""

import json
import logging
import time

import requests

log = logging.getLogger("dxzaza.ysf")

YSF_HOSTS_URL = "http://www.pistar.uk/downloads/YSF_Hosts.txt"
CACHE_SECONDS = 24 * 3600
TIMEOUT = 8

BUILTIN_ROOMS = [
    {"id": "00052", "name": "GB-CQ-UK-ECHO", "description": "Parrot CQ-UK", "host": "81.150.10.62", "port": 42495},
    {"id": "22022", "name": "US-PA Parrot", "description": "YSF Echo Test", "host": "24.229.253.31", "port": 42101},
    {"id": "22201", "name": "IT-C4FM Italy", "description": "YCS222", "host": "145.239.75.155", "port": 42000},
    {"id": "22208", "name": "IT-Italy Centro", "description": "ItaC Digiland", "host": "194.164.22.245", "port": 42000},
    {"id": "00009", "name": "GB-CQ-UK", "description": "Main Reflector", "host": "149.102.158.76", "port": 42200},
    {"id": "00007", "name": "XX-EUROPELINK", "description": "Europelink", "host": "161.97.73.43", "port": 42000},
    {"id": "00008", "name": "XX-WORLDLINK", "description": "World link", "host": "94.72.113.36", "port": 42000},
]


def country_of(name):
    prefix = name.split("-", 1)[0].upper() if "-" in name else ""
    return prefix if len(prefix) == 2 and prefix.isalpha() else ""


def parse_ysf_hosts(text):
    """designator;name;description;host;port;..."""
    out = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(";")
        if len(parts) < 5:
            continue
        rid, name, desc, host, port = (p.strip() for p in parts[:5])
        try:
            port = int(port)
        except ValueError:
            continue
        if not host or not (1 <= port <= 65535):
            continue
        out.append({"id": rid[:5], "name": name[:30], "description": desc[:30], "host": host, "port": port,
                    "country": country_of(name), "parrot": "PARROT" in (name + desc).upper()
                    or "ECHO" in (name + desc).upper()})
    return out


class YSFDirectory:
    def __init__(self, data_dir, fetch=None):
        self.path = data_dir / "ysf_rooms.json"
        self.fetch = fetch or self._fetch

    def _fetch(self, url):
        res = requests.get(url, timeout=TIMEOUT, headers={"User-Agent": "DXZaza"})
        res.raise_for_status()
        return res.text

    def rooms(self, force=False):
        try:
            cached = json.loads(self.path.read_text())
            if not force and time.time() - cached.get("updated", 0) < CACHE_SECONDS and cached.get("rooms"):
                return cached
        except (OSError, ValueError):
            cached = {}
        try:
            rooms = parse_ysf_hosts(self.fetch(YSF_HOSTS_URL))
            if not rooms:
                raise ValueError("empty room list")
            data = {"updated": time.time(), "rooms": rooms, "source": "Pi-Star YSF_Hosts (DVRef)"}
            try:
                self.path.write_text(json.dumps(data))
            except OSError:
                pass
            return data
        except Exception as exc:
            if cached.get("rooms"):
                return dict(cached, error="list not updated: %s" % exc.__class__.__name__)
            rooms = [dict(r, country=country_of(r["name"]),
                          parrot="PARROT" in (r["name"] + r["description"]).upper()
                          or "ECHO" in (r["name"] + r["description"]).upper()) for r in BUILTIN_ROOMS]
            return {"updated": 0, "rooms": rooms, "error": "using the built-in list (%s)" % exc.__class__.__name__}

    def find(self, room_id):
        for room in self.rooms().get("rooms", []):
            if room["id"] == str(room_id):
                return room
        return None
