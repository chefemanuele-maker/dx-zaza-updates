"""YSF reflector client (C4FM / System Fusion rooms, UDP, usually port 42000).

Link            YSFP callsign(10)   ->  YSFP name     (the reflector answers the poll)
Keep-alive      YSFP callsign(10)  every 5 s
Voice / data    YSFD gateway(10) source(10) dest(10) counter/end(1) frame(120)   = 155 bytes
Leaving         YSFU callsign(10)

The engine sees the same events as with a D-STAR reflector: {"type": "header"}, {"type": "voice",
"ambe": <72-bit DMR AMBE+2 frame for the DVstick>}, last=True at the end. DN voice is converted
to the DVstick's DMR layout (voice.ysf); VW ("wide") voice needs another vocoder and is not played.
"""

import logging
import threading
import time

from voice import ysf
from voice.linkbase import LinkError, ReflectorClient

log = logging.getLogger("dxzaza.ysf")

DEFAULT_PORT = 42000
POLL_SECONDS = 5.0
WIDE_NOTE = "C4FM wide (VW): audio not supported, ask for DN"


def build_ysfd(gateway, source, dest, counter, frame, end=False):
    return (b"YSFD" + ysf.callsign_field(gateway) + ysf.callsign_field(source) + ysf.callsign_field(dest)
            + bytes([((counter & 0x7F) << 1) | (1 if end else 0)]) + bytes(frame))


def parse_ysfd(data):
    if len(data) < 155 or data[:4] != b"YSFD":
        return None
    return {"gateway": data[4:14].decode("ascii", "replace").strip(),
            "source": data[14:24].decode("ascii", "replace").strip(),
            "dest": data[24:34].decode("ascii", "replace").strip(),
            "counter": data[34] >> 1, "end": bool(data[34] & 1), "frame": data[35:155]}


class YSFClient(ReflectorClient):
    protocol = "ysf"
    default_port = DEFAULT_PORT
    keepalive_seconds = POLL_SECONDS

    def __init__(self, callsign, on_dsvt=None, on_state=None, sock=None):
        super().__init__(callsign, "B", on_dsvt=on_dsvt, on_state=on_state, sock=sock)
        self._rx_key = None
        self._rx_seq = 0
        self._rx_stream = 0
        self._rx_wide = False
        self._tx = None
        self.room_name = ""
        # received frames checked with DX Zaza's own decoders (diagnostics for the operator)
        self.checks = {"fich_ok": 0, "fich_bad": 0, "dch_ok": 0, "dch_bad": 0, "dn_frames": 0,
                       "vw_frames": 0, "vch_fixed": 0}

    def _poll(self):
        return b"YSFP" + ysf.callsign_field(self.callsign)

    # ------------------------------------------------------------ link control
    def connect(self, host, module="", reflector="", port=None, wait=6.0):
        import socket
        port = int(port or self.default_port)
        try:
            infos = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_DGRAM)
        except (socket.gaierror, OSError) as exc:
            raise LinkError("cannot resolve %s (%s)" % (host, exc))
        self.addr = infos[0][4]
        self.host = host
        if self.sock is None:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.bind(("0.0.0.0", 0))
        self.sock.settimeout(0.5)
        self.reflector = (reflector or host).upper()
        self.module = ""
        self._stop.clear()
        self._ack.clear()
        self._set_state("linking", self.reflector)
        self._thread = threading.Thread(target=self._run, name="ysf-rx", daemon=True)
        self._thread.start()
        if not self._send_until_ack(self._poll(), time.monotonic() + wait, every=1.0):
            self.close()
            raise LinkError("no answer from %s: check the room address and that UDP %s is not blocked"
                            % (host, port))
        self.linked_at = time.time()
        self._set_state("linked", self.reflector)

    def _keepalive_packet(self):
        return self._poll()

    def _unlink_packets(self):
        return [b"YSFU" + ysf.callsign_field(self.callsign)]

    # ------------------------------------------------------------ receive
    def _handle(self, data):
        if data.startswith(b"YSFP"):
            self.room_name = data[4:14].decode("ascii", "replace").strip()
            self._ack.set()
            return
        if data.startswith(b"YSFU"):
            self._remote_unlinked("the room closed the link")
            return
        if data.startswith(b"YSFD"):
            self._on_ysfd(parse_ysfd(data))

    def _on_ysfd(self, p):
        if p is None or self._tx is not None:
            return
        key = (p["gateway"], p["source"])
        info = ysf.parse_frame(p["frame"])
        fich = info["fich"] if info else None
        if fich is None:
            self.checks["fich_bad"] += 1
        else:
            self.checks["fich_ok"] += 1
        if self._rx_key != key:
            if p["end"] or (fich and fich["fi"] == ysf.FI_TERMINATOR):
                return                                 # tail of a transmission we never saw
            self._rx_key = key
            self._rx_seq = 0
            self._rx_wide = False
            self._rx_stream = (self._rx_stream + 1) & 0xFFFF or 1
            dt = fich["dt"] if fich else ysf.DT_VD_MODE2
            self._deliver({"type": "header", "stream_id": self._rx_stream, "my": p["source"] or "?", "suffix": "",
                           "ur": p["dest"], "rpt1": p["gateway"], "rpt2": "", "mode": "ysf",
                           "ysf": {"dt": ysf.DT_NAMES.get(dt, "?"), "wide": dt == ysf.DT_VOICE_FR}})
        stream = self._rx_stream
        if fich is not None:
            if fich["fi"] in (ysf.FI_HEADER, ysf.FI_TERMINATOR) or fich["dt"] == ysf.DT_VD_MODE2:
                self.checks["dch_ok" if info["dch"] is not None else "dch_bad"] += 1
            if fich["fi"] == ysf.FI_COMMUNICATIONS:
                if fich["dt"] == ysf.DT_VD_MODE2:
                    self.checks["dn_frames"] += 1
                    self.checks["vch_fixed"] += info["errors"]
                    for frame in info["voice"]:
                        self._deliver({"type": "voice", "stream_id": stream, "seq": self._rx_seq % 21,
                                       "ambe": frame, "slow": b"", "last": False})
                        self._rx_seq += 1
                elif fich["dt"] == ysf.DT_VOICE_FR:
                    self.checks["vw_frames"] += 1
                    if not self._rx_wide:
                        self._rx_wide = True
                        self._deliver({"type": "caller", "stream_id": stream, "my": p["source"] or "?",
                                       "note": WIDE_NOTE})
                    # keep the transmission "alive" (who is talking) without audio
                    self._deliver({"type": "voice", "stream_id": stream, "seq": 0, "ambe": b"", "slow": b"",
                                   "last": False, "silent": True})
        if p["end"] or (fich and fich["fi"] == ysf.FI_TERMINATOR):
            self._deliver({"type": "voice", "stream_id": stream, "seq": self._rx_seq, "ambe": b"", "slow": b"",
                           "last": True})
            self._rx_key = None

    # ------------------------------------------------------------ transmit
    def send_header(self, stream_id, header=None):
        if self._tx is not None and self._tx["engine_stream"] == stream_id:
            return                                     # the engine sends the header twice
        self._tx = {"engine_stream": stream_id, "frames": [], "fn": 0, "counter": 0}
        frame = ysf.build_header(self.callsign, "ALL")
        self._send(build_ysfd(self.callsign, self.callsign, "ALL", 0, frame))

    def _send_frame(self, tx, frame, end=False):
        tx["counter"] = (tx["counter"] + 1) & 0x7F
        self._send(build_ysfd(self.callsign, self.callsign, "ALL", tx["counter"], frame, end=end))

    def send_voice(self, stream_id, seq, ambe, slow, last=False):
        tx = self._tx
        if tx is None:
            return
        if ambe:
            tx["frames"].append(bytes(ambe))
        while len(tx["frames"]) >= 5 or (last and tx["frames"]):
            while len(tx["frames"]) < 5:
                tx["frames"].append(ysf.SILENCE_DMR)
            frames, tx["frames"] = tx["frames"][:5], tx["frames"][5:]
            fn = tx["fn"]
            frame = ysf.build_voice(fn, ysf.vd2_dch_for(fn, self.callsign), frames)
            self._send_frame(tx, frame)
            tx["fn"] = (fn + 1) % (ysf.FRAME_TOTAL + 1)
        if last:
            self._send_frame(tx, ysf.build_header(self.callsign, "ALL", terminator=True), end=True)
            self._tx = None
