let refreshTick = 0;
let latestIndex = 0;
let activePage = "global-map";
let activeKeyboardInput = null;
let activeKeyboardSelectionStart = null;
let activeKeyboardSelectionEnd = null;
let keyboardShift = true;
let keyboardSymbols = false;
let propagationCycle = 0;
let touchDragScrollEnabled = false;
let touchDragScrollStartY = 0;
let touchDragScrollLastY = 0;
let touchDragScrollIgnore = false;
let pointerDragScrollActive = false;
let pointerDragScrollId = null;
let pointerDragScrollLastY = 0;
let pointerDragScrollContainer = null;
const LIVE_MODE = true;

if (typeof window !== "undefined" && window.DX_ZAZA_TOUCH_DEBUG === undefined) {
  window.DX_ZAZA_TOUCH_DEBUG = false;
}

const dxZazaState = {
  band: "all",
  mode: "all",
  search: "",
  dxSource: "not-ready",
  solarSource: "checking",
  language: "en",
  setupRequired: true,
  setupReasonKey: "setup.configure_operator",
  networkOnline: false,
  operatorConfigured: false,
  operatorCallsignMasked: ""
};

const translations = {
  "en": {
    "nav.globalMap": "Global Map",
    "nav.liveDxSpots": "Live Radio Spots",
    "nav.hfPropagation": "HF Propagation",
    "nav.wifiSetup": "Wi-Fi Setup",
    "nav.digitalVoice": "Digital Voice",
    "nav.radioTools": "Radio Tools",
    "brand.subtitle": "global radio map",
    "topbar.eyebrow": "GLOBAL RADIO INTELLIGENCE",
    "time.local": "Local Time",
    "status.online": "ONLINE",
    "status.partialOnline": "PARTIAL ONLINE",
    "status.offlineFallback": "OFFLINE / SAFE FALLBACK",
    "status.dxActive": "Radio spots online",
    "status.dxOffline": "Radio spots offline",
    "status.dxFallbackShown": "reconnecting",
    "status.solarActive": "Propagation online",
    "status.solarOffline": "Propagation offline",
    "status.solarFallbackShown": "retrying",
    "status.staticPreviewShown": "retrying",
    "status.checking": "Checking status",
    "status.checking_radio": "Checking radio spots...",
    "status.checking_propagation": "Checking propagation...",
    "status.checking_radio_data": "Checking live radio data.",
    "status.checking_propagation_data": "Checking live propagation data.",
    "setup.required": "SETUP REQUIRED",
    "setup.configure_operator": "Configure Operator Callsign to enable live radio spots.",
    "setup.live_readiness": "Live readiness",
    "setup.ready_for_live": "Ready for live",
    "setup.operator_not_configured": "Operator not configured",
    "setup.network_online": "Network online",
    "setup.network_offline": "Network offline",
    "filters.band": "Band",
    "filters.mode": "Mode",
    "filters.search": "Search",
    "filters.search_placeholder": "callsign",
    "filters.all_bands": "All Bands",
    "filters.all_modes": "All Modes",
    "global_map.live_badge": "LIVE RADIO SPOTS",
    "global_map.static_preview": "RECONNECTING",
    "global_map.live_notice": "Live radio data active.",
    "global_map.preview_notice": "DX cluster not reachable right now: reconnecting automatically.",
    "global_map.no_live_filter": "No live radio spots currently available for this filter. Try All Modes.",
    "global_map.no_preview_filter": "No preview spots match this filter. Try All Modes.",
    "global_map.no_filter": "No radio spots currently match this filter. Try All Modes.",
    "global_map.setup_empty": "Complete Operator Setup to enable live map activity.",
    "global_map.offline_empty": "No live radio activity is currently available.",
    "summary.live": "LIVE ACTIVITY SUMMARY",
    "summary.preview": "WAITING FOR LIVE DATA",
    "summary.active_spots": "Active spots",
    "summary.top_band": "Top band",
    "summary.latest_de": "Latest DE",
    "summary.footer_live": "Live radio data active.",
    "summary.footer_preview": "DX cluster not reachable right now: reconnecting automatically.",
    "spots.eyebrow": "LIVE RADIO SPOTS",
    "spots.eyebrow_preview": "RADIO SPOTS / RECONNECTING",
    "spots.title": "Live Radio Spots",
    "spots.title_preview": "Radio Spots",
    "spots.nav_live": "Live Radio Spots",
    "spots.nav_preview": "Live Radio Spots",
    "spots.badge_live": "LIVE RADIO SPOTS",
    "spots.badge_preview": "RECONNECTING",
    "spots.notice_live": "Live radio data active.",
    "spots.notice_stale": "Connection to the DX cluster lost: reconnecting. The list shows the last spots received.",
    "propagation.notice_stale": "NOAA not reachable: last real values shown ({m} min old), updating.",
    "spots.notice_preview": "DX cluster not reachable right now: reconnecting automatically (other nodes are tried too).",
    "spots.no_results": "No spots match current filters",
    "spots.setup_empty": "Configure Operator Callsign to enable live radio spots.",
    "spots.offline_empty": "Live radio spots are temporarily unavailable.",
    "spots.just_now": "Just now",
    "spots.table.spotter": "Spotter / DE",
    "spots.table.frequency": "Frequency",
    "spots.table.band": "Band",
    "spots.table.mode": "Mode",
    "spots.table.country": "Country/Region",
    "spots.table.comment": "Comment",
    "spots.table.last_seen": "Last Seen",
    "propagation.eyebrow": "HF PROPAGATION",
    "propagation.title": "Space Weather",
    "propagation.live_badge": "LIVE PROPAGATION DATA",
    "propagation.preview_badge": "NOAA NOT REACHABLE",
    "propagation.notice_live": "Live propagation data active.",
    "propagation.notice_preview": "NOAA data not reachable right now: retrying every minute. No values are invented.",
    "propagation.live_message": "Live propagation data active",
    "propagation.preview_message": "NOAA data not available yet",
    "propagation.preview_shown": "NOAA data not available yet: retrying automatically",
    "propagation.global_summary": "Global Conditions Summary",
    "propagation.storm_watch": "Storm Watch",
    "propagation.storm_risk_low": "Storm risk low.",
    "propagation.solar_wind": "Solar Wind",
    "propagation.solar_gauges": "Solar Gauges",
    "propagation.solar_conditions": "Solar Conditions",
    "propagation.band_conditions": "Band Conditions",
    "propagation.greyline_window": "Grey-Line Window",
    "propagation.forecast_outlook": "Forecast Outlook",
    "propagation.data_note": "Data Note",
    "propagation.source_live_note": "Live propagation data active.",
    "propagation.source_preview_note": "NOAA/SWPC not reachable: values appear as soon as the connection is back.",
    "propagation.kp_index": "Kp Index",
    "propagation.a_index": "A Index",
    "propagation.sfi": "Solar Flux / SFI",
    "propagation.xray_class": "X-Ray class",
    "propagation.geomagnetic_field": "Geomagnetic field",
    "propagation.geomagnetic_load": "Geomagnetic load",
    "propagation.upper_hf_support": "Upper HF support",
    "propagation.flare_activity": "Flare activity",
    "propagation.bz": "Bz",
    "propagation.storm_level": "Storm Level",
    "propagation.aurora_risk": "Aurora Risk",
    "propagation.hf_impact": "HF Impact",
    "wifi.eyebrow": "WI-FI SETUP",
    "wifi.title": "DX Zaza Network",
    "wifi.pi_setup": "Pi setup",
    "wifi.subtitle": "Review network status and scan available Wi-Fi networks.",
    "wifi.management": "WI-FI MANAGEMENT",
    "wifi.coming_soon": "Coming soon",
    "wifi.setup_mode_required": "Setup mode required",
    "wifi.management_later": "Wi-Fi management from the app will be available in setup mode.",
    "wifi.network_status": "NETWORK STATUS",
    "wifi.current_mode": "Current Mode",
    "wifi.setup_mode": "Setup Mode",
    "wifi.device_network": "Device Network",
    "wifi.internet": "Internet",
    "wifi.wifi": "Wi-Fi",
    "wifi.ethernet": "Ethernet",
    "wifi.ip_address": "IP address",
    "wifi.connected": "Connected",
    "wifi.disconnected": "Not connected",
    "wifi.unavailable": "Unavailable",
    "wifi.read_only": "Read only",
    "wifi.scan_prompt": "Scan to view available Wi-Fi networks.",
    "wifi.scan_complete": "Available Wi-Fi networks updated.",
    "wifi.scan_empty": "No Wi-Fi networks found.",
    "wifi.scan_unavailable": "Wi-Fi scan is unavailable on this device.",
    "wifi.signal": "Signal",
    "wifi.secured": "Secured",
    "wifi.open": "Open",
    "wifi.current_network": "Connected network",
    "wifi.not_connected": "Not connected",
    "wifi.wifi_country": "Wi-Fi Country",
    "wifi.available_networks": "AVAILABLE NETWORKS",
    "wifi.pi_backend": "Pi backend",
    "wifi.scan": "Scan Wi-Fi",
    "wifi.scanning": "Scanning...",
    "wifi.scan_available_pi": "Live Wi-Fi scan is available on Raspberry Pi backend.",
    "wifi.scan_backend_required": "Raspberry Pi backend required for live Wi-Fi scan.",
    "wifi.connect_network": "CONNECT NETWORK",
    "wifi.ssid": "SSID",
    "wifi.ssid_placeholder": "Select or enter SSID",
    "wifi.password": "Password",
    "wifi.password_placeholder": "Wi-Fi password",
    "wifi.connect": "Connect",
    "wifi.save_restart": "Save & Restart Wi-Fi",
    "wifi.ready_pi_backend": "Ready for Raspberry Pi Wi-Fi backend.",
    "wifi.connecting": "Connecting...",
    "wifi.connect_started": "Connection attempt started. If the device does not reappear, it will return to the previous network automatically.",
    "wifi.connect_success": "Connected successfully.",
    "wifi.connect_failed": "Unable to connect to this Wi-Fi network. The previous connection was restored.",
    "wifi.connect_note": "Connection attempt started. If the device does not reappear, it will return to the previous network automatically.",
    "wifi.select_network": "Select a Wi-Fi network.",
    "wifi.selected_network": "Selected network: ",
    "wifi.not_applied": " not applied. Raspberry Pi backend required.",
    "wifi.backend_required_changes": "Raspberry Pi backend required for live Wi-Fi changes.",
    "settings.operatorSetup": "OPERATOR SETUP",
    "settings.operatorCallsign": "Operator Callsign",
    "settings.saveCallsign": "Save Callsign",
    "settings.systemSettings": "SYSTEM SETTINGS",
    "settings.language": "Language",
    "settings.saveLanguage": "Save Language",
    "settings.languageEnglish": "Language: English",
    "settings.languageItalian": "Language: Italiano",
    "settings.languageSaved": "Language saved.",
    "settings.languageSaving": "Saving language...",
    "settings.languageUnavailable": "Language settings unavailable.",
    "settings.language_note": "Saved locally for the DX Zaza interface.",
    "operator.callsign_placeholder": "Enter your callsign",
    "operator.readonly_note": "Used only for read-only live radio data access. DX Zaza does not transmit.",
    "operator.not_saved": "No operator callsign saved.",
    "operator.saved_prefix": "Operator callsign saved: ",
    "operator.saved": "Operator callsign saved.",
    "operator.enter": "Enter an operator callsign.",
    "operator.saving": "Saving callsign...",
    "operator.settings_unavailable": "Settings unavailable on this device.",
    "operator.not_saved_error": "Callsign not saved.",
    "radio_tools.eyebrow": "RADIO TOOLS",
    "radio_tools.title": "DX Monitoring Quick Reference",
    "radio_tools.badge": "monitoring guide",
    "radio_tools.band_quick_guide": "Band Quick Guide",
    "radio_tools.mode_quick_guide": "Mode Quick Guide",
    "radio_tools.propagation_cheat_sheet": "Propagation Cheat Sheet",
    "radio_tools.dx_monitoring_tips": "DX Monitoring Tips",
    "radio_tools.frequency_reference": "Frequency Reference",
    "radio_tools.product_note": "Product Note",
    "radio_tools.best": "Best:",
    "radio_tools.use": "Use:",
    "radio_tools.10m_best": "daylight / high solar activity",
    "radio_tools.10m_use": "DX, SSB, FT8",
    "radio_tools.15m_best": "daytime DX",
    "radio_tools.15m_use": "DX, CW, SSB, FT8",
    "radio_tools.20m_best": "all-round DX band",
    "radio_tools.20m_use": "worldwide DX, FT8, SSB, CW",
    "radio_tools.30m_best": "digital/CW",
    "radio_tools.30m_use": "FT8, CW",
    "radio_tools.40m_best": "evening/night",
    "radio_tools.40m_use": "regional + DX, SSB, FT8, CW",
    "radio_tools.80m_best": "night/low band",
    "radio_tools.80m_use": "local/regional, grey-line",
    "radio_tools.ft8_note": "Weak signal digital mode, very popular for DX monitoring.",
    "radio_tools.cw_note": "Morse code, efficient for weak signals.",
    "radio_tools.ssb_note": "Voice mode, common on HF bands.",
    "radio_tools.rtty_note": "Digital text mode, useful for contests and DX.",
    "radio_tools.amfm_note": "Less common on HF DX, useful in specific bands/services.",
    "radio_tools.sfi_high": "SFI high = better higher-band chances",
    "radio_tools.kp_low": "Kp low = more stable HF conditions",
    "radio_tools.kp_high": "Kp high = possible geomagnetic disturbance",
    "radio_tools.greyline": "Grey-line = good time for low-band DX",
    "radio_tools.xray": "X-Ray flares = can affect HF propagation",
    "radio_tools.tip_20m": "Start with 20m for general DX activity.",
    "radio_tools.tip_lowbands": "Try 40m and 80m during evening/night.",
    "radio_tools.tip_kp": "Watch Kp before judging poor band conditions.",
    "radio_tools.tip_ft8": "Use FT8 for weak-signal monitoring.",
    "radio_tools.tip_compare": "Compare map activity with propagation page.",
    "radio_tools.tip_filter": "Filter by band/mode to reduce noise.",
    "radio_tools.hf_bands": "HF Bands",
    "radio_tools.satellite_reminder": "Satellite quick reminder",
    "radio_tools.satellite_note": "Always verify current uplink/downlink before operation.",
    "radio_tools.licence_note": "Check your licence and local band plan before transmitting. DX Zaza is for monitoring and information.",
    "radio_tools.product_note_body": "DX Zaza is a monitoring dashboard. It does not transmit. It helps operators understand live activity, bands, modes and propagation.",
    "digital_voice.eyebrow": "DIGITAL VOICE",
    "digital_voice.title": "Digital Voice",
    "digital_voice.badge": "optional module",
    "digital_voice.subtitle": "BlueDV / AMBE module preparation",
    "digital_voice.module_status": "Module status",
    "digital_voice.status": "Status",
    "digital_voice.readiness": "Readiness",
    "digital_voice.ambe_hardware": "AMBE hardware",
    "digital_voice.permissions": "Permissions",
    "digital_voice.audio": "Audio",
    "digital_voice.listen_only": "Listen-only",
    "digital_voice.operation": "Operation",
    "digital_voice.ready": "Ready",
    "digital_voice.check_required": "Check required",
    "digital_voice.locked": "Locked",
    "digital_voice.not_available": "Not available",
    "digital_voice.not_available_yet": "Not available yet",
    "digital_voice.not_configured_short": "Not configured",
    "digital_voice.operation_not_configured": "Operation not configured",
    "digital_voice.readiness_message": "Requires AMBE Server or BlueDV, audio setup, and operator configuration.",
    "digital_voice.not_configured": "Not configured",
    "digital_voice.hardware_detected": "Hardware detected",
    "digital_voice.detected": "Detected",
    "digital_voice.prepared_not_installed": "Digital Voice support is prepared but not installed yet.",
    "digital_voice.hardware_detected_message": "Compatible AMBE hardware detected. BlueDV and AMBE Server are not installed yet.",
    "digital_voice.dvstick": "DVstick",
    "digital_voice.device": "Device",
    "digital_voice.not_detected": "Not detected",
    "digital_voice.supported_hardware": "Supported hardware",
    "digital_voice.bluedv": "BlueDV",
    "digital_voice.installed": "Installed",
    "digital_voice.not_installed": "Not installed",
    "digital_voice.modes": "Modes",
    "digital_voice.planned": "Planned",
    "digital_voice.product_note": "Product note",
    "digital_voice.note_optional": "This page is prepared for optional Digital Voice support.",
    "digital_voice.note_core": "DX Zaza Core remains a monitoring dashboard.",
    "digital_voice.note_requirements": "Digital Voice operation requires compatible AMBE hardware, audio setup, and valid network configuration.",
    "digital_voice.power_warning": "Stable power supply recommended for USB digital voice hardware.",
    "footer.text": "DX Zaza radio monitoring dashboard",
    "keyboard.label": "On-screen keyboard",
    "keyboard.password_entry": "Password entry",
    "keyboard.text_entry": "Text entry",
    "keyboard.done": "Done",
    "keyboard.shift": "Shift",
    "keyboard.symbols": "Symbols",
    "keyboard.space": "Space",
    "keyboard.backspace": "Backspace",
    "keyboard.clear": "Clear"
  },
  "it": {
    "nav.globalMap": "Mappa Globale",
    "nav.liveDxSpots": "Spot Radio Live",
    "nav.hfPropagation": "Propagazione HF",
    "nav.wifiSetup": "Setup Wi-Fi",
    "nav.digitalVoice": "Voce Digitale",
    "nav.radioTools": "Strumenti Radio",
    "brand.subtitle": "mappa radio globale",
    "topbar.eyebrow": "INTELLIGENCE RADIO GLOBALE",
    "time.local": "Ora locale",
    "status.online": "ONLINE",
    "status.partialOnline": "PARZIALE ONLINE",
    "status.offlineFallback": "OFFLINE / MODALITA SICURA",
    "status.dxActive": "Spot radio online",
    "status.dxOffline": "Spot radio offline",
    "status.dxFallbackShown": "riconnessione",
    "status.solarActive": "Propagazione online",
    "status.solarOffline": "Propagazione offline",
    "status.solarFallbackShown": "nuovo tentativo",
    "status.staticPreviewShown": "nuovo tentativo",
    "status.checking": "Controllo stato",
    "status.checking_radio": "Controllo spot radio...",
    "status.checking_propagation": "Controllo propagazione...",
    "status.checking_radio_data": "Controllo dati radio live.",
    "status.checking_propagation_data": "Controllo dati propagazione live.",
    "setup.required": "SETUP RICHIESTO",
    "setup.configure_operator": "Configura il Callsign Operatore per abilitare gli spot radio live.",
    "setup.live_readiness": "Stato live",
    "setup.ready_for_live": "Pronto per live",
    "setup.operator_not_configured": "Operatore non configurato",
    "setup.network_online": "Rete online",
    "setup.network_offline": "Rete offline",
    "filters.band": "Banda",
    "filters.mode": "Modo",
    "filters.search": "Cerca",
    "filters.search_placeholder": "callsign",
    "filters.all_bands": "Tutte le bande",
    "filters.all_modes": "Tutti i modi",
    "global_map.live_badge": "LIVE RADIO SPOTS",
    "global_map.static_preview": "RICONNESSIONE",
    "global_map.live_notice": "Dati radio live attivi.",
    "global_map.preview_notice": "DX cluster non raggiungibile ora: riconnessione automatica in corso.",
    "global_map.no_live_filter": "Nessuno spot radio live disponibile per questo filtro. Prova Tutti i modi.",
    "global_map.no_preview_filter": "Nessuno spot preview corrisponde a questo filtro. Prova Tutti i modi.",
    "global_map.no_filter": "Nessuno spot radio corrisponde a questo filtro. Prova Tutti i modi.",
    "global_map.setup_empty": "Completa il Setup Operatore per abilitare l'attivita live sulla mappa.",
    "global_map.offline_empty": "Nessuna attivita radio live e attualmente disponibile.",
    "summary.live": "RIEPILOGO ATTIVITA LIVE",
    "summary.preview": "IN ATTESA DEI DATI LIVE",
    "summary.active_spots": "Spot attivi",
    "summary.top_band": "Banda top",
    "summary.latest_de": "Ultimo DE",
    "summary.footer_live": "Dati radio live attivi.",
    "summary.footer_preview": "DX cluster non raggiungibile ora: riconnessione automatica.",
    "spots.eyebrow": "SPOT RADIO LIVE",
    "spots.eyebrow_preview": "SPOT RADIO / RICONNESSIONE",
    "spots.title": "Spot Radio Live",
    "spots.title_preview": "Spot Radio",
    "spots.nav_live": "Spot Radio Live",
    "spots.nav_preview": "Spot Radio Live",
    "spots.badge_live": "LIVE RADIO SPOTS",
    "spots.badge_preview": "RICONNESSIONE",
    "spots.notice_live": "Dati radio live attivi.",
    "spots.notice_stale": "Collegamento al DX cluster perso: riconnessione in corso. La lista mostra gli ultimi spot ricevuti.",
    "propagation.notice_stale": "NOAA non raggiungibile: ultimi valori reali ({m} min fa), aggiornamento in corso.",
    "spots.notice_preview": "DX cluster non raggiungibile ora: riconnessione automatica (provo anche altri nodi).",
    "spots.no_results": "Nessuno spot corrisponde ai filtri correnti",
    "spots.setup_empty": "Configura il Callsign Operatore per abilitare gli spot radio live.",
    "spots.offline_empty": "Gli spot radio live sono temporaneamente non disponibili.",
    "spots.just_now": "Ora",
    "spots.table.spotter": "Spotter / DE",
    "spots.table.frequency": "Frequenza",
    "spots.table.band": "Band",
    "spots.table.mode": "Mode",
    "spots.table.country": "Paese/Regione",
    "spots.table.comment": "Commento",
    "spots.table.last_seen": "Ultimo visto",
    "propagation.eyebrow": "HF PROPAGATION",
    "propagation.title": "Meteo Spaziale",
    "propagation.live_badge": "LIVE PROPAGATION DATA",
    "propagation.preview_badge": "NOAA NON RAGGIUNGIBILE",
    "propagation.notice_live": "Dati propagazione live attivi.",
    "propagation.notice_preview": "Dati NOAA non raggiungibili ora: nuovo tentativo ogni minuto. Nessun valore inventato.",
    "propagation.live_message": "Dati propagazione live attivi",
    "propagation.preview_message": "Dati NOAA non ancora disponibili",
    "propagation.preview_shown": "Dati NOAA non ancora disponibili: nuovo tentativo automatico",
    "propagation.global_summary": "Riepilogo condizioni globali",
    "propagation.storm_watch": "Controllo tempesta",
    "propagation.storm_risk_low": "Rischio tempesta basso.",
    "propagation.solar_wind": "Vento solare",
    "propagation.solar_gauges": "Indicatori solari",
    "propagation.solar_conditions": "Condizioni solari",
    "propagation.band_conditions": "Condizioni bande",
    "propagation.greyline_window": "Finestra grey-line",
    "propagation.forecast_outlook": "Previsione",
    "propagation.data_note": "Nota dati",
    "propagation.source_live_note": "Dati propagazione live attivi.",
    "propagation.source_preview_note": "NOAA/SWPC non raggiungibile: i valori compaiono appena torna la connessione.",
    "propagation.kp_index": "Indice Kp",
    "propagation.a_index": "Indice A",
    "propagation.sfi": "Solar Flux / SFI",
    "propagation.xray_class": "X-Ray class",
    "propagation.geomagnetic_field": "Campo geomagnetico",
    "propagation.geomagnetic_load": "Carico geomagnetico",
    "propagation.upper_hf_support": "Supporto bande HF alte",
    "propagation.flare_activity": "Attivita flare",
    "propagation.bz": "Bz",
    "propagation.storm_level": "Livello tempesta",
    "propagation.aurora_risk": "Rischio aurora",
    "propagation.hf_impact": "Impatto HF",
    "wifi.eyebrow": "WI-FI SETUP",
    "wifi.title": "Rete DX Zaza",
    "wifi.pi_setup": "Setup Pi",
    "wifi.subtitle": "Controlla lo stato rete e scansiona le reti Wi-Fi disponibili.",
    "wifi.management": "GESTIONE WI-FI",
    "wifi.coming_soon": "Prossimamente",
    "wifi.setup_mode_required": "Modalita setup richiesta",
    "wifi.management_later": "La gestione Wi-Fi dall'app sara disponibile nella modalita setup.",
    "wifi.network_status": "STATO RETE",
    "wifi.current_mode": "Modalita corrente",
    "wifi.setup_mode": "Modalita setup",
    "wifi.device_network": "Rete dispositivo",
    "wifi.internet": "Internet",
    "wifi.wifi": "Wi-Fi",
    "wifi.ethernet": "Ethernet",
    "wifi.ip_address": "Indirizzo IP",
    "wifi.connected": "Connesso",
    "wifi.disconnected": "Non connesso",
    "wifi.unavailable": "Non disponibile",
    "wifi.read_only": "Sola lettura",
    "wifi.scan_prompt": "Scansiona per vedere le reti Wi-Fi disponibili.",
    "wifi.scan_complete": "Reti Wi-Fi disponibili aggiornate.",
    "wifi.scan_empty": "Nessuna rete Wi-Fi trovata.",
    "wifi.scan_unavailable": "Scansione Wi-Fi non disponibile su questo dispositivo.",
    "wifi.signal": "Segnale",
    "wifi.secured": "Protetta",
    "wifi.open": "Aperta",
    "wifi.current_network": "Rete connessa",
    "wifi.not_connected": "Non connesso",
    "wifi.wifi_country": "Paese Wi-Fi",
    "wifi.available_networks": "RETI DISPONIBILI",
    "wifi.pi_backend": "Backend Pi",
    "wifi.scan": "Scansiona Wi-Fi",
    "wifi.scanning": "Scansione...",
    "wifi.scan_available_pi": "La scansione Wi-Fi live e disponibile sul backend Raspberry Pi.",
    "wifi.scan_backend_required": "Backend Raspberry Pi richiesto per scansione Wi-Fi live.",
    "wifi.connect_network": "CONNETTI RETE",
    "wifi.ssid": "SSID",
    "wifi.ssid_placeholder": "Seleziona o inserisci SSID",
    "wifi.password": "Password",
    "wifi.password_placeholder": "Password Wi-Fi",
    "wifi.connect": "Connetti",
    "wifi.save_restart": "Salva e riavvia Wi-Fi",
    "wifi.ready_pi_backend": "Pronto per backend Wi-Fi Raspberry Pi.",
    "wifi.connecting": "Connessione...",
    "wifi.connect_started": "Tentativo di connessione avviato. Se il dispositivo non ricompare, tornera automaticamente alla rete precedente.",
    "wifi.connect_success": "Connessione riuscita.",
    "wifi.connect_failed": "Impossibile connettersi a questa rete Wi-Fi. La connessione precedente e stata ripristinata.",
    "wifi.connect_note": "Tentativo di connessione avviato. Se il dispositivo non ricompare, tornera automaticamente alla rete precedente.",
    "wifi.select_network": "Seleziona una rete Wi-Fi.",
    "wifi.selected_network": "Rete selezionata: ",
    "wifi.not_applied": " non applicata. Backend Raspberry Pi richiesto.",
    "wifi.backend_required_changes": "Backend Raspberry Pi richiesto per modifiche Wi-Fi live.",
    "settings.operatorSetup": "SETUP OPERATORE",
    "settings.operatorCallsign": "Callsign Operatore",
    "settings.saveCallsign": "Salva Callsign",
    "settings.systemSettings": "IMPOSTAZIONI SISTEMA",
    "settings.language": "Lingua",
    "settings.saveLanguage": "Salva Lingua",
    "settings.languageEnglish": "Lingua: English",
    "settings.languageItalian": "Lingua: Italiano",
    "settings.languageSaved": "Lingua salvata.",
    "settings.languageSaving": "Salvataggio lingua...",
    "settings.languageUnavailable": "Impostazioni lingua non disponibili.",
    "settings.language_note": "Salvato localmente per l'interfaccia DX Zaza.",
    "operator.callsign_placeholder": "Inserisci il tuo callsign",
    "operator.readonly_note": "Usato solo per accesso read-only ai dati radio live. DX Zaza non trasmette.",
    "operator.not_saved": "Nessun callsign operatore salvato.",
    "operator.saved_prefix": "Callsign operatore salvato: ",
    "operator.saved": "Callsign operatore salvato.",
    "operator.enter": "Inserisci un callsign operatore.",
    "operator.saving": "Salvataggio callsign...",
    "operator.settings_unavailable": "Impostazioni non disponibili su questo dispositivo.",
    "operator.not_saved_error": "Callsign non salvato.",
    "radio_tools.eyebrow": "RADIO TOOLS",
    "radio_tools.title": "Riferimento Rapido Monitoraggio DX",
    "radio_tools.badge": "guida monitoraggio",
    "radio_tools.band_quick_guide": "Guida rapida bande",
    "radio_tools.mode_quick_guide": "Guida rapida modi",
    "radio_tools.propagation_cheat_sheet": "Promemoria propagazione",
    "radio_tools.dx_monitoring_tips": "Consigli monitoraggio DX",
    "radio_tools.frequency_reference": "Riferimento frequenze",
    "radio_tools.product_note": "Nota prodotto",
    "radio_tools.best": "Meglio:",
    "radio_tools.use": "Uso:",
    "radio_tools.10m_best": "luce diurna / alta attivita solare",
    "radio_tools.10m_use": "DX, SSB, FT8",
    "radio_tools.15m_best": "DX diurno",
    "radio_tools.15m_use": "DX, CW, SSB, FT8",
    "radio_tools.20m_best": "banda DX tuttofare",
    "radio_tools.20m_use": "DX mondiale, FT8, SSB, CW",
    "radio_tools.30m_best": "digitale/CW",
    "radio_tools.30m_use": "FT8, CW",
    "radio_tools.40m_best": "sera/notte",
    "radio_tools.40m_use": "regionale + DX, SSB, FT8, CW",
    "radio_tools.80m_best": "notte/bande basse",
    "radio_tools.80m_use": "locale/regionale, grey-line",
    "radio_tools.ft8_note": "Modo digitale per segnali deboli, molto usato per monitoraggio DX.",
    "radio_tools.cw_note": "Codice Morse, efficiente con segnali deboli.",
    "radio_tools.ssb_note": "Modo voce, comune sulle bande HF.",
    "radio_tools.rtty_note": "Modo digitale testuale, utile per contest e DX.",
    "radio_tools.amfm_note": "Meno comune nel DX HF, utile in bande/servizi specifici.",
    "radio_tools.sfi_high": "SFI alto = migliori possibilita sulle bande alte",
    "radio_tools.kp_low": "Kp basso = condizioni HF piu stabili",
    "radio_tools.kp_high": "Kp alto = possibile disturbo geomagnetico",
    "radio_tools.greyline": "Grey-line = buon momento per DX su bande basse",
    "radio_tools.xray": "Flare X-Ray = possono influenzare la propagazione HF",
    "radio_tools.tip_20m": "Inizia da 20m per attivita DX generale.",
    "radio_tools.tip_lowbands": "Prova 40m e 80m sera/notte.",
    "radio_tools.tip_kp": "Controlla Kp prima di giudicare male una banda.",
    "radio_tools.tip_ft8": "Usa FT8 per monitoraggio di segnali deboli.",
    "radio_tools.tip_compare": "Confronta attivita mappa con pagina propagazione.",
    "radio_tools.tip_filter": "Filtra per banda/modo per ridurre rumore.",
    "radio_tools.hf_bands": "Bande HF",
    "radio_tools.satellite_reminder": "Promemoria rapido satelliti",
    "radio_tools.satellite_note": "Verifica sempre uplink/downlink correnti prima di operare.",
    "radio_tools.licence_note": "Controlla licenza e band plan locale prima di trasmettere. DX Zaza e per monitoraggio e informazione.",
    "radio_tools.product_note_body": "DX Zaza e una dashboard di monitoraggio. Non trasmette. Aiuta gli operatori a capire attivita live, bande, modi e propagazione.",
    "digital_voice.eyebrow": "VOCE DIGITALE",
    "digital_voice.title": "Voce Digitale",
    "digital_voice.badge": "modulo opzionale",
    "digital_voice.subtitle": "Modulo BlueDV / AMBE",
    "digital_voice.module_status": "Stato modulo",
    "digital_voice.status": "Stato",
    "digital_voice.readiness": "Readiness",
    "digital_voice.ambe_hardware": "Hardware AMBE",
    "digital_voice.permissions": "Permessi",
    "digital_voice.audio": "Audio",
    "digital_voice.listen_only": "Solo ascolto",
    "digital_voice.operation": "Operazione",
    "digital_voice.ready": "Pronto",
    "digital_voice.check_required": "Controllo richiesto",
    "digital_voice.locked": "Bloccato",
    "digital_voice.not_available": "Non disponibile",
    "digital_voice.not_available_yet": "Non disponibile",
    "digital_voice.not_configured_short": "Da configurare",
    "digital_voice.operation_not_configured": "Operazione non configurata",
    "digital_voice.readiness_message": "Richiede AMBE Server o BlueDV, audio e configurazione operatore.",
    "digital_voice.not_configured": "Non configurato",
    "digital_voice.hardware_detected": "Hardware rilevato",
    "digital_voice.detected": "DVstick rilevata",
    "digital_voice.prepared_not_installed": "Il supporto Voce Digitale e preparato ma non ancora installato.",
    "digital_voice.hardware_detected_message": "Hardware AMBE compatibile rilevato. BlueDV e AMBE Server non sono ancora installati.",
    "digital_voice.dvstick": "DVstick",
    "digital_voice.device": "Dispositivo",
    "digital_voice.not_detected": "Non rilevato",
    "digital_voice.supported_hardware": "Hardware supportato",
    "digital_voice.bluedv": "BlueDV",
    "digital_voice.installed": "Installato",
    "digital_voice.not_installed": "Non installato",
    "digital_voice.modes": "Modi",
    "digital_voice.planned": "Pianificato",
    "digital_voice.product_note": "Nota prodotto",
    "digital_voice.note_optional": "Questa pagina e preparata per supporto opzionale Voce Digitale.",
    "digital_voice.note_core": "DX Zaza Core resta una dashboard di monitoraggio.",
    "digital_voice.note_requirements": "La Voce Digitale richiede hardware AMBE compatibile, setup audio e configurazione rete valida.",
    "digital_voice.power_warning": "Alimentazione stabile consigliata per hardware USB Voce Digitale.",
    "footer.text": "Dashboard monitoraggio radio DX Zaza",
    "keyboard.label": "Tastiera su schermo",
    "keyboard.password_entry": "Inserimento password",
    "keyboard.text_entry": "Inserimento testo",
    "keyboard.done": "Fine",
    "keyboard.shift": "Maiusc",
    "keyboard.symbols": "Simboli",
    "keyboard.space": "Spazio",
    "keyboard.backspace": "Cancella",
    "keyboard.clear": "Pulisci"
  }
};

function t(key) {
  const lang = translations[dxZazaState.language] ? dxZazaState.language : "en";
  return translations[lang][key] || translations.en[key] || key;
}

function escapeHtml(value) {
  const element = document.createElement("div");
  element.textContent = String(value ?? "");
  return element.innerHTML;
}

function applyTranslations() {
  document.querySelectorAll("[data-i18n]").forEach((element) => {
    element.textContent = t(element.dataset.i18n);
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((element) => {
    element.setAttribute("placeholder", t(element.dataset.i18nPlaceholder));
  });
  document.querySelectorAll("[data-i18n-title]").forEach((element) => {
    element.setAttribute("title", t(element.dataset.i18nTitle));
  });
  document.documentElement.lang = dxZazaState.language === "it" ? "it" : "en";
  renderLiveStatusCard();
  renderAllDxViews();
  renderPropagationPage();
  renderTouchKeyboard();
  updateLanguageMessage(dxZazaState.language);
  renderSetupReadinessStatus();
  renderOperatorSettings();
  renderNetworkStatus(currentNetworkStatus);
  renderWifiNetworks();
  renderDigitalVoiceStatus(currentDigitalVoiceStatus);
}

const bandFilterOptions = [
  { value: "all", label: "All Bands", labelKey: "filters.all_bands" },
  { value: "70cm", label: "70cm" },
  { value: "10m", label: "10m" },
  { value: "6m", label: "6m" },
  { value: "4m", label: "4m" },
  { value: "2m", label: "2m" },
  { value: "12m", label: "12m" },
  { value: "15m", label: "15m" },
  { value: "17m", label: "17m" },
  { value: "20m", label: "20m" },
  { value: "30m", label: "30m" },
  { value: "40m", label: "40m" },
  { value: "60m", label: "60m" },
  { value: "160m", label: "160m" },
  { value: "80m", label: "80m" }
];

const modeFilterOptions = [
  { value: "all", label: "All Modes", labelKey: "filters.all_modes" },
  { value: "FT8", label: "FT8" },
  { value: "FT4", label: "FT4" },
  { value: "CW", label: "CW" },
  { value: "SSB", label: "SSB" },
  { value: "RTTY", label: "RTTY" },
  { value: "APRS", label: "APRS" },
  { value: "FM", label: "FM" },
  { value: "AM", label: "AM" }
];

// Marker positions are calibrated to dx_zaza_world_map_bg.jpeg (1536x878).
// They are prefix/country/region visual positions, not GPS-exact locations.
const visualMapPositions = {
  "United Kingdom": { x: 45.9, y: 36.2 },
  "Ireland": { x: 44.0, y: 36.5 },
  "Portugal": { x: 43.6, y: 45.8 },
  "Spain": { x: 46.0, y: 45.1 },
  "France": { x: 47.8, y: 40.9 },
  "Belgium": { x: 48.7, y: 38.1 },
  "Netherlands": { x: 49.0, y: 36.5 },
  "Germany": { x: 50.2, y: 37.4 },
  "Switzerland": { x: 49.7, y: 41.2 },
  "Austria": { x: 51.6, y: 40.3 },
  "Italy": { x: 52.0, y: 44.1 },
  "Sweden": { x: 52.8, y: 29.3 },
  "Norway": { x: 50.8, y: 27.5 },
  "Finland": { x: 55.4, y: 27.4 },
  "Denmark": { x: 50.1, y: 34.4 },
  "Poland": { x: 53.1, y: 37.4 },
  "Czech Republic": { x: 51.3, y: 38.9 },
  "Greece": { x: 55.0, y: 47.8 },
  "Croatia": { x: 52.4, y: 43.2 },
  "Bulgaria": { x: 55.0, y: 44.6 },
  "Slovakia": { x: 52.4, y: 39.5 },
  "Slovenia": { x: 51.6, y: 42.0 },
  "Romania": { x: 55.0, y: 42.3 },
  "Ukraine": { x: 57.6, y: 38.5 },
  "Russia": { x: 63.6, y: 31.5 },
  "European Russia": { x: 60.0, y: 36.0 },
  "Turkey": { x: 57.4, y: 46.4 },
  "Israel": { x: 57.0, y: 51.6 },
  "Morocco": { x: 46.8, y: 50.2 },
  "Algeria": { x: 50.0, y: 50.8 },
  "Egypt": { x: 55.2, y: 52.5 },
  "South Africa": { x: 56.6, y: 77.0 },
  "Namibia": { x: 52.8, y: 71.6 },
  "Kenya": { x: 59.5, y: 64.2 },
  "Nigeria": { x: 49.8, y: 59.8 },
  "Ghana": { x: 47.2, y: 61.0 },
  "Tanzania": { x: 59.2, y: 67.0 },
  "United States": { x: 22.7, y: 42.7 },
  "Canada": { x: 22.6, y: 29.0 },
  "Alaska": { x: 11.7, y: 25.5 },
  "Hawaii": { x: 13.9, y: 58.0 },
  "Mexico": { x: 21.5, y: 51.4 },
  "Puerto Rico": { x: 30.2, y: 54.0 },
  "Cuba": { x: 26.1, y: 52.2 },
  "Dominican Republic": { x: 28.3, y: 53.0 },
  "Bahamas": { x: 27.3, y: 50.2 },
  "Jamaica": { x: 26.4, y: 54.0 },
  "Brazil": { x: 34.8, y: 68.8 },
  "Argentina": { x: 31.9, y: 79.3 },
  "Chile": { x: 29.5, y: 78.4 },
  "Uruguay": { x: 34.4, y: 78.0 },
  "Colombia": { x: 27.8, y: 58.6 },
  "Venezuela": { x: 29.4, y: 56.4 },
  "Peru": { x: 28.4, y: 66.0 },
  "Ecuador": { x: 25.8, y: 62.5 },
  "Japan": { x: 82.7, y: 42.5 },
  "China": { x: 74.7, y: 44.0 },
  "South Korea": { x: 80.4, y: 40.6 },
  "India": { x: 68.8, y: 53.6 },
  "Thailand": { x: 73.2, y: 57.0 },
  "Indonesia": { x: 75.2, y: 66.2 },
  "Philippines": { x: 79.2, y: 57.3 },
  "Malaysia": { x: 73.4, y: 59.7 },
  "Singapore": { x: 74.3, y: 61.0 },
  "Australia": { x: 80.4, y: 76.2 },
  "New Zealand": { x: 88.8, y: 82.0 },
  "Fiji": { x: 91.2, y: 68.2 },
  "Papua New Guinea": { x: 82.6, y: 64.7 }
};

const regionalVisualMapPositions = {
  EA1: { x: 45.1, y: 42.6 }, EA2: { x: 46.3, y: 42.4 }, EA3: { x: 47.3, y: 43.5 },
  EA4: { x: 45.9, y: 45.1 }, EA5: { x: 46.8, y: 46.0 }, EA6: { x: 48.1, y: 46.5 },
  EA7: { x: 45.5, y: 47.5 }, EA8: { x: 41.9, y: 51.5 }, EA9: { x: 44.6, y: 49.2 },
  CT1: { x: 43.5, y: 45.7 }, CT2: { x: 43.7, y: 44.1 }, CT3: { x: 40.7, y: 53.5 },
  GM: { x: 45.0, y: 31.5 }, MM: { x: 45.0, y: 31.5 },
  GW: { x: 45.1, y: 37.4 }, MW: { x: 45.1, y: 37.4 },
  GI: { x: 44.6, y: 34.8 }, MI: { x: 44.6, y: 34.8 },
  G: { x: 46.0, y: 36.3 }, M: { x: 46.0, y: 36.3 }, "2E": { x: 46.0, y: 36.3 },
  IK7: { x: 53.2, y: 46.0 }, IZ7: { x: 53.2, y: 46.0 }, I7: { x: 53.2, y: 46.0 },
  UA4: { x: 60.0, y: 36.0 }, R4: { x: 60.0, y: 36.0 },
  KH6: { x: 13.9, y: 58.0 }, NH6: { x: 13.9, y: 58.0 }, WH6: { x: 13.9, y: 58.0 },
  KL: { x: 11.7, y: 25.5 }, NL: { x: 11.7, y: 25.5 }, WL: { x: 11.7, y: 25.5 },
  KP4: { x: 30.2, y: 54.0 }, NP4: { x: 30.2, y: 54.0 }, WP4: { x: 30.2, y: 54.0 }
};

const callsignPrefixMap = [
  { prefixes: ["2E", "GB", "GC", "GD", "GI", "GJ", "GM", "GN", "GP", "GS", "GT", "GU", "GW", "G", "MC", "MD", "MI", "MJ", "MM", "MP", "MS", "MT", "MU", "MW", "M"], country: "United Kingdom", region: "Europe", markerX: 47, markerY: 31 },
  { prefixes: ["IK", "IZ", "IW", "IQ", "IR", "IT", "IU", "II", "I"], country: "Italy", region: "Europe", markerX: 51, markerY: 39 },
  { prefixes: ["DL", "DA", "DB", "DC", "DD", "DF", "DG", "DH", "DJ", "DK", "DM", "DN", "DO", "DP", "DQ", "DR"], country: "Germany", region: "Europe", markerX: 50, markerY: 34 },
  { prefixes: ["F", "FA", "FB", "FC", "FD", "FE", "FF", "FG", "FH", "FI", "FJ", "FK", "FL", "FM", "FN", "FO", "FP", "FQ", "FR", "FS", "FT", "FU", "FV", "FW", "FY"], country: "France", region: "Europe", markerX: 48, markerY: 38 },
  { prefixes: ["EA", "EB", "EC", "ED", "EE", "EF", "EG", "EH", "AM", "AN", "AO"], country: "Spain", region: "Europe", markerX: 46, markerY: 42 },
  { prefixes: ["CT", "CQ", "CR", "CS", "CU"], country: "Portugal", region: "Europe", markerX: 44, markerY: 43 },
  { prefixes: ["PA", "PB", "PC", "PD", "PE", "PF", "PG", "PH", "PI"], country: "Netherlands", region: "Europe", markerX: 49, markerY: 33 },
  { prefixes: ["ON", "OO", "OP", "OQ", "OR", "OS", "OT"], country: "Belgium", region: "Europe", markerX: 49, markerY: 35 },
  { prefixes: ["HB"], country: "Switzerland", region: "Europe", markerX: 50, markerY: 38 },
  { prefixes: ["OE"], country: "Austria", region: "Europe", markerX: 52, markerY: 38 },
  { prefixes: ["SP", "SQ"], country: "Poland", region: "Europe", markerX: 53, markerY: 35 },
  { prefixes: ["OK", "OL"], country: "Czech Republic", region: "Europe", markerX: 51, markerY: 36 },
  { prefixes: ["SM", "SA"], country: "Sweden", region: "Europe", markerX: 52, markerY: 27 },
  { prefixes: ["LA", "LB", "LC", "LD", "LE", "LF", "LG", "LH", "LI", "LJ", "LM", "LN"], country: "Norway", region: "Europe", markerX: 50, markerY: 25 },
  { prefixes: ["OH"], country: "Finland", region: "Europe", markerX: 55, markerY: 26 },
  { prefixes: ["OZ"], country: "Denmark", region: "Europe", markerX: 50, markerY: 31 },
  { prefixes: ["EI"], country: "Ireland", region: "Europe", markerX: 45, markerY: 32 },
  { prefixes: ["SV"], country: "Greece", region: "Europe", markerX: 55, markerY: 44 },
  { prefixes: ["9A"], country: "Croatia", region: "Europe", markerX: 52, markerY: 40 },
  { prefixes: ["LZ"], country: "Bulgaria", region: "Europe", markerX: 55, markerY: 42 },
  { prefixes: ["OM"], country: "Slovakia", region: "Europe", markerX: 52, markerY: 37 },
  { prefixes: ["S5"], country: "Slovenia", region: "Europe", markerX: 51, markerY: 39 },
  { prefixes: ["YO", "YP", "YQ", "YR"], country: "Romania", region: "Europe", markerX: 55, markerY: 39 },
  { prefixes: ["UR", "US", "UT", "UU", "UV", "UW", "UX", "UY", "UZ"], country: "Ukraine", region: "Europe", markerX: 57, markerY: 37 },
  { prefixes: ["UA4", "R4"], country: "Russia", region: "European Russia", markerX: 60, markerY: 36 },
  { prefixes: ["R", "RA", "RK", "RL", "RM", "RN", "RO", "RP", "RQ", "RT", "RU", "RV", "RW", "RX", "RZ", "UA", "UB", "UC", "UD", "UE", "UF", "UG", "UH", "UI", "RC", "RD", "RE", "RF", "RG", "RJ", "RY"], country: "Russia", region: "Europe/Asia", markerX: 62, markerY: 33 },
  { prefixes: ["KH6", "NH6", "WH6"], country: "Hawaii", region: "North America", markerX: 9, markerY: 52 },
  { prefixes: ["KL", "NL", "WL"], country: "Alaska", region: "North America", markerX: 12, markerY: 23 },
  { prefixes: ["AA", "AB", "AC", "AD", "AE", "AF", "AG", "AI", "AJ", "AK", "AL", "K", "N", "W"], country: "United States", region: "North America", markerX: 22, markerY: 39 },
  { prefixes: ["VE", "VA", "VO", "VY"], country: "Canada", region: "North America", markerX: 23, markerY: 29 },
  { prefixes: ["XE"], country: "Mexico", region: "North America", markerX: 20, markerY: 48 },
  { prefixes: ["PY", "PP", "PU", "PR", "PT", "PV", "PW", "PX"], country: "Brazil", region: "South America", markerX: 34, markerY: 68 },
  { prefixes: ["LU", "LW"], country: "Argentina", region: "South America", markerX: 31, markerY: 77 },
  { prefixes: ["CE"], country: "Chile", region: "South America", markerX: 29, markerY: 78 },
  { prefixes: ["CX"], country: "Uruguay", region: "South America", markerX: 34, markerY: 76 },
  { prefixes: ["HK"], country: "Colombia", region: "South America", markerX: 27, markerY: 59 },
  { prefixes: ["YV", "YY"], country: "Venezuela", region: "South America", markerX: 29, markerY: 56 },
  { prefixes: ["OA"], country: "Peru", region: "South America", markerX: 28, markerY: 66 },
  { prefixes: ["HC"], country: "Ecuador", region: "South America", markerX: 25, markerY: 63 },
  { prefixes: ["JA", "JE", "JF", "JG", "JH", "JI", "JJ", "JK", "JL", "JM", "JN", "JO", "JP", "JQ", "JR", "JS", "7J", "7K", "7L", "7M", "7N"], country: "Japan", region: "Asia", markerX: 82, markerY: 41 },
  { prefixes: ["BA", "BD", "BG", "BH", "BI", "BJ", "BL", "BM", "BN", "BO", "BP", "BQ", "BR", "BS", "BT", "BU", "BV", "BW", "BX", "BY", "BZ"], country: "China", region: "Asia", markerX: 75, markerY: 44 },
  { prefixes: ["HL", "DS", "DT", "D7", "D8", "D9"], country: "South Korea", region: "Asia", markerX: 80, markerY: 40 },
  { prefixes: ["VU"], country: "India", region: "Asia", markerX: 69, markerY: 51 },
  { prefixes: ["HS"], country: "Thailand", region: "Asia", markerX: 73, markerY: 55 },
  { prefixes: ["YB", "YC", "YD", "YE", "YF", "YG", "YH"], country: "Indonesia", region: "Asia", markerX: 75, markerY: 64 },
  { prefixes: ["DU", "DV", "DW", "DX", "DY"], country: "Philippines", region: "Asia", markerX: 79, markerY: 56 },
  { prefixes: ["9M2", "9M6", "9M8"], country: "Malaysia", region: "Asia", markerX: 73, markerY: 57 },
  { prefixes: ["9V"], country: "Singapore", region: "Asia", markerX: 74, markerY: 59 },
  { prefixes: ["4X", "4Z"], country: "Israel", region: "Asia", markerX: 58, markerY: 45 },
  { prefixes: ["TA", "TB", "TC", "YM"], country: "Turkey", region: "Asia", markerX: 57, markerY: 42 },
  { prefixes: ["VK"], country: "Australia", region: "Oceania", markerX: 80, markerY: 73 },
  { prefixes: ["ZL"], country: "New Zealand", region: "Oceania", markerX: 88, markerY: 81 },
  { prefixes: ["3D2"], country: "Fiji", region: "Oceania", markerX: 91, markerY: 67 },
  { prefixes: ["P2"], country: "Papua New Guinea", region: "Oceania", markerX: 82, markerY: 64 },
  { prefixes: ["ZS"], country: "South Africa", region: "Africa", markerX: 56, markerY: 73 },
  { prefixes: ["V5"], country: "Namibia", region: "Africa", markerX: 52, markerY: 68 },
  { prefixes: ["CN"], country: "Morocco", region: "Africa", markerX: 47, markerY: 48 },
  { prefixes: ["SU"], country: "Egypt", region: "Africa", markerX: 56, markerY: 49 },
  { prefixes: ["5Z"], country: "Kenya", region: "Africa", markerX: 59, markerY: 61 },
  { prefixes: ["5N"], country: "Nigeria", region: "Africa", markerX: 49, markerY: 58 },
  { prefixes: ["9G"], country: "Ghana", region: "Africa", markerX: 47, markerY: 59 },
  { prefixes: ["5H"], country: "Tanzania", region: "Africa", markerX: 59, markerY: 64 },
  { prefixes: ["7X"], country: "Algeria", region: "Africa", markerX: 50, markerY: 49 },
  { prefixes: ["CO", "CM", "CL"], country: "Cuba", region: "Caribbean", markerX: 25, markerY: 51 },
  { prefixes: ["KP4", "NP4", "WP4"], country: "Puerto Rico", region: "Caribbean", markerX: 30, markerY: 53 },
  { prefixes: ["HI"], country: "Dominican Republic", region: "Caribbean", markerX: 28, markerY: 52 },
  { prefixes: ["C6"], country: "Bahamas", region: "Caribbean", markerX: 27, markerY: 49 },
  { prefixes: ["6Y"], country: "Jamaica", region: "Caribbean", markerX: 26, markerY: 53 }
];

const systemHealthDemo = {
  cpu: "36°C",
  ram: "demo",
  disk: "demo",
  uptime: "demo",
  network: "local display ready"
};

// no invented values: everything shows "—" until real NOAA data has been read
const NO_VALUE = "\u2014";
const propagationDemo = {
  sfi: NO_VALUE,
  kp: NO_VALUE,
  aIndex: NO_VALUE,
  xray: NO_VALUE,
  solarWind: NO_VALUE,
  bz: NO_VALUE,
  storm: NO_VALUE,
  auroraRisk: NO_VALUE,
  hfImpact: NO_VALUE,
  summary: "",
  greyLine: "Grey-line active soon.",
  forecast: "Stable short-term outlook."
};

const propagationBandRatings = [
  { band: "10m", rating: "Fair" },
  { band: "12m", rating: "Fair" },
  { band: "15m", rating: "Good" },
  { band: "17m", rating: "Good" },
  { band: "20m", rating: "Excellent" },
  { band: "30m", rating: "Good" },
  { band: "40m", rating: "Good" },
  { band: "80m", rating: "Fair" }
];

const propagationDemoVariants = [
  { kp: NO_VALUE, sfi: NO_VALUE, aIndex: NO_VALUE, xray: NO_VALUE, solarWind: NO_VALUE, bz: NO_VALUE, storm: NO_VALUE, auroraRisk: NO_VALUE, hfImpact: NO_VALUE }
];

const solarConditionsDemo = [
  { label: "Solar Flux / SFI", value: NO_VALUE, status: NO_VALUE },
  { label: "Kp Index", value: NO_VALUE, status: NO_VALUE },
  { label: "A Index", value: NO_VALUE, status: NO_VALUE },
  { label: "X-Ray Flux", value: NO_VALUE, status: NO_VALUE },
  { label: "Solar Wind", value: NO_VALUE, status: NO_VALUE },
  { label: "Bz", value: NO_VALUE, status: NO_VALUE },
  { label: "Storm Level", value: NO_VALUE, status: NO_VALUE },
  { label: "Aurora Risk", value: NO_VALUE, status: NO_VALUE },
  { label: "HF Impact", value: NO_VALUE, status: NO_VALUE }
];

const dxSpotsLive = [];

function normalizeCallsign(call) {
  const raw = String(call || "").trim().toUpperCase().replace(/\s+/g, "");
  if (!raw) {
    return "";
  }
  const parts = raw.split("/").filter(Boolean);
  if (parts.length === 1) {
    return parts[0];
  }
  const portableSuffixes = ["P", "M", "MM", "AM", "QRP", "QRPP", "PORTABLE", "MOBILE"];
  if (portableSuffixes.includes(parts[parts.length - 1])) {
    return parts.slice(0, -1).join("/");
  }
  return raw;
}

function getCallsignPrefixCandidates(callsign) {
  const normalized = normalizeCallsign(callsign);
  if (!normalized) {
    return [];
  }
  const parts = normalized.split("/").filter(Boolean);
  if (parts.length > 1) {
    return [parts[0], parts[parts.length - 1], normalized];
  }
  return [normalized];
}

function getPrefixRegionForCallsign(callsign) {
  const candidates = getCallsignPrefixCandidates(callsign);
  const prefixEntries = callsignPrefixMap
    .flatMap((entry) => entry.prefixes.map((prefix) => ({ ...entry, matchedPrefix: prefix })))
    .sort((a, b) => b.matchedPrefix.length - a.matchedPrefix.length);
  for (const candidate of candidates) {
    const match = prefixEntries.find((entry) => candidate.startsWith(entry.matchedPrefix));
    if (match) {
      return {
        country: match.country,
        region: match.region,
        markerX: match.markerX,
        markerY: match.markerY,
        matchedPrefix: match.matchedPrefix
      };
    }
  }
  return {
    country: "Unknown",
    region: "Unmapped",
    markerX: 50,
    markerY: 50,
    matchedPrefix: null
  };
}

function clampMapPercent(value) {
  return Math.max(4, Math.min(96, Number(value) || 50));
}

function getVisualMapPosition(country, callsign) {
  const candidates = getCallsignPrefixCandidates(callsign);
  const regionalEntries = Object.entries(regionalVisualMapPositions)
    .sort((a, b) => b[0].length - a[0].length);
  for (const candidate of candidates) {
    const match = regionalEntries.find(([prefix]) => candidate.startsWith(prefix));
    if (match) {
      return {
        markerX: clampMapPercent(match[1].x),
        markerY: clampMapPercent(match[1].y),
        calibrated: true
      };
    }
  }
  const visual = visualMapPositions[country];
  if (visual) {
    return {
      markerX: clampMapPercent(visual.x),
      markerY: clampMapPercent(visual.y),
      calibrated: true
    };
  }
  return {
    markerX: 50,
    markerY: 50,
    calibrated: false
  };
}

function applyPrefixPosition(spot) {
  const region = getPrefixRegionForCallsign(spot.de);
  const visual = getVisualMapPosition(region.country, spot.de);
  return {
    ...spot,
    markerX: visual.markerX,
    markerY: visual.markerY,
    markerCountry: region.country,
    markerRegion: region.region,
    markerPrefix: region.matchedPrefix,
    markerCalibrated: visual.calibrated
  };
}

async function fetchLiveJson(path) {
  const response = await fetch(path, { cache: "no-store" });
  if (!response.ok) {
    throw new Error(path + " " + response.status);
  }
  return response.json();
}

async function postLiveJson(path, payload) {
  const response = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload || {})
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.ok === false) {
    throw new Error(data.error || "Save failed");
  }
  return data;
}

function replaceArrayContents(target, items) {
  target.splice(0, target.length, ...(Array.isArray(items) ? items : []));
}

function normalizeLiveDxSpot(spot) {
  return {
    time: spot.time || "",
    de: spot.de || "SPOTTER",
    frequency: spot.frequency || "14.074 MHz",
    band: spot.band || "Unknown",
    mode: spot.mode || "Unknown",
    country: spot.country || spot.region || "Unknown",
    region: spot.region || "",
    comment: String(spot.comment || "").replace(/[\u0000-\u001f\u007f-\u009f]+/g, " ").trim() || "DX cluster spot",
    lastSeen: spot.lastSeen || "Just now",
    markerX: spot.markerX,
    markerY: spot.markerY
  };
}

function cleanDisplayToken(value) {
  const text = String(value || "").trim();
  const lower = text.toLowerCase();
  if (!text || lower === "unknown" || lower === "unmapped") {
    return "";
  }
  return text;
}

function formatTableToken(value) {
  return cleanDisplayToken(value) || "--";
}

function formatMapMarkerMeta(spot) {
  return [
    cleanDisplayToken(String(spot.frequency || "").replace(" MHz", "")),
    cleanDisplayToken(spot.band),
    cleanDisplayToken(spot.mode)
  ].filter(Boolean).join(" ");
}

function formatCountryRegion(spot) {
  const country = cleanDisplayToken(spot.markerCountry || spot.country);
  const region = cleanDisplayToken(spot.markerRegion || spot.region);
  if (country && region && country !== region) {
    return country + " / " + region;
  }
  return country || region || "Unmapped";
}

function normalizeLiveSolar(data) {
  const ok = Boolean(data && data.ok);
  const v = (x) => (ok && x !== undefined && x !== null && x !== "" ? x : NO_VALUE);
  const next = {
    sfi: v(data.sfi),
    kp: v(data.kp),
    aIndex: v(data.aIndex),
    xray: v(data.xray),
    solarWind: v(data.solarWind),
    bz: v(data.bz),
    storm: v(data.storm),
    auroraRisk: v(data.auroraRisk),
    hfImpact: v(data.hfImpact),
    summary: ok ? (data.summary || "") : ""
  };
  Object.assign(propagationDemo, next);
  propagationDemoVariants.splice(0, propagationDemoVariants.length, next);
}

async function updateDxSpotsFromApi() {
  try {
    const data = await fetchLiveJson("/api/dx-spots");
    dxZazaState.dxSource = data.source || "offline";
    dxZazaState.dxStale = Boolean(data.stale);
    dxZazaState.dxHost = data.host || "";
    dxZazaState.setupRequired = Boolean(data.setupRequired);
    replaceArrayContents(dxSpotsLive, (data.spots || []).map(normalizeLiveDxSpot));
  } catch (error) {
    // one failed poll (app busy/restarting): keep the list, mark it as not fresh
    dxZazaState.dxStale = dxSpotsLive.length > 0;
    if (!dxSpotsLive.length) dxZazaState.dxSource = "offline";
    return;
  }
}

async function updateSolarFromApi() {
  try {
    const data = await fetchLiveJson("/api/solar");
    dxZazaState.solarSource = data.ok ? (data.source || "unavailable") : "unavailable";
    dxZazaState.solarStale = Boolean(data.stale);
    dxZazaState.solarStaleMinutes = data.staleMinutes || 0;
    normalizeLiveSolar(data);
  } catch (error) {
    // the app is restarting: keep what is on screen, the next refresh will update it
    return;
  }
}

let lastLiveSignature = "";
const LIVE_REFRESH_MS = 5000;  // the server holds a live cluster session: this is just a cheap read

async function refreshLiveData() {
  if (!LIVE_MODE) {
    return;
  }
  await Promise.all([
    updateDxSpotsFromApi(),
    updateSolarFromApi()
  ]);
  // the age of each spot changes every second: it must not force a redraw by itself
  const signature = JSON.stringify([dxSpotsLive, propagationDemo, dxZazaState.dxSource,
    dxZazaState.solarSource, dxZazaState.setupRequired, dxZazaState.dxStale, dxZazaState.solarStale, dxZazaState.dxHost], (k, v) => (k === "lastSeen" || k === "ageSeconds" || k === "receivedAt") ? undefined : v);
  if (signature === lastLiveSignature) {
    return;
  }
  lastLiveSignature = signature;
  renderAllDxViews();
  renderLiveStatusCard();
  renderPropagationPage();
  refreshTouchDragScrollContainers();
}

function getTouchScrollRoot() {
  return document.scrollingElement || document.documentElement || document.body;
}

function isTouchScrollFormTarget(target) {
  return Boolean(target && target.closest(
    "input, textarea, select, button, form, label, [contenteditable='true'], [role='button'], .touch-key, .keyboard-key, .touch-keyboard, .virtual-keyboard"
  ));
}

function getTouchScrollTop(element) {
  if (element === document.body || element === document.documentElement) {
    return getTouchScrollRoot().scrollTop;
  }
  return element.scrollTop;
}

function setTouchScrollTop(element, value) {
  if (element === document.body || element === document.documentElement) {
    getTouchScrollRoot().scrollTop = value;
    return;
  }
  element.scrollTop = value;
}

function canTouchScrollElement(element, deltaY) {
  if (!element) {
    return false;
  }
  const scrollElement = (element === document.body || element === document.documentElement) ? getTouchScrollRoot() : element;
  const style = window.getComputedStyle(scrollElement);
  const overflowY = style.overflowY || style.overflow;
  if (!["auto", "scroll", "overlay"].includes(overflowY)) {
    return false;
  }
  const maxScrollTop = Math.max(0, scrollElement.scrollHeight - scrollElement.clientHeight);
  if (maxScrollTop <= 1) {
    return false;
  }
  const currentTop = getTouchScrollTop(element);
  if (deltaY > 0) {
    return currentTop < maxScrollTop;
  }
  if (deltaY < 0) {
    return currentTop > 0;
  }
  return false;
}

function findTouchScrollContainer(target, deltaY) {
  if (document.body.classList.contains("global-map-active")) {
    return null;
  }
  let element = target instanceof Element ? target : null;
  while (element) {
    if (element.matches("[data-touch-scroll-container='true']") && canTouchScrollElement(element, deltaY)) {
      return element;
    }
    element = element.parentElement;
  }
  const activePageScroll = document.querySelector(".page.active .page-scroll");
  if (canTouchScrollElement(activePageScroll, deltaY)) {
    return activePageScroll;
  }
  const activePage = document.querySelector(".page.active");
  if (canTouchScrollElement(activePage, deltaY)) {
    return activePage;
  }
  return null;
}

function findPointerScrollContainer(target, deltaY) {
  if (document.body.classList.contains("global-map-active")) {
    return null;
  }
  const start = target instanceof Element ? target : null;
  const candidates = [
    start?.closest(".table-wrap"),
    start?.closest(".page-scroll"),
    document.querySelector(".page.active .page-scroll")
  ].filter(Boolean);
  return candidates.find((element) => canTouchScrollElement(element, deltaY)) || null;
}

function findAnyPointerScrollContainer(target) {
  if (document.body.classList.contains("global-map-active")) {
    return null;
  }
  const start = target instanceof Element ? target : null;
  const candidates = [
    start?.closest(".table-wrap"),
    start?.closest(".page-scroll"),
    document.querySelector(".page.active .page-scroll")
  ].filter(Boolean);
  return candidates.find((element) => {
    const style = window.getComputedStyle(element);
    const overflowY = style.overflowY || style.overflow;
    return ["auto", "scroll", "overlay"].includes(overflowY) && element.scrollHeight > element.clientHeight + 1;
  }) || null;
}

function debugTouchScroll(message, details) {
  if (typeof window !== "undefined" && window.DX_ZAZA_TOUCH_DEBUG) {
    console.log("[DX Zaza touch]", message, details || "");
  }
}

function resetPointerDragScroll() {
  if (pointerDragScrollContainer) {
    pointerDragScrollContainer.classList.remove("is-drag-scrolling");
  }
  pointerDragScrollActive = false;
  pointerDragScrollId = null;
  pointerDragScrollLastY = 0;
  pointerDragScrollContainer = null;
}

function refreshTouchDragScrollContainers() {
  const root = getTouchScrollRoot();
  [
    root,
    document.body,
    ...document.querySelectorAll(
      ".page-scroll, .page.active, .table-wrap, .spots-panel, .wifi-panel, .propagation-panel, .digital-voice-panel, .radio-tools-panel"
    )
  ].forEach((element) => {
    if (element) {
      element.dataset.touchScrollContainer = "true";
    }
  });
}

function enableTouchDragScroll() {
  refreshTouchDragScrollContainers();
  if (touchDragScrollEnabled) {
    return;
  }
  touchDragScrollEnabled = true;

  document.addEventListener("touchstart", (event) => {
    if (!event.touches || event.touches.length !== 1) {
      touchDragScrollIgnore = true;
      return;
    }
    touchDragScrollIgnore = isTouchScrollFormTarget(event.target);
    touchDragScrollStartY = event.touches[0].clientY;
    touchDragScrollLastY = touchDragScrollStartY;
  }, { passive: true });

  document.addEventListener("touchmove", (event) => {
    if (touchDragScrollIgnore || !event.touches || event.touches.length !== 1) {
      return;
    }
    const currentY = event.touches[0].clientY;
    const deltaY = touchDragScrollLastY - currentY;
    if (Math.abs(deltaY) < 2) {
      return;
    }
    const container = findTouchScrollContainer(event.target, deltaY);
    if (!container) {
      return;
    }
    const scrollElement = (container === document.body || container === document.documentElement) ? getTouchScrollRoot() : container;
    const maxScrollTop = Math.max(0, scrollElement.scrollHeight - scrollElement.clientHeight);
    const currentTop = getTouchScrollTop(container);
    const nextTop = Math.max(0, Math.min(maxScrollTop, currentTop + deltaY));
    if (nextTop === currentTop) {
      return;
    }
    setTouchScrollTop(container, nextTop);
    touchDragScrollLastY = currentY;
    event.preventDefault();
  }, { passive: false });

  document.addEventListener("touchend", () => {
    touchDragScrollIgnore = false;
  }, { passive: true });

  document.addEventListener("touchcancel", () => {
    touchDragScrollIgnore = false;
  }, { passive: true });

  document.addEventListener("pointerdown", (event) => {
    if (isTouchScrollFormTarget(event.target)) {
      resetPointerDragScroll();
      return;
    }
    const container = findAnyPointerScrollContainer(event.target);
    const supportedPointer = ["touch", "pen", "mouse"].includes(event.pointerType);
    if (!supportedPointer || !container) {
      resetPointerDragScroll();
      return;
    }
    pointerDragScrollActive = true;
    pointerDragScrollId = event.pointerId;
    pointerDragScrollLastY = event.clientY;
    pointerDragScrollContainer = container;
    debugTouchScroll("pointerdown", { pointerType: event.pointerType, container: container.className });
  }, { passive: true });

  document.addEventListener("pointermove", (event) => {
    if (!pointerDragScrollActive || event.pointerId !== pointerDragScrollId) {
      return;
    }
    if (event.pointerType === "mouse" && event.buttons !== 1) {
      resetPointerDragScroll();
      return;
    }
    const deltaY = pointerDragScrollLastY - event.clientY;
    if (Math.abs(deltaY) < 1) {
      return;
    }
    const container = pointerDragScrollContainer && canTouchScrollElement(pointerDragScrollContainer, deltaY)
      ? pointerDragScrollContainer
      : findPointerScrollContainer(event.target, deltaY);
    if (!container) {
      return;
    }
    const maxScrollTop = Math.max(0, container.scrollHeight - container.clientHeight);
    const currentTop = container.scrollTop;
    const nextTop = Math.max(0, Math.min(maxScrollTop, currentTop + deltaY));
    if (nextTop === currentTop) {
      return;
    }
    container.scrollTop = nextTop;
    container.classList.add("is-drag-scrolling");
    pointerDragScrollContainer = container;
    pointerDragScrollLastY = event.clientY;
    debugTouchScroll("pointermove", { pointerType: event.pointerType, deltaY, scrollTop: nextTop });
    event.preventDefault();
    event.stopPropagation();
  }, { passive: false });

  document.addEventListener("pointerup", resetPointerDragScroll, { passive: true });
  document.addEventListener("pointercancel", resetPointerDragScroll, { passive: true });
}

function switchPage(pageName) {
  // leaving a page: the on-screen keyboard belongs to a field of that page
  if (typeof closeTouchKeyboard === "function" && activePage !== pageName) closeTouchKeyboard();
  activePage = pageName;
  document.body.classList.toggle("global-map-active", pageName === "global-map");
  document.querySelectorAll(".page").forEach((page) => page.classList.remove("active"));
  document.getElementById("page-" + pageName).classList.add("active");
  document.querySelectorAll(".nav-button").forEach((button) => {
    button.classList.toggle("active", button.dataset.page === pageName);
  });
  refreshTouchDragScrollContainers();
  if (pageName === "global-map") {
    requestAnimationFrame(syncMapVisualLayer);
    if (typeof window.dxzMapShown === "function") window.dxzMapShown();
  }
}

function currentSpots() {
  if (dxZazaState.setupRequired || !isDxLive()) {
    return [];
  }
  const rotated = dxSpotsLive.slice(latestIndex).concat(dxSpotsLive.slice(0, latestIndex));
  return rotated.map(applyPrefixPosition);
}

function getFilteredDxSpots() {
  const selectedBand = dxZazaState.band.toLowerCase();
  const selectedMode = dxZazaState.mode.toLowerCase();
  const search = dxZazaState.search.trim().toUpperCase();
  return currentSpots().filter((spot) => {
    const bandOk = selectedBand === "all" || String(spot.band || "").toLowerCase() === selectedBand;
    const modeOk = selectedMode === "all" || String(spot.mode || "").toLowerCase() === selectedMode;
    const searchOk = !search || spot.de.toUpperCase().includes(search);
    return bandOk && modeOk && searchOk;
  });
}

function getLatestMapSpots() {
  return getFilteredDxSpots().slice(0, 3);
}

function calculateMarkerOffset(spot, index, spots) {
  const standardOffsets = [
    { x: 24, y: -70, side: "right" },
    { x: -24, y: 62, side: "left" },
    { x: -24, y: -82, side: "left" }
  ];
  const closeOffsets = [
    { x: 34, y: -92, side: "right" },
    { x: -34, y: 84, side: "left" },
    { x: -34, y: -116, side: "left" }
  ];
  const hasNearbyMarker = spots.some((other, otherIndex) => {
    return otherIndex !== index && Math.abs(other.markerX - spot.markerX) <= 10 && Math.abs(other.markerY - spot.markerY) <= 10;
  });
  const offsets = hasNearbyMarker ? closeOffsets : standardOffsets;
  return offsets[index] || offsets[offsets.length - 1];
}

function calculateLeaderLine(offset) {
  const labelAnchorX = offset.side === "left" ? -34 : 34;
  const labelAnchorY = offset.y + 24;
  const length = Math.max(36, Math.hypot(labelAnchorX, labelAnchorY));
  const angle = Math.atan2(labelAnchorY, labelAnchorX) * 180 / Math.PI;
  return { length, angle };
}

function isDxLive() {
  // "dx-cluster-live": permanent cluster session (0.5.6+), "dx-cluster-telnet": one-shot read
  return dxZazaState.dxSource === "dx-cluster-live" || dxZazaState.dxSource === "dx-cluster-telnet";
}

function isSolarLive() {
  return dxZazaState.solarSource === "NOAA/SWPC";
}

function setStatusClasses(element, state) {
  if (!element) {
    return;
  }
  ["status-online", "status-partial", "status-offline", "status-live", "status-fallback", "live-source", "fallback-source", "is-live", "is-fallback", "is-partial"].forEach((name) => {
    element.classList.remove(name);
  });
  if (state === "online") {
    element.classList.add("status-online", "status-live", "live-source", "is-live");
  } else if (state === "partial") {
    element.classList.add("status-partial", "status-fallback", "fallback-source", "is-partial");
  } else {
    element.classList.add("status-offline", "status-fallback", "fallback-source", "is-fallback");
  }
}

function renderMapSourceStatus() {
  const live = isDxLive();
  const setupRequired = dxZazaState.setupRequired;
  const badge = document.getElementById("mapSourceBadge");
  const notice = document.getElementById("mapSourceNotice");
  const map = document.getElementById("worldMap");
  const title = document.querySelector("#page-global-map h2");
  const eyebrow = document.querySelector("#page-global-map .map-panel > .section-heading .eyebrow");
  if (badge) {
    badge.textContent = setupRequired ? t("setup.required") : (live ? t("global_map.live_badge") : t("global_map.static_preview"));
    setStatusClasses(badge, live ? "online" : "offline");
  }
  if (title) {
    title.textContent = setupRequired ? t("setup.required") : (live ? "Global Live Map" : "Global Map");
  }
  if (eyebrow) {
    eyebrow.textContent = live ? "GLOBAL LIVE MAP" : "GLOBAL MAP";
  }
  if (notice) {
    notice.textContent = setupRequired ? t(dxZazaState.setupReasonKey) : (live
      ? t("global_map.live_notice")
      : t("global_map.preview_notice"));
    setStatusClasses(notice, live ? "online" : "offline");
  }
  if (map) {
    map.classList.toggle("is-live-source", live);
    map.classList.toggle("is-static-preview", !live);
  }
}

function renderSolarSourceStatus() {
  const live = isSolarLive();
  const badge = document.getElementById("propagationSourceBadge");
  const notice = document.getElementById("solarSourceNotice");
  if (badge) {
    badge.textContent = live ? t("propagation.live_badge") : t("propagation.preview_badge");
    setStatusClasses(badge, live ? "online" : "offline");
  }
  if (notice) {
    notice.textContent = live
      ? (dxZazaState.solarStale ? t("propagation.notice_stale").replace("{m}", dxZazaState.solarStaleMinutes) : t("propagation.notice_live"))
      : t("propagation.notice_preview");
    setStatusClasses(notice, live ? "online" : "offline");
  }
}

function renderLiveStatusCard() {
  const card = document.getElementById("liveStatusCard");
  const title = document.getElementById("liveStatusTitle");
  const dx = document.getElementById("liveStatusDx");
  const solar = document.getElementById("liveStatusSolar");
  if (!card || !title || !dx || !solar) {
    return;
  }
  const dxLive = isDxLive();
  const solarLive = isSolarLive();
  if (dxZazaState.setupRequired) {
    setStatusClasses(card, "offline");
    title.textContent = t("setup.required");
    dx.textContent = t(dxZazaState.setupReasonKey);
    solar.textContent = solarLive ? t("status.solarActive") : t("status.solarOffline");
    const summaryNote = document.getElementById("summarySourceNote");
    if (summaryNote) {
      summaryNote.textContent = t(dxZazaState.setupReasonKey);
      setStatusClasses(summaryNote, "offline");
    }
    renderLiveSpotsSourceBadge();
    renderMapSourceStatus();
    renderSolarSourceStatus();
    return;
  }
  const state = dxLive && solarLive ? "online" : (dxLive || solarLive ? "partial" : "offline");
  setStatusClasses(card, state);
  title.textContent = dxLive && solarLive ? t("status.online") : (dxLive || solarLive ? t("status.partialOnline") : t("status.offlineFallback"));
  dx.textContent = dxLive ? t("status.dxActive") : t("status.dxOffline");
  solar.textContent = solarLive ? t("status.solarActive") : t("status.solarOffline");
  if (!dxLive && !solarLive) {
    solar.textContent += " / " + t("status.staticPreviewShown");
  } else if (!dxLive) {
    dx.textContent += " / " + t("status.dxFallbackShown");
  } else if (!solarLive) {
    solar.textContent += " / " + t("status.solarFallbackShown");
  }
  const summaryNote = document.getElementById("summarySourceNote");
  if (summaryNote) {
    summaryNote.textContent = dxLive ? t("summary.footer_live") : t("summary.footer_preview");
    setStatusClasses(summaryNote, dxLive ? "online" : "offline");
  }
  renderLiveSpotsSourceBadge();
  renderMapSourceStatus();
  renderSolarSourceStatus();
}

function renderLiveSpotsSourceBadge() {
  const badge = document.getElementById("liveSpotsSourceBadge");
  const notice = document.getElementById("liveSpotsSourceNotice");
  const title = document.querySelector("#page-live-spots h2");
  const eyebrow = document.querySelector("#page-live-spots .eyebrow");
  const navButton = document.querySelector(".nav-button[data-page='live-spots']");
  const live = isDxLive();
  const setupRequired = dxZazaState.setupRequired;
  if (title) {
    title.textContent = setupRequired ? t("setup.required") : (live ? t("spots.title") : t("spots.title_preview"));
  }
  if (eyebrow) {
    eyebrow.textContent = live ? t("spots.eyebrow") : t("spots.eyebrow_preview");
  }
  if (navButton) {
    navButton.textContent = live ? t("spots.nav_live") : t("spots.nav_preview");
  }
  if (badge) {
    badge.textContent = setupRequired ? t("setup.required") : (live ? t("spots.badge_live") : t("spots.badge_preview"));
    setStatusClasses(badge, live ? "online" : "offline");
  }
  if (notice) {
    notice.textContent = setupRequired ? t(dxZazaState.setupReasonKey) : (live
      ? (dxZazaState.dxStale ? t("spots.notice_stale") : t("spots.notice_live") + (dxZazaState.dxHost ? " · " + dxZazaState.dxHost : ""))
      : t("spots.notice_preview"));
    setStatusClasses(notice, live ? "online" : "offline");
  }
}

function syncMapVisualLayer() {
  const frame = document.querySelector(".global-map-page .map-image-frame");
  const layer = document.querySelector(".global-map-page .map-visual-layer");
  if (!frame || !layer) {
    return;
  }
  const frameRect = frame.getBoundingClientRect();
  if (!frameRect.width || !frameRect.height) {
    return;
  }
  const mapRatio = 1536 / 878;
  let layerWidth = frameRect.width;
  let layerHeight = layerWidth / mapRatio;
  if (layerHeight > frameRect.height) {
    layerHeight = frameRect.height;
    layerWidth = layerHeight * mapRatio;
  }
  layer.style.width = layerWidth.toFixed(2) + "px";
  layer.style.height = layerHeight.toFixed(2) + "px";
}

function renderMapMarkers() {
  syncMapVisualLayer();
  const markersLayer = document.getElementById("dxMarkers");
  const noResults = document.getElementById("mapNoResults");
  markersLayer.innerHTML = "";
  const mapSpots = getLatestMapSpots();
  if (noResults) {
    noResults.textContent = dxZazaState.setupRequired
      ? t("global_map.setup_empty")
      : (isDxLive() ? t("global_map.no_live_filter") : t("global_map.offline_empty"));
    noResults.hidden = mapSpots.length > 0;
  }
  mapSpots.forEach((spot, index) => {
    const offset = calculateMarkerOffset(spot, index, mapSpots);
    const leaderLine = calculateLeaderLine(offset);
    const marker = document.createElement("button");
    marker.type = "button";
    marker.className = "dx-map-marker" + (spot.markerPrefix ? "" : " unmapped") + (index === 0 ? " hot live-flash" : "");
    marker.style.left = spot.markerX + "%";
    marker.style.top = spot.markerY + "%";
    marker.style.setProperty("--label-x", offset.x + "px");
    marker.style.setProperty("--label-y", offset.y + "px");
    marker.style.setProperty("--line-length", leaderLine.length.toFixed(1) + "px");
    marker.style.setProperty("--line-angle", leaderLine.angle.toFixed(1) + "deg");
    marker.dataset.country = spot.markerCountry || "Unknown";
    marker.dataset.region = spot.markerRegion || "Unmapped";
    marker.dataset.prefix = spot.markerPrefix || "";
    const mapLabel = spot.de || "SPOTTER";
    const markerMeta = formatMapMarkerMeta(spot);
    marker.setAttribute("aria-label", (mapLabel + " " + markerMeta).trim());
    marker.innerHTML = "" +
      "<span class=\"dx-marker-pin\" aria-hidden=\"true\">" +
        "<span class=\"dx-marker-line\"></span>" +
        "<span class=\"dx-marker-dot\"></span>" +
        "<span class=\"dx-marker-label label-" + offset.side + "\">" +
          "<strong class=\"dx-marker-call\">" + mapLabel + "</strong>" +
          "<span class=\"dx-marker-meta\">" + markerMeta.replace(/ /g, " · ") + "</span>" +
        "</span>" +
      "</span>";
    markersLayer.appendChild(marker);
  });
}

function renderDxSpotsTable() {
  const tableBody = document.getElementById("dxTableBody");
  tableBody.innerHTML = "";
  const spots = getFilteredDxSpots();
  if (spots.length === 0) {
    const row = document.createElement("tr");
    const emptyMessage = dxZazaState.setupRequired
      ? t("spots.setup_empty")
      : (isDxLive() ? t("spots.no_results") : t("spots.offline_empty"));
    row.innerHTML = '<td class="no-results-cell" colspan="7">' + emptyMessage + '</td>';
    tableBody.appendChild(row);
    return;
  }
  spots.forEach((spot, index) => {
    const row = document.createElement("tr");
    row.className = index === 0 ? "is-latest" : "";
    row.innerHTML = "" +
      "<td><strong>" + spot.de + "</strong></td>" +
      "<td>" + spot.frequency + "</td>" +
      "<td><span class=\"band-badge\">" + formatTableToken(spot.band) + "</span></td>" +
      "<td><span class=\"mode-badge\">" + formatTableToken(spot.mode) + "</span></td>" +
      "<td>" + formatCountryRegion(spot) + "</td>" +
      "<td class=\"comment-cell\">" + spot.comment + "</td>" +
      "<td class=\"last-seen-cell\">" + (index === 0 ? t("spots.just_now") : spot.lastSeen) + "</td>";
    tableBody.appendChild(row);
  });
}

function renderActivitySummary() {
  const spots = getFilteredDxSpots();
  const bandCounts = spots.reduce((counts, spot) => {
    counts[spot.band] = (counts[spot.band] || 0) + 1;
    return counts;
  }, {});
  const topBand = Object.entries(bandCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || "--";
  document.getElementById("summaryActiveSpots").textContent = String(spots.length);
  document.getElementById("summaryTopBand").textContent = topBand;
  document.getElementById("summaryLatestDx").textContent = spots[0]?.de || "--";
  const summaryEyebrow = document.querySelector(".summary-panel .eyebrow");
  if (summaryEyebrow) {
    summaryEyebrow.textContent = isDxLive() ? t("summary.live") : t("summary.preview");
  }
}

function renderSystemHealth() {
  const panel = document.getElementById("systemHealthPanel");
  if (!panel) {
    return;
  }
  panel.innerHTML = "" +
    "<div class=\"health-row\"><span>CPU Temp</span><strong>" + systemHealthDemo.cpu + "</strong></div>" +
    "<div class=\"health-row\"><span>RAM</span><strong>" + systemHealthDemo.ram + "</strong></div>" +
    "<div class=\"health-row\"><span>Disk</span><strong>" + systemHealthDemo.disk + "</strong></div>" +
    "<div class=\"health-row\"><span>Network</span><strong>" + systemHealthDemo.network + "</strong></div>";
}

function formatClockTime(date, timeZone) {
  return new Intl.DateTimeFormat("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
    timeZone
  }).format(date);
}

function updateClocks() {
  const now = new Date();
  const localClock = document.getElementById("localTimeClock");
  const utcClock = document.getElementById("utcTimeClock");
  if (localClock) {
    localClock.textContent = formatClockTime(now);
  }
  if (utcClock) {
    utcClock.textContent = formatClockTime(now, "UTC");
  }
}

function ratingClass(rating) {
  return String(rating || "").toLowerCase();
}

function badgeClass(status) {
  return String(status || "").toLowerCase().replace(/[^a-z0-9]+/g, "-");
}

function currentPropagationDemo() {
  const variant = propagationDemoVariants[propagationCycle % propagationDemoVariants.length];
  return {
    ...propagationDemo,
    ...variant
  };
}

function renderPropagationSourceStatus() {
  const title = document.getElementById("propagationTitle");
  if (title) {
    title.textContent = t("propagation.title");
  }
  renderSolarSourceStatus();
}

function currentSolarConditions() {
  const data = currentPropagationDemo();
  if (!isSolarLive()) {
    return solarConditionsDemo.map((item) => ({ ...item }));
  }
  return solarConditionsDemo.map((item) => {
    if (item.label === "Solar Flux / SFI") return { ...item, label: t("propagation.sfi"), value: String(data.sfi), status: data.hfImpact || item.status };
    if (item.label === "Kp Index") return { ...item, label: t("propagation.kp_index"), value: String(data.kp), status: data.kp >= 5 ? "Storm" : data.kp >= 4 ? "Active" : "Quiet" };
    if (item.label === "A Index") return { ...item, label: t("propagation.a_index"), value: String(data.aIndex), status: data.aIndex >= 20 ? "Storm" : data.aIndex >= 12 ? "Active" : "Quiet" };
    if (item.label === "X-Ray Flux") return { ...item, value: data.xray, status: String(data.xray).startsWith("M") ? "Active" : "Quiet" };
    if (item.label === "Solar Wind") return { ...item, label: t("propagation.solar_wind"), value: data.solarWind, status: Number.parseInt(data.solarWind, 10) >= 500 ? "Active" : "Quiet" };
    if (item.label === "Bz") return { ...item, label: t("propagation.bz"), value: data.bz, status: String(data.bz).startsWith("-") ? "Fair" : "Good" };
    if (item.label === "Storm Level") return { ...item, label: t("propagation.storm_level"), value: data.storm, status: data.storm };
    if (item.label === "Aurora Risk") return { ...item, label: t("propagation.aurora_risk"), value: data.auroraRisk || item.value, status: data.auroraRisk || item.status };
    if (item.label === "HF Impact") return { ...item, label: t("propagation.hf_impact"), value: data.hfImpact || item.value, status: data.hfImpact || item.status };
    return item;
  });
}

function renderSolarConditions() {
  const sourceNote = isSolarLive() ? t("propagation.live_message") : t("propagation.preview_message");
  const cards = currentSolarConditions().map((item) => (
    "<div class=\"solar-condition-card\">" +
      "<span>" + item.label + "</span>" +
      "<strong>" + item.value + "</strong>" +
      "<em class=\"status-badge " + badgeClass(item.status) + "\">" + item.status + "</em>" +
    "</div>"
  )).join("");
  return "" +
    "<section class=\"prop-card full solar-conditions-card\">" +
      "<h3>" + t("propagation.solar_conditions") + "</h3>" +
      "<div class=\"solar-conditions-grid\">" + cards + "</div>" +
      "<p class=\"demo-source-note\">" + sourceNote + "</p>" +
    "</section>";
}

function renderPropagationPage() {
  const container = document.getElementById("propagationPage");
  if (!container) {
    return;
  }
  const data = currentPropagationDemo();
  renderPropagationSourceStatus();
  const summaryText = isSolarLive() ? t("propagation.live_message") : t("propagation.preview_shown");
  const sourceText = isSolarLive()
    ? t("propagation.source_live_note")
    : t("propagation.source_preview_note");
  const bandCards = propagationBandRatings.map((item) => (
    "<div class=\"band-rating-card " + ratingClass(item.rating) + "\">" +
      "<span>" + item.band + "</span>" +
      "<strong>" + item.rating + "</strong>" +
    "</div>"
  )).join("");
  container.innerHTML = "" +
    "<section class=\"prop-card wide\">" +
      "<h3>" + t("propagation.global_summary") + "</h3>" +
      "<p>" + summaryText + "</p>" +
      "<div class=\"prop-badge-row\">" +
        "<span class=\"prop-badge kp\">Kp " + data.kp + "</span>" +
        "<span class=\"prop-badge\">A " + data.aIndex + "</span>" +
        "<span class=\"prop-badge sfi\">SFI " + data.sfi + "</span>" +
        "<span class=\"prop-badge xray\">X-Ray " + data.xray + "</span>" +
      "</div>" +
    "</section>" +
    "<section class=\"prop-card side storm-card\">" +
      "<h3>" + t("propagation.storm_watch") + "</h3>" +
      "<p>" + t("propagation.storm_risk_low") + "</p>" +
      "<div class=\"prop-meta\">" +
        "<div><span>" + t("propagation.solar_wind") + "</span><strong>" + data.solarWind + "</strong></div>" +
        "<div><span>" + t("propagation.bz") + "</span><strong>" + data.bz + "</strong></div>" +
      "</div>" +
    "</section>" +
    "<section class=\"prop-card full\">" +
      "<h3>" + t("propagation.solar_gauges") + "</h3>" +
      "<div class=\"prop-gauge-grid\">" +
        "<div class=\"prop-gauge\"><span>" + t("propagation.kp_index") + "</span><strong>" + data.kp + "</strong><small>" + t("propagation.geomagnetic_field") + "</small></div>" +
        "<div class=\"prop-gauge\"><span>" + t("propagation.a_index") + "</span><strong>" + data.aIndex + "</strong><small>" + t("propagation.geomagnetic_load") + "</small></div>" +
        "<div class=\"prop-gauge\"><span>" + t("propagation.sfi") + "</span><strong>" + data.sfi + "</strong><small>" + t("propagation.upper_hf_support") + "</small></div>" +
        "<div class=\"prop-gauge\"><span>" + t("propagation.xray_class") + "</span><strong>" + data.xray + "</strong><small>" + t("propagation.flare_activity") + "</small></div>" +
      "</div>" +
    "</section>" +
    renderSolarConditions() +
    "<section class=\"prop-card full\">" +
      "<h3>" + t("propagation.band_conditions") + "</h3>" +
      "<div class=\"band-rating-grid\">" + bandCards + "</div>" +
    "</section>" +
    "<section class=\"prop-card side greyline-card\">" +
      "<h3>" + t("propagation.greyline_window") + "</h3>" +
      "<p>" + data.greyLine + "</p>" +
    "</section>" +
    "<section class=\"prop-card side forecast-card\">" +
      "<h3>" + t("propagation.forecast_outlook") + "</h3>" +
      "<p>" + data.forecast + "</p>" +
    "</section>" +
    "<section class=\"prop-card full source-note-card\">" +
      "<h3>" + t("propagation.data_note") + "</h3>" +
      "<p>" + sourceText + "</p>" +
    "</section>";
}

function simulatePropagationRefresh() {
  propagationCycle = (propagationCycle + 1) % propagationDemoVariants.length;
  renderPropagationPage();
}

function simulateSolarRefresh() {
  renderPropagationPage();
}

function renderSetupReadinessStatus() {
  const networkStatus = document.getElementById("wifiNetworkStatus");
  const readinessStatus = document.getElementById("wifiReadinessStatus");
  if (networkStatus) networkStatus.textContent = t(dxZazaState.networkOnline ? "setup.network_online" : "setup.network_offline");
  if (readinessStatus) readinessStatus.textContent = t(dxZazaState.setupRequired ? "setup.required" : "setup.ready_for_live");
}

function connectionStatusKey(device) {
  if (!device?.available) return "wifi.unavailable";
  return device.connected ? "wifi.connected" : "wifi.disconnected";
}

let currentNetworkStatus = null;

function renderNetworkStatus(network) {
  currentNetworkStatus = network || {};
  network = currentNetworkStatus;
  const wifi = network?.wifi || {};
  const ethernet = network?.ethernet || {};
  const values = {
    wifiNetworkStatus: t(network?.internet?.online ? "setup.network_online" : "setup.network_offline"),
    wifiConnectionStatus: t(connectionStatusKey(wifi)),
    wifiCurrentSsid: wifi.connected && wifi.ssid ? wifi.ssid : "-",
    wifiIpAddress: wifi.connected && wifi.ip ? wifi.ip : "-",
    ethernetConnectionStatus: t(connectionStatusKey(ethernet))
  };
  Object.entries(values).forEach(([id, value]) => {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
  });
}

let availableWifiNetworks = [];

function renderWifiNetworks() {
  const list = document.getElementById("wifiNetworkList");
  const select = document.getElementById("wifiSsidSelect");
  if (select) {
    const selected = select.value;
    select.innerHTML = "<option value=\"\">" + escapeHtml(t("wifi.ssid_placeholder")) + "</option>" +
      availableWifiNetworks.map((network) => "<option value=\"" + escapeHtml(network.ssid) + "\">" + escapeHtml(network.ssid) + "</option>").join("");
    if (availableWifiNetworks.some((network) => network.ssid === selected)) {
      select.value = selected;
    }
  }
  if (!list) return;
  list.innerHTML = availableWifiNetworks.map((network) => {
    const detail = [
      t("wifi.signal") + ": " + network.signal + "%",
      t(network.secured ? "wifi.secured" : "wifi.open"),
      network.connected ? t("wifi.current_network") : ""
    ].filter(Boolean).join(" · ");
    return "<button type=\"button\" class=\"network-option" + (network.connected ? " active" : "") + "\" data-ssid=\"" + escapeHtml(network.ssid) + "\">" +
      "<strong>" + escapeHtml(network.ssid) + "</strong><span>" + escapeHtml(detail) + "</span></button>";
  }).join("");
  list.querySelectorAll("[data-ssid]").forEach((button) => {
    button.addEventListener("click", () => {
      if (select) select.value = button.dataset.ssid || "";
    });
  });
}

async function loadNetworkStatus() {
  try {
    const data = await fetchLiveJson("/api/network/status");
    renderNetworkStatus(data?.network);
  } catch (error) {
    renderNetworkStatus({});
  }
}

async function scanWifiNetworks() {
  const button = document.getElementById("wifiScanButton");
  const message = document.getElementById("wifiScanMessage");
  if (!button || !message) return;
  button.disabled = true;
  message.textContent = t("wifi.scanning");
  try {
    const data = await fetchLiveJson("/api/network/wifi/scan");
    availableWifiNetworks = Array.isArray(data?.networks) ? data.networks : [];
    renderWifiNetworks();
    message.textContent = t(availableWifiNetworks.length ? "wifi.scan_complete" : "wifi.scan_empty");
    await loadNetworkStatus();
  } catch (error) {
    availableWifiNetworks = [];
    renderWifiNetworks();
    message.textContent = t("wifi.scan_unavailable");
  } finally {
    button.disabled = false;
  }
}

function setupWifiScan() {
  loadNetworkStatus();
  const button = document.getElementById("wifiScanButton");
  if (button) button.addEventListener("click", scanWifiNetworks);
  const form = document.getElementById("wifiConnectForm");
  if (form) form.addEventListener("submit", connectWifiNetwork);
}

let currentDigitalVoiceStatus = null;
let currentDigitalVoiceReadiness = null;

function renderDigitalVoiceStatus(status) {
  currentDigitalVoiceStatus = status || currentDigitalVoiceStatus || {};
  const digitalVoice = currentDigitalVoiceStatus || {};
  const dvstick = digitalVoice.dvstick || {};
  const blueDv = digitalVoice.blue_dv || {};
  const ambeServer = digitalVoice.ambe_server || {};
  const hardwareDetected = digitalVoice.module_status === "hardware_detected" || dvstick.detected === true;
  const values = {
    digitalVoiceModuleStatus: hardwareDetected ? t("digital_voice.hardware_detected") : t("digital_voice.not_configured"),
    digitalVoiceModuleMessage: hardwareDetected ? t("digital_voice.hardware_detected_message") : t("digital_voice.prepared_not_installed"),
    digitalVoiceDevice: dvstick.detected ? t("digital_voice.detected") : t("digital_voice.not_detected"),
    digitalVoiceHardware: dvstick.detected && dvstick.type ? dvstick.type : "DVMEGA DVstick 30 / AMBE USB device",
    digitalVoiceBlueDv: blueDv.installed ? t("digital_voice.installed") : t("digital_voice.not_installed"),
    digitalVoiceAmbeServer: ambeServer.installed ? t("digital_voice.installed") : t("digital_voice.not_installed")
  };
  Object.entries(values).forEach(([id, value]) => {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
  });
  const warning = document.getElementById("digitalVoiceWarning");
  if (warning) {
    const warnings = Array.isArray(digitalVoice.warnings) ? digitalVoice.warnings : [];
    warning.hidden = warnings.length === 0;
    warning.textContent = warnings.length ? t("digital_voice.power_warning") : "";
  }
}

function readinessLabel(value, trueKey, falseKey) {
  return value === true ? t(trueKey) : t(falseKey);
}

function renderDigitalVoiceReadiness(readiness) {
  currentDigitalVoiceReadiness = readiness || currentDigitalVoiceReadiness || {};
  const data = currentDigitalVoiceReadiness || {};
  const values = {
    digitalVoiceHardwareReady: readinessLabel(data.hardware_ready, "digital_voice.ready", "digital_voice.not_configured_short"),
    digitalVoiceDvstickReady: readinessLabel(data.hardware_ready, "digital_voice.detected", "digital_voice.not_detected"),
    digitalVoicePermissionsReady: data.permissions_ready === true ? t("digital_voice.ready") : t("digital_voice.check_required"),
    digitalVoiceAmbeServerReady: readinessLabel(data.ambe_server_ready, "digital_voice.ready", "digital_voice.not_installed"),
    digitalVoiceBlueDvReady: readinessLabel(data.blue_dv_ready, "digital_voice.ready", "digital_voice.not_installed"),
    digitalVoiceAudioReady: readinessLabel(data.audio_ready, "digital_voice.ready", "digital_voice.not_configured_short"),
    digitalVoiceTxReady: data.tx_enabled === true ? t("digital_voice.ready") : t("digital_voice.locked"),
    digitalVoiceListenOnly: data.listen_only_available === true ? t("digital_voice.ready") : t("digital_voice.not_available_yet"),
    digitalVoiceOperationReady: data.safe_to_operate === true ? t("digital_voice.ready") : t("digital_voice.operation_not_configured"),
    digitalVoiceReadinessMessage: data.message || t("digital_voice.readiness_message")
  };
  Object.entries(values).forEach(([id, value]) => {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
  });
}

async function loadDigitalVoiceReadiness() {
  try {
    const data = await fetchLiveJson("/api/digital-voice/readiness");
    renderDigitalVoiceReadiness(data?.readiness);
  } catch (error) {
    renderDigitalVoiceReadiness({});
  }
}

async function loadDigitalVoiceStatus() {
  try {
    const data = await fetchLiveJson("/api/digital-voice/status");
    renderDigitalVoiceStatus(data?.digital_voice);
  } catch (error) {
    renderDigitalVoiceStatus({});
  }
}

async function connectWifiNetwork(event) {
  if (event) event.preventDefault();
  const select = document.getElementById("wifiSsidSelect");
  const password = document.getElementById("wifiPassword");
  const button = document.getElementById("wifiConnectButton");
  const message = document.getElementById("wifiConnectMessage");
  const ssid = (select?.value || "").trim();
  if (!ssid) {
    if (message) message.textContent = t("wifi.select_network");
    if (password) password.value = "";
    return;
  }
  if (button) button.disabled = true;
  if (message) message.textContent = t("wifi.connect_started");
  try {
    const response = await fetch("/api/network/wifi/connect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ssid,
        password: password?.value || "",
        timeout_seconds: 45
      })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data.ok === false) {
      if (message) message.textContent = data.message || t("wifi.connect_failed");
      return;
    }
    if (message) message.textContent = data.message || t("wifi.connect_success");
    await loadNetworkStatus();
    await loadSetupReadiness();
  } catch (error) {
    if (message) message.textContent = t("wifi.connect_started");
  } finally {
    if (password) password.value = "";
    if (button) button.disabled = false;
  }
}

function renderOperatorSettings() {
  const input = document.getElementById("operatorCallsign");
  const message = document.getElementById("operatorSetupMessage");
  if (input) input.value = "";
  if (!message) return;
  message.textContent = dxZazaState.operatorConfigured
    ? t("operator.saved_prefix") + dxZazaState.operatorCallsignMasked
    : t("operator.not_saved");
}

function updateOperatorSettings(settings) {
  lastLiveSignature = ""; // operator / QTH changed: redraw distances on the next refresh
  dxZazaState.operatorConfigured = settings?.operator?.configured === true;
  dxZazaState.operatorCallsignMasked = dxZazaState.operatorConfigured
    ? settings?.operator?.callsign_masked || ""
    : "";
  renderOperatorSettings();
}

async function loadSetupReadiness() {
  try {
    const settings = await fetchLiveJson("/api/settings");
    dxZazaState.setupRequired = Boolean(settings?.setup?.required);
    dxZazaState.networkOnline = Boolean(settings?.network?.online);
    const operatorConfigured = Boolean(settings?.operator?.configured);
    updateOperatorSettings(settings);
    dxZazaState.setupReasonKey = !operatorConfigured
      ? "setup.configure_operator"
      : "setup.network_offline";
    renderSetupReadinessStatus();
    renderAllDxViews();
    renderLiveStatusCard();
  } catch (error) {
    dxZazaState.setupRequired = true;
  }
}

async function loadOperatorSettings() {
  const message = document.getElementById("operatorSetupMessage");
  if (!message || !LIVE_MODE) {
    return;
  }
  try {
    const settings = await fetchLiveJson("/api/settings");
    updateOperatorSettings(settings);
  } catch (error) {
    message.textContent = t("operator.settings_unavailable");
  }
}

async function saveOperatorCallsign(event) {
  if (event) {
    event.preventDefault();
  }
  const input = document.getElementById("operatorCallsign");
  const message = document.getElementById("operatorSetupMessage");
  if (!input || !message) {
    return;
  }
  const callsign = input.value.trim().toUpperCase();
  input.value = "";
  if (!callsign) {
    message.textContent = t("operator.enter");
    return;
  }
  message.textContent = t("operator.saving");
  try {
    const data = await postLiveJson("/api/settings/operator", { callsign });
    updateOperatorSettings(data);
    await loadSetupReadiness();
    await refreshLiveData();
  } catch (error) {
    message.textContent = error.message || t("operator.not_saved_error");
  }
}

function updateLanguageMessage(language) {
  const message = document.getElementById("languageSettingsMessage");
  if (!message) {
    return;
  }
  message.textContent = language === "it" ? t("settings.languageItalian") : t("settings.languageEnglish");
}

function getOptionLabel(option) {
  return option?.labelKey ? t(option.labelKey) : option?.label;
}

async function loadLanguageSettings() {
  const select = document.getElementById("uiLanguage");
  const message = document.getElementById("languageSettingsMessage");
  if (!select || !message || !LIVE_MODE) {
    return;
  }
  try {
    const settings = await fetchLiveJson("/api/settings");
    const language = settings?.ui?.language === "it" ? "it" : "en";
    dxZazaState.language = language;
    select.value = language;
    applyTranslations();
    updateLanguageMessage(language);
  } catch (error) {
    message.textContent = t("settings.languageUnavailable");
  }
}

async function saveLanguageSetting(event) {
  if (event) {
    event.preventDefault();
  }
  const select = document.getElementById("uiLanguage");
  const message = document.getElementById("languageSettingsMessage");
  if (!select || !message) {
    return;
  }
  const language = select.value === "it" ? "it" : "en";
  message.textContent = t("settings.languageSaving");
  try {
    const data = await postLiveJson("/api/settings/language", { language });
    dxZazaState.language = data?.ui?.language === "it" ? "it" : "en";
    select.value = dxZazaState.language;
    applyTranslations();
    message.textContent = t("settings.languageSaved");
  } catch (error) {
    message.textContent = error.message || t("settings.languageUnavailable");
  }
}

function setupLanguageSettings() {
  loadLanguageSettings();
  const form = document.getElementById("languageSettingsForm");
  if (form) {
    form.addEventListener("submit", saveLanguageSetting);
  }
}

function setupOperatorSetup() {
  loadOperatorSettings();
  const form = document.getElementById("operatorSetupForm");
  if (form) {
    form.addEventListener("submit", saveOperatorCallsign);
  }
}

const KEYBOARD_ROWS = [
  ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
  ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
  ["a", "s", "d", "f", "g", "h", "j", "k", "l"],
  ["Shift", "z", "x", "c", "v", "b", "n", "m", "Backspace"],
  ["Symbols", "Space", "Clear", "Done"]
];
const KEYBOARD_SYMBOL_ROWS = [
  ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
  ["-", "_", ".", "@", "#", "!", "?", "/", ":", "&"],
  ["+", "=", "*", "(", ")", "$", "%", "'", "\""],
  ["Shift", ",", ";", "<", ">", "[", "]", "~", "Backspace"],
  ["Symbols", "Space", "Clear", "Done"]
];

function keyboardKeyText(key) {
  const actionLabelKey = {
    Shift: "keyboard.shift",
    Symbols: "keyboard.symbols",
    Space: "keyboard.space",
    Backspace: "keyboard.backspace",
    Clear: "keyboard.clear",
    Done: "keyboard.done"
  }[key];
  if (key === "Backspace") return "⌫";
  if (key === "Shift") return keyboardShift ? "⇧ ABC" : "⇧ abc";
  if (key === "Symbols") return keyboardSymbols ? "ABC" : "?123";
  if (actionLabelKey) return t(actionLabelKey);
  return keyboardShift && !keyboardSymbols ? key.toUpperCase() : key;
}

function renderTouchKeyboard() {
  const keysLayer = document.getElementById("touchKeyboardKeys");
  if (!keysLayer) {
    return;
  }
  // build the keys once, then only relabel them: fast on the Raspberry Pi
  if (!keysLayer.dataset.built) {
    keysLayer.innerHTML = "";
    KEYBOARD_ROWS.forEach((row, r) => {
      const rowEl = document.createElement("div");
      rowEl.className = "keyboard-row";
      row.forEach((_, c) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "keyboard-key";
        button.dataset.row = r;
        button.dataset.col = c;
        // act on finger down: no click delay, and the text field keeps the focus
        button.addEventListener("pointerdown", (event) => {
          event.preventDefault();
          button.classList.add("pressed");
          setTimeout(() => button.classList.remove("pressed"), 120);
          handleVirtualKey(button.dataset.key);
        });
        button.addEventListener("click", (event) => event.preventDefault());
        rowEl.appendChild(button);
      });
      keysLayer.appendChild(rowEl);
    });
    keysLayer.dataset.built = "1";
  }
  const rows = keyboardSymbols ? KEYBOARD_SYMBOL_ROWS : KEYBOARD_ROWS;
  keysLayer.querySelectorAll(".keyboard-key").forEach((button) => {
    const key = rows[button.dataset.row][button.dataset.col];
    button.dataset.key = key;
    button.textContent = keyboardKeyText(key);
    button.className = "keyboard-key";
    if (key === "Space") button.classList.add("extra-wide");
    if (["Backspace", "Clear", "Done"].includes(key)) button.classList.add("wide", "action");
    if (key === "Symbols" || key === "Shift") button.classList.add("wide", "warning");
    if (key === "Shift" && keyboardShift) button.classList.add("on");
  });
  updateKeyboardPreview();
}

function updateKeyboardPreview() {
  const preview = document.getElementById("touchKeyboardPreview");
  if (!preview) return;
  if (!activeKeyboardInput) { preview.textContent = ""; return; }
  const value = activeKeyboardInput.value || "";
  const secret = activeKeyboardInput.type === "password";
  preview.textContent = secret ? "•".repeat(value.length) : value;
  preview.classList.toggle("empty", !value);
  if (!value) preview.textContent = activeKeyboardInput.placeholder || "";
}

function keepInputAboveKeyboard() {
  const keyboard = document.getElementById("touchKeyboard");
  if (!keyboard || !activeKeyboardInput) return;
  const height = keyboard.getBoundingClientRect().height || 260;
  document.documentElement.style.setProperty("--kb-h", Math.round(height) + "px");
  // after the padding is applied, move the field into the free space above the keyboard
  requestAnimationFrame(() => requestAnimationFrame(() => {
    const input = activeKeyboardInput;
    if (!input) return;
    const kbTop = window.innerHeight - height;
    const rect = input.getBoundingClientRect();
    const wanted = Math.max(70, (kbTop - rect.height) / 2);
    const delta = rect.top - wanted;
    if (Math.abs(delta) < 8) return;
    let box = input.parentElement;
    while (box && box !== document.body) {
      const style = getComputedStyle(box);
      if (/(auto|scroll)/.test(style.overflowY) && box.scrollHeight > box.clientHeight) break;
      box = box.parentElement;
    }
    if (box && box !== document.body) box.scrollTop += delta;
    else window.scrollBy(0, delta);
  }));
}

function openTouchKeyboard(inputElement) {
  activeKeyboardInput = inputElement;
  setActiveKeyboardSelectionFromInput(inputElement);
  const keyboard = document.getElementById("touchKeyboard");
  const label = document.getElementById("touchKeyboardLabel");
  if (!keyboard) {
    return;
  }
  if (label) {
    label.textContent = inputElement.id === "wifiPassword" ? t("keyboard.password_entry") : t("keyboard.text_entry");
  }
  // no system keyboard on top of ours; always start on the letters
  inputElement.setAttribute("inputmode", "none");
  keyboardSymbols = false;
  keyboardShift = inputElement.type !== "password";   // callsigns in capitals, passwords as typed
  keyboard.hidden = false;
  document.body.classList.add("keyboard-open");
  focusActiveKeyboardInput();
  renderTouchKeyboard();
  keepInputAboveKeyboard();
}

function closeTouchKeyboard() {
  const keyboard = document.getElementById("touchKeyboard");
  if (keyboard) {
    keyboard.hidden = true;
  }
  document.body.classList.remove("keyboard-open");
  if (activeKeyboardInput) activeKeyboardInput.blur();
  activeKeyboardInput = null;
  activeKeyboardSelectionStart = null;
  activeKeyboardSelectionEnd = null;
}

function focusActiveKeyboardInput() {
  if (!activeKeyboardInput) {
    return;
  }
  activeKeyboardInput.focus({ preventScroll: true });
}

function setActiveKeyboardSelectionFromInput(inputElement) {
  if (!inputElement) {
    return;
  }
  const fallback = inputElement.value.length;
  activeKeyboardSelectionStart = typeof inputElement.selectionStart === "number" ? inputElement.selectionStart : fallback;
  activeKeyboardSelectionEnd = typeof inputElement.selectionEnd === "number" ? inputElement.selectionEnd : activeKeyboardSelectionStart;
}

function getActiveKeyboardSelection() {
  if (!activeKeyboardInput) {
    return { start: 0, end: 0 };
  }
  const length = activeKeyboardInput.value.length;
  const start = typeof activeKeyboardSelectionStart === "number" ? activeKeyboardSelectionStart : length;
  const end = typeof activeKeyboardSelectionEnd === "number" ? activeKeyboardSelectionEnd : start;
  return {
    start: Math.max(0, Math.min(start, length)),
    end: Math.max(0, Math.min(end, length))
  };
}

function setActiveKeyboardCursor(position) {
  if (!activeKeyboardInput) {
    return;
  }
  const nextPosition = Math.max(0, Math.min(position, activeKeyboardInput.value.length));
  activeKeyboardSelectionStart = nextPosition;
  activeKeyboardSelectionEnd = nextPosition;
  focusActiveKeyboardInput();
  if (typeof activeKeyboardInput.setSelectionRange === "function") {
    activeKeyboardInput.setSelectionRange(nextPosition, nextPosition);
  }
}

function updateActiveInput(value) {
  if (!activeKeyboardInput) {
    return;
  }
  const { start, end } = getActiveKeyboardSelection();
  activeKeyboardInput.value = activeKeyboardInput.value.slice(0, start) + value + activeKeyboardInput.value.slice(end);
  const nextPosition = start + value.length;
  setActiveKeyboardCursor(nextPosition);
  activeKeyboardInput.dispatchEvent(new Event("input", { bubbles: true }));
  updateKeyboardPreview();
}

function toggleShift() {
  keyboardShift = !keyboardShift;
  renderTouchKeyboard();
}

function backspaceActiveInput() {
  if (!activeKeyboardInput) {
    return;
  }
  const { start, end } = getActiveKeyboardSelection();
  if (start !== end) {
    activeKeyboardInput.value = activeKeyboardInput.value.slice(0, start) + activeKeyboardInput.value.slice(end);
    setActiveKeyboardCursor(start);
  } else if (start > 0) {
    activeKeyboardInput.value = activeKeyboardInput.value.slice(0, start - 1) + activeKeyboardInput.value.slice(start);
    setActiveKeyboardCursor(start - 1);
  }
  activeKeyboardInput.dispatchEvent(new Event("input", { bubbles: true }));
  updateKeyboardPreview();
}

function clearActiveInput() {
  if (!activeKeyboardInput) {
    return;
  }
  activeKeyboardInput.value = "";
  setActiveKeyboardCursor(0);
  activeKeyboardInput.dispatchEvent(new Event("input", { bubbles: true }));
  updateKeyboardPreview();
}

function handleVirtualKey(key) {
  if (key === "Done") {
    closeTouchKeyboard();
    return;
  }
  if (key === "Shift") {
    toggleShift();
    return;
  }
  if (key === "Symbols") {
    keyboardSymbols = !keyboardSymbols;
    renderTouchKeyboard();
    return;
  }
  if (key === "Backspace") {
    backspaceActiveInput();
    return;
  }
  if (key === "Clear") {
    clearActiveInput();
    return;
  }
  if (key === "Space") {
    updateActiveInput(" ");
    return;
  }
  updateActiveInput(keyboardSymbols ? key : (keyboardShift ? key.toUpperCase() : key));
}

function setupTouchKeyboard() {
  renderTouchKeyboard();
  document.querySelectorAll("[data-touch-keyboard='true']").forEach((input) => {
    input.setAttribute("inputmode", "none");
    input.addEventListener("focus", () => openTouchKeyboard(input));
    input.addEventListener("click", () => {
      openTouchKeyboard(input);
      setActiveKeyboardSelectionFromInput(input);
    });
    input.addEventListener("touchstart", () => openTouchKeyboard(input), { passive: true });
    input.addEventListener("select", () => setActiveKeyboardSelectionFromInput(input));
    input.addEventListener("keyup", () => setActiveKeyboardSelectionFromInput(input));
    input.addEventListener("input", () => setActiveKeyboardSelectionFromInput(input));
  });
  document.querySelectorAll("[data-key='Done']").forEach((button) => {
    button.addEventListener("click", closeTouchKeyboard);
  });
}

function filterDxSpots() {
  renderDxSpotsTable();
}

function renderFilterOptions(select, options) {
  select.innerHTML = options.map((option) => '<option value="' + option.value + '">' + getOptionLabel(option) + '</option>').join("");
}

function getAvailableModeFilterOptions() {
  const presentModes = new Set(currentSpots().map((spot) => String(spot.mode || "").trim()).filter((mode) => {
    const normalized = mode.toLowerCase();
    return mode && normalized !== "unknown" && normalized !== "unmapped";
  }));
  const options = [modeFilterOptions[0]];
  modeFilterOptions.slice(1).forEach((option) => {
    if (presentModes.has(option.value)) {
      options.push(option);
    }
  });
  Array.from(presentModes).sort().forEach((mode) => {
    if (!options.some((option) => option.value === mode)) {
      options.push({ value: mode, label: mode });
    }
  });
  return options;
}

function syncModeFilterOptions() {
  const options = getAvailableModeFilterOptions();
  if (dxZazaState.mode !== "all" && !options.some((option) => option.value === dxZazaState.mode)) {
    dxZazaState.mode = "all";
  }
  document.querySelectorAll("[data-filter='mode']").forEach((select) => {
    renderFilterOptions(select, options);
  });
  return options;
}

function syncFilterControls() {
  const currentModeOptions = syncModeFilterOptions();
  document.querySelectorAll("[data-filter='band']").forEach((select) => {
    select.value = dxZazaState.band;
  });
  document.querySelectorAll("[data-filter='mode']").forEach((select) => {
    select.value = dxZazaState.mode;
  });
  const search = document.getElementById("callsignSearch");
  if (search) {
    search.value = dxZazaState.search;
  }
  const activeFilterBadge = document.getElementById("activeFilterBadge");
  if (activeFilterBadge) {
    const bandLabel = getOptionLabel(bandFilterOptions.find((option) => option.value === dxZazaState.band)) || t("filters.all_bands");
    const modeLabel = getOptionLabel(currentModeOptions.find((option) => option.value === dxZazaState.mode)) || t("filters.all_modes");
    activeFilterBadge.textContent = bandLabel + " / " + modeLabel;
  }
}

function renderAllDxViews() {
  syncFilterControls();
  renderMapMarkers();
  renderDxSpotsTable();
  renderActivitySummary();
  refreshTouchDragScrollContainers();
}

function updateGlobalFilters(band, mode) {
  if (band !== undefined) {
    dxZazaState.band = band || "all";
  }
  if (mode !== undefined) {
    dxZazaState.mode = mode || "all";
  }
  syncFilterControls();
  renderAllDxViews();
}

function setupFilterListeners() {
  document.querySelectorAll("[data-filter='band']").forEach((select) => {
    renderFilterOptions(select, bandFilterOptions);
    select.addEventListener("change", () => updateGlobalFilters(select.value, undefined));
  });
  document.querySelectorAll("[data-filter='mode']").forEach((select) => {
    select.addEventListener("change", () => updateGlobalFilters(undefined, select.value));
  });
  const search = document.getElementById("callsignSearch");
  if (search) {
    search.addEventListener("input", () => {
      dxZazaState.search = search.value;
      renderAllDxViews();
    });
  }
  syncFilterControls();
}

function simulateRealtimeUpdates() {
  let busy = false;
  setInterval(async () => {
    if (busy || document.body.classList.contains("keyboard-open")) {
      return;
    }
    busy = true;
    refreshTick += 1;
    if (refreshTick % 12 === 0) lastLiveSignature = "";
    try {
      if (LIVE_MODE) {
        await refreshLiveData();
      } else {
        latestIndex = dxSpotsLive.length ? (latestIndex + 1) % dxSpotsLive.length : 0;
        renderMapMarkers();
        renderDxSpotsTable();
        renderActivitySummary();
        simulatePropagationRefresh();
      }
    } finally {
      busy = false;
    }
  }, LIVE_MODE ? LIVE_REFRESH_MS : 2500);
}

setInterval(updateClocks, 1000);

window.addEventListener("resize", () => requestAnimationFrame(syncMapVisualLayer), { passive: true });
window.addEventListener("orientationchange", () => requestAnimationFrame(syncMapVisualLayer), { passive: true });

document.querySelectorAll(".nav-button").forEach((button) => {
  button.addEventListener("click", () => switchPage(button.dataset.page));
});

document.body.classList.toggle("global-map-active", activePage === "global-map");
updateClocks();
setupFilterListeners();
renderLiveStatusCard();
renderAllDxViews();
renderPropagationPage();
loadSetupReadiness();
setupOperatorSetup();
setupLanguageSettings();
setupWifiScan();
loadDigitalVoiceStatus();
loadDigitalVoiceReadiness();
setupTouchKeyboard();
enableTouchDragScroll();
refreshLiveData();
simulateRealtimeUpdates();
