/* DX Zaza — signal decoders for the Listen Live player.
   - FT8 / FT4: ft8_lib by Karlis Goba (MIT licence), compiled to WebAssembly (dx-zaza-ftx-wasm.js).
     Audio is collected in UTC time slots (15 s FT8, 7.5 s FT4) and decoded at the end of each slot,
     like WSJT-X does.
   - CW: our own decoder: finds the tone, follows its on/off keying, learns the speed by itself and
     turns dits and dahs into text.
   Everything runs on this computer, from the audio the KiwiSDR sends: nothing is sent anywhere.
   Works in the browser and in Node (for the tests). */
(function (root) {
  "use strict";

  // ------------------------------------------------------------------ resampling to 12 kHz
  class Resampler {
    constructor(rateIn, rateOut) { this.set(rateIn, rateOut); }
    set(rateIn, rateOut) { this.step = rateIn / rateOut; this.pos = 0; this.last = 0; this.same = Math.abs(rateIn - rateOut) < 1; }
    run(x) {
      if (this.same) return x;
      const out = [];
      let p = this.pos;
      while (p < x.length) {
        const i = Math.floor(p), f = p - i;
        const a = i === 0 ? this.last : x[i - 1], b = x[i];   // index -1 = last sample of the previous chunk
        out.push(a + (b - a) * f);
        p += this.step;
      }
      this.pos = p - x.length;
      this.last = x[x.length - 1];
      return Float32Array.from(out);
    }
  }

  // ------------------------------------------------------------------ FT8 / FT4
  // compiled once, in the background (browsers do not allow a synchronous build on the page)
  let wasm = null;
  const ready = (function load() {
    const b64 = root.DXZ_FTX_WASM;
    if (!b64 || typeof WebAssembly === "undefined") return Promise.resolve(null);
    try {
      const bin = typeof atob === "function" ? Uint8Array.from(atob(b64), (c) => c.charCodeAt(0)) : Buffer.from(b64, "base64");
      const env = { pow: Math.pow, log10: Math.log10, log: Math.log, exp: Math.exp, cos: Math.cos, sin: Math.sin, atan2: Math.atan2, tanh: Math.tanh };
      return WebAssembly.instantiate(bin, { env }).then((r) => (wasm = r.instance.exports)).catch(() => null);
    } catch (_) { return Promise.resolve(null); }
  })();
  function ftxModule() { return wasm; }

  // one decoder at a time (the player has one receiver); onDecodes(list, slotStartMs) after every slot
  class FtxDecoder {
    constructor(protocol, opts) {
      this.protocol = protocol === "ft4" ? "ft4" : "ft8";
      this.slotMs = this.protocol === "ft4" ? 7500 : 15000;
      this.now = (opts && opts.now) || (() => Date.now());
      this.onDecodes = (opts && opts.onDecodes) || (() => {});
      this.x = null;
      this.ok = true;
      this.rs = null;
      this.slot = null;
      this.fill = 0;
      this.blocks = 0;
    }

    begin(slot, msIntoSlot) {
      this.slot = slot;
      // joined late in this slot: its messages are cut, the first useful decode is at the end of the next one
      this.partial = msIntoSlot > 2500;
      if (!this.firstAt) this.firstAt = (slot + (this.partial ? 2 : 1)) * this.slotMs;
      this.bs = this.x.ftx_start(this.protocol === "ft4" ? 1 : 0);
      this.buf = new Float32Array(this.bs);
      this.fill = 0;
      this.blocks = 0;
      // started in the middle of a slot: silence for the part we missed keeps the timing right
      let pad = Math.round(Math.max(0, msIntoSlot) * 12);
      while (pad > 0) { const n = Math.min(pad, this.bs - this.fill); this.fill += n; pad -= n; if (this.fill === this.bs) this.flush(); }
    }

    flush() {
      const inp = new Float32Array(this.x.memory.buffer, this.x.ftx_input(), this.bs);
      inp.set(this.buf);
      this.buf.fill(0);
      this.x.ftx_process();
      this.fill = 0;
      this.blocks++;
    }

    // samples: Float32Array (-1..1) at `rate` Hz, just received
    push(samples, rate) {
      if (!this.ok || !samples || !samples.length) return;
      if (!this.x) { this.x = ftxModule(); if (!this.x) return; }
      if (!this.rs || this.rs.rateIn !== rate) { this.rs = new Resampler(rate, 12000); this.rs.rateIn = rate; }
      const t = this.now();
      const slot = Math.floor(t / this.slotMs);
      if (this.slot === null) this.begin(slot, t - slot * this.slotMs);
      else if (slot !== this.slot) { this.finish(); this.begin(slot, 0); }
      const x = this.rs.run(samples);
      let i = 0;
      while (i < x.length) {
        const n = Math.min(x.length - i, this.bs - this.fill);
        this.buf.set(x.subarray(i, i + n), this.fill);
        this.fill += n; i += n;
        if (this.fill === this.bs) this.flush();
      }
    }

    finish() {
      const full = (this.slotMs / 1000) / (this.protocol === "ft4" ? 0.048 : 0.16);
      if (this.partial || this.blocks < full * 0.7) return;   // joined late, or too little audio (connection gap)
      const n = this.x.ftx_decode();
      const list = [];
      if (n > 0) {
        const mem = new Uint8Array(this.x.memory.buffer);
        const o = this.x.ftx_output();
        let e = o;
        while (mem[e]) e++;
        let text = "";
        for (let i = o; i < e; i++) text += String.fromCharCode(mem[i]);
        text.split("\n").forEach((line) => {
          const p = line.split("\t");
          if (p.length >= 4 && p[3]) list.push({ snr: Number(p[0]), dt: Number(p[1]) / 10, hz: Number(p[2]), text: p.slice(3).join(" ").trim() });
        });
        list.sort((a, b) => a.hz - b.hz);
      }
      this.onDecodes(list, this.slot * this.slotMs);
    }

    stop() { this.ok = false; }
  }

  // ------------------------------------------------------------------ CW
  const MORSE = {
    ".-": "A", "-...": "B", "-.-.": "C", "-..": "D", ".": "E", "..-.": "F", "--.": "G", "....": "H", "..": "I", ".---": "J",
    "-.-": "K", ".-..": "L", "--": "M", "-.": "N", "---": "O", ".--.": "P", "--.-": "Q", ".-.": "R", "...": "S", "-": "T",
    "..-": "U", "...-": "V", ".--": "W", "-..-": "X", "-.--": "Y", "--..": "Z",
    ".----": "1", "..---": "2", "...--": "3", "....-": "4", ".....": "5", "-....": "6", "--...": "7", "---..": "8", "----.": "9", "-----": "0",
    ".-.-.-": ".", "--..--": ",", "..--..": "?", "-..-.": "/", "-...-": "=", ".-.-.": "+", "-....-": "-", ".--.-.": "@", "---...": ":",
    "-.--.": "(", "-.--.-": ")", ".----.": "'", "-.-.--": "!", "...-.-": "<SK>", ".-...": "<AS>", "-.-.-": "<KA>", "........": "<HH>",
  };

  class CwDecoder {
    // onText(str) gets every new character (" " between words); onInfo({wpm, hz, snr, key})
    constructor(opts) {
      opts = opts || {};
      this.onText = opts.onText || (() => {});
      this.onInfo = opts.onInfo || (() => {});
      this.lo = opts.lo || 300;
      this.hi = opts.hi || 900;
      this.rate = 0;
      this.reset();
    }

    reset() {
      this.tone = 0;                 // Hz, 0 = not found yet
      this.hist = new Float32Array(0);
      this.histFill = 0;
      this.blockN = 0; this.acc = null; this.accN = 0;
      this.sig = 0; this.noise = 0;
      this.key = false; this.run = 0; this.pend = 0; this.sm = 0;   // ms in the current state
      this.dit = 60;                    // ms (20 WPM to start)
      this.code = "";
      this.spaceSent = true;
      this.lastInfo = 0;
      this.clock = 0;                   // ms of audio seen
      this.marks = [];
      this.seen = [];
      this.held = [];
      this.learned = false;
      this.queue = [];
    }

    setRate(rate) {
      this.rate = rate;
      this.blockN = Math.max(16, Math.round(rate * 0.004));    // 4 ms steps
      this.hist = new Float32Array(Math.round(rate * 0.75));     // last 0.75 s for finding the tone
      this.histFill = 0;
    }

    // power of one frequency in a buffer (Goertzel)
    static power(x, from, n, hz, rate) {
      const w = 2 * Math.PI * hz / rate, c = 2 * Math.cos(w);
      let s1 = 0, s2 = 0;
      for (let i = 0; i < n; i++) { const s = x[from + i] + c * s1 - s2; s2 = s1; s1 = s; }
      return (s1 * s1 + s2 * s2 - c * s1 * s2) / (n * n);
    }

    findTone() {
      const x = this.hist, n = x.length;
      let best = 0, bestP = 0;
      const ps = [];
      for (let hz = this.lo; hz <= this.hi; hz += 10) {
        const p = CwDecoder.power(x, 0, n, hz, this.rate);
        ps.push(p);
        if (p > bestP) { bestP = p; best = hz; }
      }
      ps.sort((a, b) => a - b);
      const med = ps[Math.floor(ps.length / 2)] || 1e-12;
      // a real tone stands well above the rest of the passband, and keeps coming back at the same place
      const clear = bestP > med * 20;
      const same = clear && this.tone && Math.abs(best - this.tone) <= 25;
      this.seen.push(same ? 1 : 0);
      if (this.seen.length > 8) this.seen.shift();
      if (clear && !same) {
        // a new tone: take it if the old one is gone (or there was none)
        if (!this.tone || this.seen.reduce((a, b) => a + b, 0) === 0) { this.tone = best; this.sig = 0; this.noise = 0; this.seen = [1]; this.held = []; }
      } else if (same) this.tone = this.tone * 0.7 + best * 0.3;
    }

    // the tone was confirmed at least twice in the last 4 seconds: decode; otherwise it is only noise
    get present() { return this.seen.reduce((a, b) => a + b, 0) >= 2; }

    push(samples, rate) {
      if (!samples || !samples.length) return;
      if (rate !== this.rate) this.setRate(rate);
      for (let i = 0; i < samples.length; i++) {
        // keep the last 0.75 s for the tone search, look again twice a second
        this.hist[this.histFill++] = samples[i];
        if (this.histFill === this.hist.length) {
          const had = this.tone;
          this.findTone();
          if (!had && this.tone) {
            // tone just found: read the last 0.75 s too, so the first letters are not lost
            for (let k = 0; k < this.hist.length; k++) this.sample(this.hist[k]);
            this.trimHist();
            continue;
          }
          this.trimHist();
        }
        if (this.tone) this.sample(samples[i]);
      }
    }

    trimHist() {
      const keep = Math.floor(this.hist.length / 3);
      this.hist.copyWithin(0, this.hist.length - keep);
      this.histFill = keep;
    }

    sample(v) {
      if (!this.acc || this.acc.length !== this.blockN * 2) { this.acc = new Float32Array(this.blockN * 2); this.accN = 0; }
      this.acc[this.blockN + this.accN++] = v;
      if (this.accN === this.blockN) {
        // 8 ms window moved by 4 ms
        const p = CwDecoder.power(this.acc, 0, this.blockN * 2, this.tone, this.rate);
        this.acc.copyWithin(0, this.blockN);
        this.accN = 0;
        const ms = this.blockN * 1000 / this.rate;
        // until the tone is confirmed, keep the levels (up to 4 s) and read them once it is
        if (!this.present) { this.held.push(p); if (this.held.length > 1000) this.held.shift(); return; }
        if (this.held.length) { const h = this.held; this.held = []; h.forEach((q) => this.step(q, ms)); }
        this.step(p, ms);
      }
    }

    step(p, ms) {
      this.clock += ms;
      const a = Math.sqrt(p);
      // levels: the signal level follows the peaks, the noise level follows the valleys
      if (!this.sig) { this.sig = a; this.noise = a; }
      if (a > this.sig) this.sig += (a - this.sig) * 0.3; else this.sig += (a - this.sig) * 0.002;
      if (a < this.noise) this.noise += (a - this.noise) * 0.3; else this.noise += (a - this.noise) * 0.004;
      const span = this.sig - this.noise;
      const snr = this.noise > 0 ? 20 * Math.log10(this.sig / this.noise) : 0;
      const usable = snr > 8 && this.present;
      this.sm = (this.sm || 0) * 0.5 + a * 0.5;
      const raw = usable && (this.key ? this.sm > this.noise + span * 0.4 : this.sm > this.noise + span * 0.6);
      // a change counts only when it lasts a moment (noise spikes and short fades are ignored);
      // both edges are delayed the same, so the lengths stay right
      const on = this.key;
      if (raw === this.key) {
        this.run += this.pend + ms;
        this.pend = 0;
        if (!on) this.gap(false);
      } else {
        this.pend = (this.pend || 0) + ms;
        if (this.pend >= Math.max(10, this.dit * 0.3)) {
          if (this.key) this.mark(this.run); else this.gap(true);
          this.key = raw;
          this.run = this.pend;
          this.pend = 0;
        }
      }
      if (this.clock - this.lastInfo > 500) {
        this.lastInfo = this.clock;
        this.onInfo({ wpm: Math.round(1200 / this.dit), hz: Math.round(this.tone), snr: Math.round(snr), key: this.key });
      }
    }

    mark(ms) {
      if (ms < Math.max(8, this.dit * 0.3)) return;        // click or noise
      this.marks.push(ms);
      if (this.marks.length > 24) this.marks.shift();
      // speed: the dit length that best explains the recent marks (dits ~1, dahs ~3)
      if (this.marks.length >= 6) {
        const s = this.marks.slice().sort((x, y) => x - y);
        let bestErr = Infinity, best = this.dit;
        for (let c = 1; c < s.length; c++) {
          const d = s.slice(0, c), h = s.slice(c);
          const md = d.reduce((u, v) => u + v, 0) / d.length, mh = h.reduce((u, v) => u + v, 0) / h.length;
          if (mh < md * 2) continue;
          const est = (md + mh / 3) / 2;
          const err = d.reduce((u, v) => u + (v - md) ** 2, 0) + h.reduce((u, v) => u + (v - mh) ** 2, 0);
          if (err < bestErr) { bestErr = err; best = est; }
        }
        if (bestErr < Infinity) this.dit = this.learned ? Math.max(20, Math.min(240, this.dit * 0.6 + best * 0.4)) : Math.max(20, Math.min(240, best));
      }
      // until the speed is known, keep what we heard and read it afterwards (so the first letters are right too)
      if (!this.learned) {
        this.queue.push(ms);
        if (this.marks.length >= 6) {
          this.learned = true;
          const q = this.queue;
          this.queue = [];
          q.forEach((v) => (v < 0 ? this.endGap(-v) : this.symbol(v)));
        }
        return;
      }
      this.symbol(ms);
    }

    symbol(ms) {
      this.code += ms < this.dit * 2 ? "." : "-";
      if (this.code.length > 8) this.code = this.code.slice(-8);
      this.spaceSent = false;
    }

    // start = true: the silence just ended (a new tone began); false: still silent
    gap(start) {
      if (!this.learned) {
        if (start && this.queue.length) this.queue.push(-this.run);
        return;
      }
      if (!start) this.endGap(this.run);
    }

    endGap(ms) {
      if (this.code && ms > this.dit * 2.2) {
        this.onText(MORSE[this.code] || "·");
        this.code = "";
      }
      if (!this.spaceSent && !this.code && ms > this.dit * 5.5) {
        this.onText(" ");
        this.spaceSent = true;
      }
    }
  }

  const api = { FtxDecoder, CwDecoder, Resampler, ready, available: () => !!ftxModule() || !!root.DXZ_FTX_WASM };
  root.dxzDecoders = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
