/* DX Zaza 0.4 — geographic map layers, accurate propagation, operator QTH and BlueDV page.
 * Loaded after cybernode-zumspot.js. Overrides a few of its functions (same names). */
(function () {
  "use strict";

  // ------------------------------------------------------------------ i18n
  Object.assign(translations.en, {
    "nav.bluedv": "BlueDV",
    "layers.daynight": "Day / Night",
    "layers.aurora": "Aurora",
    "layers.satellites": "Satellites",
    "layers.paths": "Paths",
    "map.home": "Your QTH",
    "map.sun": "Sun",
    "map.iss_visible": "ISS above your horizon",
    "spots.distance": "km",
    "locator.label": "QTH Locator (Maidenhead)",
    "locator.placeholder": "e.g. JN45 or JN45ab",
    "locator.save": "Save Locator",
    "locator.note": "Used for distances, beam headings, grey line and satellite passes. Only the 4-character square is shown.",
    "locator.saved": "Locator saved",
    "locator.none": "No locator saved.",
    "prop.bands_title": "HF Band Conditions (N0NBH)",
    "prop.day": "Day",
    "act.title": "HF bands right now",
    "act.sub": "From live DX cluster spots, last {m} min",
    "act.sub_near": "From live DX cluster spots, last {m} min · heard within {km} km of you",
    "act.best": "Best now",
    "act.none": "Collecting live spots: the first results appear within a few minutes.",
    "act.excellent": "Excellent", "act.good": "Good", "act.fair": "Fair", "act.far": "Far only", "act.closed": "No activity",
    "act.spots": "spots", "act.near": "near you", "act.countries": "countries", "act.max": "max",
    "act.note": "A band is rated by the stations near you that are hearing DX on it right now (real spots, not a forecast).",
    "prop.night": "Night",
    "prop.vhf_title": "VHF Conditions",
    "prop.bands_unavailable": "Band conditions not available right now.",
    "prop.bands_disabled": "N0NBH band conditions are switched off in this DX Zaza (data_sources.n0nbh_band_conditions). Enable them only with N0NBH's permission for commercial units.",
    "prop.bands_credit": "Calculated conditions by Paul L Herrman N0NBH (hamqsl.com).",
    "prop.kp_history": "Kp — last 24 hours",
    "prop.greyline_title": "Grey line at your QTH",
    "prop.sunrise": "Sunrise",
    "prop.sunset": "Sunset",
    "prop.greyline_now": "Grey line is active now at your QTH.",
    "prop.greyline_next": "Next grey line window",
    "prop.greyline_no_qth": "Save your QTH locator in Wi-Fi Setup > Operator Setup to see sunrise, sunset and grey line times.",
    "prop.storm_quiet": "Geomagnetic field quiet: no storm expected now.",
    "prop.storm_active": "Geomagnetic activity raised: higher latitudes may be disturbed.",
    "prop.storm_storm": "Geomagnetic storm: HF paths over high latitudes degraded.",
    "prop.density": "Density",
    "prop.aurora": "Aurora",
    "prop.polar_note": "Polar day or night at your QTH today.",
    "prop.satellites_title": "Next satellite passes",
    "prop.satellites_none": "Save your QTH locator to see satellite passes.",
    "prop.satellites_unavailable": "Satellite data not available right now.",
    "bluedv.eyebrow": "DIGITAL VOICE",
    "bluedv.title": "BlueDV",
    "bluedv.subtitle": "BlueDV Radio by PA7LIM with your DVstick: D-STAR, DMR, Fusion and EchoLink from the browser.",
    "bluedv.app": "BlueDV Radio",
    "bluedv.service": "Service",
    "bluedv.web": "Web page",
    "bluedv.dvstick": "DVstick",
    "bluedv.mode": "AMBE mode",
    "bluedv.boot": "Start at boot",
    "bluedv.installed": "Installed",
    "bluedv.not_installed": "Not installed",
    "bluedv.running": "Running",
    "bluedv.stopped": "Stopped",
    "bluedv.starting": "Starting...",
    "bluedv.ready": "Ready",
    "bluedv.free": "Free",
    "bluedv.owner_bluedv": "In use by BlueDV",
    "bluedv.owner_ambe": "In use by AMBE Server",
    "bluedv.owner_busy": "In use by another program",
    "bluedv.owner_absent": "Not connected",
    "bluedv.mode_direct": "Direct (BlueDV uses the DVstick)",
    "bluedv.mode_ambe": "Through DX Zaza AMBE Server",
    "bluedv.yes": "Yes",
    "bluedv.no": "No",
    "bluedv.start": "Start BlueDV",
    "bluedv.stop": "Stop BlueDV",
    "bluedv.fullscreen": "Full screen",
    "bluedv.reload": "Reload",
    "bluedv.working": "Please wait...",
    "bluedv.password_warning": "BlueDV still uses the default password (bluedv / bluedv): change it in BlueDV Setup.",
    "bluedv.callsign_warning": "Callsign not set in BlueDV: open BlueDV Setup and enter your callsign and DMR ID.",
    "bluedv.install_title": "Install BlueDV Radio on the Raspberry Pi",
    "bluedv.install_steps": "Connect the DVstick and the QX-18B microphone, then on the Raspberry Pi run:",
    "bluedv.install_note": "BlueDV Radio is downloaded from the official PA7LIM site. It needs Raspberry Pi OS 64-bit (trixie).",
    "bluedv.web_wait": "BlueDV web page appears here when BlueDV is running.",
    "bluedv.credit": "BlueDV Radio is free software by David PA7LIM (pa7lim.nl). DX Zaza only starts, stops and shows it.",
    "bluedv.one_owner": "Only one program can use the DVstick at a time: starting BlueDV stops the AMBE Server if needed."
  });
  Object.assign(translations.it, {
    "nav.bluedv": "BlueDV",
    "layers.daynight": "Giorno / Notte",
    "layers.aurora": "Aurora",
    "layers.satellites": "Satelliti",
    "layers.paths": "Percorsi",
    "map.home": "Il tuo QTH",
    "map.sun": "Sole",
    "map.iss_visible": "ISS sopra il tuo orizzonte",
    "spots.distance": "km",
    "locator.label": "Locatore QTH (Maidenhead)",
    "locator.placeholder": "es. JN45 o JN45ab",
    "locator.save": "Salva locatore",
    "locator.note": "Serve per distanze, direzione d'antenna, grey line e passaggi dei satelliti. Viene mostrato solo il quadrato a 4 caratteri.",
    "locator.saved": "Locatore salvato",
    "locator.none": "Nessun locatore salvato.",
    "prop.bands_title": "Condizioni bande HF (N0NBH)",
    "prop.day": "Giorno",
    "act.title": "Bande HF adesso",
    "act.sub": "Dagli spot DX in tempo reale, ultimi {m} min",
    "act.sub_near": "Dagli spot DX in tempo reale, ultimi {m} min · ascoltati entro {km} km da te",
    "act.best": "Migliori adesso",
    "act.none": "Sto raccogliendo gli spot dal vivo: i primi risultati compaiono entro pochi minuti.",
    "act.excellent": "Ottima", "act.good": "Buona", "act.fair": "Discreta", "act.far": "Solo lontano", "act.closed": "Nessuna attività",
    "act.spots": "spot", "act.near": "vicino a te", "act.countries": "paesi", "act.max": "max",
    "act.note": "Ogni banda è valutata da quante stazioni vicino a te stanno ascoltando DX su quella banda in questo momento (spot reali, non una previsione).",
    "prop.night": "Notte",
    "prop.vhf_title": "Condizioni VHF",
    "prop.bands_unavailable": "Condizioni delle bande non disponibili in questo momento.",
    "prop.bands_disabled": "Le condizioni delle bande N0NBH sono disattivate in questo DX Zaza (data_sources.n0nbh_band_conditions). Per le unità in vendita attivale solo con il permesso di N0NBH.",
    "prop.bands_credit": "Condizioni calcolate da Paul L Herrman N0NBH (hamqsl.com).",
    "prop.kp_history": "Kp — ultime 24 ore",
    "prop.greyline_title": "Grey line al tuo QTH",
    "prop.sunrise": "Alba",
    "prop.sunset": "Tramonto",
    "prop.greyline_now": "In questo momento al tuo QTH c'è la grey line.",
    "prop.greyline_next": "Prossima finestra di grey line",
    "prop.greyline_no_qth": "Salva il locatore del tuo QTH in Wi-Fi Setup > Operator Setup per vedere alba, tramonto e orari della grey line.",
    "prop.storm_quiet": "Campo geomagnetico tranquillo: nessuna tempesta in corso.",
    "prop.storm_active": "Attività geomagnetica in aumento: le latitudini alte possono essere disturbate.",
    "prop.storm_storm": "Tempesta geomagnetica: i percorsi HF alle alte latitudini sono degradati.",
    "prop.density": "Densità",
    "prop.aurora": "Aurora",
    "prop.polar_note": "Oggi al tuo QTH c'è giorno o notte polare.",
    "prop.satellites_title": "Prossimi passaggi dei satelliti",
    "prop.satellites_none": "Salva il locatore del QTH per vedere i passaggi dei satelliti.",
    "prop.satellites_unavailable": "Dati dei satelliti non disponibili in questo momento.",
    "bluedv.eyebrow": "VOCE DIGITALE",
    "bluedv.title": "BlueDV",
    "bluedv.subtitle": "BlueDV Radio di PA7LIM con la tua DVstick: D-STAR, DMR, Fusion ed EchoLink dal browser.",
    "bluedv.app": "BlueDV Radio",
    "bluedv.service": "Servizio",
    "bluedv.web": "Pagina web",
    "bluedv.dvstick": "DVstick",
    "bluedv.mode": "Modalità AMBE",
    "bluedv.boot": "Avvio automatico",
    "bluedv.installed": "Installato",
    "bluedv.not_installed": "Non installato",
    "bluedv.running": "In funzione",
    "bluedv.stopped": "Fermo",
    "bluedv.starting": "Avvio in corso...",
    "bluedv.ready": "Pronta",
    "bluedv.free": "Libera",
    "bluedv.owner_bluedv": "Usata da BlueDV",
    "bluedv.owner_ambe": "Usata da AMBE Server",
    "bluedv.owner_busy": "Usata da un altro programma",
    "bluedv.owner_absent": "Non collegata",
    "bluedv.mode_direct": "Diretta (BlueDV usa la DVstick)",
    "bluedv.mode_ambe": "Tramite AMBE Server di DX Zaza",
    "bluedv.yes": "Sì",
    "bluedv.no": "No",
    "bluedv.start": "Avvia BlueDV",
    "bluedv.stop": "Ferma BlueDV",
    "bluedv.fullscreen": "Schermo intero",
    "bluedv.reload": "Ricarica",
    "bluedv.working": "Attendere...",
    "bluedv.password_warning": "BlueDV usa ancora la password predefinita (bluedv / bluedv): cambiala nel Setup di BlueDV.",
    "bluedv.callsign_warning": "Nominativo non impostato in BlueDV: apri il Setup di BlueDV e inserisci nominativo e DMR ID.",
    "bluedv.install_title": "Installa BlueDV Radio sul Raspberry Pi",
    "bluedv.install_steps": "Collega la DVstick e il microfono QX-18B, poi sul Raspberry Pi esegui:",
    "bluedv.install_note": "BlueDV Radio viene scaricato dal sito ufficiale di PA7LIM. Serve Raspberry Pi OS 64-bit (trixie).",
    "bluedv.web_wait": "La pagina di BlueDV compare qui quando BlueDV è in funzione.",
    "bluedv.credit": "BlueDV Radio è un software gratuito di David PA7LIM (pa7lim.nl). DX Zaza si limita ad avviarlo, fermarlo e mostrarlo.",
    "bluedv.one_owner": "Un solo programma alla volta può usare la DVstick: avviando BlueDV, l'AMBE Server viene fermato se necessario."
  });

  const esc = (v) => escapeHtml(v);
  const store = {
    get(key, fallback) { try { const v = localStorage.getItem(key); return v === null ? fallback : JSON.parse(v); } catch (e) { return fallback; } },
    set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* ignore */ } }
  };

  // ------------------------------------------------------------------ projection
  const MAP = { latTop: 82, latBottom: -58, ratio: 360 / 140, image: "assets/dx_zaza_world_map_v2.jpg" };
  const span = MAP.latTop - MAP.latBottom;
  const toX = (lon) => ((lon + 180) / 360) * 100;
  const toY = (lat) => ((MAP.latTop - lat) / span) * 100;
  const svgX = (lon) => lon + 180;
  const svgY = (lat) => MAP.latTop - lat;
  const RAD = Math.PI / 180;

  // ------------------------------------------------------------------ sun
  function sunPosition(date) {
    const n = date.getTime() / 86400000 + 2440587.5 - 2451545.0;
    const L = (280.460 + 0.9856474 * n) % 360;
    const g = ((357.528 + 0.9856003 * n) % 360) * RAD;
    const lambda = (L + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g)) * RAD;
    const eps = (23.439 - 0.0000004 * n) * RAD;
    const ra = Math.atan2(Math.cos(eps) * Math.sin(lambda), Math.cos(lambda)) / RAD;
    const dec = Math.asin(Math.sin(eps) * Math.sin(lambda)) / RAD;
    const gmst = (280.46061837 + 360.98564736629 * n) % 360;
    let lon = ra - gmst;
    lon = ((lon + 540) % 360) - 180;
    // equation of time (minutes): 4 * (mean longitude - right ascension), wrapped to +-180 deg
    let diff = ((L - ra + 180) % 360 + 360) % 360 - 180;
    const eot = 4 * diff;
    return { dec, lon, eot };
  }

  function sunAltitude(lat, lon, sun) {
    const h = (lon - sun.lon) * RAD;
    return Math.asin(Math.sin(lat * RAD) * Math.sin(sun.dec * RAD) + Math.cos(lat * RAD) * Math.cos(sun.dec * RAD) * Math.cos(h)) / RAD;
  }

  function sunEvents(lat, lon, day) {
    // NOAA approximation: returns {sunrise, sunset} as Date (UTC) or polar flags
    const noonGuess = new Date(Date.UTC(day.getUTCFullYear(), day.getUTCMonth(), day.getUTCDate(), 12));
    const sun = sunPosition(noonGuess);
    const cosH = (Math.sin(-0.833 * RAD) - Math.sin(lat * RAD) * Math.sin(sun.dec * RAD)) / (Math.cos(lat * RAD) * Math.cos(sun.dec * RAD));
    if (cosH > 1) return { polar: "night" };
    if (cosH < -1) return { polar: "day" };
    const h0 = Math.acos(cosH) / RAD;
    const noonMin = 720 - 4 * lon - sun.eot;
    const base = Date.UTC(day.getUTCFullYear(), day.getUTCMonth(), day.getUTCDate());
    return { sunrise: new Date(base + (noonMin - 4 * h0) * 60000), sunset: new Date(base + (noonMin + 4 * h0) * 60000) };
  }

  // ------------------------------------------------------------------ state
  const geo = {
    home: null,
    aurora: [],
    sats: [],
    issTrack: [],
    bands: null,
    layers: Object.assign({ daynight: true, aurora: true, satellites: true, paths: true }, store.get("dxz.layers", {}))
  };
  window.dxzGeo = geo;   // read-only use by the ISS Live module

  // ------------------------------------------------------------------ overrides: map
  window.syncMapVisualLayer = function () {
    const frame = document.querySelector(".global-map-page .map-image-frame");
    const layer = document.querySelector(".global-map-page .map-visual-layer");
    if (!frame || !layer) return;
    const r = frame.getBoundingClientRect();
    if (!r.width || !r.height) return;
    // keep geography exact in both axes (linear scaling), allowing up to ~35% vertical stretch
    // so the map fills the panel like the original artwork.
    const minRatio = 1.9;
    const visible = Math.min(r.height, window.innerHeight - Math.max(0, r.top) - 70);
    const availH = visible > 260 ? visible : r.height;
    let w = r.width, h = Math.min(availH, w / minRatio);
    if (h < w / MAP.ratio) h = w / MAP.ratio;
    if (h > availH) { h = availH; w = Math.min(r.width, h * MAP.ratio); }
    layer.style.width = w.toFixed(2) + "px";
    layer.style.height = h.toFixed(2) + "px";
  };

  const originalApplyPrefixPosition = window.applyPrefixPosition;
  window.applyPrefixPosition = function (spot) {
    const base = originalApplyPrefixPosition(spot);
    if (typeof spot.lat === "number" && typeof spot.lon === "number" && spot.lat <= MAP.latTop && spot.lat >= MAP.latBottom) {
      return Object.assign(base, {
        markerX: toX(spot.lon),
        markerY: toY(spot.lat),
        markerCountry: spot.country || base.markerCountry,
        markerRegion: spot.region || base.markerRegion,
        markerPrefix: base.markerPrefix || spot.country || "geo",
        markerCalibrated: true
      });
    }
    return Object.assign(base, { markerPrefix: "", markerX: 50, markerY: 50, markerCalibrated: false });
  };

  window.normalizeLiveDxSpot = function (spot) {
    return {
      time: spot.time || "",
      de: spot.de || "SPOTTER",
      frequency: spot.frequency || "14.074 MHz",
      band: spot.band || "Unknown",
      mode: spot.mode || "Unknown",
      country: spot.country || spot.region || "Unknown",
      region: spot.region || "",
      comment: String(spot.comment || "").replace(/[\u0000-\u001f\u007f-\u009f]+/g, " ").trim() || "DX cluster spot",
      lastSeen: spot.lastSeen || "Just now",
      lat: typeof spot.lat === "number" ? spot.lat : undefined,
      lon: typeof spot.lon === "number" ? spot.lon : undefined,
      precision: spot.precision || "",
      distanceKm: spot.distanceKm,
      bearing: spot.bearing
    };
  };

  const originalFormatCountryRegion = window.formatCountryRegion;
  window.formatCountryRegion = function (spot) {
    const text = originalFormatCountryRegion(spot);
    if (typeof spot.distanceKm === "number") {
      return text + " · " + spot.distanceKm.toLocaleString() + " km " + Math.round(spot.bearing) + "°";
    }
    return text;
  };

  const originalRenderMapMarkers = window.renderMapMarkers;
  window.renderMapMarkers = function () {
    originalRenderMapMarkers();
    drawVectorLayer();
  };

  // ------------------------------------------------------------------ map DOM
  function setupMapLayers() {
    const layer = document.querySelector(".global-map-page .map-visual-layer");
    const img = layer && layer.querySelector(".world-map-image");
    if (!layer || !img) return;
    img.src = MAP.image;
    const shade = layer.querySelector(".map-shade");
    const night = document.createElement("canvas");
    night.id = "dxzNight"; night.width = 720; night.height = 280; night.className = "dxz-layer dxz-night";
    const aurora = document.createElement("canvas");
    aurora.id = "dxzAurora"; aurora.width = 360; aurora.height = 140; aurora.className = "dxz-layer dxz-aurora";
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.id = "dxzVector"; svg.setAttribute("viewBox", "0 0 360 " + span); svg.setAttribute("preserveAspectRatio", "none");
    svg.classList.add("dxz-layer", "dxz-vector");
    const anchor = shade || img.nextSibling;
    layer.insertBefore(night, anchor);
    layer.insertBefore(aurora, anchor);
    layer.insertBefore(svg, anchor);

    const controls = document.querySelector(".global-map-page .global-filter-bar");
    if (controls) {
      const bar = document.createElement("div");
      bar.className = "dxz-layer-toggles";
      ["daynight", "aurora", "satellites", "paths"].forEach((key) => {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "dxz-layer-chip" + (geo.layers[key] ? " on" : "");
        b.dataset.layer = key;
        b.dataset.i18n = "layers." + key;
        b.textContent = t("layers." + key);
        b.addEventListener("click", () => {
          geo.layers[key] = !geo.layers[key];
          b.classList.toggle("on", geo.layers[key]);
          store.set("dxz.layers", geo.layers);
          drawAll();
        });
        bar.appendChild(b);
      });
      controls.appendChild(bar);
    }
  }

  /* Day / night colouring for one point, from the sun's altitude (degrees).
     Night: deep blue, darker the lower the sun. Grey line (twilight): amber band.
     Day: a light warm tint so the sunlit side stands out. Returns [r, g, b, alpha 0-1]. */
  function dayNightShade(alt) {
    const night = Math.min(1, Math.max(0, -alt / 12));
    let a = Math.pow(night, 0.8) * 0.78;
    let r = 2, g = 7, b = 26;
    const tw = Math.exp(-Math.pow((alt + 3) / 3.4, 2)) * 0.42;   // peak at civil twilight
    if (tw > 0.01) {
      const outA = tw + a * (1 - tw);
      r = (255 * tw + r * a * (1 - tw)) / outA;
      g = (168 * tw + g * a * (1 - tw)) / outA;
      b = (56 * tw + b * a * (1 - tw)) / outA;
      a = outA;
    }
    if (alt > 0.5 && a < 0.02) {                                  // sunlit side
      const d = Math.min(1, alt / 25) * 0.12;
      return [255, 226, 150, d];
    }
    return [r, g, b, a];
  }

  function drawNight() {
    const c = document.getElementById("dxzNight");
    if (!c) return;
    const ctx = c.getContext("2d");
    ctx.clearRect(0, 0, c.width, c.height);
    c.style.display = geo.layers.daynight ? "" : "none";
    if (!geo.layers.daynight) return;
    const sun = sunPosition(new Date());
    const img = ctx.createImageData(c.width, c.height);
    for (let y = 0; y < c.height; y++) {
      const lat = MAP.latTop - (y + 0.5) * span / c.height;
      for (let x = 0; x < c.width; x++) {
        const lon = -180 + (x + 0.5) * 360 / c.width;
        const alt = sunAltitude(lat, lon, sun);
        const sh = dayNightShade(alt);
        const i = (y * c.width + x) * 4;
        img.data[i] = sh[0]; img.data[i + 1] = sh[1]; img.data[i + 2] = sh[2]; img.data[i + 3] = Math.round(sh[3] * 255);
      }
    }
    ctx.putImageData(img, 0, 0);
  }

  function drawAurora() {
    const c = document.getElementById("dxzAurora");
    if (!c) return;
    const ctx = c.getContext("2d");
    ctx.clearRect(0, 0, c.width, c.height);
    c.style.display = geo.layers.aurora ? "" : "none";
    if (!geo.layers.aurora) return;
    (geo.aurora || []).forEach(([lon, lat, v]) => {
      if (lat > MAP.latTop || lat < MAP.latBottom) return;
      const x = (lon + 180) * c.width / 360, y = (MAP.latTop - lat) * c.height / span;
      ctx.fillStyle = "rgba(80,255,140," + Math.min(0.85, v / 45).toFixed(2) + ")";
      ctx.fillRect(x - 0.6, y - 0.6, 1.6, 1.6);
    });
  }

  function greatCircle(lat1, lon1, lat2, lon2, steps) {
    const p1 = lat1 * RAD, l1 = lon1 * RAD, p2 = lat2 * RAD, l2 = lon2 * RAD;
    const d = 2 * Math.asin(Math.sqrt(Math.sin((p2 - p1) / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin((l2 - l1) / 2) ** 2));
    if (!d) return [[lon1, lat1]];
    const pts = [];
    for (let i = 0; i <= steps; i++) {
      const f = i / steps;
      const A = Math.sin((1 - f) * d) / Math.sin(d), B = Math.sin(f * d) / Math.sin(d);
      const x = A * Math.cos(p1) * Math.cos(l1) + B * Math.cos(p2) * Math.cos(l2);
      const y = A * Math.cos(p1) * Math.sin(l1) + B * Math.cos(p2) * Math.sin(l2);
      const z = A * Math.sin(p1) + B * Math.sin(p2);
      pts.push([Math.atan2(y, x) / RAD, Math.atan2(z, Math.sqrt(x * x + y * y)) / RAD]);
    }
    return pts;
  }

  function polylines(points) {
    // split at the date line so lines don't cross the whole map
    const out = [];
    let cur = [];
    points = points || [];
    points.forEach((p, i) => {
      if (i > 0 && Math.abs(p[0] - points[i - 1][0]) > 180) { out.push(cur); cur = []; }
      cur.push(svgX(p[0]).toFixed(2) + "," + svgY(p[1]).toFixed(2));
    });
    out.push(cur);
    return out.filter((l) => l.length > 1).map((l) => l.join(" "));
  }

  function drawVectorLayer() {
    const svg = document.getElementById("dxzVector");
    if (!svg) return;
    let html = "";
    const zs = " scale(" + (1 / ((window.dxzZoom && window.dxzZoom.view().k) || 1)).toFixed(4) + ")";
    const sun = sunPosition(new Date());
    if (geo.layers.daynight) {
      // terminator (sun altitude 0) as a golden line
      const pts = [];
      for (let lon = -180; lon <= 180; lon += 2) {
        const lat = Math.atan(-Math.cos((lon - sun.lon) * RAD) / Math.tan(sun.dec * RAD)) / RAD;
        pts.push([lon, lat]);
      }
      polylines(pts).forEach((p) => { html += "<polyline class=\"dxz-terminator\" points=\"" + p + "\"/>"; });
      if (sun.dec <= MAP.latTop && sun.dec >= MAP.latBottom) {
        html += "<g class=\"dxz-sun\" transform=\"translate(" + svgX(sun.lon).toFixed(2) + " " + svgY(sun.dec).toFixed(2) + ")" + zs + "\">" +
          "<circle class=\"halo\" r=\"3.4\"/><circle class=\"core\" r=\"1.5\"/><title>" + esc(t("map.sun")) + "</title></g>";
      }
    }
    if (typeof window.dxzSpotVectors === "function") {
      html += window.dxzSpotVectors({ polylines, greatCircle, svgX, svgY, home: geo.home, paths: geo.layers.paths });
    }
    if (geo.home) {
      html += "<g class=\"dxz-home\" transform=\"translate(" + svgX(geo.home.lon).toFixed(2) + " " + svgY(geo.home.lat).toFixed(2) + ")" + zs + "\">" +
        "<circle r=\"2.6\"/><path d=\"M-1.5 0.4 L0 -1.2 L1.5 0.4 L1.5 1.4 L-1.5 1.4 Z\"/><title>" + esc(t("map.home") + " " + (geo.home.locator || "")) + "</title></g>";
    }
    if (geo.layers.satellites) {
      polylines(geo.issTrack).forEach((p) => { html += "<polyline class=\"dxz-iss-track\" points=\"" + p + "\"/>"; });
      (geo.sats || []).forEach((s) => {
        if (s.lat > MAP.latTop || s.lat < MAP.latBottom) return;
        const iss = s.name === "ISS";
        html += "<g class=\"dxz-sat" + (iss ? " iss" : "") + (s.visible ? " visible" : "") + "\" transform=\"translate(" +
          svgX(s.lon).toFixed(2) + " " + svgY(s.lat).toFixed(2) + ")" + zs + "\"><circle r=\"" + (iss ? 1.9 : 1.2) + "\"/>" +
          "<text x=\"2.6\" y=\"1\">" + esc(s.name) + "</text><title>" + esc(s.name + " " + s.altKm + " km") + "</title></g>";
      });
    }
    svg.innerHTML = html;
  }

  function drawAll() { drawNight(); drawAurora(); drawVectorLayer(); }

  // ------------------------------------------------------------------ data
  async function loadContext() {
    try {
      const ctx = await fetchLiveJson("/api/map/context");
      geo.home = ctx.home || null;
    } catch (e) { /* keep */ }
    drawVectorLayer();
  }
  async function loadAurora() {
    try { const d = await fetchLiveJson("/api/aurora"); if (d.ok) geo.aurora = d.points || []; else if (!d.stale) geo.aurora = []; } catch (e) { /* keep the last layer */ }
    drawAurora();
  }
  async function loadSatellites() {
    try {
      const d = await fetchLiveJson("/api/satellites");
      geo.sats = (d.ok && d.satellites) || [];
      geo.issTrack = (d.ok && d.issTrack) || [];
      geo.satOk = Boolean(d.ok);
    } catch (e) { /* app busy: keep the last positions */ }
    drawVectorLayer();
  }
  async function loadActivity() {
    try { geo.activity = await fetchLiveJson("/api/band-activity"); } catch (e) { /* keep the last */ }
    if (typeof activePage !== "undefined" && activePage === "hf-propagation") renderPropagationPage();
  }
  async function loadBands() {
    try { geo.bands = await fetchLiveJson("/api/bands"); } catch (e) { /* keep the last table */ }
    if (typeof activePage !== "undefined" && activePage === "hf-propagation") renderPropagationPage();
  }

  // ------------------------------------------------------------------ propagation page
  function fmtTime(d) {
    if (!d) return "--:--";
    const utc = String(d.getUTCHours()).padStart(2, "0") + ":" + String(d.getUTCMinutes()).padStart(2, "0") + "Z";
    const loc = String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
    return loc + " <small>(" + utc + ")</small>";
  }

  function rateClass(v) {
    const s = String(v || "").toLowerCase();
    return s.startsWith("good") ? "good" : s.startsWith("fair") ? "fair" : s.startsWith("poor") ? "poor" : "na";
  }

  function activitySection() {
    const a = geo.activity;
    const fmtKm = (n) => Number(n || 0).toLocaleString(dxZazaState.language === "it" ? "it-IT" : "en-GB");
    if (!a || !a.ok) {
      return "<section class=\"prop-card full\"><h3>" + t("act.title") + "</h3><p>" + t("act.none") + "</p></section>";
    }
    const sub = (a.nearKm ? t("act.sub_near").replace("{km}", fmtKm(a.nearKm)) : t("act.sub")).replace("{m}", a.windowMinutes);
    const max = Math.max(1, ...a.bands.map((b) => b.score));
    const shown = a.bands.filter((b) => b.band !== "60m" || b.spots > 0);
    const rows = shown.map((b) => {
      const detail = b.spots
        ? b.spots + " " + t("act.spots") + (a.nearKm ? " · " + b.near + " " + t("act.near") : "") +
          " · " + b.countries + " " + t("act.countries") + (b.maxKm ? " · " + t("act.max") + " " + fmtKm(b.maxKm) + " km" : "") +
          (b.modes.length ? " · " + b.modes.map(esc).join(", ") : "")
        : "";
      return "<div class=\"dxz-act-row " + b.rating + "\"><span class=\"band\">" + esc(b.band) + "</span>" +
        "<span class=\"bar\"><i style=\"width:" + Math.round(b.score / max * 100) + "%\"></i></span>" +
        "<strong class=\"dxz-act-rate " + b.rating + "\">" + t("act." + b.rating) + "</strong>" +
        "<small>" + detail + "</small></div>";
    }).join("");
    const best = a.best && a.best.length
      ? "<p class=\"dxz-act-best\">" + t("act.best") + ": <b>" + a.best.map(esc).join(" · ") + "</b></p>"
      : "<p class=\"dxz-act-best\">" + t("act.none") + "</p>";
    return "<section class=\"prop-card full dxz-act\"><h3>" + t("act.title") + "</h3>" +
      "<p class=\"demo-source-note\">" + sub + "</p>" + best +
      "<div class=\"dxz-act-table\">" + rows + "</div>" +
      "<p class=\"demo-source-note\">" + t("act.note") + "</p></section>";
  }

  function bandsSection() {
    const b = geo.bands;
    // live band activity from the DX cluster always; N0NBH's calculated table only when switched on
    if (!b || !b.ok || !b.bands || !Object.keys(b.bands).length) return activitySection();
    const order = ["80m-40m", "30m-20m", "17m-15m", "12m-10m"];
    const rows = order.filter((k) => b.bands[k]).map((k) => (
      "<div class=\"dxz-band-row\"><span>" + k + "</span>" +
      "<strong class=\"dxz-rate " + rateClass(b.bands[k].day) + "\">" + esc(b.bands[k].day || "--") + "</strong>" +
      "<strong class=\"dxz-rate " + rateClass(b.bands[k].night) + "\">" + esc(b.bands[k].night || "--") + "</strong></div>"
    )).join("");
    const vhf = (b.vhf || []).map((p) => {
      const open = !/closed/i.test(p.value);
      const label = p.name === "vhf-aurora" ? "Aurora" : "E-Skip " + String(p.location || "").replace(/_/g, " ").replace("europe", "EU").replace("north america", "NA");
      return "<div class=\"dxz-vhf " + (open ? "open" : "closed") + "\"><span>" + esc(label) + "</span><strong>" + esc(open ? p.value : (dxZazaState.language === "it" ? "Chiusa" : "Closed")) + "</strong></div>";
    }).join("");
    return activitySection() + "<section class=\"prop-card full\"><h3>" + t("prop.bands_title") + "</h3>" +
      "<div class=\"dxz-band-head\"><span></span><span>" + t("prop.day") + "</span><span>" + t("prop.night") + "</span></div>" +
      "<div class=\"dxz-band-table\">" + rows + "</div>" +
      (vhf ? "<h3 class=\"dxz-sub\">" + t("prop.vhf_title") + "</h3><div class=\"dxz-vhf-grid\">" + vhf + "</div>" : "") +
      "<p class=\"demo-source-note\">" + t("prop.bands_credit") + (b.updated ? " · " + esc(b.updated) : "") + "</p></section>";
  }

  function greylineSection() {
    if (!geo.home) {
      return "<section class=\"prop-card side greyline-card\"><h3>" + t("prop.greyline_title") + "</h3><p>" + t("prop.greyline_no_qth") + "</p></section>";
    }
    const now = new Date();
    const ev = sunEvents(geo.home.lat, geo.home.lon, now);
    if (ev.polar) {
      return "<section class=\"prop-card side greyline-card\"><h3>" + t("prop.greyline_title") + " · " + esc(geo.home.locator) + "</h3><p>" + t("prop.polar_note") + "</p></section>";
    }
    const alt = sunAltitude(geo.home.lat, geo.home.lon, sunPosition(now));
    const active = alt > -6 && alt < 3;
    const windows = [ev.sunrise, ev.sunset];
    const tomorrow = sunEvents(geo.home.lat, geo.home.lon, new Date(now.getTime() + 86400000));
    if (tomorrow.sunrise) windows.push(tomorrow.sunrise);
    const next = windows.find((d) => d.getTime() + 30 * 60000 > now.getTime());
    return "<section class=\"prop-card side greyline-card\"><h3>" + t("prop.greyline_title") + " · " + esc(geo.home.locator) + "</h3>" +
      "<div class=\"prop-meta\">" +
      "<div><span>" + t("prop.sunrise") + "</span><strong>" + fmtTime(ev.sunrise) + "</strong></div>" +
      "<div><span>" + t("prop.sunset") + "</span><strong>" + fmtTime(ev.sunset) + "</strong></div></div>" +
      "<p class=\"" + (active ? "dxz-greyline-now" : "") + "\">" + (active ? t("prop.greyline_now") : t("prop.greyline_next") + ": " + fmtTime(next)) + "</p></section>";
  }

  function kpSection(data) {
    const hist = Array.isArray(data.kpHistory) ? data.kpHistory : [];
    if (!hist.length) return "";
    const bars = hist.map((h) => {
      const k = Number(h.kp) || 0;
      const cls = k >= 5 ? "poor" : k >= 4 ? "fair" : "good";
      return "<div class=\"dxz-kp-bar " + cls + "\" style=\"height:" + Math.max(6, k / 9 * 100).toFixed(0) + "%\"><span>" + k.toFixed(0) + "</span></div>";
    }).join("");
    return "<h3 class=\"dxz-sub\">" + t("prop.kp_history") + "</h3><div class=\"dxz-kp-chart\">" + bars + "</div>";
  }

  function satellitesSection() {
    if (!geo.home) return "<section class=\"prop-card side\"><h3>" + t("prop.satellites_title") + "</h3><p>" + t("prop.satellites_none") + "</p></section>";
    if (!geo.satOk) return "<section class=\"prop-card side\"><h3>" + t("prop.satellites_title") + "</h3><p>" + t("prop.satellites_unavailable") + "</p></section>";
    const list = [];
    geo.sats.forEach((s) => (s.passes || []).forEach((p) => list.push(Object.assign({ name: s.name }, p))));
    list.sort((a, b) => a.aos.localeCompare(b.aos));
    const rows = list.slice(0, 6).map((p) => (
      "<div class=\"dxz-pass\"><strong>" + esc(p.name) + "</strong><span>" + fmtTime(new Date(p.aos)) + "</span>" +
      "<span>" + p.maxEl + "° · " + p.durationMin + " min</span></div>"
    )).join("");
    return "<section class=\"prop-card side\"><h3>" + t("prop.satellites_title") + "</h3>" + (rows || "<p>--</p>") + "</section>";
  }

  window.renderPropagationPage = function () {
    const container = document.getElementById("propagationPage");
    if (!container) return;
    const data = currentPropagationDemo();
    renderPropagationSourceStatus();
    const live = isSolarLive();
    const storm = String(data.storm || "Quiet").toLowerCase();
    const stormText = !live ? "\u2014" : storm === "storm" ? t("prop.storm_storm") : storm === "active" ? t("prop.storm_active") : t("prop.storm_quiet");
    container.innerHTML = "" +
      "<section class=\"prop-card wide\">" +
        "<h3>" + t("propagation.global_summary") + "</h3>" +
        "<p>" + (live ? t("propagation.live_message") : t("propagation.preview_shown")) + "</p>" +
        "<div class=\"prop-badge-row\">" +
          "<span class=\"prop-badge kp\">Kp " + esc(data.kp) + "</span>" +
          "<span class=\"prop-badge\">A " + esc(data.aIndex) + "</span>" +
          "<span class=\"prop-badge sfi\">SFI " + esc(data.sfi) + "</span>" +
          "<span class=\"prop-badge xray\">X-Ray " + esc(data.xray) + "</span>" +
        "</div>" +
        kpSection(data) +
      "</section>" +
      "<section class=\"prop-card side storm-card\">" +
        "<h3>" + t("propagation.storm_watch") + "</h3>" +
        "<p>" + stormText + "</p>" +
        "<div class=\"prop-meta\">" +
          "<div><span>" + t("propagation.solar_wind") + "</span><strong>" + esc(data.solarWind) + "</strong></div>" +
          "<div><span>" + t("propagation.bz") + "</span><strong>" + esc(data.bz) + "</strong></div>" +
          (data.density ? "<div><span>" + t("prop.density") + "</span><strong>" + esc(data.density) + "</strong></div>" : "") +
          "<div><span>" + t("prop.aurora") + "</span><strong>" + esc(data.auroraRisk) + "</strong></div>" +
        "</div>" +
      "</section>" +
      bandsSection() +
      greylineSection() +
      satellitesSection() +
      renderSolarConditions() +
      "<section class=\"prop-card full source-note-card\">" +
        "<h3>" + t("propagation.data_note") + "</h3>" +
        "<p>" + (live ? t("propagation.source_live_note") : t("propagation.source_preview_note")) + "</p>" +
      "</section>";
  };

  const originalNormalizeLiveSolar = window.normalizeLiveSolar;
  window.normalizeLiveSolar = function (d) {
    originalNormalizeLiveSolar(d);
    propagationDemo.density = d.density || "";
    propagationDemo.kpHistory = d.kpHistory || [];
    propagationDemoVariants.forEach((v) => { v.density = propagationDemo.density; v.kpHistory = propagationDemo.kpHistory; });
  };

  // ------------------------------------------------------------------ operator locator
  function setupLocatorForm() {
    const card = document.querySelector(".operator-setup-card");
    if (!card || document.getElementById("operatorLocatorForm")) return;
    const form = document.createElement("form");
    form.id = "operatorLocatorForm";
    form.className = "wifi-form operator-form dxz-locator-form";
    form.innerHTML = "<label><span data-i18n=\"locator.label\">" + t("locator.label") + "</span>" +
      "<input id=\"operatorLocator\" type=\"text\" autocomplete=\"off\" autocapitalize=\"characters\" spellcheck=\"false\" maxlength=\"8\" data-touch-keyboard=\"true\" data-i18n-placeholder=\"locator.placeholder\" placeholder=\"" + t("locator.placeholder") + "\"></label>" +
      "<button type=\"submit\" class=\"primary-action\" data-i18n=\"locator.save\">" + t("locator.save") + "</button>" +
      "<p class=\"wifi-demo-note\" data-i18n=\"locator.note\">" + t("locator.note") + "</p>" +
      "<p id=\"operatorLocatorMessage\" class=\"wifi-demo-message\" role=\"status\">" + t("locator.none") + "</p>";
    card.appendChild(form);
    const locInput = form.querySelector("#operatorLocator");
    if (typeof openTouchKeyboard === "function") {
      locInput.addEventListener("focus", () => openTouchKeyboard(locInput));
      locInput.addEventListener("click", () => { openTouchKeyboard(locInput); setActiveKeyboardSelectionFromInput(locInput); });
      locInput.addEventListener("touchstart", () => openTouchKeyboard(locInput), { passive: true });
      ["select", "keyup", "input"].forEach((ev) => locInput.addEventListener(ev, () => setActiveKeyboardSelectionFromInput(locInput)));
    }
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const input = document.getElementById("operatorLocator");
      const msg = document.getElementById("operatorLocatorMessage");
      try {
        const res = await postLiveJson("/api/settings/locator", { locator: input.value });
        msg.textContent = t("locator.saved") + ": " + res.operator.locator.slice(0, 4);
        input.value = "";
        await loadContext();
        loadSatellites();
        renderPropagationPage();
      } catch (err) {
        msg.textContent = err.message;
      }
    });
    fetchLiveJson("/api/settings").then((s) => {
      const loc = s.operator && s.operator.locator;
      if (loc) document.getElementById("operatorLocatorMessage").textContent = t("locator.saved") + ": " + loc.slice(0, 4);
    }).catch(() => {});
  }

  // ------------------------------------------------------------------ BlueDV page
  const bluedv = { status: null, busy: false, frameLoaded: false };

  function bluedvUrl(port) {
    return location.protocol + "//" + (location.hostname || "localhost") + ":" + port + "/";
  }

  function ownerText(o) {
    if (!o) return "--";
    if (!o.stable_device_ready && o.hardware_owner === "unknown") return t("bluedv.owner_absent");
    return { free: t("bluedv.free"), blue_dv: t("bluedv.owner_bluedv"), ambe_server: t("bluedv.owner_ambe"), busy: t("bluedv.owner_busy") }[o.hardware_owner] || t("bluedv.owner_absent");
  }

  function renderBlueDv() {
    const s = bluedv.status;
    const grid = document.getElementById("bluedvStatusGrid");
    if (!grid || !s) return;
    const stateText = s.running ? (s.web_ready ? t("bluedv.running") : t("bluedv.starting")) : t("bluedv.stopped");
    grid.innerHTML = [
      [t("bluedv.app"), s.installed ? t("bluedv.installed") : t("bluedv.not_installed"), s.installed ? "ok" : "warn"],
      [t("bluedv.service"), stateText, s.running ? "ok" : ""],
      [t("bluedv.web"), s.web_ready ? t("bluedv.ready") + " · :" + s.web_port : "--", s.web_ready ? "ok" : ""],
      [t("bluedv.dvstick"), ownerText(s.dvstick), s.dvstick && s.dvstick.hardware_owner === "busy" ? "warn" : ""],
      [t("bluedv.mode"), s.ambe_mode === "ambe_server" ? t("bluedv.mode_ambe") : t("bluedv.mode_direct"), ""],
      [t("bluedv.boot"), s.enabled_at_boot ? t("bluedv.yes") : t("bluedv.no"), ""]
    ].map(([k, v, c]) => "<div class=\"" + c + "\"><span>" + esc(k) + "</span><strong>" + esc(v) + "</strong></div>").join("");
    const pill = document.getElementById("bluedvStatePill");
    pill.textContent = s.installed ? stateText : t("bluedv.not_installed");
    pill.className = "source-pill " + (s.running && s.web_ready ? "live-source" : (s.installed ? "" : "fallback-source"));
    const m = document.getElementById("bluedvMessage");
    m.hidden = !m.textContent.trim();
    document.getElementById("bluedvStart").disabled = bluedv.busy || !s.installed || s.running;
    document.getElementById("bluedvStop").disabled = bluedv.busy || !s.running;
    document.getElementById("bluedvFullscreen").disabled = !s.web_ready;
    document.getElementById("bluedvReload").disabled = !s.web_ready;
    const warn = [];
    if (s.installed && s.default_password) warn.push(t("bluedv.password_warning"));
    if (s.installed && !s.callsign_configured) warn.push(t("bluedv.callsign_warning"));
    document.getElementById("bluedvWarnings").innerHTML = warn.map((w) => "<p>" + esc(w) + "</p>").join("");
    document.getElementById("bluedvInstallCard").hidden = s.installed;
    const frame = document.getElementById("bluedvFrame");
    const wait = document.getElementById("bluedvFrameWait");
    if (s.web_ready) {
      if (!bluedv.frameLoaded) { frame.src = bluedvUrl(s.web_port); bluedv.frameLoaded = true; }
      frame.hidden = false; wait.hidden = true;
    } else {
      if (bluedv.frameLoaded) { frame.src = "about:blank"; bluedv.frameLoaded = false; }
      frame.hidden = true; wait.hidden = false;
    }
  }

  async function loadBlueDv() {
    try { bluedv.status = await fetchLiveJson("/api/bluedv/status"); } catch (e) { return; }
    window.dxzBlueDvInstalled = !!(bluedv.status && bluedv.status.installed);
    const nav = document.querySelector(".nav-button[data-page='bluedv']");
    if (nav) nav.hidden = !window.dxzBlueDvInstalled;
    renderBlueDv();
  }

  async function bluedvAction(action) {
    const msg = document.getElementById("bluedvMessage");
    bluedv.busy = true; renderBlueDv();
    msg.textContent = t("bluedv.working");
    msg.hidden = false;
    try {
      const res = await postLiveJson("/api/bluedv/" + action, {});
      msg.textContent = res.message || "";
      if (res.status) bluedv.status = res.status;
    } catch (err) {
      msg.textContent = err.message;
    }
    bluedv.busy = false;
    setTimeout(loadBlueDv, 1500);
    setTimeout(loadBlueDv, 5000);
    renderBlueDv();
  }

  function setupBlueDv() {
    if (!document.getElementById("page-bluedv")) return;
    document.getElementById("bluedvStart").addEventListener("click", () => bluedvAction("start"));
    document.getElementById("bluedvStop").addEventListener("click", () => bluedvAction("stop"));
    document.getElementById("bluedvReload").addEventListener("click", () => {
      const f = document.getElementById("bluedvFrame");
      if (bluedv.status && bluedv.status.web_ready) f.src = bluedvUrl(bluedv.status.web_port);
    });
    document.getElementById("bluedvFullscreen").addEventListener("click", () => {
      const f = document.getElementById("bluedvFrame");
      if (f.requestFullscreen) f.requestFullscreen().catch(() => {});
    });
    loadBlueDv();
    setInterval(() => { if (activePage === "bluedv") loadBlueDv(); }, 5000);
    document.querySelector(".nav-button[data-page='bluedv']").addEventListener("click", loadBlueDv);
  }

  // ------------------------------------------------------------------ start
  setupMapLayers();
  setupLocatorForm();
  setupBlueDv();
  syncMapVisualLayer();
  loadContext();
  loadAurora();
  loadSatellites();
  loadBands();
  drawAll();
  setInterval(drawNight, 60 * 1000);
  setInterval(loadSatellites, 30 * 1000);
  setInterval(loadAurora, 10 * 60 * 1000);
  setInterval(loadBands, 30 * 60 * 1000);
  loadActivity();
  setInterval(loadActivity, 60 * 1000);
  setInterval(loadContext, 10 * 60 * 1000);
  // re-render our parts whenever the interface language is (re)applied
  const originalApplyTranslations = window.applyTranslations;
  window.applyTranslations = function () {
    originalApplyTranslations.apply(this, arguments);
    document.querySelectorAll(".dxz-layer-chip").forEach((b) => { b.textContent = t("layers." + b.dataset.layer); });
    renderBlueDv();
    drawVectorLayer();
  };
  applyTranslations();
  window.dxZazaGeo = { sunPosition, sunAltitude, sunEvents, dayNightShade, geo, drawAll, drawVectorLayer, MAP };
})();
