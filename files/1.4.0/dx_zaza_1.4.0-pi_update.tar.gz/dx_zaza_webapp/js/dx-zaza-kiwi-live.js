/* DX Zaza — Listen Live: a clean KiwiSDR player (waterfall + real audio) for one spot.
   "Listen Live" on a station card asks the backend for the best free receiver (close to the
   station that spotted it), then talks to that KiwiSDR directly with its public WebSocket
   protocol (the same one its own web page and kiwirecorder use): one sound stream and one
   waterfall stream, like one listener on the receiver's web page.
   Busy or refused receiver: the next one is tried by itself. The small button opens the full
   KiwiSDR interface on the "Listen KiwiSDR" page. Closing the player frees the channel. */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const lang = () => ((window.dxZazaState && dxZazaState.language) || document.documentElement.lang || "en").startsWith("it") ? "it" : "en";
  const S = {
    en: { live: "LIVE", finding: "Finding the best receiver for {dx}…", connecting: "Connecting to {rx}…",
      busy: "Receiver busy, trying another…", none: "No free KiwiSDR receiver found for this frequency right now.",
      lost: "Connection lost.", near: "{km} km from {call}, who heard it", other: "Another receiver", full: "Open in Listen KiwiSDR (full interface)",
      close: "Stop", mute: "Sound on/off", credit: "KiwiSDR of {name}",
      ft8: "FT8 decoder", ft4: "FT4 decoder", cw: "CW decoder", first: "Listening… first decodes in {s} s", next: "next decode in {s} s",
      heard: "{n} messages", nodec: "nothing decoded in this slot", waitcw: "Waiting for a clear CW signal…", wpm: "{w} WPM · {hz} Hz",
      nowasm: "Decoder not available on this device." },
    it: { live: "LIVE", finding: "Cerco il ricevitore migliore per {dx}…", connecting: "Mi collego a {rx}…",
      busy: "Ricevitore occupato, ne provo un altro…", none: "Nessun ricevitore KiwiSDR libero trovato ora per questa frequenza.",
      lost: "Collegamento perso.", near: "a {km} km da {call}, che l'ha sentita", other: "Un altro ricevitore", full: "Apri in Ascolta KiwiSDR (interfaccia completa)",
      close: "Stop", mute: "Audio sì/no", credit: "KiwiSDR di {name}",
      ft8: "Decoder FT8", ft4: "Decoder FT4", cw: "Decoder CW", first: "In ascolto… prime decodifiche tra {s} s", next: "prossima decodifica tra {s} s",
      heard: "{n} messaggi", nodec: "nessuna decodifica in questo periodo", waitcw: "Aspetto un segnale CW chiaro…", wpm: "{w} WPM · {hz} Hz",
      nowasm: "Decoder non disponibile su questo dispositivo." },
  };
  const t = (k) => (S[lang()] || S.en)[k] || S.en[k] || k;
  const HP = "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M4 15v-3a8 8 0 0 1 16 0v3\"/><rect x=\"3\" y=\"14\" width=\"4.5\" height=\"7\" rx=\"1.5\"/><rect x=\"16.5\" y=\"14\" width=\"4.5\" height=\"7\" rx=\"1.5\"/></svg>";
  const ICON = {
    other: "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"><path d=\"M20 11a8 8 0 1 0-2.3 5.7\"/><path d=\"M20 5v6h-6\"/></svg>",
    full: "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"><path d=\"M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7\"/></svg>",
    close: "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\" stroke-linecap=\"round\"><path d=\"M6 6l12 12M18 6L6 18\"/></svg>",
    on: "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M4 9h4l5-4v14l-5-4H4z\"/><path d=\"M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12\"/></svg>",
    off: "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M4 9h4l5-4v14l-5-4H4z\"/><path d=\"M17 9l5 6M22 9l-5 6\"/></svg>",
  };

  // passband (Hz, relative to the dial frequency) and the frequency sent to the receiver
  function tuning(mode, fKHz, dialKHz) {
    switch (mode) {
      case "ft8": case "ft4": return { mod: "usb", lo: 100, hi: 3000, f: dialKHz || fKHz - 1.5 };   // the whole FT8/FT4 sub-band
      case "lsb": return { mod: "lsb", lo: -2700, hi: -300, f: fKHz };
      case "cw": return { mod: "usb", lo: 400, hi: 800, f: fKHz - 0.6 };        // CW heard as a 600 Hz tone
      case "am": return { mod: "am", lo: -4900, hi: 4900, f: fKHz };
      case "nbfm": return { mod: "nbfm", lo: -6000, hi: 6000, f: fKHz };
      default: return { mod: "usb", lo: 300, hi: 2700, f: fKHz };
    }
  }

  // ------------------------------------------------------------------ IMA ADPCM (if a receiver sends compressed audio)
  const STEP = [7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118,
    130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411,
    1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487,
    12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767];
  const IDX = [-1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8];
  function adpcm(state, bytes) {
    const out = new Float32Array(bytes.length * 2);
    let k = 0;
    for (let i = 0; i < bytes.length; i++) {
      for (const code of [bytes[i] & 15, bytes[i] >> 4]) {
        const step = STEP[state.index];
        let diff = step >> 3;
        if (code & 1) diff += step >> 2;
        if (code & 2) diff += step >> 1;
        if (code & 4) diff += step;
        state.prev = Math.max(-32768, Math.min(32767, state.prev + (code & 8 ? -diff : diff)));
        state.index = Math.max(0, Math.min(88, state.index + IDX[code]));
        out[k++] = state.prev / 32768;
      }
    }
    return out;
  }

  // ------------------------------------------------------------------ waterfall colours (dark blue -> cyan -> yellow -> red -> white)
  const PALETTE = (() => {
    const stops = [[0, [2, 6, 18]], [0.25, [10, 40, 110]], [0.45, [0, 160, 200]], [0.62, [60, 220, 120]], [0.78, [250, 220, 60]], [0.9, [250, 90, 40]], [1, [255, 255, 255]]];
    const p = new Uint8Array(256 * 3);
    for (let i = 0; i < 256; i++) {
      const x = i / 255;
      let j = 0;
      while (j < stops.length - 2 && x > stops[j + 1][0]) j++;
      const [x0, c0] = stops[j], [x1, c1] = stops[j + 1];
      const f = Math.max(0, Math.min(1, (x - x0) / (x1 - x0)));
      for (let c = 0; c < 3; c++) p[i * 3 + c] = Math.round(c0[c] + (c1[c] - c0[c]) * f);
    }
    return p;
  })();

  // ------------------------------------------------------------------ one KiwiSDR session
  class Session {
    constructor(url, spot, fKHz, mode, audioCtx, ui, dialKHz) {
      this.base = url.replace(/^http/, "ws");
      this.spot = spot;
      this.tune = tuning(mode, fKHz, dialKHz);
      this.fKHz = fKHz;
      this.ctx = audioCtx;
      this.ui = ui;
      this.closed = false;
      this.next = 0;
      this.adpcm = { index: 0, prev: 0 };
      this.floor = 120;
      this.span = 70;
      const ts = Math.floor(Date.now() / 1000);
      this.snd = this.open("/" + ts + "/SND", (tag, b) => this.onSnd(tag, b));
      this.wf = this.open("/" + ts + "/W/F", (tag, b) => this.onWf(tag, b));
      this.keep = setInterval(() => { this.send(this.snd, "SET keepalive"); this.send(this.wf, "SET keepalive"); }, 5000);
      this.firstAudio = setTimeout(() => { if (!this.gotAudio) this.fail("busy"); }, 6000);
    }

    open(path, handler) {
      let ws;
      try { ws = new WebSocket(this.base + path); } catch (_) { setTimeout(() => this.fail("busy"), 0); return null; }
      ws.binaryType = "arraybuffer";
      ws.onopen = () => this.send(ws, "SET auth t=kiwi p=");
      ws.onmessage = (ev) => {
        if (this.closed || !(ev.data instanceof ArrayBuffer)) return;
        const b = new Uint8Array(ev.data);
        handler(String.fromCharCode(b[0], b[1], b[2]), b);
      };
      ws.onerror = () => this.fail(this.gotAudio ? "lost" : "busy");
      ws.onclose = () => { if (!this.closed) this.fail(this.gotAudio ? "lost" : "busy"); };
      return ws;
    }

    send(ws, text) { try { if (ws && ws.readyState === 1) ws.send(text); } catch (_) { /* closing */ } }

    msgs(b) {
      const text = new TextDecoder().decode(b.subarray(4));
      const out = {};
      text.split(" ").forEach((p) => { const i = p.indexOf("="); out[i < 0 ? p : p.slice(0, i)] = i < 0 ? "" : p.slice(i + 1); });
      return out;
    }

    refused(m) {
      return ("too_busy" in m) || ("redirect" in m) || ("down" in m) || (m.badp && m.badp !== "0");
    }

    onSnd(tag, b) {
      if (tag === "MSG") {
        const m = this.msgs(b);
        if (this.refused(m)) return this.fail("busy");
        if (m.audio_rate) { this.rate = Number(m.audio_rate); this.send(this.snd, "SET AR OK in=" + this.rate + " out=44100"); }
        if (m.sample_rate) {
          this.srate = Number(m.sample_rate);
          const u = this.tune;
          ["SET squelch=0 max=0", "SET genattn=0", "SET gen=0 mix=-1",
            "SET mod=" + u.mod + " low_cut=" + u.lo + " high_cut=" + u.hi + " freq=" + u.f.toFixed(3),
            "SET agc=1 hang=0 thresh=-100 slope=6 decay=1000 manGain=50", "SET compression=0",
            "SET ident_user=" + encodeURIComponent(this.ui.ident()), "SET keepalive"].forEach((c) => this.send(this.snd, c));
        }
        return;
      }
      if (tag !== "SND" || b.length < 10) return;
      const flags = b[3];
      const smeter = (b[8] << 8) | b[9];
      this.ui.meter(0.1 * smeter - 127);
      const data = b.subarray(10);
      let samples;
      if (flags & 0x10) samples = adpcm(this.adpcm, data);
      else {
        const n = data.length >> 1;
        samples = new Float32Array(n);
        const little = flags & 0x80;
        for (let i = 0; i < n; i++) {
          let v = little ? (data[2 * i + 1] << 8) | data[2 * i] : (data[2 * i] << 8) | data[2 * i + 1];
          if (v & 0x8000) v -= 0x10000;
          samples[i] = v / 32768;
        }
      }
      if (!this.gotAudio) { this.gotAudio = true; clearTimeout(this.firstAudio); this.ui.playing(); }
      this.play(samples);
      // the decoders get the exact receiver rate (e.g. 12001.1 Hz) when it is known
      const r = this.srate && Math.abs(this.srate - this.rate) < this.rate * 0.02 ? this.srate : this.rate;
      if (r) this.ui.audio(samples, r);
    }

    play(samples) {
      const ctx = this.ctx;
      if (!ctx || !this.rate || !samples.length) return;
      const now = ctx.currentTime;
      // jitter buffer: starts small (quick start), grows a little after each gap, never above 0.9 s
      if (this.cushion === undefined) this.cushion = 0.25;
      if (this.next < now + 0.02) {
        if (this.next) this.cushion = Math.min(0.9, this.cushion + 0.15);
        this.next = now + this.cushion;
      } else if (this.next > now + this.cushion + 1.0) {
        this.next = now + this.cushion;           // too far behind (tab was asleep): catch up
      }
      const buf = ctx.createBuffer(1, samples.length, this.rate);
      buf.copyToChannel(samples, 0);
      const src = ctx.createBufferSource();
      src.buffer = buf;
      src.connect(this.ui.out);
      src.start(this.next);
      this.next += samples.length / this.rate;
    }

    onWf(tag, b) {
      if (tag === "MSG") {
        const m = this.msgs(b);
        if (this.refused(m)) return this.fail("busy");
        if (m.bandwidth) this.bw = Number(m.bandwidth) / 1000;
        if ("wf_setup" in m) {
          const u = this.tune;
          const cf = u.f + (u.lo + u.hi) / 2000;           // centre of the passband
          this.zoom = 11;
          ["SET zoom=" + this.zoom + " cf=" + cf.toFixed(3), "SET maxdb=-10 mindb=-110", "SET wf_speed=3",
            "SET wf_comp=0", "SET interp=13", "SET keepalive"].forEach((c) => this.send(this.wf, c));
        }
        return;
      }
      if (tag !== "W/F" || b.length < 16 + 64) return;
      const dv = new DataView(b.buffer, b.byteOffset + 4, 12);
      const xbin = dv.getUint32(0, true), zoom = dv.getUint32(4, true) & 0xffff;
      const px = b.subarray(16);
      const bw = this.bw || 30000;
      const start = xbin * bw / (1024 * 16384);
      const span = bw / Math.pow(2, zoom);
      this.ui.row(px, start, span, this);
    }

    fail(why) {
      if (this.closed) return;
      this.close();
      this.ui.failed(why);
    }

    close() {
      this.closed = true;
      clearInterval(this.keep);
      clearTimeout(this.firstAudio);
      [this.snd, this.wf].forEach((ws) => { try { if (ws) ws.close(); } catch (_) { /* gone */ } });
    }
  }

  // ------------------------------------------------------------------ the player window
  let panel = null, session = null, ctx = null, gain = null, muted = false, current = null, seq = 0;

  function el() {
    if (panel) return panel;
    panel = document.createElement("div");
    panel.id = "dxzLive";
    panel.className = "dxz-live";
    panel.hidden = true;
    panel.innerHTML =
      "<div class=\"lv-head\"><span class=\"lv-tag\"><i></i><b></b></span><span class=\"lv-call\"></span>" +
      "<span class=\"lv-btns\"><button type=\"button\" data-act=\"mute\"></button><button type=\"button\" data-act=\"other\">" + ICON.other + "</button>" +
      "<button type=\"button\" data-act=\"close\">" + ICON.close + "</button></span></div>" +
      "<div class=\"lv-wf\"><canvas width=\"1024\" height=\"150\"></canvas><span class=\"lv-pb\"></span><p class=\"lv-msg\"></p></div>" +
      "<div class=\"lv-dec\" hidden><div class=\"dc-head\"><b></b><span class=\"dc-led\"></span><span class=\"dc-st\"></span></div><div class=\"dc-body\"></div></div>" +
      "<div class=\"lv-foot\"><span class=\"lv-meter\"><i></i></span><span class=\"lv-db\"></span><span class=\"lv-rx\"></span></div>";
    panel.addEventListener("click", (e) => {
      const b = e.target.closest("[data-act]");
      if (!b) return;
      const act = b.dataset.act;
      if (act === "close") stop();
      else if (act === "mute") { muted = !muted; if (gain) gain.gain.value = muted ? 0 : 1; texts(); }
      else if (act === "other" && current) { current.skip.push(current.url); find(); }
    });
    document.body.appendChild(panel);
    return panel;
  }

  function texts() {
    const p = el();
    p.querySelector(".lv-tag b").textContent = t("live");
    const btn = (a) => p.querySelector("[data-act=\"" + a + "\"]");
    btn("mute").innerHTML = muted ? ICON.off : ICON.on;
    btn("mute").title = t("mute");
    btn("other").title = t("other");
    btn("close").title = t("close");
  }

  function message(text) {
    const m = el().querySelector(".lv-msg");
    m.textContent = text || "";
    m.hidden = !text;
  }

  const ui = {
    ident() {
      const m = /[?&]u=([A-Z0-9/]+)/.exec((current && current.listenUrl) || "");
      return m ? m[1] + " (DX Zaza)" : "DX Zaza";
    },
    meter(db) {
      const p = el();
      const f = Math.max(0, Math.min(1, (db + 127) / 80));
      p.querySelector(".lv-meter i").style.width = (f * 100).toFixed(0) + "%";
      const s = db <= -73 ? "S" + Math.max(0, Math.min(9, Math.round((db + 127) / 6))) : "S9+" + Math.round(db + 73);
      p.querySelector(".lv-db").textContent = s + " · " + Math.round(db) + " dBm";
    },
    playing() { message(""); decStart(); },
    audio(samples, rate) { if (decoder) decoder.push(samples, rate); },
    row(px, start, span, sess) {
      const c = el().querySelector("canvas");
      const g = c.getContext("2d");
      const W = c.width, H = c.height;
      g.drawImage(c, 0, 0, W, H - 2, 0, 2, W, H - 2);               // scroll down by two lines
      // automatic contrast: follow the noise floor
      const sorted = Array.from(px).sort((a, b) => a - b);
      const floor = sorted[Math.floor(sorted.length * 0.2)];
      sess.floor = sess.floor * 0.9 + floor * 0.1;
      const line = g.createImageData(W, 1);
      const n = px.length;
      for (let x = 0; x < W; x++) {
        const v = px[Math.min(n - 1, Math.floor(x * n / W))];
        const k = Math.max(0, Math.min(255, Math.round((v - sess.floor + 6) / sess.span * 255)));
        line.data[x * 4] = PALETTE[k * 3]; line.data[x * 4 + 1] = PALETTE[k * 3 + 1]; line.data[x * 4 + 2] = PALETTE[k * 3 + 2]; line.data[x * 4 + 3] = 255;
      }
      g.putImageData(line, 0, 0);
      g.putImageData(line, 0, 1);
      // passband marker
      const u = sess.tune;
      const lo = (u.f + u.lo / 1000 - start) / span, hi = (u.f + u.hi / 1000 - start) / span;
      const pb = el().querySelector(".lv-pb");
      pb.style.left = (Math.max(0, lo) * 100).toFixed(2) + "%";
      pb.style.width = (Math.max(0.005, Math.min(1, hi) - Math.max(0, lo)) * 100).toFixed(2) + "%";
    },
    failed(why) {
      if (why === "busy" && current) { message(t("busy")); current.skip.push(current.url); find(); }
      else message(t(why === "lost" ? "lost" : "none"));
    },
    get out() { return gain; },
  };

  // candidates for a spot, asked once (also in advance, when its card is opened) and kept a minute
  const cache = new Map();
  function spotKey(spot) { return (spot.dx || "") + "|" + (spot.frequency || "") + "|" + (spot.de || ""); }
  function query(spot, skip) {
    const q = new URLSearchParams();
    q.set("freq", spot.frequency);
    q.set("mode", spot.mode || "");
    q.set("verify", "0");                        // the player checks by connecting: quicker
    if (typeof spot.lat === "number") { q.set("lat", spot.lat); q.set("lon", spot.lon); }
    if (typeof spot.dxLat === "number") { q.set("dxlat", spot.dxLat); q.set("dxlon", spot.dxLon); }
    if (skip && skip.length) q.set("skip", skip.join(","));
    return fetch("/api/kiwi/listen?" + q.toString(), { cache: "no-store" }).then((r) => r.json()).catch(() => null);
  }
  function candidates(spot) {
    const k = spotKey(spot);
    const hit = cache.get(k);
    if (hit && Date.now() - hit.at < 60000) return hit.p;
    const p = query(spot);
    cache.set(k, { at: Date.now(), p });
    if (cache.size > 30) cache.delete(cache.keys().next().value);
    return p;
  }
  function prefetch(spot) { if (spot && spot.frequency) candidates(spot); }

  async function find() {
    const my = ++seq;
    if (session) { session.close(); session = null; }
    decStop();
    const p = el();
    const c = current;
    p.querySelector(".lv-rx").textContent = "";
    if (c.skip.length > 10) { message(t("none")); return; }
    // next candidate from the list we already have; ask again only when it is used up
    if (!c.list || !c.list.length) {
      message(t("finding").replace("{dx}", c.spot.dx || "?"));
      const d = c.skip.length ? await query(c.spot, c.skip) : await candidates(c.spot);
      if (my !== seq || current !== c) return;
      if (!d || !d.ok) { message(t("none")); return; }
      c.meta = d;
      c.list = (d.candidates || [d.receiver]).filter((r) => c.skip.indexOf(r.url) < 0);
      if (!c.list.length) { message(t("none")); return; }
    }
    const d = c.meta;
    const r = c.list.shift();
    c.url = r.url;
    c.listenUrl = r.listenUrl || "";
    const name = r.label || r.name || r.url;
    const near = typeof r.fromRefKm === "number" && c.spot.de ? t("near").replace("{km}", r.fromRefKm.toLocaleString()).replace("{call}", c.spot.de) : "";
    p.querySelector(".lv-rx").textContent = [name, near].filter(Boolean).join(" — ");
    p.querySelector(".lv-rx").title = t("credit").replace("{name}", name) + (r.saved ? "" : " · " + (d.credit || ""));
    message(t("connecting").replace("{rx}", (r.loc || name).slice(0, 60)));
    const cv = p.querySelector("canvas");
    cv.getContext("2d").clearRect(0, 0, cv.width, cv.height);
    c.mode = d.mode;
    session = new Session(r.url, c.spot, d.freqKHz, d.mode, ctx, ui, d.dialKHz);
  }

  // ------------------------------------------------------------------ CW / FT8 / FT4 decoding (dx-zaza-decoders.js)
  let decoder = null, decTimer = null, decKind = "";
  const esc = (x) => String(x).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;" }[c]));
  const two = (n) => String(n).padStart(2, "0");
  function decBox() { return el().querySelector(".lv-dec"); }
  function decStatus(text) { decBox().querySelector(".dc-st").textContent = text || ""; }

  function decStart() {
    decStop();
    const kind = current && current.mode;
    const D = window.dxzDecoders;
    if (!D || ["cw", "ft8", "ft4"].indexOf(kind) < 0) return;
    const box = decBox(), body = box.querySelector(".dc-body");
    box.hidden = false;
    box.className = "lv-dec is-" + kind;
    box.querySelector(".dc-head b").textContent = t(kind);
    body.innerHTML = "";
    decKind = kind;
    const call = String((current.spot && current.spot.dx) || "").toUpperCase();
    if (kind === "cw") {
      decStatus(t("waitcw"));
      const line = document.createElement("p");
      body.appendChild(line);
      decoder = new D.CwDecoder({
        lo: 300, hi: 900,
        onText: (ch) => {
          let txt = line.textContent + ch;
          if (txt.length > 600) txt = txt.slice(-500);
          line.textContent = txt;
          body.scrollTop = body.scrollHeight;
        },
        onInfo: (i) => {
          box.querySelector(".dc-led").classList.toggle("on", !!i.key);
          if (i.hz && i.snr > 8) decStatus(t("wpm").replace("{w}", i.wpm).replace("{hz}", i.hz));
        },
      });
      return;
    }
    if (!D.available()) { decStatus(t("nowasm")); return; }
    const slotMs = kind === "ft4" ? 7500 : 15000;
    let decodedOnce = false;
    decoder = new D.FtxDecoder(kind, {
      onDecodes: (list, slotStart) => {
        decodedOnce = true;
        const d = new Date(slotStart);
        const hhmmss = two(d.getUTCHours()) + two(d.getUTCMinutes()) + two(d.getUTCSeconds());
        const stick = body.scrollTop + body.clientHeight >= body.scrollHeight - 8;
        if (!list.length) {
          const p = document.createElement("p");
          p.className = "dc-none";
          p.textContent = hhmmss + "  · " + t("nodec");
          body.appendChild(p);
        }
        list.forEach((m) => {
          const p = document.createElement("p");
          const words = m.text.toUpperCase().split(/\s+/);
          if (call && words.indexOf(call) >= 0) p.className = "dc-me";
          else if (words[0] === "CQ") p.className = "dc-cq";
          p.innerHTML = "<i>" + hhmmss + "</i><i>" + (m.snr >= 0 ? "+" : "") + m.snr + "</i><i>" + m.hz + "</i><span>" + esc(m.text) + "</span>";
          body.appendChild(p);
        });
        while (body.children.length > 250) body.removeChild(body.firstChild);
        if (stick) body.scrollTop = body.scrollHeight;
        box.dataset.count = list.length;
      },
    });
    const tick = () => {
      const first = !decodedOnce;
      const now = Date.now();
      const left = Math.max(0, Math.ceil(((first && decoder && decoder.firstAt ? decoder.firstAt : now + slotMs - (now % slotMs)) - now) / 1000));
      decStatus((first ? t("first") : t("next")).replace("{s}", left) +
        (decodedOnce ? " · " + t("heard").replace("{n}", box.dataset.count || 0) : ""));
    };
    tick();
    decTimer = setInterval(tick, 1000);
  }

  function decStop() {
    if (decoder && decoder.stop) decoder.stop();
    decoder = null;
    decKind = "";
    clearInterval(decTimer);
    decTimer = null;
    if (panel) { const b = decBox(); b.hidden = true; b.querySelector(".dc-body").innerHTML = ""; b.querySelector(".dc-led").classList.remove("on"); }
  }

  function start(spot) {
    if (!spot) return;
    // the audio is started inside the click (browsers allow sound only after a user action)
    try {
      if (!ctx) {
        ctx = new (window.AudioContext || window.webkitAudioContext)();
        gain = ctx.createGain();
        gain.connect(ctx.destination);
      }
      if (ctx.state === "suspended") ctx.resume();
      gain.gain.value = muted ? 0 : 1;
    } catch (_) { /* no audio device: the waterfall still works */ }
    const p = el();
    texts();
    p.querySelector(".lv-call").textContent = (spot.dx || "?") + " · " + (spot.frequency || "") + " · " + (spot.mode || "");
    p.hidden = false;
    current = { spot, skip: [], url: "" };
    find();
  }

  function stop() {
    seq++;
    if (session) { session.close(); session = null; }
    decStop();
    current = null;
    if (panel) panel.hidden = true;
    if (ctx && ctx.state === "running") ctx.suspend().catch(() => {});
  }

  window.dxzKiwiLive = { start, stop, prefetch };
})();
