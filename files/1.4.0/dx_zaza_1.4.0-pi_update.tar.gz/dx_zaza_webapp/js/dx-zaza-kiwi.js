/* DX Zaza — Listen page: KiwiSDR web receivers.
   - "Listen" on a spot (map card or spot list) opens the best free receiver, closest to the station
     that heard the spot, already tuned to the spot frequency and mode.
   - The page tunes any frequency, lists the operator's receivers (own + public ones they added)
     with free channels and distance, and shows the receiver's own web interface.
   - The receiver is released (iframe unloaded) when the operator presses Stop or leaves the page.
   - Map layer "KiwiSDR": the receivers on the world map; tap one to listen there. */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const lang = () => ((window.dxZazaState && dxZazaState.language) || document.documentElement.lang || "en").startsWith("it") ? "it" : "en";
  const S = {
    en: {
      nav: "Listen KiwiSDR", eyebrow: "KIWISDR WEB RECEIVERS", title: "Listen KiwiSDR", pill: "no radio needed",
      freq: "Frequency (kHz)", mode: "Mode", listen: "Listen", receivers: "RECEIVERS", refresh: "Refresh",
      add_title: "ADD A RECEIVER", own: "This is my own KiwiSDR", add: "Add",
      find_note: "Find public receivers on", find_note2: ": open one, copy its address and add it here.",
      stop: "Stop", wait: "Choose a frequency, or tap Listen on a spot of the map.",
      credit: "Audio and waterfall come from the KiwiSDR you choose, run by its owner: follow its time limits and leave it free when you finish (Stop, or leave this page).",
      empty: "No receivers yet. Add your own KiwiSDR or a public one (see below).",
      users: "users", free: "free", full: "full", offline: "not reachable", pwd: "password", mine: "mine",
      limits: "time limits", km: "km from you", remove: "Remove", make_own: "Mark as mine", listen_here: "Listen here",
      adding: "Checking the receiver…", added: "Receiver added.", removed: "Receiver removed.",
      first: "First add at least one KiwiSDR receiver:<ol><li>Tap <b>rx.kiwisdr.com</b> (bottom left): the public list opens in your browser.</li><li>Open a receiver you like, then copy its address from the address bar (for example <code>sdr.example.org:8073</code>).</li><li>Paste it in <b>ADD A RECEIVER</b> and tap <b>Add</b>. Add a few in different countries.</li></ol>Then tap Listen again: DX Zaza picks the best one for each spot.",
      none_free: "No receiver in your list can take a listener on this frequency now. Add more receivers or try again in a minute.",
      bad_freq: "Type a frequency between 10 and 30000 kHz.",
      near_spotter: "close to {call}, who heard the spot", near_you: "close to you",
      spot_for: "Listening for {dx} on {f} kHz", others: "Other receivers", chip: "KiwiSDR",
      find_pi: "Open rx.kiwisdr.com on a phone or computer, choose a receiver, then type its address here.",
      card_listen: "Listen", card_title: "Hear this station live: waterfall and audio from a KiwiSDR receiver near the spotter",
      finding: "Finding the best receiver to hear {dx}…", listening: "LISTENING", other: "Another receiver",
      bigger: "Open in the Listen page", close: "Stop listening", heard_near: "{km} km from {call}, who heard it",
      click_hint: "No sound? Click once inside the receiver.", auto: "Listen automatically when I tap a callsign on the map",
      none_auto: "No free KiwiSDR receiver found for this frequency right now.",
    },
    it: {
      nav: "Ascolta KiwiSDR", eyebrow: "RICEVITORI WEB KIWISDR", title: "Ascolta KiwiSDR", pill: "senza radio",
      freq: "Frequenza (kHz)", mode: "Modo", listen: "Ascolta", receivers: "RICEVITORI", refresh: "Aggiorna",
      add_title: "AGGIUNGI UN RICEVITORE", own: "È il mio KiwiSDR", add: "Aggiungi",
      find_note: "Trovi i ricevitori pubblici su", find_note2: ": aprine uno, copia il suo indirizzo e aggiungilo qui.",
      stop: "Stop", wait: "Scegli una frequenza, oppure tocca Ascolta su uno spot della mappa.",
      credit: "Audio e cascata arrivano dal KiwiSDR che scegli, gestito dal suo proprietario: rispetta i suoi limiti di tempo e lascialo libero quando hai finito (Stop, o cambia pagina).",
      empty: "Nessun ricevitore. Aggiungi il tuo KiwiSDR o uno pubblico (vedi sotto).",
      users: "utenti", free: "libero", full: "pieno", offline: "non raggiungibile", pwd: "password", mine: "mio",
      limits: "limiti di tempo", km: "km da te", remove: "Rimuovi", make_own: "Segna come mio", listen_here: "Ascolta qui",
      adding: "Controllo il ricevitore…", added: "Ricevitore aggiunto.", removed: "Ricevitore rimosso.",
      first: "Prima aggiungi almeno un ricevitore KiwiSDR:<ol><li>Tocca <b>rx.kiwisdr.com</b> (in basso a sinistra): l'elenco pubblico si apre nel browser.</li><li>Apri un ricevitore che ti piace e copia il suo indirizzo dalla barra degli indirizzi (per esempio <code>sdr.example.org:8073</code>).</li><li>Incollalo in <b>AGGIUNGI UN RICEVITORE</b> e tocca <b>Aggiungi</b>. Aggiungine alcuni in paesi diversi.</li></ol>Poi tocca di nuovo Ascolta: DX Zaza sceglie il migliore per ogni spot.",
      none_free: "Nessun ricevitore della tua lista è libero su questa frequenza ora. Aggiungi altri ricevitori o riprova tra un minuto.",
      bad_freq: "Scrivi una frequenza tra 10 e 30000 kHz.",
      near_spotter: "vicino a {call}, che ha ascoltato lo spot", near_you: "vicino a te",
      spot_for: "In ascolto di {dx} su {f} kHz", others: "Altri ricevitori", chip: "KiwiSDR",
      find_pi: "Apri rx.kiwisdr.com da un telefono o computer, scegli un ricevitore e scrivi qui il suo indirizzo.",
      card_listen: "Ascolta", card_title: "Ascolta questa stazione dal vivo: cascata e audio da un KiwiSDR vicino a chi l'ha sentita",
      finding: "Cerco il ricevitore migliore per sentire {dx}…", listening: "IN ASCOLTO", other: "Un altro ricevitore",
      bigger: "Apri nella pagina Ascolta", close: "Smetti di ascoltare", heard_near: "a {km} km da {call}, che l'ha sentito",
      click_hint: "Non senti? Clicca una volta dentro il ricevitore.", auto: "Ascolta in automatico quando tocco un nominativo sulla mappa",
      none_auto: "Nessun ricevitore KiwiSDR libero trovato ora per questa frequenza.",
    },
  };
  const t = (k) => (S[lang()] || S.en)[k] || S.en[k] || k;
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[c]));
  const HP = "<svg class=\"hp\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M4 15v-3a8 8 0 0 1 16 0v3\"/><rect x=\"3\" y=\"14\" width=\"4.5\" height=\"7\" rx=\"1.5\"/><rect x=\"16.5\" y=\"14\" width=\"4.5\" height=\"7\" rx=\"1.5\"/></svg>";
  const QUICK = [["1840", "cw"], ["3573", "usb"], ["7074", "usb"], ["10136", "usb"], ["14074", "usb"], ["14200", "usb"], ["18100", "usb"], ["21074", "usb"], ["28074", "usb"]];

  let receivers = [];
  let current = null;        // {url, listenUrl, name}
  let showOnMap = false;
  let isDesktop = true;

  async function api(path, opts) {
    const res = await fetch(path, Object.assign({ cache: "no-store" }, opts || {}));
    return res.json();
  }
  const post = (path, body) => api(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });

  // ------------------------------------------------------------------ texts
  let textsLang = "";
  function texts() {
    if (textsLang === lang()) return;
    textsLang = lang();
    const nav = $("dxzKiwiNav");
    if (nav) nav.textContent = t("nav");
    document.querySelectorAll("#page-kiwi [data-k]").forEach((el) => { el.textContent = t(el.dataset.k); });
    const q = $("kiwiQuick");
    if (q && !q.childElementCount) {
      q.innerHTML = QUICK.map(([f, m]) => "<button type=\"button\" class=\"kiwi-q\" data-f=\"" + f + "\" data-m=\"" + m + "\">" + (Number(f) / 1000).toFixed(3).replace(/0+$/, "").replace(/\.$/, "") + "</button>").join("");
    }
    const chip = document.querySelector(".dxz-kiwi-chip span");
    if (chip) chip.textContent = t("chip");
  }

  // ------------------------------------------------------------------ receivers list
  function pills(r) {
    if (!r.ok) return "<span class=\"kp off\">" + esc(t("offline")) + "</span>";
    let h = "<span class=\"kp " + (r.free ? "ok" : "busy") + "\">" + esc(r.users + "/" + r.usersMax + " " + t("users")) + "</span>";
    if (r.own) h += "<span class=\"kp mine\">★ " + esc(t("mine")) + "</span>";
    if (r.password) h += "<span class=\"kp pw\">" + esc(t("pwd")) + "</span>";
    if (r.limits) h += "<span class=\"kp lim\">" + esc(t("limits")) + "</span>";
    return h;
  }

  function renderList() {
    const box = $("kiwiList");
    if (!box) return;
    if (!receivers.length) { box.innerHTML = "<p class=\"kiwi-empty\">" + esc(t("empty")) + "</p>"; return; }
    box.innerHTML = receivers.map((r, i) =>
      "<div class=\"kiwi-rx" + (current && current.url === r.url ? " on" : "") + (r.ok ? "" : " down") + "\" data-i=\"" + i + "\">" +
      "<div class=\"kn\"><strong>" + esc(r.label || r.name || r.url) + "</strong>" +
      "<small>" + esc([r.loc, r.antenna].filter(Boolean).join(" · ") || r.url) + "</small>" +
      "<div class=\"kps\">" + pills(r) + (typeof r.distanceKm === "number" ? "<span class=\"kp\">" + esc(r.distanceKm.toLocaleString() + " " + t("km")) + "</span>" : "") + "</div></div>" +
      "<div class=\"ka\"><button type=\"button\" class=\"secondary-action kiwi-small\" data-act=\"listen\"" + (r.ok && (r.free || r.own) ? "" : " disabled") + ">" + esc(t("listen_here")) + "</button>" +
      "<button type=\"button\" class=\"kiwi-icon\" data-act=\"own\" title=\"" + esc(t("make_own")) + "\">" + (r.own ? "★" : "☆") + "</button>" +
      "<button type=\"button\" class=\"kiwi-icon\" data-act=\"remove\" title=\"" + esc(t("remove")) + "\">×</button></div></div>"
    ).join("");
  }

  async function loadList(fresh) {
    try {
      const d = await api("/api/kiwi/receivers" + (fresh ? "?fresh=1" : ""));
      receivers = (d && d.receivers) || [];
    } catch (_) { /* restarting */ }
    renderList();
    if (showOnMap && typeof window.dxzAfterMarkers === "function") window.dxzAfterMarkers();
  }

  // ------------------------------------------------------------------ player
  function play(url, name, info) {
    const f = $("kiwiFrame");
    current = { url: url.split("/?")[0], listenUrl: url, name };
    f.src = url;
    f.hidden = false;
    $("kiwiWait").hidden = true;
    $("kiwiStop").hidden = false;
    $("kiwiRxName").textContent = name || url;
    $("kiwiRxInfo").textContent = info || "";
    renderList();
  }

  function stop() {
    const f = $("kiwiFrame");
    if (f && f.src !== "about:blank") f.src = "about:blank";   // frees the channel on the receiver
    if (f) f.hidden = true;
    if ($("kiwiWait")) $("kiwiWait").hidden = false;
    if ($("kiwiStop")) $("kiwiStop").hidden = true;
    if ($("kiwiRxName")) $("kiwiRxName").textContent = "—";
    if ($("kiwiRxInfo")) $("kiwiRxInfo").textContent = "";
    current = null;
    renderList();
  }

  function msg(text) { const m = $("kiwiAddMsg"); if (m) m.textContent = text || ""; }

  async function listen(opts) {
    // opts: {freq (kHz or "14.246 MHz"), mode, lat, lon, url, spot}
    const q = new URLSearchParams();
    q.set("freq", opts.freq);
    if (opts.mode) q.set("mode", opts.mode);
    if (typeof opts.lat === "number" && typeof opts.lon === "number") { q.set("lat", opts.lat); q.set("lon", opts.lon); }
    if (opts.spot && typeof opts.spot.dxLat === "number") { q.set("dxlat", opts.spot.dxLat); q.set("dxlon", opts.spot.dxLon); }
    if (opts.url) q.set("url", opts.url);
    if (window.dxzKiwiLive) window.dxzKiwiLive.stop();
    goPage();
    let d;
    try { d = await api("/api/kiwi/listen?" + q.toString()); } catch (_) { d = null; }
    if (!d || !d.ok) {
      stop();
      if (d && d.error === "no_receiver" && !receivers.length) { await loadList(false); }
      if (d && d.error === "no_receiver" && !receivers.length) { $("kiwiWait").innerHTML = "<div class=\"kiwi-first\">" + t("first") + "</div>"; const u = $("kiwiUrl"); if (u) u.focus(); }
      else $("kiwiWait").textContent = d && d.error === "no_receiver" ? t("none_free") : t("bad_freq");
      return;
    }
    $("kiwiFreq").value = d.freqKHz;
    $("kiwiMode").value = d.mode;
    const r = d.receiver;
    let info = [r.loc, r.antenna].filter(Boolean).join(" · ");
    if (opts.spot) {
      const near = opts.spot.de ? t("near_spotter").replace("{call}", opts.spot.de) : t("near_you");
      info = t("spot_for").replace("{dx}", opts.spot.dx || "?").replace("{f}", d.freqKHz) + " · " + near + (info ? " · " + info : "");
    }
    play(r.listenUrl, r.label || r.name, info);
  }

  function goPage() {
    if (typeof switchPage === "function") switchPage("kiwi");
  }

  // ------------------------------------------------------------------ spot buttons (map card + spot list)
  window.dxzCardActions = function (spot) {
    return "<button type=\"button\" class=\"dxz-listen\" title=\"" + esc(t("card_title")) + "\">" + HP + " Listen Live</button>";
  };
  window.dxzListenMini = function () {
    return " <button type=\"button\" class=\"dxz-listen-mini\" title=\"" + esc(t("card_title")) + "\">" + HP + "</button>";
  };
  function listenSpot(s) {
    if (!s) return;
    if (window.dxzKiwiLive) window.dxzKiwiLive.start(s);       // clean live player: waterfall + audio
    else listen({ freq: s.frequency, mode: s.mode, lat: s.lat, lon: s.lon, spot: s });
  }

  document.addEventListener("click", (e) => {
    const b = e.target.closest && e.target.closest(".dxz-listen");
    if (b) {
      e.stopPropagation();
      const card = b.closest(".dxz-card");
      listenSpot(card && card._spot);
      if (card) card.hidden = true;
      return;
    }
    const m = e.target.closest && e.target.closest(".dxz-listen-mini");
    if (m) {
      e.stopPropagation();
      const row = m.closest("tr");
      const body = $("dxTableBody");
      listenSpot(body && body._spots && row ? body._spots[Number(row.dataset.i)] : null);
    }
  }, true);


  // ------------------------------------------------------------------ map layer: receivers
  function addChip() {
    const bar = document.querySelector(".global-map-page .dxz-layer-toggles");
    if (!bar) return false;
    if (bar.querySelector(".dxz-kiwi-chip")) return true;
    const b = document.createElement("button");
    b.type = "button";
    b.className = "dxz-layer-chip dxz-kiwi-chip";
    b.innerHTML = "<i class=\"kiwi-ico\"></i><span>" + esc(t("chip")) + "</span>";
    b.addEventListener("click", () => {
      showOnMap = !showOnMap;
      b.classList.toggle("active", showOnMap);
      if (showOnMap && !receivers.length) loadList(false);
      placePins();
    });
    const iss = bar.querySelector(".dxz-iss-chip");
    bar.insertBefore(b, iss || null);
    return true;
  }

  function placePins() {
    const layer = $("dxMarkers");
    if (!layer) return;
    layer.querySelectorAll(".dxz-kiwi-pin").forEach((el) => el.remove());
    if (!showOnMap || !window.dxzMapPoint) return;
    receivers.forEach((r, i) => {
      if (typeof r.lat !== "number") return;
      const pt = window.dxzMapPoint(r.lon, r.lat);
      if (!pt) return;
      const el = document.createElement("div");
      el.className = "dxz-kiwi-pin" + (r.ok && r.free ? "" : " busy") + (r.own ? " own" : "");
      el.dataset.lon = r.lon;
      el.dataset.lat = r.lat;
      el.dataset.i = i;
      el.title = (r.label || r.name || r.url) + (r.ok ? " · " + r.users + "/" + r.usersMax : "");
      el.style.left = pt.x.toFixed(1) + "px";
      el.style.top = pt.y.toFixed(1) + "px";
      layer.appendChild(el);
    });
  }
  const prevAfter = window.dxzAfterMarkers;
  window.dxzAfterMarkers = function (layer) {
    if (typeof prevAfter === "function") prevAfter(layer);
    placePins();
  };
  // tapping a callsign opens its card: get the receivers ready, so "Listen Live" starts at once
  document.addEventListener("click", (e) => {
    const btn = e.target.closest && e.target.closest(".dxz-dx");
    if (!btn || !window.dxzKiwiLive) return;
    const layer = $("dxMarkers");
    const s = layer && layer._stations && layer._stations[Number(btn.dataset.i)];
    if (s) window.dxzKiwiLive.prefetch(s);
  }, true);

  // ------------------------------------------------------------------ page events
  function bind() {
    $("kiwiTune").addEventListener("submit", (e) => {
      e.preventDefault();
      const f = $("kiwiFreq").value.trim();
      if (!f) { $("kiwiWait").textContent = t("bad_freq"); return; }
      listen({ freq: f, mode: $("kiwiMode").value, url: current ? current.url : "" });
    });
    $("kiwiQuick").addEventListener("click", (e) => {
      const b = e.target.closest(".kiwi-q");
      if (!b) return;
      $("kiwiFreq").value = b.dataset.f;
      $("kiwiMode").value = b.dataset.m;
      listen({ freq: b.dataset.f, mode: b.dataset.m, url: current ? current.url : "" });
    });
    $("kiwiStop").addEventListener("click", stop);
    $("kiwiRefresh").addEventListener("click", () => loadList(true));
    $("kiwiList").addEventListener("click", async (e) => {
      const b = e.target.closest("[data-act]");
      const row = e.target.closest(".kiwi-rx");
      if (!b || !row) return;
      const r = receivers[Number(row.dataset.i)];
      if (!r) return;
      if (b.dataset.act === "listen") listen({ freq: $("kiwiFreq").value || "14074", mode: $("kiwiMode").value, url: r.url });
      else if (b.dataset.act === "remove") {
        if (current && current.url === r.url) stop();
        await post("/api/kiwi/remove", { url: r.url });
        msg(t("removed"));
        loadList(false);
      } else if (b.dataset.act === "own") {
        await post("/api/kiwi/own", { url: r.url, own: !r.own });
        loadList(false);
      }
    });
    $("kiwiAdd").addEventListener("submit", async (e) => {
      e.preventDefault();
      const url = $("kiwiUrl").value.trim();
      if (!url) return;
      msg(t("adding"));
      let d;
      try { d = await post("/api/kiwi/receivers", { url, own: $("kiwiOwn").checked }); } catch (_) { d = { ok: false, error: "" }; }
      if (d.ok) { msg(t("added")); $("kiwiUrl").value = ""; $("kiwiOwn").checked = false; loadList(false); }
      else msg(d.error || "");
    });
    $("kiwiFind").addEventListener("click", async () => {
      if (isDesktop) {
        try { const d = await post("/api/open-external", { url: "http://rx.kiwisdr.com/" }); if (d.ok) return; } catch (_) { /* fall through */ }
      }
      msg(t("find_pi"));
    });
    // leaving the page frees the receiver channel
    document.querySelectorAll(".nav-button").forEach((b) => b.addEventListener("click", () => {
      if (b.dataset.page !== "kiwi" && current) stop();
      if (b.dataset.page === "kiwi") { texts(); loadList(false); }
    }));
  }

  async function boot() {
    try { const s = await api("/api/status"); isDesktop = !(s && s.features && s.features.platform === "pi"); } catch (_) { /* default */ }
    texts();
    bind();
    let tries = 0;
    const iv = setInterval(() => { if (addChip() || ++tries > 40) clearInterval(iv); }, 500);
    loadList(false);
    setInterval(() => { texts(); }, 5000);
    setInterval(() => { if ((current || showOnMap) && !document.hidden) loadList(false); }, 120000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
