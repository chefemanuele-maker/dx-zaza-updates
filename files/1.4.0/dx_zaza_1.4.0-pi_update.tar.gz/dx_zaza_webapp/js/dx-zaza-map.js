/* DX Zaza 0.5 — readable, accurate spot map.
 *
 * Each cluster spot has two stations:
 *   DX   the station that is TRANSMITTING on the spotted frequency  -> big dot + callsign label
 *   DE   the spotter who heard it                                   -> small ring
 * joined by the great-circle path, coloured by band. Positions come from the backend
 * (locator in the comment, call area, or DXCC entity from cty.dat).
 * Loaded after dx-zaza-geo.js; replaces the old 3-label CyberNode markers. */
(function () {
  "use strict";

  const MAX_STATIONS = 18;     // DX stations drawn on the map
  const MAP_MAX_AGE_MIN = 30;  // older spots leave the map (they stay in the Live Radio Spots list)
  const MAP_FADE_AGE_MIN = 15; // after this they are drawn faded: probably not on the air any more
  const ageMin = (s) => (Date.now() - (s.receivedAt || Date.now())) / 60000;
  const MAX_LABELS = 18;       // labelled when there is room (the rest: dot + card)
  let pinned = false;          // station card opened by a click

  const BANDS = [
    ["160m", "#c084fc"], ["80m", "#8b9cff"], ["60m", "#60a5fa"], ["40m", "#38bdf8"],
    ["30m", "#2dd4bf"], ["20m", "#4ade80"], ["17m", "#bef264"], ["15m", "#facc15"],
    ["12m", "#fb923c"], ["10m", "#f87171"], ["6m", "#f472b6"], ["4m", "#e879f9"],
    ["2m", "#f0abfc"], ["70cm", "#ffffff"]
  ];
  const BAND_COLOR = Object.fromEntries(BANDS);
  const OTHER_COLOR = "#cbd5e1";
  const colorOf = (band) => BAND_COLOR[String(band || "").toLowerCase()] || OTHER_COLOR;
  window.dxzBandColor = colorOf;

  Object.assign(translations.en, {
    "spots.table.dx": "DX station",
    "spots.table.dx_country": "Transmitting from",
    "spots.table.spotter": "Heard by (spotter)",
    "spots.table.time": "UTC",
    "summary.latest_dx": "Latest DX",
    "map.legend_dx": "transmitting",
    "map.legend_de": "spotter",
    "map.legend_day": "day",
    "map.legend_grey": "grey line",
    "map.legend_night": "night",
    "map.heard_by": "heard by",
    "map.precision_locator": "exact locator",
    "map.precision_call-area": "call area",
    "map.precision_country": "country centre",
    "map.from_you": "from your QTH",
    "map.more": "more stations in Live Radio Spots"
  });
  Object.assign(translations.it, {
    "spots.table.dx": "Stazione DX",
    "spots.table.dx_country": "Trasmette da",
    "spots.table.spotter": "Ascoltata da (spotter)",
    "spots.table.time": "UTC",
    "summary.latest_dx": "Ultimo DX",
    "map.legend_dx": "trasmette",
    "map.legend_de": "chi l'ha ascoltata",
    "map.legend_day": "giorno",
    "map.legend_grey": "grey line",
    "map.legend_night": "notte",
    "map.heard_by": "ascoltata da",
    "map.precision_locator": "locatore esatto",
    "map.precision_call-area": "area del nominativo",
    "map.precision_country": "centro del paese",
    "map.from_you": "dal tuo QTH",
    "map.more": "altre stazioni in Spot Radio Live"
  });

  const G = window.dxZazaGeo;
  const MAP = G.MAP;
  const span = MAP.latTop - MAP.latBottom;
  const pctX = (lon) => ((lon + 180) / 360) * 100;
  const pctY = (lat) => ((MAP.latTop - lat) / span) * 100;
  const onMap = (lat, lon) => typeof lat === "number" && typeof lon === "number" && lat <= MAP.latTop && lat >= MAP.latBottom;
  const esc = (v) => escapeHtml(v == null ? "" : v);

  // ------------------------------------------------------------------ data
  const previousNormalize = window.normalizeLiveDxSpot;
  window.normalizeLiveDxSpot = function (spot) {
    const out = previousNormalize(spot);
    out.dx = spot.dx || "";
    out.dxCountry = spot.dxCountry || "";
    out.dxRegion = spot.dxRegion || "";
    out.dxLat = typeof spot.dxLat === "number" ? spot.dxLat : undefined;
    out.dxLon = typeof spot.dxLon === "number" ? spot.dxLon : undefined;
    out.dxPrecision = spot.dxPrecision || "";
    out.time = spot.time || "";
    // when the cluster posted it (server age at download time)
    out.receivedAt = typeof spot.ageSeconds === "number" ? Date.now() - spot.ageSeconds * 1000 : Date.now();
    return out;
  };

  // real order from the cluster (newest first): no fake rotation, so nothing jumps around
  window.currentSpots = function () {
    if (dxZazaState.setupRequired || !isDxLive()) return [];
    return dxSpotsLive.slice();
  };

  // search matches the DX station or the spotter
  // several bands / modes at once (dxZazaState.bands / .modes, empty = all)
  window.getFilteredDxSpots = function () {
    const bands = (dxZazaState.bands || []).map((b) => b.toLowerCase());
    const modes = (dxZazaState.modes || []).map((m) => m.toLowerCase());
    const search = dxZazaState.search.trim().toUpperCase();
    return currentSpots().filter((s) =>
      (!bands.length || bands.includes(String(s.band || "").toLowerCase())) &&
      (!modes.length || modes.includes(String(s.mode || "").toLowerCase())) &&
      (!search || String(s.dx || "").toUpperCase().includes(search) || String(s.de || "").toUpperCase().includes(search)));
  };

  function stationsForMap() {
    const seen = new Set();
    const out = [];
    for (const s of getFilteredDxSpots()) {
      if (!s.dx || !onMap(s.dxLat, s.dxLon)) continue;
      if (ageMin(s) > MAP_MAX_AGE_MIN) continue;
      const key = s.dx.toUpperCase();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(s);
      if (out.length >= MAX_STATIONS) break;
    }
    return out;
  }

  // ------------------------------------------------------------------ vectors (SVG, drawn by geo)
  window.dxzSpotVectors = function (ctx) {
    if (!ctx.paths) return "";
    let html = "";
    const stations = stationsForMap();
    // oldest first so the newest path is on top
    stations.slice().reverse().forEach((s) => {
      if (!onMap(s.lat, s.lon) && typeof s.lat !== "number") return;
      if (typeof s.lat !== "number" || typeof s.lon !== "number") return;
      const pts = ctx.greatCircle(s.lat, s.lon, s.dxLat, s.dxLon, 72);
      const color = colorOf(s.band);
      const newest = s === stations[0];
      ctx.polylines(pts).forEach((p) => {
        html += "<polyline class=\"dxz-spot-halo\" points=\"" + p + "\"/>";
        html += "<polyline class=\"dxz-spot-path" + (newest ? " newest" : "") + (ageMin(s) > MAP_FADE_AGE_MIN ? " aged" : "") +
          "\" style=\"stroke:" + color + "\" points=\"" + p + "\"/>";
      });
    });
    return html;
  };

  // ------------------------------------------------------------------ label placement
  const measure = (() => {
    const c = document.createElement("canvas").getContext("2d");
    return (text, font) => { c.font = font; return c.measureText(text).width; };
  })();

  function placeLabels(items, W, H) {
    // items: {x, y, w, h, important}; returns {dx, dy} or null for each (px offsets of the label box)
    const placed = [{ x: W - 360, y: 0, w: 360, h: 56 }];   // zoom / style / region controls
    const legend = document.getElementById("dxzLegend");
    if (legend && !legend.hidden) placed.push({ x: 0, y: H - legend.offsetHeight - 14, w: legend.offsetWidth + 14, h: legend.offsetHeight + 14 });
    const dots = items.map((it) => ({ x: it.x - 9, y: it.y - 9, w: 18, h: 18 }));
    const hit = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
    return items.map((it, i) => {
      const g = 9;
      const cands = [
        [g, -it.h / 2], [-g - it.w, -it.h / 2],                 // right, left
        [g - 2, -it.h - g + 4], [g - 2, g - 4],                  // up-right, down-right
        [-it.w - g + 2, -it.h - g + 4], [-it.w - g + 2, g - 4],  // up-left, down-left
        [-it.w / 2, -it.h - g - 2], [-it.w / 2, g + 2],          // above, below
        [g + 18, -it.h / 2], [-g - 18 - it.w, -it.h / 2]         // further right / left
      ];
      for (const [dx, dy] of cands) {
        const box = { x: it.x + dx, y: it.y + dy, w: it.w, h: it.h };
        if (box.x < 2 || box.y < 2 || box.x + box.w > W - 2 || box.y + box.h > H - 2) continue;
        if (placed.some((p) => hit(p, box))) continue;
        if (dots.some((d, j) => j !== i && hit(d, box))) continue;
        placed.push(box);
        return { dx, dy };
      }
      return null;
    });
  }

  // ------------------------------------------------------------------ markers (HTML, crisp text)
  let lastSignature = "";
  window.renderMapMarkers = function () {
    syncMapVisualLayer();
    const layer = document.getElementById("dxMarkers");
    const noResults = document.getElementById("mapNoResults");
    if (!layer) return;
    // the map page is hidden (another page is open): draw when it is shown again, not at size 0
    if (!layer.clientWidth || !layer.clientHeight) { lastSignature = ""; return; }
    const W = layer.clientWidth || 1, H = layer.clientHeight || 1;
    const view = (window.dxzZoom && window.dxzZoom.view()) || { k: 1, tx: 0, ty: 0 };
    const px = (lon, lat) => ({
      x: (pctX(lon) / 100 * W * view.k + view.tx).toFixed(1),
      y: (pctY(lat) / 100 * H * view.k + view.ty).toFixed(1)
    });
    const stations = stationsForMap();
    // redraw only when something changed (data, filters, size, zoom or language)
    const signature = [W, H, view.k.toFixed(3), Math.round(view.tx), Math.round(view.ty), dxZazaState.language,
      stations.map((s) => s.dx + s.frequency + s.de + s.time).join("|")].join("#");
    if (signature === lastSignature && layer.childElementCount) return;
    lastSignature = signature;
    if (noResults) {
      noResults.textContent = dxZazaState.setupRequired ? t("global_map.setup_empty")
        : (isDxLive() ? t("global_map.no_live_filter") : t("global_map.offline_empty"));
      noResults.hidden = stations.length > 0;
    }
    const font = "700 14px \"JetBrains Mono\", SFMono-Regular, Menlo, Consolas, monospace";
    const small = "800 11px \"JetBrains Mono\", SFMono-Regular, Menlo, Consolas, monospace";
    // label boxes are placed in screen pixels (after zoom/pan); stations outside the view get none
    const items = stations.map((s) => ({
      x: pctX(s.dxLon) / 100 * W * view.k + view.tx,
      y: pctY(s.dxLat) / 100 * H * view.k + view.ty,
      w: Math.ceil(measure(s.dx, font) + measure(s.band || "", small) + 30),
      h: 26
    }));
    const visible = items.map((it) => it.x >= 0 && it.x <= W && it.y >= 0 && it.y <= H);
    const order = items.map((it, i) => i).filter((i) => visible[i]).slice(0, MAX_LABELS);
    const placedSlots = placeLabels(order.map((i) => items[i]), W, H);
    const slots = [];
    order.forEach((i, j) => { slots[i] = placedSlots[j]; });

    let html = "";
    // spotters first (under the DX dots)
    stations.forEach((s) => {
      if (!onMap(s.lat, s.lon)) return;
      html += "<span class=\"dxz-de\" data-lon=\"" + s.lon + "\" data-lat=\"" + s.lat + "\" style=\"left:" + px(s.lon, s.lat).x + "px;top:" + px(s.lon, s.lat).y +
        "px;--c:" + colorOf(s.band) + "\" title=\"" + esc(s.de + " · " + (s.country || "")) + "\"></span>";
    });
    stations.forEach((s, i) => {
      const color = colorOf(s.band);
      const slot = slots[i];
      const label = slot ? "<span class=\"dxz-label\" style=\"left:" + slot.dx + "px;top:" + slot.dy + "px\">" +
        "<b>" + esc(s.dx) + "</b><i>" + esc(s.band || "") + "</i></span>" : "";
      html += "<div role=\"button\" tabindex=\"0\" class=\"dxz-dx" + (i === 0 ? " newest" : "") +
        (ageMin(s) > MAP_FADE_AGE_MIN ? " aged" : "") + "\" data-i=\"" + i + "\" style=\"left:" +
        px(s.dxLon, s.dxLat).x + "px;top:" + px(s.dxLon, s.dxLat).y + "px;--c:" + color + "\" data-lon=\"" + s.dxLon + "\" data-lat=\"" + s.dxLat + "\" aria-label=\"" +
        esc(s.dx + " " + s.frequency + " " + (s.dxCountry || "")) + "\"><span class=\"dot\"></span>" + label + "</div>";
    });
    layer.innerHTML = html;
    if (typeof window.dxzAfterMarkers === "function") window.dxzAfterMarkers(layer);
    pinned = false;
    hideCard();
    layer._stations = stations;
    renderLegend(stations);
    if (G.drawVectorLayer) G.drawVectorLayer();
  };

  // screen position (inside #dxMarkers) of a point, with the current zoom: used by the ISS hotspot
  window.dxzMapPoint = function (lon, lat) {
    const layer = document.getElementById("dxMarkers");
    if (!layer) return null;
    const W = layer.clientWidth || 1, H = layer.clientHeight || 1;
    const view = (window.dxzZoom && window.dxzZoom.view()) || { k: 1, tx: 0, ty: 0 };
    return { x: pctX(lon) / 100 * W * view.k + view.tx, y: pctY(lat) / 100 * H * view.k + view.ty, W, H };
  };

  // fast path while zooming / panning: move the markers, labels are placed again afterwards
  window.dxzPositionMarkers = function () {
    const layer = document.getElementById("dxMarkers");
    if (!layer) return;
    const W = layer.clientWidth || 1, H = layer.clientHeight || 1;
    const view = (window.dxzZoom && window.dxzZoom.view()) || { k: 1, tx: 0, ty: 0 };
    layer.querySelectorAll("[data-lon]").forEach((el) => {
      const lon = Number(el.dataset.lon), lat = Number(el.dataset.lat);
      el.style.left = (pctX(lon) / 100 * W * view.k + view.tx).toFixed(1) + "px";
      el.style.top = (pctY(lat) / 100 * H * view.k + view.ty).toFixed(1) + "px";
    });
  };

  function renderLegend(stations) {
    // under the map, not on it: nothing on the map (ISS, stations) is ever hidden by the legend
    const map = document.getElementById("worldMap");
    if (!map) return;
    let el = document.getElementById("dxzLegend");
    if (!el) {
      el = document.createElement("div");
      el.id = "dxzLegend";
      el.className = "dxz-legend";
    }
    if (el.previousElementSibling !== map) map.insertAdjacentElement("afterend", el);
    const bands = BANDS.map((b) => b[0]).filter((b) => stations.some((s) => String(s.band).toLowerCase() === b));
    el.hidden = !stations.length;
    el.innerHTML = bands.map((b) => "<span style=\"--c:" + BAND_COLOR[b] + "\"><i></i>" + esc(b) + "</span>").join("") +
      "<span class=\"key\"><i class=\"dx\"></i>" + esc(t("map.legend_dx")) + "</span>" +
      "<span class=\"key\"><i class=\"de\"></i>" + esc(t("map.legend_de")) + "</span>" +
      ((window.dxZazaGeo && window.dxZazaGeo.geo.layers.daynight) ?
        "<span class=\"key\"><i class=\"day\"></i>" + esc(t("map.legend_day")) + "</span>" +
        "<span class=\"key\"><i class=\"grey\"></i>" + esc(t("map.legend_grey")) + "</span>" +
        "<span class=\"key\"><i class=\"night\"></i>" + esc(t("map.legend_night")) + "</span>" : "");
  }

  // ------------------------------------------------------------------ station card (outside the zoomed layer)
  function cardEl() {
    let card = document.getElementById("dxzSpotCard");
    const frame = document.querySelector(".global-map-page .map-visual-layer");
    if (!card && frame) {
      card = document.createElement("div");
      card.id = "dxzSpotCard";
      card.className = "dxz-card";
      card.hidden = true;
      frame.appendChild(card);
    }
    return card;
  }
  function hideCard() { const c = document.getElementById("dxzSpotCard"); if (c) c.hidden = true; }

  function showCard(btn) {
    const layer = document.getElementById("dxMarkers");
    const card = cardEl();
    const s = layer && layer._stations && layer._stations[Number(btn.dataset.i)];
    if (!s || !card) return;
    const prec = s.dxPrecision ? t("map.precision_" + s.dxPrecision) : "";
    const dist = typeof s.distanceKm === "number"
      ? "<p>" + esc(s.distanceKm.toLocaleString()) + " km · " + esc(Math.round(s.bearing)) + "° " + esc(t("map.from_you")) + "</p>" : "";
    card.innerHTML =
      "<h4 style=\"--c:" + colorOf(s.band) + "\">" + esc(s.dx) + "</h4>" +
      "<p class=\"where\">" + esc(s.dxCountry || "?") + (prec ? " <small>(" + esc(prec) + ")</small>" : "") + "</p>" +
      "<p><strong>" + esc(s.frequency) + "</strong> · " + esc(s.band) + " · " + esc(s.mode) + (s.time ? " · " + esc(s.time) : "") + "</p>" +
      "<p>" + esc(t("map.heard_by")) + " <strong>" + esc(s.de) + "</strong> · " + esc(s.country || "") + "</p>" + dist +
      (s.comment ? "<p class=\"comment\">" + esc(s.comment) + "</p>" : "") +
      (typeof window.dxzCardActions === "function" ? "<div class=\"dxz-card-actions\">" + window.dxzCardActions(s) + "</div>" : "") +
      "<div class=\"dxz-card-qrz\"></div>";
    card.hidden = false;
    card._spot = s;
    const frame = card.parentElement.getBoundingClientRect();
    const r = btn.getBoundingClientRect();
    const x = r.left + r.width / 2 - frame.left, y = r.top + r.height / 2 - frame.top;
    const W = frame.width, H = frame.height, cw = card.offsetWidth, ch = card.offsetHeight;
    card.style.left = Math.max(6, Math.min(W - cw - 6, x + 16 > W - cw - 6 ? x - cw - 16 : x + 16)) + "px";
    card.style.top = Math.max(6, Math.min(H - ch - 6, y - ch / 2)) + "px";
  }

  function fillQrz() {
    const card = document.getElementById("dxzSpotCard");
    if (card && card._spot && window.dxzQrz) window.dxzQrz.fillCard(card.querySelector(".dxz-card-qrz"), card._spot.dx, card);
  }

  document.addEventListener("click", (e) => {
    const btn = e.target.closest && e.target.closest(".dxz-dx");
    const card = document.getElementById("dxzSpotCard");
    if (btn) { showCard(btn); pinned = true; fillQrz(); e.stopPropagation(); return; }
    if (card && !e.target.closest(".dxz-card")) { card.hidden = true; pinned = false; }
  });
  document.addEventListener("keydown", (e) => {
    const btn = e.target.closest && e.target.closest(".dxz-dx");
    if (btn && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); showCard(btn); pinned = true; fillQrz(); }
  });
  document.addEventListener("mouseover", (e) => {
    const btn = e.target.closest && e.target.closest(".dxz-dx");
    if (btn && !pinned) showCard(btn);
  });
  document.addEventListener("mouseout", (e) => {
    const btn = e.target.closest && e.target.closest(".dxz-dx");
    const card = document.getElementById("dxzSpotCard");
    if (btn && card && !pinned && !(e.relatedTarget && btn.contains(e.relatedTarget))) card.hidden = true;
  });

  // ------------------------------------------------------------------ table + summary
  window.renderDxSpotsTable = function () {
    const body = document.getElementById("dxTableBody");
    if (!body) return;
    const spots = getFilteredDxSpots();
    if (!spots.length) {
      const msg = dxZazaState.setupRequired ? t("spots.setup_empty") : (isDxLive() ? t("spots.no_results") : t("spots.offline_empty"));
      body.innerHTML = "<tr><td class=\"no-results-cell\" colspan=\"8\">" + esc(msg) + "</td></tr>";
      return;
    }
    body._spots = spots;   // tap a callsign: details + QRZ card (dx-zaza-qrz.js)
    body.innerHTML = spots.map((s, i) => {
      const dist = typeof s.distanceKm === "number" ? " <small>" + esc(s.distanceKm.toLocaleString()) + " km " + esc(Math.round(s.bearing)) + "°</small>" : "";
      return "<tr data-i=\"" + i + "\" class=\"" + (i === 0 ? "is-latest" : "") + "\">" +
        "<td><strong class=\"dxz-call\" role=\"button\" tabindex=\"0\" style=\"--c:" + colorOf(s.band) + "\">" + esc(s.dx || "?") + "</strong>" + (typeof window.dxzListenMini === "function" ? window.dxzListenMini(i) : "") + "</td>" +
        "<td>" + esc(s.frequency) + "</td>" +
        "<td><span class=\"band-badge dxz-band\" style=\"--c:" + colorOf(s.band) + "\">" + esc(formatTableToken(s.band)) + "</span></td>" +
        "<td><span class=\"mode-badge\">" + esc(formatTableToken(s.mode)) + "</span></td>" +
        "<td>" + esc(s.dxCountry || "?") + dist + "</td>" +
        "<td><span class=\"dxz-de-call\" role=\"button\" tabindex=\"0\">" + esc(s.de) + "</span> <small>" + esc(s.country || "") + "</small></td>" +
        "<td class=\"comment-cell\">" + esc(s.comment) + "</td>" +
        "<td class=\"last-seen-cell\">" + esc(s.time || (i === 0 ? t("spots.just_now") : s.lastSeen)) + "</td></tr>";
    }).join("");
  };

  const previousSummary = window.renderActivitySummary;
  window.renderActivitySummary = function () {
    previousSummary();
    const latest = getFilteredDxSpots()[0];
    const el = document.getElementById("summaryLatestDx");
    if (el) el.textContent = latest ? (latest.dx || latest.de) : "--";
  };

  // back on the map page (see switchPage): lay the markers out again at the real size
  window.dxzMapShown = function () {
    requestAnimationFrame(() => requestAnimationFrame(() => {
      lastSignature = "";
      if (typeof renderMapMarkers === "function") renderMapMarkers();
    }));
  };

  window.addEventListener("resize", () => {
    clearTimeout(window.__dxzMapResize);
    window.__dxzMapResize = setTimeout(() => { if (typeof renderMapMarkers === "function") renderMapMarkers(); }, 150);
  });
  if (typeof renderAllDxViews === "function") renderAllDxViews();
  // label widths depend on the font: place them again once the bundled fonts are loaded
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(() => { lastSignature = ""; renderMapMarkers(); });
  }
})();
