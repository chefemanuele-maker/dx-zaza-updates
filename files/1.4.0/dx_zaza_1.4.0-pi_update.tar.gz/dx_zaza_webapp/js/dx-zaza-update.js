/* DX Zaza — online updates.
   The app checks by itself (backend, every few hours). When a new version exists a button appears
   next to the clocks: one press downloads the signed update, installs it and restarts DX Zaza.
   Settings shows the installed version and a "check now" button. */
(function () {
  "use strict";
  const POLL_IDLE = 5 * 60 * 1000;
  const POLL_BUSY = 1500;
  let timer = null;
  let last = null;
  let restarting = false;

  function it() { return (document.documentElement.lang || "").startsWith("it") || (window.dxZazaState && window.dxZazaState.language === "it"); }
  const T = {
    newVersion: () => it() ? "Nuova versione" : "New version",
    update: () => it() ? "Aggiorna" : "Update",
    downloading: () => it() ? "Scarico…" : "Downloading…",
    installing: () => it() ? "Installo…" : "Installing…",
    restarting: () => it() ? "Riavvio DX Zaza…" : "Restarting DX Zaza…",
    title: () => it() ? "AGGIORNAMENTI" : "UPDATES",
    installed: () => it() ? "Versione installata" : "Installed version",
    check: () => it() ? "Controlla ora" : "Check now",
    checking: () => it() ? "Controllo…" : "Checking…",
    current: () => it() ? "DX Zaza è aggiornato." : "DX Zaza is up to date.",
    available: (v) => (it() ? "Disponibile la versione " : "Version ") + v + (it() ? "." : " is available."),
    offline: () => it() ? "Impossibile controllare ora (nessuna connessione?). Riprovo da solo più tardi." : "Could not check now (no connection?). It will retry by itself.",
    auto: () => it() ? "DX Zaza controlla da solo gli aggiornamenti. Gli aggiornamenti sono firmati digitalmente: vengono installati solo quelli ufficiali. Le tue impostazioni restano." :
      "DX Zaza checks for updates by itself. Updates are digitally signed: only official ones are installed. Your settings are kept.",
    unsupported: () => it() ? "Aggiornamento automatico non ancora disponibile su questo sistema." : "Automatic updates are not available on this system yet."
  };

  function el(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = text;
    return node;
  }

  function chip() {
    let node = document.getElementById("dxzUpdate");
    if (node) return node;
    const bar = document.querySelector(".global-clock-bar");
    if (!bar) return null;
    node = el("button", "time-chip update-chip");
    node.id = "dxzUpdate";
    node.type = "button";
    node.hidden = true;
    node.append(el("span"), el("strong"));
    node.addEventListener("click", install);
    bar.insertBefore(node, bar.firstChild);
    return node;
  }

  function card() {
    let node = document.getElementById("dxzUpdateCard");
    if (node) return node;
    const anchor = document.querySelector(".system-settings-card");
    if (!anchor) return null;
    node = el("section", "wifi-card update-card");
    node.id = "dxzUpdateCard";
    node.innerHTML = '<p class="eyebrow"></p><div class="update-body">' +
      '<p class="update-version"><span></span> <strong></strong></p>' +
      '<p class="update-state" role="status"></p><p class="update-notes"></p>' +
      '<div class="update-actions"><button type="button" class="secondary-action update-check"></button>' +
      '<button type="button" class="primary-action update-now" hidden></button></div>' +
      '<p class="wifi-demo-note update-auto"></p></div>';
    node.querySelector(".update-check").addEventListener("click", checkNow);
    node.querySelector(".update-now").addEventListener("click", install);
    anchor.after(node);
    return node;
  }

  function render(d) {
    last = d;
    const c = chip();
    const k = card();
    const working = d.state === "downloading" || d.state === "installing";
    if (c) {
      c.hidden = !(d.state === "available" || working || restarting);
      c.classList.toggle("is-working", working || restarting);
      c.disabled = working || restarting || Boolean(d.busy);
      c.querySelector("span").textContent = restarting ? T.restarting() :
        working ? (d.state === "downloading" ? T.downloading() + " " + (d.progress || 0) + "%" : T.installing()) :
        T.newVersion() + " " + (d.latest || "");
      c.querySelector("strong").textContent = working || restarting ? "⟳" : "⬆ " + T.update();
      c.title = d.busy || d.notes || "";
    }
    if (k) {
      k.querySelector(".eyebrow").textContent = T.title();
      k.querySelector(".update-version span").textContent = T.installed() + ":";
      k.querySelector(".update-version strong").textContent = d.current || "";
      let state = "";
      if (!d.supported) state = T.unsupported();
      else if (restarting) state = T.restarting();
      else if (d.state === "downloading") state = T.downloading() + " " + (d.progress || 0) + "%";
      else if (d.state === "installing") state = T.installing();
      else if (d.state === "checking") state = T.checking();
      else if (d.state === "available") state = T.available(d.latest);
      else if (d.state === "current") state = T.current();
      else if (d.state === "error") state = T.offline();
      if (d.error && /install/.test(d.error)) state += " ⚠ " + d.error;
      if (d.busy && d.state === "available") state += " — " + d.busy;
      k.querySelector(".update-state").textContent = state;
      k.querySelector(".update-notes").textContent = d.state === "available" ? (d.notes || "") : "";
      const btn = k.querySelector(".update-now");
      btn.hidden = d.state !== "available";
      btn.disabled = Boolean(d.busy);
      btn.textContent = "⬆ " + T.update() + " " + (d.latest || "");
      const chk = k.querySelector(".update-check");
      chk.textContent = d.state === "checking" ? T.checking() : T.check();
      chk.disabled = !d.supported || working || d.state === "checking";
      k.querySelector(".update-auto").textContent = T.auto();
    }
  }

  function schedule(ms) {
    clearTimeout(timer);
    timer = setTimeout(load, ms);
  }

  async function load() {
    let d = null;
    try {
      const res = await fetch("/api/update/status", { cache: "no-store" });
      d = await res.json();
    } catch (_) {
      d = null;   // DX Zaza is restarting (during an update this is expected)
    }
    if (!d) { schedule(restarting ? 2000 : 30000); return; }
    if (restarting && last && d.current && d.current !== restartFrom) {
      location.reload();
      return;
    }
    if (restarting && d.state === "available") restarting = false;   // install failed: show why
    render(d);
    const working = d.state === "downloading" || d.state === "installing" || d.state === "checking";
    if (d.state === "installing") { restarting = true; restartFrom = d.current; }
    schedule(working || restarting ? POLL_BUSY : POLL_IDLE);
  }
  let restartFrom = "";

  async function checkNow() {
    if (last) render(Object.assign({}, last, { state: "checking" }));
    try {
      const res = await fetch("/api/update/check", { method: "POST", cache: "no-store" });
      render(await res.json());
    } catch (_) { /* retry by itself */ }
    schedule(POLL_IDLE);
  }

  async function install() {
    if (!last || last.state !== "available" || last.busy) return;
    render(Object.assign({}, last, { state: "downloading", progress: 0 }));
    try {
      const res = await fetch("/api/update/install", { method: "POST", cache: "no-store" });
      const d = await res.json();
      if (!d.ok && d.error) render(Object.assign({}, last, { state: "available", busy: d.error }));
    } catch (_) { /* status poll shows what happened */ }
    schedule(POLL_BUSY);
  }

  function boot() {
    chip(); card(); load();
    // the backend makes its first check about 40 s after start: show the result soon after
    setTimeout(load, 50000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
