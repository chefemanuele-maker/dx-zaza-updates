"""KiwiSDR receivers: listen to the bands through a KiwiSDR web receiver from inside DX Zaza.

The operator adds receivers by address: their own KiwiSDR, or public ones they choose from the
public list (rx.kiwisdr.com, opened in the browser by the operator: DX Zaza does not read that
list automatically). For each receiver DX Zaza reads its public status page (http://host:port/status,
the same one the KiwiSDR network uses) to know name, position, antenna, free channels and limits.
The Listen page then shows the receiver's own web interface tuned to a frequency and mode
(URL ?f=14074usbz10), so the receiver owner's rules (time limits, passwords, channels) always apply.

Courtesy: status is read at most every 2 minutes per receiver, only while someone looks at the
list or asks to listen; the receiver is released as soon as the operator leaves the Listen page.
"""
import ipaddress
import math
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse

import requests

STATUS_TTL = 120
STATUS_TIMEOUT = (4, 6)
MAX_RECEIVERS = 40
KEEP_FIELDS = ("status", "offline", "name", "sdr_hw", "bands", "users", "users_max", "gps", "grid", "loc",
               "antenna", "snr", "sw_version", "auth", "asl")
GPS_RE = re.compile(r"\(\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\)")
DEFAULT_PORT = 8073
PUBLIC_LIST_URL = "http://rx.kiwisdr.com/"
# machine-readable copy of the public KiwiSDR list, published for map makers (regenerated every few
# minutes from kiwisdr.com/public). Read at most every 30 minutes, kept on disk.
DIRECTORY_URL = "http://rx.linkfanel.net/kiwisdr_com.js"
DIRECTORY_TTL = 30 * 60
DIRECTORY_CREDIT = "Receiver list: rx.linkfanel.net (KiwiSDR public list)"
VERIFY_TOP = 4
BAD_RECEIVER_SECONDS = 10 * 60


def normalize_url(value):
    """'kiwi.example.org:8073' -> 'http://kiwi.example.org:8073'. Raises ValueError."""
    text = str(value or "").strip()
    if not text:
        raise ValueError("Type the address of the KiwiSDR")
    if "://" not in text:
        text = "http://" + text
    u = urlparse(text)
    if u.scheme not in ("http", "https") or not u.hostname or u.username or u.password:
        raise ValueError("Use an address like kiwi.example.org:8073")
    host = u.hostname.lower()
    if not re.fullmatch(r"[a-z0-9.\-]+|[0-9a-f:]+", host):
        raise ValueError("Use an address like kiwi.example.org:8073")
    try:
        port = u.port or (DEFAULT_PORT if u.scheme == "http" else 443)
    except ValueError:
        raise ValueError("The port must be a number")
    shown = "[%s]" % host if ":" in host else host
    default = (u.scheme == "https" and port == 443)
    return "%s://%s%s" % (u.scheme, shown, "" if default else ":%d" % port)


def is_local_address(url):
    host = urlparse(url).hostname or ""
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_private or ip.is_loopback or ip.is_link_local
    except ValueError:
        return host.endswith(".local") or host == "localhost"


def parse_status(text):
    info = {}
    for line in str(text or "").splitlines()[:80]:
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key in KEEP_FIELDS:               # never keep op_email or the IP fields
            info[key] = value.strip()[:160]
    if "users_max" not in info or "KiwiSDR" not in info.get("sdr_hw", "") + info.get("sw_version", ""):
        raise ValueError("This address does not answer like a KiwiSDR")
    out = {
        "name": info.get("name", "")[:120],
        "loc": info.get("loc", "")[:80],
        "antenna": info.get("antenna", "").strip()[:80],
        "grid": info.get("grid", "")[:8],
        "online": info.get("status", "active") in ("active", "private") and info.get("offline", "no") != "yes",
        "users": _int(info.get("users")),
        "usersMax": _int(info.get("users_max")),
        "password": info.get("auth") == "password",
        "limits": "Limits" in info.get("sdr_hw", ""),
        "gps": "GPS" in info.get("sdr_hw", ""),
        "snr": _int((info.get("snr", "0").split(",") + ["0", "0"])[1]),
        "version": info.get("sw_version", "").replace("KiwiSDR_", "")[:20],
    }
    m = GPS_RE.search(info.get("gps", ""))
    if m:
        lat, lon = float(m.group(1)), float(m.group(2))
        if -90 <= lat <= 90 and -180 <= lon <= 180 and not (lat == -69.0 and lon == 90.0):   # -69,90 = "not set"
            out["lat"], out["lon"] = round(lat, 3), round(lon, 3)
    lo, _, hi = info.get("bands", "0-30000000").partition("-")
    out["bandLowKHz"], out["bandHighKHz"] = _int(lo) // 1000, (_int(hi) // 1000) or 30000
    return out


def _int(value):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0


def distance_km(lat1, lon1, lat2, lon2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 6371.0 * 2 * math.asin(min(1.0, math.sqrt(a)))


# FT8 / FT4 "dial" frequencies (kHz, USB): the signals sit 0-3 kHz above them
FT8_DIALS = (1840, 3573, 5357, 7074, 10136, 14074, 18100, 21074, 24915, 28074)
FT4_DIALS = (3575.5, 7047.5, 10140, 14080, 18104, 21140, 24919, 28180)


def ftx_dial(mode, freq_khz):
    """Dial frequency for an FT8/FT4 spot (the receiver is tuned there, USB 0-3 kHz), else 0."""
    dials = FT4_DIALS if mode == "ft4" else FT8_DIALS
    for d in dials:
        if d - 0.05 <= freq_khz <= d + 3.2:
            return float(d)
    return round(freq_khz - 1.5, 2) if mode in ("ft8", "ft4") else 0.0


def kiwi_mode(mode, freq_khz):
    m = str(mode or "").upper()
    if m in ("CW", "CW-R"):
        return "cw"
    if m == "FT8":
        return "ft8"
    if m == "FT4":
        return "ft4"
    if m in ("AM",):
        return "am"
    if m in ("FM", "NFM"):
        return "nbfm"
    if m == "LSB":
        return "lsb"
    if m == "USB":
        return "usb"
    if m in ("SSB", "PHONE", ""):
        if m == "" and any(d <= freq_khz <= d + 3.2 for d in FT8_DIALS):
            return "ft8"
        return "lsb" if 0 < freq_khz < 10000 else "usb"
    return "usb"                                     # RTTY, PSK, JT65, ... upper sideband


def parse_freq_khz(value):
    """'14.246 MHz' / '14246.0' / 14074 -> kHz (float), or 0."""
    text = str(value or "").strip().lower().replace(",", ".")
    m = re.search(r"\d+(?:\.\d+)?", text)
    if not m:
        return 0.0
    f = float(m.group(0))
    if "mhz" in text or f < 1000:
        f *= 1000.0
    return round(f, 2) if 10 <= f <= 32000 else 0.0


def listen_url(base, freq_khz, mode, callsign="", zoom=10):
    if mode in ("ft8", "ft4"):                       # the full KiwiSDR page: USB on the dial frequency
        freq_khz, mode = ftx_dial(mode, freq_khz), "usb"
    f = ("%.2f" % freq_khz).rstrip("0").rstrip(".")
    url = "%s/?f=%s%sz%d" % (base, f, mode, zoom)
    if callsign:
        url += "&u=" + re.sub(r"[^A-Z0-9/]", "", callsign.upper())[:20]
    return url


def parse_directory(text):
    """'var kiwisdr_com = [ {...}, ... ];' -> list of receivers (public fields only, no e-mail)."""
    import json
    var = text.find("kiwisdr_com")
    start, end = text.find("[", max(0, var)), text.rfind("]")
    if start < 0 or end <= start:
        raise ValueError("not a KiwiSDR list")
    body = re.sub(r",\s*([\]}])", r"\1", text[start:end + 1])      # JavaScript allows trailing commas
    rows = json.loads(body)
    out = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        if str(row.get("offline", "no")) == "yes" or str(row.get("status", "active")) not in ("active", ""):
            continue
        try:
            url = normalize_url(row.get("url", ""))
        except ValueError:
            continue
        lines = "\n".join("%s=%s" % (k, row[k]) for k in KEEP_FIELDS if k in row)
        try:
            info = parse_status(lines)
        except ValueError:
            continue
        if "lat" not in info:
            continue
        info["url"] = url
        out.append(info)
    return out


class PublicKiwiList:
    def __init__(self, session=None, clock=time.time, store_path=None, url=DIRECTORY_URL):
        self.session = session or requests.Session()
        self.clock = clock
        self.store_path = store_path
        self.url = url
        self.rows, self.loaded_at, self.error = [], 0.0, ""
        self.lock = threading.Lock()
        self._load_store()

    def _load_store(self):
        import json
        try:
            data = json.loads(open(self.store_path, encoding="utf-8").read()) if self.store_path else None
        except (OSError, ValueError):
            data = None
        if data and isinstance(data.get("rows"), list):
            self.rows, self.loaded_at = data["rows"], float(data.get("at", 0))

    def get(self):
        with self.lock:
            if self.rows and self.clock() - self.loaded_at < DIRECTORY_TTL:
                return self.rows
            try:
                r = self.session.get(self.url, timeout=(6, 25), headers={"User-Agent": "DXZaza (KiwiSDR receiver choice)"})
                r.raise_for_status()
                rows = parse_directory(r.content.decode("utf-8", "replace"))   # no charset in the reply: never guess Latin-1
                if rows:
                    self.rows, self.loaded_at, self.error = rows, self.clock(), ""
                    self._save()
            except Exception as exc:                 # keep the last list (also from disk)
                self.error = str(exc)[:120]
                self.loaded_at = self.clock() - DIRECTORY_TTL + 300 if self.rows else self.loaded_at
            return self.rows

    def _save(self):
        import json
        if not self.store_path:
            return
        try:
            tmp = str(self.store_path) + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"at": self.loaded_at, "rows": self.rows}, fh)
            import os
            os.replace(tmp, self.store_path)
        except OSError:
            pass


def spot_score(r, freq_khz, spotter=None, home=None, dx=None):
    """Lower is better. The station that spotted the DX heard it on that frequency: a receiver
    near the spotter is the best bet to hear the same signal. Then quiet antenna (SNR), free
    channels, and the operator's own receiver gets a bonus."""
    ref = spotter or home or dx
    d = distance_km(ref[0], ref[1], r["lat"], r["lon"]) if ref and "lat" in r else 15000.0
    score = d
    if dx and "lat" in r and distance_km(dx[0], dx[1], r["lat"], r["lon"]) < 150:
        score += 400                                  # too close to the DX: overloaded / ground wave only
    score -= min(40, max(0, r.get("snr", 0))) * 25    # good antenna / quiet location
    if r.get("usersMax"):
        score += 600 * r.get("users", 0) / r["usersMax"]
    if r.get("limits"):
        score += 150
    if r.get("own"):
        score -= 1500
    return score


class KiwiDirectory:
    def __init__(self, get_receivers, save_receivers, session=None, clock=time.time, public=None, use_public=None):
        self.public = public                          # PublicKiwiList or None
        self.use_public = use_public or (lambda: True)
        self.bad = {}                                 # url -> time it failed (skip for a while)
        self.get_receivers = get_receivers          # -> list of {"url", "label", "own"}
        self.save_receivers = save_receivers
        self.session = session or requests.Session()
        self.clock = clock
        self.cache = {}                             # url -> (time, info or None, error)
        self.lock = threading.Lock()
        self.pool = ThreadPoolExecutor(max_workers=6, thread_name_prefix="kiwi")

    def preload(self):
        """Read the public list in the background at start-up, so the first Listen is quick."""
        if self.public is not None and self.use_public():
            threading.Thread(target=self.public.get, name="kiwi-list", daemon=True).start()

    # ------------------------------------------------------------ status
    def fetch(self, url):
        try:
            r = self.session.get(url + "/status", timeout=STATUS_TIMEOUT, headers={"User-Agent": "DXZaza (KiwiSDR status)"},
                                 allow_redirects=False)
            r.raise_for_status()
            info, err = parse_status(r.content[:20000].decode("utf-8", "replace")), ""
        except ValueError as exc:
            info, err = None, str(exc)
        except Exception:
            info, err = None, "not reachable"
        with self.lock:
            self.cache[url] = (self.clock(), info, err)
        return info, err

    def status(self, url, fresh=False):
        with self.lock:
            hit = self.cache.get(url)
        if hit and not fresh and self.clock() - hit[0] < STATUS_TTL:
            return hit[1], hit[2]
        return self.fetch(url)

    def receivers(self, home=None, fresh=False):
        saved = list(self.get_receivers() or [])
        results = list(self.pool.map(lambda r: self.status(r["url"], fresh), saved)) if saved else []
        out = []
        for rec, (info, err) in zip(saved, results):
            item = {"url": rec["url"], "label": rec.get("label", ""), "own": bool(rec.get("own")),
                    "local": is_local_address(rec["url"]), "ok": info is not None, "error": err}
            if info:
                item.update(info)
                item["free"] = item["online"] and item["users"] < item["usersMax"]
                if home and "lat" in item:
                    item["distanceKm"] = round(distance_km(home[0], home[1], item["lat"], item["lon"]))
            out.append(item)
        return out

    # ------------------------------------------------------------ list management
    def add(self, value, label="", own=False):
        url = normalize_url(value)
        saved = list(self.get_receivers() or [])
        if any(r["url"] == url for r in saved):
            raise ValueError("This receiver is already in the list")
        if len(saved) >= MAX_RECEIVERS:
            raise ValueError("The list is full (%d receivers)" % MAX_RECEIVERS)
        info, err = self.fetch(url)
        if info is None:
            raise ValueError("No KiwiSDR answered at %s (%s)" % (url, err))
        saved.append({"url": url, "label": str(label or "")[:60], "own": bool(own)})
        self.save_receivers(saved)
        return dict(info, url=url, own=bool(own))

    def remove(self, url):
        saved = [r for r in (self.get_receivers() or []) if r["url"] != url]
        self.save_receivers(saved)

    def set_own(self, url, own):
        saved = list(self.get_receivers() or [])
        for r in saved:
            if r["url"] == url:
                r["own"] = bool(own)
        self.save_receivers(saved)

    # ------------------------------------------------------------ choose
    def best(self, freq_khz, near=None, home=None, exclude=(), dx=None, verify=True):
        """Receivers that can take a listener on this frequency, the best first (see spot_score).
        Candidates: the operator's receivers plus the public KiwiSDR network. The best few are
        checked live (free channel right now) before they are proposed."""
        now = self.clock()
        mine = [dict(r, own=r.get("own", False), saved=True) for r in self.receivers(home=home)
                if r.get("ok") and r.get("free") and (r.get("own") or not r.get("password"))]
        seen = {r["url"] for r in mine}
        pub = []
        if self.public is not None and self.use_public():
            for r in self.public.get():
                if r["url"] not in seen and r.get("online") and r.get("users", 0) < r.get("usersMax", 0) and not r.get("password"):
                    pub.append(dict(r, free=True, saved=False))
        cands = [r for r in mine + pub if r.get("bandLowKHz", 0) <= freq_khz <= r.get("bandHighKHz", 30000)
                 and r["url"] not in exclude and now - self.bad.get(r["url"], -1e9) > BAD_RECEIVER_SECONDS]
        cands.sort(key=lambda r: spot_score(r, freq_khz, spotter=near, home=home, dx=dx))
        ref = near or home
        # check the first few candidates at the same time (not one after the other): faster answer
        checked = None
        if verify:
            todo = [r["url"] for r in cands if not r.get("saved")][:VERIFY_TOP + 3]
            checked = dict(zip(todo, (res[0] for res in self.pool.map(lambda u: self.status(u, fresh=True), todo))))
        out, tries = [], 0
        for r in cands:
            if verify and not r.get("saved") and len(out) < VERIFY_TOP:
                tries += 1
                if tries > VERIFY_TOP + 3:
                    break
                info = checked.get(r["url"]) if checked is not None else self.status(r["url"], fresh=True)[0]
                if info is None or not info["online"] or info["users"] >= info["usersMax"] or info["password"]:
                    self.bad[r["url"]] = now
                    continue
                r.update(info)
            if ref and "lat" in r:
                r["fromRefKm"] = round(distance_km(ref[0], ref[1], r["lat"], r["lon"]))
            out.append(r)
            if len(out) >= 10:
                break
        return out
