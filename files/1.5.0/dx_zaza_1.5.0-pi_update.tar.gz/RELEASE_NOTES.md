# 1.5.0 — Licence and map card

- Licence: every device is activated once with the licence key printed on the card in the box
  (Settings > Licence, or the window shown after the 14-day trial). The key is bound to that
  device by the DX Zaza licence server; afterwards DX Zaza checks it without internet. A key
  can be moved to another device once every 30 days. Updates are delivered to activated
  devices only.
- Map: the station card opens only with a click on the callsign (not on the dot, not on
  mouse-over) and stays open until its × is pressed, also while new spots arrive.

# 1.4.0 — Decoders in Listen Live (CW, FT8, FT4)

- Listen Live now reads what it hears. For a CW spot, a CW decoder under the waterfall finds
  the tone by itself, learns the speed (WPM) and writes the text as it is sent; it stays quiet on
  plain noise. For FT8 and FT4 spots the receiver is tuned to the whole FT8/FT4 sub-band (dial
  frequency, USB 100-3000 Hz) and every 15 s (FT8) or 7.5 s (FT4), aligned to UTC like WSJT-X,
  the decoded messages appear: time, SNR, audio frequency and message. CQ calls are green, lines
  with the spotted station are highlighted.
- Decoding runs on the customer's device from the receiver audio; nothing is sent anywhere.
  FT8/FT4 use ft8_lib by Kārlis Goba (MIT licence) compiled to WebAssembly (tools/ftx_wasm);
  the CW decoder is DX Zaza's own. The computer clock must be right (automatic time on).
- The full KiwiSDR page opens FT8/FT4 spots on the dial frequency.
- Spot list: the bell characters some cluster nodes add to comments no longer show as empty
  boxes; on laptop-size windows every column, UTC time included, fits without side scrolling.
- KiwiSDR receiver names with accents or symbols are shown correctly (the list is read as UTF-8).

# 1.3.0 — Listen (KiwiSDR web receivers)

- Listen Live: the station card has a "Listen Live" button. DX Zaza picks by itself the KiwiSDR
  most likely to hear that station — free, close to the station that spotted it (it heard the
  signal on that frequency), quiet antenna, your own receiver first when it fits — among your
  receivers and the public KiwiSDR network, checks live that it has a free channel and opens a
  clean player: only the waterfall around the spot, the passband, an S-meter and the real audio
  (DX Zaza talks to the receiver with its public WebSocket protocol, one listener like its web
  page). Busy receivers are skipped automatically; buttons: sound, another receiver, open the
  full KiwiSDR interface on the "Listen KiwiSDR" page, stop.
- Public network: the list published for map makers at rx.linkfanel.net (generated from the
  KiwiSDR public list), read at most every 30 minutes and kept on disk; config
  "kiwisdr": {"public": false} turns it off.

- New "Listen" page: hear the bands through KiwiSDR web receivers, no radio needed. Tune any
  frequency from 10 kHz to 30 MHz (quick buttons for the FT8/CW/SSB calling frequencies) and the
  receiver's own web interface (audio, waterfall, decoders) opens inside DX Zaza.
- "Listen" on every spot (station card on the map, headphone button in the spot list): DX Zaza
  picks a free receiver close to the station that heard the spot and tunes it to the spot
  frequency and mode.
- Receivers: the operator's own KiwiSDR (marked as mine, always preferred) and public receivers
  the operator adds by address from rx.kiwisdr.com (the public list is opened by the operator,
  not read automatically). Each receiver's public status page gives name, position, antenna, free
  channels and limits (read at most every 2 minutes); the e-mail field of the status is never kept.
- Map layer "KiwiSDR": the receivers on the world map (green free, red full, yellow your own);
  tap one to listen there.
- Courtesy: the receiver channel is released when you press Stop or leave the page; receivers
  with a password are used only if they are your own.

# 1.2.1 (Windows, Raspberry Pi, Mac)

- Settings shows the "Updates" card on the desktop apps too (it was hidden together with the
  Raspberry-only Wi-Fi cards).
- The update button appears within a minute of start-up when a new version is out.

# 1.2.0 (Windows, Raspberry Pi) — online updates

- DX Zaza checks by itself for new versions (at start-up and every 6 hours). When one is out, a
  green "New version — Update" button appears next to the clocks: one press downloads the update,
  installs it and restarts DX Zaza. Settings shows the installed version and a "Check now" button.
- Updates come from the official DX Zaza releases on GitHub and are digitally signed (Ed25519):
  the app installs only updates signed with the DX Zaza key and whose file matches the signed
  checksum, and never an older version. Settings are kept.
- Never while on air: the button waits while you are transmitting, receiving or linked.
- Windows: the new installer runs silently in the same place, then DX Zaza reopens.
- Raspberry Pi: a small root-owned helper re-checks the signature and runs the usual update
  (backup, health check, automatic rollback). Installed once by the normal update to 1.2.0.

# 1.1.0 (Mac, Raspberry Pi, Windows) — HF bands right now

- New "HF bands right now" on the HF Propagation page: which bands are open at this moment, worked
  out by DX Zaza from the live DX cluster spots of the last 15 minutes (no forecast, no third-party
  table, nothing to license). Each band shows Excellent / Good / Fair / Far only / No activity, with
  the spots heard by stations within 2,000 km of your QTH, the countries, the longest path and the
  modes in use, plus the three best bands now. Updated every minute.
- The N0NBH message is gone: N0NBH's calculated table appears only if it is switched on
  (with N0NBH's permission for units that are sold).

# 1.0.1 (Windows) — first Windows build

- Built and checked on Windows 11 Pro (x64): Python 3.12.10, PortAudio 19.7, PyInstaller 6.22,
  installer made with Inno Setup 6.7 (DX-Zaza-1.0.1-Windows-x64-Setup.exe, 22.8 MB, per-user
  install, Start-menu and desktop icons). The built app passed the start-up check (all pages and
  APIs answer; NOAA, satellites, ISS, C4FM and DMR lists live; Windows sound devices listed) and
  runs in its own window (Microsoft Edge WebView2), ISS Live with sound working.
- Same features as macOS 1.0.0 plus the later shared fixes (speaker released on unlink, ISS
  player self-healing, adaptive audio buffer).
- Tests of Raspberry-only parts (udev, nmcli Wi-Fi, ALSA HDMI) are skipped on Windows.
- Not yet: code-signing certificate (Windows SmartScreen will warn on first start), test with the
  DVstick and a microphone on Windows.

# 1.0.8 (Raspberry Pi) — ISS Live sound, real cause

- The real reason why turning on the ISS sound froze the video: after the first radio link DX Zaza
  kept the screen's HDMI sound output open even when unlinked, and on the Raspberry that output can
  be used by one program at a time, so the browser could not play the ISS sound. DX Zaza now
  releases the speaker when you unlink (it opens it again on the next link).

# 1.0.7 (Raspberry Pi) — ISS Live sound on the touch screen

- Turning on the ISS Live sound paused the video on the Raspberry: the screen's browser blocks
  sound started by a page script. The kiosk browser (which only ever shows DX Zaza) now allows it
  (--autoplay-policy=no-user-gesture-required); the quick update adds the setting to the existing
  kiosk start script (backup kept, restored if the change cannot be verified), new installs get it
  from setup_kiosk_autostart.sh.

# 1.0.6 (Raspberry Pi) — ISS Live restarts reliably

- After a radio link (or the reload button) the ISS video could stay paused with a spinner: it
  restarted with sound on, which the browser does not allow without a tap. Automatic restarts are now
  always silent (tap the speaker button to hear it), and DX Zaza watches the state the YouTube player
  reports: a player that does not reach "playing" is started again muted, then rebuilt at the live
  edge; only if that fails too a short message asks for one tap on ↻.

# 1.0.5 (Raspberry Pi) — ISS video and radio audio never fight for the speaker

- Found on the real Raspberry: the browser's ISS video kept the HDMI sound output, so DX Zaza's
  voice could not open the speaker ("Device unavailable"). Now the video is stopped the instant a
  link is requested (D-STAR, DMR, C4FM, EchoLink), and if the speaker is still busy for a moment
  the voice engine retries every 2 s until it opens (the link stays up, no audio lost after that).

# 1.0.4 (Raspberry Pi) — lighter and faster

- ISS Live on the Raspberry stops the video while a radio link is up (D-STAR, DMR, C4FM,
  EchoLink) and starts it again, live, when you unlink: the 4 small cores stay free for the voice
  audio. The player shows why it is paused.
- Voice audio buffer: starts at 80 ms and grows up to 240 ms only if real gaps are heard (busy
  Raspberry or jittery internet). The gap counter now counts only real gaps inside an over, not the
  normal end of every over (the 36 "gaps" seen in the test were mostly ends of overs).
- Less work in the background: the voice status is read every 1.5 s on the voice page when nobody
  is talking (0.6 s while on air), every 5 s elsewhere, every 10 s when the screen is hidden.
- "Controlla Raspberry" shows which programs use the processor and the real audio gaps.

# 1.0.3 (Raspberry Pi)

- ISS Live no longer covers the map or the other pages: the player now sits inside the menu
  column, under the Restart button (compact title bar on the 7"/10" touch screen). When there
  is no room, or when enlarged, it can be dragged anywhere by its title bar (finger or mouse).
  It hides while the on-screen keyboard is open (the video keeps playing).

# 1.0.2 (Raspberry Pi)

- Map: after moving the map the area button shows "Area" (or "World" when not zoomed) instead of
  repeating the zoom number already shown between − and +.
- Checked on the real Raspberry Pi 4 with 1.0.1: DX cluster 0 drops in 2 hours, NOAA, weather,
  satellites, ISS Live, C4FM (1,646 rooms), DMR (1,263 servers), EchoLink directory reachable,
  EchoLink codec 3.4 ms + 2.7 ms per 20 ms packet, 52 °C, no throttling, no app errors.

# 1.0.1 (Raspberry Pi) — the 1.0 features on the touch screen

- Everything in desktop 1.0.0 (C4FM, EchoLink without router setup, DMR, ISS Live, start-up
  screen, reliable DX cluster with automatic SSID, weather retries, real NOAA solar wind, security).
- Touch screen: the on-screen keyboard closes when you change page; the floating ISS player sits
  next to the menu (the Restart button stays visible) and hides while the keyboard is open; the
  ISS card fits the 600-pixel-high screen.
- "Controlla Raspberry" also checks the DX cluster node and login, NOAA, ISS Live, C4FM/DMR/EchoLink
  lists and how fast this Raspberry runs the EchoLink codec.

# 1.0.0 (desktop) — first release

Final check passed on the developer's Mac (macOS, Apple Silicon): all pages, live data, ISS Live,
D-STAR with the DVstick, DX cluster stable for 20+ minutes next to a Raspberry Pi with the same
callsign; 231 automated tests. Content = 0.9.5 below, plus: dxfun.com removed from the DX cluster
fallback nodes (it did not answer).

# 0.9.5 (desktop) — final check before sale

- Security: other web pages open in the user's browser can no longer send commands to DX Zaza
  (cross-site requests and DNS-rebinding host names are refused).
- Space weather: NOAA retired the 5-minute solar-wind files; solar wind speed, density, Bz and Bt
  now come from NOAA's ACE hourly data (real-time RTSW as fallback). NOAA fill values are never shown.
- DX cluster: found the real cause of the reconnection every 2-4 minutes — the Raspberry Pi and the
  Mac logged in with the same callsign and the node ("Reconnected as M7ESZ ..., this instance is
  disconnected") kept dropping one of them. DX Zaza now recognises that message and logs in with an
  SSID (e.g. M7ESZ-4, the usual way to run several cluster sessions with one callsign); the node in
  use and the SSID are shown on the spots page.
- A short DNS hiccup no longer blanks the spot list while the DX cluster is delivering spots.
- Third-party notices shipped inside the app (docs/THIRD_PARTY_NOTICES.md); data-source and
  commercial checklists updated.
- "Controlla app Mac" also checks ISS Live and every online source the app uses.

# 0.9.4 (desktop) — ISS Live, clean player

- ISS Live plays only NASA's official space-station stream in a clean player: no YouTube control
  bar, keyboard shortcuts, annotations or captions; related videos only from NASA; no "open on
  YouTube" link. DX Zaza's own buttons: sound, back to live (reload), enlarge, close.
  YouTube's small logo/title stay: YouTube's terms do not allow hiding or covering them.

# 0.9.3 (desktop) — ISS Live

- New "ISS Live" button on the Global Map: NASA's official live video from the space station
  ("Live High-Definition Views from the ISS") opens in a small player under the menu, with sound
  on/off, enlarge and close. It keeps playing while you move between pages. DX Zaza finds the
  stream by itself (checked with YouTube's oEmbed: only NASA's own space-station stream is
  played) and switches to the new address when NASA restarts it.
- Hover (or tap) the ISS on the map: altitude, position, next pass over your QTH and the ARISS
  amateur radio frequencies — voice downlink 145.800, voice uplink 145.200 (Region 1) /
  144.490 (Regions 2-3, your region highlighted), FM repeater 145.990 (67 Hz) / 437.800, APRS
  437.825 — with the ARISS status date.

# 0.9.2 (desktop) — reliable online data

- DX cluster: if the node does not answer or stops sending spots, DX Zaza moves to the next public
  node by itself (dxc.hamserve.uk, VE7CC, W3LPL). "Live" only once spots really arrive; a
  session with no new spots for 10 minutes is reconnected. While reconnecting the last spots stay
  on screen, clearly marked, with the node in use shown.
- DX cluster: fixed a long-standing drop every 4 minutes. The empty "keep-alive" line made
  dxc.hamserve.uk close the session; nothing is sent any more (the OS TCP keep-alive and the
  spot-silence check find a dead link instead). A dropped session is back within 2 seconds.
- Weather: a slow answer from MET Norway is retried at once and then after 30 s, 1, 2, 4 min
  (previously 10 min with the box hidden). The last forecast is kept (also after a restart) and
  shown dimmed while updating.
- Space weather (NOAA): the demo numbers shown when NOAA could not be read are gone. Last real
  values are kept (marked with their age) or "—" is shown, retried every minute; NOAA feeds are
  read in parallel. Same for the N0NBH band table and the aurora layer.
- The fixed demo satellite-pass list is removed (real passes come from CelesTrak + SGP4).
- Map, satellites and voice settings no longer break when a server answer is incomplete.
- "Controlla app Mac" also tests every DX cluster node, MET Norway and NOAA.

# 0.9.1 (desktop)

- Bluetooth headphones connected after DX Zaza started are now used for Digital Voice (macOS:
  the audio device list is re-read when the system output changes).

# 0.9.0 (desktop) — start-up screen

- New start-up screen: the DX Zaza logo inside a radar scope, version, "DX" in Morse code lighting
  up with a start-up sound (synthesised by DX Zaza: Morse "DX" and a soft chord), progress while
  the app gets ready. Tap to skip; the speaker button switches the sound off (remembered).
- Audio: more margin for the sound card, PTT can no longer freeze the app, faster GSM encoder.

# 0.8.2 (desktop) — EchoLink without router setup

- EchoLink connects by itself: straight when the router lets the station answer, otherwise through a
  public EchoLink proxy (one outgoing connection, nothing to open on the router). DX Zaza remembers
  which way works. The directory list is read after logging in.

# 0.8.0 (desktop) — C4FM and EchoLink

- Digital Voice now has all four modes: D-STAR, DMR, C4FM and EchoLink.
- C4FM (Yaesu System Fusion) rooms: the public YSF room list (Pi-Star host file, data from DVRef),
  search by number / name / country, parrot rooms for testing, favourites, manual address. DN voice
  goes through the DVstick (AMBE+2) and is converted to and from the C4FM layout; wide (VW) voice
  shows who is talking but is not played. Frames checked bit for bit against the MMDVM reference.
- EchoLink: log in with your own validated EchoLink callsign and password (kept on this computer
  only), directory of stations, links, repeaters and conferences, Echo test, favourites, text
  messages. Audio uses DX Zaza's own GSM 06.10 codec (bit exact with the libgsm reference), so
  EchoLink works even without the DVstick. Router: UDP 5198-5199 must reach this computer.
- Transmit on C4FM and EchoLink uses the same licence lock as D-STAR and DMR.
- After a restart DX Zaza goes back to the last C4FM room / EchoLink station too (Raspberry Pi).

# 0.7.0 (desktop) — DMR

- Digital Voice has mode tabs: D-STAR, DMR (new), C4FM and EchoLink (coming next).
- DMR through the DVstick (AMBE+2): BrandMeister, TGIF, FreeDMR and other masters (Pi-Star host
  list, built-in fallback), talkgroups with names, quick picks, favourites, "Listen" key-up to
  subscribe a talkgroup, caller callsign from the DMR ID (RadioID.net, cached 30 days), QRZ card.
- DMR settings: DMR ID (with "Find my DMR ID" on RadioID.net), hotspot suffix (ESSID),
  BrandMeister hotspot password (kept only on this computer, file readable by the owner only).
- Transmit on DMR (voice LC header, superframes with embedded LC, terminator) behind the same
  licence lock as D-STAR. Received bursts are checked with DX Zaza's own decoders (diagnostics).
- After a restart DX Zaza goes back to the last DMR talkgroup too.

# 0.6.6

- Raspberry Pi: the HDMI screen audio setting is checked and restored every time the speaker opens (the desktop audio tools can delete ~/.asoundrc after a reboot: no more silent voice).

# 0.6.5

- Weather: day or night icon from the real sun at the QTH (no sun icon after sunset); the current forecast hour is chosen at display time.

# 0.6.4

- Voice: on restart / stop DX Zaza unlinks the reflector first, so the reflector does not answer "BUSY" to the next link.

# 0.6.3 (review fixes, desktop + Raspberry Pi)

- Spots fetched at start-up (sh/dx history) are dated by their own UTC time: old spots no longer
  look "just now" and no longer appear fresh on the map.
- When the live cluster session is reconnecting, no second connection is opened every 15 s.
- QRZ.com: retry over IPv4 when a network announces IPv6 but does not route it (connection
  timeouts); a wrong password is not sent again for 10 minutes (QRZ locks out repeated failures);
  network errors are shown instead of "Not on QRZ.com"; the map card asks QRZ only when a
  station is tapped, not on mouse hover.
- Raspberry Pi: changes (transmit, settings, Wi-Fi, reboot, QRZ login) are accepted only from the
  DX Zaza screen itself; other devices on the Wi-Fi can still view the dashboard.
- Raspberry Pi quick update keeps only the last 5 backups of each kind (SD card space).
- Helper scripts (Mac and Raspberry) are now kept in tools/helpers.

# 0.6.2

- Tap a callsign on the Global Map card or in Live Radio Spots (station or spotter): spot details plus the QRZ.com card (photo when available, name, city, country, grid, distance).

# 0.6.1

- QRZ photos: loaded straight from QRZ like a browser, with DX Zaza as fallback; clear message when the QRZ account has no XML subscription (no photos).

# 0.6.0 (desktop + Raspberry Pi)

- QRZ.com: log in with your own QRZ.com account (Settings). In Digital Voice the station on the
  air gets a card with photo, name, city, country, grid, distance and heading; tap a callsign in
  "Last heard" for the big card. Street address and e-mail are never shown on screen. Full data
  needs the operator's QRZ XML Logbook Data subscription. Each callsign is looked up once a day.

# 0.5.9 (desktop + Raspberry Pi)

- Map legend moved under the map: it no longer hides the ISS or stations in the south.

# 0.5.8 (desktop + Raspberry Pi)

- Live Radio Spots in real time: one permanent, read-only DX cluster session; every new spot
  appears within seconds, newest on top, one line per station and frequency.
- Map: stations stay 15 minutes in full colour, faded until 30 minutes, then leave the map
  (they remain in the Live Radio Spots list).
- Clearer day / night: deep blue night, amber grey line (sunrise/sunset), lighter day; legend.
- Local weather next to the clocks (MET Norway, CC BY 4.0): sky, temperature, wind, humidity.
- Digital Voice: live volume control (- / + and slider, up to 300%) applied without restarting audio.
- Raspberry Pi: compact layout for the 10.1" 1024x600 screen, lighter graphics, new on-screen
  keyboard with preview, Restart button (screen / DX Zaza / Raspberry Pi), HDMI screen audio,
  reconnects the last reflector after a restart, BlueDV menu only when BlueDV is installed.

# DX Zaza 0.5.0 Desktop

## Map, filters, position and look (20/10/2026 afternoon)
- Band and Mode filters: choose several bands and several modes at once (map and spot list, remembered).
- Map zoom: mouse wheel / trackpad pinch / two fingers, drag to move, double click, + / − buttons and
  regions (World, Europe, N./S. America, Africa, Asia, Oceania, My QTH). Labels and dots keep their size.
- Sharper base map (14 px per degree) for zooming.
- Automatic position from the Internet connection (town -> QTH locator), refreshed every 6 hours;
  a typed locator switches to manual, one click goes back to automatic.
- New "Mission Control" theme: glass panels with HUD corners, icons in the menu, Chakra Petch /
  Space Grotesk / JetBrains Mono fonts (bundled), same colours.
- The map shows the transmitting DX station (not the spotter), see docs/map_v2_spots.md.

## New: DX Zaza for macOS (desktop app)
- `DX Zaza.app` with its own window and icon, installed in Applications; customer `.dmg`.
- Same code as the Raspberry Pi: map, spots, propagation, satellites work the same.
- Settings page on the desktop: callsign, QTH locator, language (Wi-Fi setup and BlueDV are Pi-only
  and hidden; the on-screen keyboard is Pi-only).
- User files in `~/Library/Application Support/DX Zaza`, log in `~/Library/Logs/DX Zaza`.

## New: built-in digital voice with the DVstick (no BlueDV needed)
- DVMEGA DVstick 30 (AMBE-3000) driven directly, no driver needed on macOS.
- D-STAR on REF (DPlus, registered callsigns), XLX / XRF (DExtra) and DCS reflectors: listen, talk with PTT (button or space bar),
  callsign + suffix + 20-character message, last heard with country, favourites.
- Vocoder test and microphone test (hear yourself through the DVstick).
- Transmit locked until the operator confirms an amateur radio licence.
- See docs/desktop_app_macos.md.

# DX Zaza 0.4.0 Live Map + BlueDV

## Global Map
- New geographic map (equirectangular, 82N to 58S) generated from public land data in the
  original DX Zaza style: every position on the map is now a real latitude/longitude.
- Day/night shading with twilight and the grey line (terminator), computed in real time.
- Sun position, aurora oval (NOAA SWPC OVATION), ISS with ground track, popular amateur
  satellites (SGP4 from CelesTrak TLEs).
- Spotter positions from the AD1C country database (cty.dat, ~340 DXCC entities) or from the
  Maidenhead locator in the spot comment when present; built-in table only as fallback.
  (Fixes e.g. Taiwan shown as China, Canary Islands shown as Spain.)
- Great-circle paths from the operator QTH to the latest spots.
- Layer buttons: Day/Night, Aurora, Satellites, Paths (remembered on the device).

## Live Radio Spots
- Distance (km) and beam heading from the operator QTH for every spot.

## HF Propagation
- Solar wind and Bz now from DSCOVR real-time products (ACE only as fallback).
- X-ray shown as flare class (e.g. C1.2) from the correct GOES 0.1-0.8 nm channel.
- A-index now read (was always N/A); Kp history of the last 24 hours.
- Storm text follows the real geomagnetic state (was always "low").
- Real HF band conditions day/night + VHF (N0NBH) - OFF by default, see commercial notes.
- Real sunrise, sunset and grey-line windows at the operator QTH.
- Next satellite passes over the operator QTH.

## Operator Setup
- New QTH Maidenhead locator setting (only the 4-character square is shown in the UI).

## BlueDV (new page)
- Integration of BlueDV Radio by PA7LIM with the DVMEGA DVstick 30.
- Install/uninstall scripts download BlueDV Radio from the official site (not bundled).
- Start/Stop from DX Zaza through a sudoers-limited helper; one DVstick owner at a time
  (direct mode stops the DX Zaza AMBE Server; optional mode through the AMBE Server UDP 2460).
- BlueDV web interface shown inside DX Zaza, with full-screen button.

## Technical
- New services: geo_service, space_service, bluedv_service. New dependency: sgp4.
- New API: /api/map/context, /api/aurora, /api/satellites, /api/bands, /api/bluedv/status,
  /api/bluedv/start, /api/bluedv/stop, /api/settings/locator.
- New tests: tests/test_phase16_geo_space.py (locator, great circle, cty.dat parsing,
  X-ray class, SGP4 orbit and passes).

# DX Zaza 0.3.0 Product Readiness

- Live radio spots.
- Live propagation data.
- Customer-facing source names hidden.
- Clear online/offline/fallback states.
- Raspberry Pi kiosk improvements.
- Touchscreen natural scroll improvements.
- Remote update base added.
