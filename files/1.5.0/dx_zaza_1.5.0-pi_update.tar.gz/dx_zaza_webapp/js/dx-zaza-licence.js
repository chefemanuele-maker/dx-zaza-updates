/* DX Zaza — licence: trial chip, activation window, Settings card.
   Trial: a small chip next to the clocks ("Trial · 9 days"). After the trial, a full-screen
   window asks for the licence key printed on the card in the box (the network and settings
   pages stay reachable, so a Raspberry Pi can get online to activate). */
(function () {
  "use strict";
  const it = () => (document.documentElement.lang || "").startsWith("it") || (window.dxZazaState && window.dxZazaState.language === "it");
  const T = {
    trial: (n) => it() ? "Prova · " + n + (n === 1 ? " giorno" : " giorni") : "Trial · " + n + (n === 1 ? " day" : " days"),
    activate: () => it() ? "Attiva" : "Activate",
    title: () => it() ? "Attiva DX Zaza" : "Activate DX Zaza",
    titleTrial: () => it() ? "Licenza DX Zaza" : "DX Zaza licence",
    ended: () => it() ? "Il periodo di prova è finito. Inserisci la chiave di licenza che trovi sul cartoncino nella confezione."
      : "The trial has ended. Enter the licence key printed on the card in the box.",
    during: (n) => it() ? "Stai usando DX Zaza in prova: restano " + n + " giorni. Inserisci la chiave di licenza del cartoncino nella confezione per attivarlo per sempre."
      : "You are using DX Zaza as a trial: " + n + " days left. Enter the licence key from the card in the box to activate it for good.",
    placeholder: () => "DXZ-XXXX-XXXX-XXXX-XXXX-XXXX",
    working: () => it() ? "Attivo…" : "Activating…",
    done: () => it() ? "Licenza attivata. Grazie!" : "Licence activated. Thank you!",
    needNet: () => it() ? "Serve internet solo per l'attivazione (una volta)." : "Internet is needed only to activate (once).",
    network: () => it() ? "Impostazioni rete" : "Network settings",
    later: () => it() ? "Più tardi" : "Later",
    cardTitle: () => it() ? "LICENZA" : "LICENCE",
    licensed: (h) => (it() ? "Attivata · chiave " : "Activated · key ") + h,
    master: () => it() ? " (master)" : " (master)",
    device: (d) => (it() ? "Codice apparecchio: " : "Device code: ") + d,
    errors: {
      bad_key: () => it() ? "Chiave non valida: controlla di averla scritta bene (20 lettere e numeri dopo DXZ)." : "Not a valid key: check you typed it correctly.",
      unknown_key: () => it() ? "Questa chiave non esiste." : "This key does not exist.",
      in_use: (d) => it() ? "Questa chiave è già attiva su un altro apparecchio. Potrà essere spostata qui tra " + d + " giorni."
        : "This key is already active on another device. It can be moved here in " + d + " days.",
      revoked: () => it() ? "Questa chiave è stata disattivata. Contatta il venditore." : "This key has been disabled. Please contact the seller.",
      offline: () => it() ? "Nessuna connessione con il server licenze. Controlla internet e riprova." : "No connection to the licence server. Check the internet and try again.",
      moved: () => it() ? "La licenza è stata spostata su un altro apparecchio." : "The licence was moved to another device.",
      other: () => it() ? "Attivazione non riuscita. Riprova tra poco." : "Activation failed. Please try again shortly.",
    },
  };
  let last = null;
  let dismissed = false;

  function errorText(d) {
    const e = d && d.error;
    if (!e) return "";
    const f = T.errors[e] || T.errors.other;
    return f(d.retryAfterDays || 30);
  }

  function form(prefix) {
    return '<div class="lic-form"><input id="' + prefix + 'Key" class="lic-key" type="text" autocomplete="off" spellcheck="false" ' +
      'autocapitalize="characters" maxlength="40" placeholder="' + T.placeholder() + '">' +
      '<button type="button" class="primary-action lic-go">' + T.activate() + "</button></div>" +
      '<p class="lic-msg" role="status"></p>';
  }

  function wire(root, prefix) {
    const input = root.querySelector(".lic-key");
    const go = root.querySelector(".lic-go");
    const pi = () => document.body.classList.contains("dxz-lite");      // Raspberry Pi: on-screen keyboard
    const touch = () => { if (pi() && typeof window.openTouchKeyboard === "function") { input.setAttribute("inputmode", "none"); window.openTouchKeyboard(input); } };
    input.addEventListener("focus", touch);
    input.addEventListener("click", touch);
    input.addEventListener("input", () => {
      // DXZ-XXXX-… as you type
      const raw = input.value.toUpperCase().replace(/[^0-9A-Z]/g, "").replace(/^DXZ/, "").slice(0, 20);
      const groups = raw.match(/.{1,4}/g) || [];
      const v = raw ? "DXZ-" + groups.join("-") : "";
      if (v !== input.value && input.value.length >= 3) input.value = v;
    });
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") activate(root); });
    go.addEventListener("click", () => activate(root));
  }

  async function activate(root) {
    const input = root.querySelector(".lic-key"), msg = root.querySelector(".lic-msg"), go = root.querySelector(".lic-go");
    if (typeof window.closeTouchKeyboard === "function") window.closeTouchKeyboard();
    msg.className = "lic-msg";
    msg.textContent = T.working();
    go.disabled = true;
    let d = null;
    try {
      d = await (await fetch("/api/licence/activate", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: input.value }) })).json();
    } catch (_) { d = { error: "offline" }; }
    go.disabled = false;
    if (d && d.status === "licensed") {
      msg.className = "lic-msg ok";
      msg.textContent = T.done();
      setTimeout(() => location.reload(), 1200);     // the whole dashboard comes back
      return;
    }
    msg.className = "lic-msg bad";
    msg.textContent = errorText(d) || T.errors.other();
  }

  // ------------------------------------------------------------------ trial chip (next to the clocks)
  function chip(d) {
    let node = document.getElementById("dxzLicChip");
    const bar = document.querySelector(".global-clock-bar");
    if (!node && bar) {
      node = document.createElement("button");
      node.type = "button";
      node.id = "dxzLicChip";
      node.className = "time-chip lic-chip";
      node.addEventListener("click", () => { dismissed = false; overlay(last, true); });
      bar.insertBefore(node, bar.firstChild);
    }
    if (!node) return;
    node.hidden = d.status !== "trial";
    node.innerHTML = "<span>DX Zaza</span><strong></strong>";
    node.querySelector("strong").textContent = T.trial(d.daysLeft);
  }

  // ------------------------------------------------------------------ activation window
  function overlay(d, open) {
    let ov = document.getElementById("dxzLicence");
    const must = d.status === "expired";
    if (!must && !open) { if (ov) ov.hidden = true; return; }
    if (!ov) {
      ov = document.createElement("div");
      ov.id = "dxzLicence";
      ov.className = "lic-overlay";
      document.body.appendChild(ov);
    }
    ov.innerHTML = '<div class="lic-box" role="dialog" aria-modal="true"><img src="assets/dx_zaza_logo.png" alt="" class="lic-logo">' +
      "<h2></h2><p class=\"lic-text\"></p>" + form("lic") + '<p class="lic-note"></p><div class="lic-foot">' +
      (document.body.classList.contains("dxz-lite") ? '<button type="button" class="secondary-action lic-net"></button>' : "") +
      (!must ? '<button type="button" class="secondary-action lic-later"></button>' : "") + '<small class="lic-device"></small></div></div>';
    ov.querySelector("h2").textContent = must ? T.title() : T.titleTrial();
    ov.querySelector(".lic-text").textContent = must ? T.ended() : T.during(d.daysLeft);
    ov.querySelector(".lic-note").textContent = T.needNet();
    ov.querySelector(".lic-device").textContent = T.device(d.device || "");
    const net = ov.querySelector(".lic-net");
    if (net) { net.textContent = T.network(); net.addEventListener("click", () => { ov.hidden = true; dismissed = true; goNetwork(); }); }
    const later = ov.querySelector(".lic-later");
    if (later) { later.textContent = T.later(); later.addEventListener("click", () => { ov.hidden = true; dismissed = true; }); }
    if (d.error === "moved") { const m = ov.querySelector(".lic-msg"); m.className = "lic-msg bad"; m.textContent = T.errors.moved(); }
    wire(ov, "lic");
    ov.hidden = false;
  }

  function goNetwork() {
    const b = document.querySelector('.nav-button[data-page="wifi"]');
    if (b) b.click();
  }

  // ------------------------------------------------------------------ Settings card
  function card(d) {
    let node = document.getElementById("dxzLicCard");
    if (!node) {
      const anchor = document.getElementById("dxzUpdateCard") || document.querySelector(".system-settings-card");
      if (!anchor) return;
      node = document.createElement("section");
      node.id = "dxzLicCard";
      node.className = "wifi-card update-card lic-card";
      anchor.after(node);
    }
    const sig = JSON.stringify([d.status, d.keyHint, d.plan, d.daysLeft, it()]);
    if (node.dataset.sig === sig) return;
    node.dataset.sig = sig;
    if (d.status === "licensed") {
      node.innerHTML = '<p class="eyebrow"></p><p class="update-version lic-ok"></p><p class="wifi-demo-note lic-device"></p>';
      node.querySelector(".lic-ok").textContent = "✓ " + T.licensed(d.keyHint || "") + (d.plan === "master" ? T.master() : "");
    } else {
      node.innerHTML = '<p class="eyebrow"></p><p class="update-state"></p>' + form("licCard") + '<p class="wifi-demo-note lic-device"></p>';
      node.querySelector(".update-state").textContent = d.status === "trial" ? T.during(d.daysLeft) : T.ended();
      wire(node, "licCard");
    }
    node.querySelector(".eyebrow").textContent = T.cardTitle();
    node.querySelector(".lic-device").textContent = T.device(d.device || "");
  }

  async function refresh() {
    try {
      const d = await (await fetch("/api/licence/status", { cache: "no-store" })).json();
      last = d;
      chip(d);
      card(d);
      if (d.status === "expired" && !dismissed) overlay(d, true);
      else if (d.status === "licensed") { const ov = document.getElementById("dxzLicence"); if (ov) ov.hidden = true; }
    } catch (_) { /* app restarting */ }
  }

  // after the trial, the window comes back a moment after the user leaves the network page
  document.addEventListener("click", (e) => {
    const b = e.target.closest && e.target.closest(".nav-button");
    if (b && b.dataset.page !== "wifi" && last && last.status === "expired") { dismissed = false; setTimeout(refresh, 300); }
  });

  window.dxzLicence = { refresh, open: () => last && overlay(last, true) };
  setTimeout(refresh, 1500);
  setInterval(refresh, 10 * 60 * 1000);
})();
