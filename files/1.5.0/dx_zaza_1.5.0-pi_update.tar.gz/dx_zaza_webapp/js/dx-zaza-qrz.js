/* DX Zaza — QRZ.com: the operator logs in with their own account (Settings); in Digital Voice
   the station on the air gets a card with photo, name, city, country, grid and distance.
   Tap a callsign in "Last heard" to see its card again. Street address and e-mail are never shown. */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const TEXT = {
    en: {
      "qrz.username": "QRZ.com username", "qrz.password": "QRZ.com password", "qrz.login": "Log in", "qrz.logout": "Log out",
      "qrz.note": "Shows photo, name, city and country of the station on the air. Full data needs your QRZ XML Logbook Data subscription. The password stays on this device only.",
      "qrz.logged": "Logged in as {u}", "qrz.sub": "subscription until {d}", "qrz.limited": "QRZ says: no XML Logbook Data subscription on this account, so no photos (only basic data)",
      "qrz.not_logged": "Not logged in: QRZ cards are off.", "qrz.checking": "Checking with QRZ.com...",
      "qrz.not_found": "Not on QRZ.com", "qrz.close": "Close", "qrz.login_hint": "Log in to QRZ.com in Settings to see photo and name.", "qrz.heard_by": "heard by", "qrz.more": "Tap for details", "qrz.details": "Full details: qrz.com/db/{c}", "qrz.km": "km"
    },
    it: {
      "qrz.username": "Nome utente QRZ.com", "qrz.password": "Password QRZ.com", "qrz.login": "Accedi", "qrz.logout": "Esci",
      "qrz.note": "Mostra foto, nome, città e paese della stazione in aria. I dati completi richiedono l'abbonamento QRZ XML Logbook Data. La password resta solo su questo dispositivo.",
      "qrz.logged": "Collegato come {u}", "qrz.sub": "abbonamento fino al {d}", "qrz.limited": "QRZ risponde: questo account non ha l'abbonamento XML Logbook Data, quindi niente foto (solo dati base)",
      "qrz.not_logged": "Non collegato: schede QRZ spente.", "qrz.checking": "Controllo con QRZ.com...",
      "qrz.not_found": "Non presente su QRZ.com", "qrz.close": "Chiudi", "qrz.login_hint": "Accedi a QRZ.com in Settings per vedere foto e nome.", "qrz.heard_by": "ascoltata da", "qrz.more": "Tocca per i dettagli", "qrz.details": "Dettagli completi: qrz.com/db/{c}", "qrz.km": "km"
    }
  };
  if (typeof translations === "object") {
    Object.keys(TEXT).forEach((l) => { if (translations[l]) Object.assign(translations[l], TEXT[l]); });
  }
  const tr = (k) => (typeof t === "function" ? t(k) : null) || TEXT.en[k] || k;

  const state = { status: null, current: "", shownAt: 0, records: {} };

  // ------------------------------------------------------------ settings
  function renderStatus() {
    const s = state.status || {};
    const msg = $("qrzMessage");
    if (!msg) return;
    $("qrzLogout").hidden = !s.configured;
    if (s.configured && s.username) $("qrzUsername").value = s.username;
    if (!s.configured) { msg.textContent = tr("qrz.not_logged"); return; }
    const parts = [tr("qrz.logged").replace("{u}", s.username)];
    if (s.subscription && !s.fullData) parts.push(tr("qrz.limited"));
    else if (s.subscription) parts.push(tr("qrz.sub").replace("{d}", s.subscription));
    if (s.error) parts.push(s.error);
    msg.textContent = parts.join(" · ");
  }
  async function loadStatus() {
    try { state.status = await (await fetch("/api/qrz/status", { cache: "no-store" })).json(); } catch (_) { return; }
    renderStatus();
  }
  async function post(path, body) {
    const res = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) throw new Error(data.error || "HTTP " + res.status);
    return data;
  }
  function setupForm() {
    const form = $("qrzForm");
    if (!form) return;
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (typeof closeTouchKeyboard === "function") closeTouchKeyboard();
      $("qrzMessage").textContent = tr("qrz.checking");
      try {
        state.status = await post("/api/qrz/login", { username: $("qrzUsername").value.trim(), password: $("qrzPassword").value });
        $("qrzPassword").value = "";
        state.records = {};
        renderStatus();
      } catch (err) { $("qrzMessage").textContent = err.message; }
    });
    $("qrzLogout").addEventListener("click", async () => {
      try { state.status = await post("/api/qrz/logout"); } catch (_) { /* */ }
      state.records = {};
      $("qrzPassword").value = "";
      renderStatus();
      hideCard();
    });
  }

  // ------------------------------------------------------------ lookups
  const inflight = {};
  async function lookup(call) {
    const key = String(call || "").trim().toUpperCase();
    if (!key) return null;
    if (state.records[key]) return state.records[key];
    if (inflight[key]) return inflight[key];          // the same call asked twice at once: one request
    inflight[key] = (async () => {
      try {
        const d = await (await fetch("/api/qrz/lookup?call=" + encodeURIComponent(key), { cache: "no-store" })).json();
        if (d.ok) state.records[key] = d;
        else if (d.notFound) state.records[key] = { notFound: true, call: key };
        else if (d.error) { delete inflight[key]; return { error: d.error, call: key }; }   // not kept: retry next time
      } catch (_) { /* try again next time */ }
      delete inflight[key];
      return state.records[key] || null;
    })();
    return inflight[key];
  }

  function cardHtml(r, big) {
    if (!r) return "";
    if (r.error) return '<div class="qrz-row"><div class="qrz-text"><b>' + esc(r.call) + "</b><small>QRZ.com: " + esc(r.error) + "</small></div></div>";
    if (r.notFound) return '<div class="qrz-row"><div class="qrz-text"><b>' + esc(r.call) + "</b><small>" + esc(tr("qrz.not_found")) + "</small></div></div>";
    // the picture comes straight from QRZ (like on qrz.com); if that is refused, through DX Zaza
    const initial = esc(String(r.displayName || r.call || "?").slice(0, 1));
    const direct = r.image ? String(r.image).replace(/^http:/, "https:") : "";
    const proxy = "/api/qrz/photo?call=" + encodeURIComponent(r.call);
    const photo = r.hasPhoto ?
      '<img class="qrz-photo" alt="" referrerpolicy="no-referrer" src="' + esc(direct || proxy) + '" data-proxy="' + esc(proxy) +
        '" data-initial="' + initial + '" onerror="dxzQrzPhotoError(this)">' :
      '<span class="qrz-photo qrz-nophoto">' + initial + "</span>";
    const place = [r.city, r.state, r.country].filter(Boolean).join(", ");
    const where = [r.grid ? r.grid.slice(0, 6).toUpperCase() : "",
      typeof r.distanceKm === "number" ? r.distanceKm.toLocaleString() + " " + tr("qrz.km") + (typeof r.bearing === "number" ? " · " + r.bearing + "°" : "") : ""].filter(Boolean).join(" · ");
    return '<div class="qrz-row' + (big ? " big" : "") + '">' + photo +
      '<div class="qrz-text"><b>' + esc(r.displayName || r.call) + (r.nickname && big ? ' <i>"' + esc(r.nickname) + '"</i>' : "") + "</b>" +
      "<small>" + esc(place) + "</small>" + (where ? "<small class=\"qrz-where\">" + esc(where) + "</small>" : "") +
      (big ? "<small class=\"qrz-link\">" + esc(tr("qrz.details").replace("{c}", r.call)) + "</small>" : "") +
      (r.qslmgr && big ? "<small>QSL: " + esc(r.qslmgr) + "</small>" : "") + "</div></div>";
  }

  window.dxzQrzPhotoError = function (img) {
    if (img.dataset.proxy && img.getAttribute("src") !== img.dataset.proxy) {
      img.src = img.dataset.proxy;                 // second try: through DX Zaza
      return;
    }
    const span = document.createElement("span");
    span.className = "qrz-photo qrz-nophoto";
    span.textContent = img.dataset.initial || "?";
    img.replaceWith(span);
  };

  // ------------------------------------------------------------ on air card
  function hideCard() { const box = $("voiceQrz"); if (box) { box.hidden = true; box.innerHTML = ""; } state.current = ""; }
  function currentCaller() {
    const big = document.querySelector("#voiceOnAir .voice-big:not(.tx)");
    if (!big) return "";
    return (big.firstChild && big.firstChild.nodeType === 3 ? big.firstChild.nodeValue : big.textContent).trim().split(/\s+/)[0].toUpperCase();
  }
  async function onAirChanged() {
    if (!state.status || !state.status.configured) return;
    const call = currentCaller();
    const box = $("voiceQrz");
    if (!box) return;
    if (!call) {
      // keep the last card for a minute after the station stops
      if (state.current && Date.now() - state.shownAt > 60000) hideCard();
      else if (state.current) box.classList.add("after");
      return;
    }
    box.classList.remove("after");
    state.shownAt = Date.now();
    if (call === state.current) return;
    state.current = call;
    box.hidden = false;
    box.innerHTML = '<div class="qrz-row"><span class="qrz-photo qrz-nophoto">…</span><div class="qrz-text"><b>' + esc(call) + "</b><small>" + esc(tr("qrz.checking")) + "</small></div></div>";
    const r = await lookup(call);
    if (state.current !== call) return;
    if (!r || r.notFound) { hideCard(); state.current = call; return; }
    box.innerHTML = cardHtml(r, false);
  }

  // ------------------------------------------------------------ tap a callsign in Last heard
  function openPanel(html) { $("dxzQrzPanelBody").innerHTML = html; $("dxzQrzPanel").hidden = false; }
  function setupHeard() {
    const tbody = $("voiceHeardBody");
    if (tbody) {
      tbody.addEventListener("click", async (e) => {
        const cell = e.target.closest("td strong");
        if (!cell || !state.status || !state.status.configured) return;
        const call = cell.textContent.trim().split(/\s+/)[0];
        openPanel('<p class="qrz-wait">' + esc(tr("qrz.checking")) + "</p>");
        const r = await lookup(call);
        openPanel(r ? cardHtml(r, true) : '<p class="qrz-wait">' + esc(tr("qrz.not_found")) + "</p>");
      });
    }
    $("dxzQrzClose").addEventListener("click", () => { $("dxzQrzPanel").hidden = true; });
    $("dxzQrzPanel").addEventListener("click", (e) => { if (e.target.id === "dxzQrzPanel") $("dxzQrzPanel").hidden = true; });
  }

  // ------------------------------------------------------------ spots: map card + Live Radio Spots table
  function spotHtml(s) {
    if (!s) return "";
    const color = (window.dxzBandColor && window.dxzBandColor(s.band)) || "var(--cyan)";
    return '<div class="qrz-spot" style="--c:' + color + '"><h3>' + esc(s.dx || s.de) + "</h3>" +
      "<p><strong>" + esc(s.frequency) + "</strong> · " + esc(s.band || "") + " · " + esc(s.mode || "") + (s.time ? " · " + esc(s.time) : "") + "</p>" +
      "<p>" + esc(s.dxCountry || s.country || "") + (typeof s.distanceKm === "number" ? " · " + esc(s.distanceKm.toLocaleString()) + " km " + esc(Math.round(s.bearing)) + "°" : "") + "</p>" +
      (s.de ? "<p>" + esc(tr("qrz.heard_by")) + " <strong>" + esc(s.de) + "</strong>" + (s.country ? " · " + esc(s.country) : "") + "</p>" : "") +
      (s.comment ? '<p class="qrz-comment">' + esc(s.comment) + "</p>" : "") + "</div>";
  }
  async function openCall(call, spot) {
    const head = spot ? spotHtml(spot) : "";
    if (!state.status || !state.status.configured) {
      openPanel(head + '<p class="qrz-wait">' + esc(tr("qrz.login_hint")) + "</p>");
      return;
    }
    openPanel(head + '<p class="qrz-wait">' + esc(tr("qrz.checking")) + "</p>");
    const r = await lookup(call);
    openPanel(head + (r ? cardHtml(r, true) : '<p class="qrz-wait">' + esc(tr("qrz.not_found")) + "</p>"));
  }
  async function fillCard(el, call, card) {
    if (!el || !call || !state.status || !state.status.configured) return;
    el.innerHTML = '<p class="qrz-wait">' + esc(tr("qrz.checking")) + "</p>";
    const r = await lookup(call);
    if (!el.isConnected) return;
    if (!r || r.notFound || r.error) { el.innerHTML = ""; return; }
    el.innerHTML = cardHtml(r, false) + '<small class="qrz-more">' + esc(tr("qrz.more")) + "</small>";
    el.onclick = (e) => { e.stopPropagation(); openCall(call, card && card._spot); };
    if (card && card.parentElement) {     // keep the grown card inside the map
      const H = card.parentElement.clientHeight, top = parseFloat(card.style.top) || 0;
      if (top + card.offsetHeight > H - 6) card.style.top = Math.max(6, H - card.offsetHeight - 6) + "px";
    }
  }
  function setupSpots() {
    const tbody = $("dxTableBody");
    if (!tbody) return;
    const handler = (e) => {
      const hit = e.target.closest(".dxz-call, .dxz-de-call");
      if (!hit) return;
      const tr = hit.closest("tr[data-i]");
      const spot = tr && tbody._spots ? tbody._spots[Number(tr.dataset.i)] : null;
      const call = hit.textContent.trim();
      if (!call || call === "?") return;
      openCall(call, hit.classList.contains("dxz-call") ? spot : null);
    };
    tbody.addEventListener("click", handler);
    tbody.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); handler(e); } });
  }
  window.dxzQrz = { lookup, openCall, fillCard };

  function init() {
    setupSpots();
    setupForm();
    setupHeard();
    loadStatus();
    const onair = $("voiceOnAir");
    if (onair) new MutationObserver(onAirChanged).observe(onair, { childList: true, subtree: true, characterData: true });
    setInterval(onAirChanged, 5000);
    setInterval(loadStatus, 5 * 60 * 1000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
