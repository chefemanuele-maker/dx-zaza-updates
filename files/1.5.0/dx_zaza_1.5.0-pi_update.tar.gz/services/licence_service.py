"""DX Zaza licence: one key per device, activated online once, then checked offline.

How it works
- Every box contains a licence key like DXZ-7KQ2-M9XA-4TRC-H3PW-5N8E (20 symbols, the last one
  is a check symbol that catches typing mistakes). Only the DX Zaza licence server can tell a
  real key from an invented one (it holds the secret the keys are made with).
- At activation the app sends the key and this device's id (a hash of the Raspberry Pi serial
  number / the Windows or Mac machine id, never the raw value) to the server. The server binds
  the key to the device and answers with a licence signed with the DX Zaza licence key
  (Ed25519). The app keeps that signed licence and checks it at every start without internet:
  a licence copied to another device does not match that device's id, and an edited licence
  fails the signature.
- The same key on a second device is refused. Moving a licence to a new device is allowed once
  every 30 days (the old device stops at its next check).
- Without a licence the app runs as a 14-day trial. The trial start is also kept by the server
  for this device, so reinstalling does not start a new trial.
- Once a week (when online) the app asks the server whether the licence is still on this device.
  Being offline never stops a licensed device.
- The signed licence is also the ticket for downloading updates.
"""
import base64
import hashlib
import json
import logging
import os
import re
import subprocess
import threading
import time
from pathlib import Path

import requests

from services import ed25519
from services.platform_service import os_name

log = logging.getLogger("dx_zaza.licence")

# public half of the DX Zaza licence signing key (the private half lives only on the licence server)
LICENCE_PUBLIC_KEY_B64 = "c/TLPCyWVapvI6OWcxlYA5zSvbICsNHQigZzWcRmpuc="
DEFAULT_SERVER = "https://dx-zaza-licence.dxzaza.workers.dev"
TRIAL_DAYS = 14
RECHECK_EVERY = 7 * 24 * 3600
ALPHABET = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"          # no 0/O, 1/I: easy to read on a card
KEY_RE = re.compile(r"^[%s]{20}$" % ALPHABET)

# without a licence these keep working, so a device can always reach the activation screen
# (and get on the network, update, restart)
OPEN_API_PREFIXES = ("/api/licence", "/api/status", "/api/ui", "/api/settings", "/api/network",
                     "/api/system", "/api/update")


# ------------------------------------------------------------------ keys
def _check_symbol(body):
    total = 0
    for i, ch in enumerate(body):
        total += (i + 1) * (ALPHABET.index(ch) + 7)
    return ALPHABET[total % 32]


def normalize_key(text):
    """'dxz 7kq2-m9xa…' -> 'DXZ-7KQ2-M9XA-4TRC-H3PW-5N8E', or None if it cannot be a key."""
    raw = re.sub(r"[^0-9A-Za-z]", "", str(text or "")).upper()
    if raw.startswith("DXZ") and len(raw) == 23:
        raw = raw[3:]
    if not KEY_RE.match(raw) or _check_symbol(raw[:19]) != raw[19]:
        return None
    return "DXZ-" + "-".join(raw[i:i + 4] for i in range(0, 20, 4))


def key_hint(key):
    return ("…" + key[-4:]) if key else ""


# ------------------------------------------------------------------ device id
def _raw_device_id():
    system = os_name()
    try:
        if system == "linux":
            for path in ("/sys/firmware/devicetree/base/serial-number", "/proc/device-tree/serial-number"):
                if os.path.exists(path):
                    value = Path(path).read_text(errors="ignore").strip("\x00\n ")
                    if value:
                        return "pi:" + value
            for line in Path("/proc/cpuinfo").read_text(errors="ignore").splitlines():
                if line.lower().startswith("serial"):
                    return "pi:" + line.split(":", 1)[1].strip()
            for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
                if os.path.exists(path):
                    return "linux:" + Path(path).read_text().strip()
        elif system == "windows":
            import winreg  # noqa: PLC0415
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography",
                                0, winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0)) as k:
                return "win:" + str(winreg.QueryValueEx(k, "MachineGuid")[0])
        elif system == "macos":
            out = subprocess.run(["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"], capture_output=True,
                                 text=True, timeout=5).stdout
            m = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', out)
            if m:
                return "mac:" + m.group(1)
    except Exception as exc:   # pragma: no cover - depends on the machine
        log.warning("device id: %s", exc)
    return ""


def device_id(raw=None):
    """Stable id of this device: a hash, so the real serial number never leaves the device."""
    raw = _raw_device_id() if raw is None else raw
    if not raw:
        return ""
    return hashlib.sha256(("dx-zaza-device|" + raw).encode()).hexdigest()[:32]


# ------------------------------------------------------------------ signed tokens
def _b64d(text):
    text = str(text or "")
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def verify_token(token, public_key_b64=None):
    """'<payload>.<signature>' signed by the licence server -> payload dict, or None."""
    try:
        body, sig = str(token).split(".", 1)
        payload = _b64d(body)
        key = base64.b64decode(public_key_b64 or LICENCE_PUBLIC_KEY_B64)
        if not ed25519.verify(key, body.encode("ascii"), _b64d(sig)):
            return None
        data = json.loads(payload.decode("utf-8"))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


class LicenceService:
    def __init__(self, data_dir, version, platform, server=None, session=None, clock=time.time,
                 device=None, public_key=None):
        self.dir = Path(data_dir)
        self.version = version
        self.platform = platform
        self.server = (server or os.environ.get("DX_ZAZA_LICENCE_URL") or DEFAULT_SERVER).rstrip("/")
        self.session = session or requests.Session()
        self.clock = clock
        self.device = device if device is not None else device_id()
        self.public_key = public_key or LICENCE_PUBLIC_KEY_B64
        self.lock = threading.Lock()
        self.thread = None
        self._verified = {}
        self.last_error = ""

    # ------------------------------------------------------------ storage
    @property
    def path(self):
        return self.dir / "licence.json"

    def _load(self):
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def _save(self, data):
        self.dir.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=1), encoding="utf-8")
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        os.replace(tmp, self.path)

    def _verify(self, token):
        if not token:
            return None
        if token not in self._verified:
            self._verified[token] = verify_token(token, self.public_key)
        return self._verified[token]

    # ------------------------------------------------------------ state
    def licence(self):
        """The valid licence payload for this device, or None."""
        data = self._load()
        p = self._verify(data.get("licence"))
        if p and p.get("kind") == "licence" and p.get("device") == self.device:
            return p
        return None

    def licence_token(self):
        return self._load().get("licence") if self.licence() else ""

    def trial_start(self):
        data = self._load()
        p = self._verify(data.get("trial"))
        starts = []
        if p and p.get("kind") == "trial" and p.get("device") == self.device:
            starts.append(float(p.get("start", 0)))
        if data.get("firstSeen"):
            starts.append(float(data["firstSeen"]))
        return min(starts) if starts else None

    def status(self):
        lic = self.licence()
        if lic:
            return {"ok": True, "status": "licensed", "allowed": True, "plan": lic.get("planName", "standard"),
                    "keyHint": lic.get("hint", ""), "since": lic.get("issued"), "device": self.device[:8],
                    "error": self.last_error}
        start = self.trial_start()
        if start is None:
            with self.lock:
                data = self._load()
                if not data.get("firstSeen"):
                    data["firstSeen"] = self.clock()
                    self._save(data)
            start = self.trial_start() or self.clock()
        left = TRIAL_DAYS - (self.clock() - start) / 86400.0
        status = "trial" if left > 0 else "expired"
        return {"ok": True, "status": status, "allowed": left > 0, "daysLeft": max(0, int(left + 0.999)),
                "trialDays": TRIAL_DAYS, "device": self.device[:8], "error": self.last_error}

    def allowed(self):
        return self.status()["allowed"]

    # ------------------------------------------------------------ server
    def _post(self, path, body):
        body = dict(body, device=self.device, platform=self.platform, version=self.version)
        res = self.session.post(self.server + path, json=body, timeout=(6, 20),
                                headers={"User-Agent": "DXZaza/%s (+licence)" % self.version})
        try:
            data = res.json()
        except ValueError:
            data = {"ok": False, "error": "server_error"}
        if res.status_code >= 500:
            raise RuntimeError(data.get("error") or "server_error")
        return data

    def activate(self, key_text):
        key = normalize_key(key_text)
        if not key:
            return dict(self.status(), ok=False, error="bad_key")
        if not self.device:
            return dict(self.status(), ok=False, error="no_device_id")
        try:
            data = self._post("/v1/activate", {"key": key})
        except Exception as exc:
            log.warning("activation failed: %s", exc)
            return dict(self.status(), ok=False, error="offline")
        token = data.get("licence")
        p = self._verify(token) if token else None
        if not data.get("ok") or not p or p.get("device") != self.device or p.get("kind") != "licence":
            return dict(self.status(), ok=False, error=str(data.get("error") or "refused"),
                        retryAfterDays=data.get("retryAfterDays"))
        with self.lock:
            stored = self._load()
            stored["licence"] = token
            stored["checkedAt"] = self.clock()
            self._save(stored)
        self.last_error = ""
        log.info("licence activated (%s)", p.get("hint", ""))
        return self.status()

    def register_trial(self):
        """Ask the server when this device's trial started (first contact wins)."""
        if self.licence() or not self.device:
            return
        try:
            data = self._post("/v1/trial", {})
        except Exception as exc:
            log.info("trial registration offline: %s", exc)
            return
        token = data.get("trial")
        p = self._verify(token) if token else None
        if p and p.get("kind") == "trial" and p.get("device") == self.device:
            with self.lock:
                stored = self._load()
                stored["trial"] = token
                self._save(stored)

    def recheck(self):
        """Weekly: is the licence still on this device (or was it moved to another one)?"""
        token = self.licence_token()
        if not token:
            return
        try:
            data = self._post("/v1/check", {"licence": token})
        except Exception as exc:
            log.info("licence check offline: %s", exc)
            return
        with self.lock:
            stored = self._load()
            if data.get("ok"):
                stored["checkedAt"] = self.clock()
                self.last_error = ""
            elif data.get("error") in ("moved", "revoked"):
                log.warning("licence %s on this device", data.get("error"))
                stored.pop("licence", None)
                self.last_error = data["error"]
            self._save(stored)

    def start(self):
        if self.thread:
            return

        def loop():
            time.sleep(20)
            while True:
                try:
                    if self.licence():
                        if self.clock() - float(self._load().get("checkedAt", 0)) > RECHECK_EVERY:
                            self.recheck()
                    else:
                        self.register_trial()
                except Exception as exc:   # never let the licence thread die
                    log.warning("licence loop: %s", exc)
                time.sleep(6 * 3600)

        self.thread = threading.Thread(target=loop, name="licence", daemon=True)
        self.thread.start()
