"""Online updates: DX Zaza checks by itself for a new version and installs it with one button.

Where updates come from
  The public GitHub repository chefemanuele-maker/dx-zaza-updates holds, for every version, the
  installers / bundles (files/<version>/) plus `latest.json` (what the newest version is and the
  SHA-256 of each file) and `latest.json.sig` (Ed25519 signature of latest.json). The app reads
      https://raw.githubusercontent.com/<repo>/main/latest.json   (+ .sig)

Why it is safe
  The signature is made with the DX Zaza private key, which never leaves the publisher. The app
  checks it against the public key below before trusting anything in the manifest, then checks the
  SHA-256 of the downloaded file against the signed manifest. A tampered or fake update is refused.
  Updates are never offered for a version older than or equal to the one installed.

What "install" does
  windows  runs the new Setup.exe silently in the same place and starts DX Zaza again
  pi       hands the verified bundle to the root-owned helper (/usr/local/sbin/dx-zaza-online-update),
           which checks the signature again and runs the usual update script (backup, health check,
           automatic rollback)
  mac      not yet (shows the notice only when a Mac package is published)

Never while on air: install is refused while the voice engine is linked or transmitting.
"""
import base64
import hashlib
import json
import logging
import os
import re
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

import requests

from services import ed25519
from services.platform_service import detect_platform, os_name, user_data_dir

log = logging.getLogger("dx_zaza.update")

# public half of the DX Zaza update signing key (the private half stays with the publisher)
PUBLIC_KEY_B64 = "m7utnL/j8vS/kcHiCKZb1vVCCN8wBbzICoysuaPcZps="
DEFAULT_REPO = "chefemanuele-maker/dx-zaza-updates"
CHECK_EVERY = 6 * 3600
FIRST_CHECK_DELAY = 40
RETRY_AFTER_ERROR = 30 * 60
MAX_DOWNLOAD = 300 * 1024 * 1024
PI_HELPER = "/usr/local/sbin/dx-zaza-online-update"
VERSION_RE = re.compile(r"(\d+)\.(\d+)\.(\d+)")


def parse_version(text):
    match = VERSION_RE.search(str(text or ""))
    return tuple(int(part) for part in match.groups()) if match else None


def is_newer(candidate, current):
    new, old = parse_version(candidate), parse_version(current)
    return bool(new and old and new > old)


def platform_key():
    system = os_name()
    if system == "windows":
        return "windows"
    if system == "macos":
        return None   # Mac: one-button install not built yet (needs a signed, notarized app)
    if detect_platform() == "pi":
        return "pi"
    return None


def verify_manifest(raw, signature_text, public_key_b64=PUBLIC_KEY_B64):
    """Return the manifest dict when the signature is valid, otherwise raise ValueError."""
    try:
        signature = base64.b64decode((signature_text or "").strip(), validate=True)
        public_key = base64.b64decode(public_key_b64, validate=True)
    except (ValueError, TypeError):
        raise ValueError("bad signature format")
    if not ed25519.verify(public_key, raw, signature):
        raise ValueError("signature check failed")
    manifest = json.loads(raw.decode("utf-8"))
    if not isinstance(manifest, dict) or manifest.get("product") != "dx-zaza" or not parse_version(manifest.get("version")):
        raise ValueError("not a DX Zaza manifest")
    return manifest


class UpdateService:
    def __init__(self, get_config, current_version, busy_check=None, session=None, clock=time.time,
                 platform=None, work_dir=None, launcher=None, exit_app=None, public_key=PUBLIC_KEY_B64,
                 licence=None):
        self.get_config = get_config
        # with a licence service, updates come from the DX Zaza licence server, for licensed devices only
        self.licence = licence
        self.public_key = public_key
        self.current_version = current_version
        self.busy_check = busy_check
        self.session = session or requests.Session()
        self.clock = clock
        self.platform = platform if platform is not None else platform_key()
        self.work_dir = Path(work_dir) if work_dir else None
        self.launcher = launcher or self._launch
        self.exit_app = exit_app or (lambda: os._exit(0))
        self.lock = threading.Lock()
        self.state = "idle"          # idle | checking | current | available | downloading | installing | error
        self.manifest = None
        self.raw = b""
        self.signature = ""
        self.error = ""
        self.progress = 0
        self.checked_at = 0.0
        self.thread = None

    # ------------------------------------------------------------ settings
    def settings(self):
        cfg = (self.get_config() or {}).get("updates") or {}
        return {
            "enabled": cfg.get("enabled", True) is not False,
            "repo": str(cfg.get("repo") or DEFAULT_REPO),
            "manifestUrl": str(cfg.get("manifestUrl") or os.environ.get("DX_ZAZA_UPDATE_URL") or ""),
        }

    def manifest_url(self):
        s = self.settings()
        return s["manifestUrl"] or "https://raw.githubusercontent.com/%s/main/latest.json" % s["repo"]

    def _user_agent(self):
        return "DXZaza/%s (+update-check)" % self.current_version()

    # ------------------------------------------------------------ checking
    def check(self):
        if not self.platform or not self.settings()["enabled"]:
            return self.status()
        with self.lock:
            if self.state in ("downloading", "installing", "checking"):
                return self._status_locked()
            self.state = "checking"
        if self.licence is not None and not self.licence.licence_token():
            with self.lock:
                self.state, self.error, self.checked_at = "unlicensed", "", self.clock()
            return self.status()
        url = self.manifest_url()
        try:
            headers = {"User-Agent": self._user_agent(), "Cache-Control": "no-cache"}
            if self.licence is not None:
                res = self.session.post(self.licence.server + "/v1/update/manifest", headers=headers, timeout=(6, 20),
                                        json={"licence": self.licence.licence_token(), "device": self.licence.device,
                                              "platform": self.platform, "version": self.current_version()})
                data = res.json()
                if not data.get("ok"):
                    if data.get("error") in ("moved", "revoked"):
                        self.licence.recheck()
                    raise RuntimeError(data.get("error") or "refused")
                raw, sig_text = data["manifest"].encode("utf-8"), data["signature"]
            else:
                res = self.session.get(url, headers=headers, timeout=(6, 20))
                res.raise_for_status()
                raw = res.content
                sig = self.session.get(url + ".sig", headers=headers, timeout=(6, 20))
                sig.raise_for_status()
                sig_text = sig.text
            manifest = verify_manifest(raw, sig_text, self.public_key)
        except Exception as exc:   # network down, 404 before the first release, bad signature
            log.warning("update check failed: %s", exc)
            with self.lock:
                self.state = "error" if self.manifest is None else self._available_state(self.manifest)
                self.error = "check: %s" % exc
                self.checked_at = self.clock()
            return self.status()
        with self.lock:
            self.manifest, self.raw, self.signature = manifest, raw, sig_text.strip()
            self.state = self._available_state(manifest)
            self.error = ""
            self.checked_at = self.clock()
        if self.state == "available":
            log.info("update available: %s -> %s", self.current_version(), manifest.get("version"))
        return self.status()

    def _asset(self, manifest):
        asset = ((manifest or {}).get("platforms") or {}).get(self.platform)
        if not isinstance(asset, dict) or not asset.get("url") or not re.fullmatch(r"[0-9a-f]{64}", str(asset.get("sha256", ""))):
            return None
        return asset

    def _available_state(self, manifest):
        if is_newer(manifest.get("version"), self.current_version()) and self._asset(manifest):
            return "available"
        return "current"

    def start(self):
        if self.thread or not self.platform:
            return

        def loop():
            time.sleep(FIRST_CHECK_DELAY)
            while True:
                self.check()
                time.sleep(RETRY_AFTER_ERROR if self.state == "error" else CHECK_EVERY)

        self.thread = threading.Thread(target=loop, name="update-check", daemon=True)
        self.thread.start()

    # ------------------------------------------------------------ status
    def status(self):
        with self.lock:
            return self._status_locked()

    def _status_locked(self):
        manifest = self.manifest or {}
        lang = (((self.get_config() or {}).get("ui") or {}).get("language") or "en")
        notes = manifest.get("notes") or {}
        if isinstance(notes, dict):
            notes = notes.get(lang) or notes.get("en") or ""
        asset = self._asset(manifest) or {}
        busy = self._busy_reason() if self.state == "available" else None
        return {
            "ok": True,
            "supported": bool(self.platform),
            "platform": self.platform,
            "current": self.current_version(),
            "state": self.state,
            "latest": manifest.get("version", ""),
            "notes": str(notes)[:2000],
            "size": asset.get("size", 0),
            "progress": self.progress,
            "error": self.error,
            "busy": busy or "",
            "checkedAgoMin": int((self.clock() - self.checked_at) / 60) if self.checked_at else None,
        }

    def _busy_reason(self):
        if not self.busy_check:
            return None
        try:
            return self.busy_check()
        except Exception:   # pragma: no cover
            return None

    # ------------------------------------------------------------ install
    def install(self):
        with self.lock:
            if self.state != "available":
                return {"ok": False, "error": "No update to install."}
            busy = self._busy_reason()
            if busy:
                return {"ok": False, "error": busy}
            self.state, self.progress, self.error = "downloading", 0, ""
            manifest = self.manifest
        threading.Thread(target=self._install, args=(manifest,), name="update-install", daemon=True).start()
        return {"ok": True, "state": "downloading"}

    def _folder(self):
        if self.work_dir:
            folder = self.work_dir
        elif self.platform == "windows":
            folder = Path(tempfile.gettempdir()) / "DXZaza-update"
        else:
            folder = user_data_dir() / "updates"
        folder.mkdir(parents=True, exist_ok=True)
        return folder

    def _install(self, manifest):
        try:
            asset = self._asset(manifest)
            folder = self._folder()
            name = os.path.basename(str(asset.get("file") or asset["url"].rsplit("/", 1)[-1])) or "update.bin"
            target = folder / name
            self._download(asset, target)
            with self.lock:
                self.state, self.progress = "installing", 100
            (folder / "latest.json").write_bytes(self.raw)
            (folder / "latest.json.sig").write_text(self.signature + "\n")
            self.launcher(self.platform, target, folder, manifest)
        except Exception as exc:
            log.error("update install failed: %s", exc)
            with self.lock:
                self.state, self.error = "available", "install: %s" % exc

    def _download(self, asset, target):
        expected = asset["sha256"]
        size = int(asset.get("size") or 0)
        digest = hashlib.sha256()
        done = 0
        partial = target.with_name(target.name + ".part")
        url, headers = asset["url"], {"User-Agent": self._user_agent()}
        if url.startswith("/") and self.licence is not None:          # file on the licence server
            url = self.licence.server + url
            headers.update({"X-DXZ-Licence": self.licence.licence_token(), "X-DXZ-Device": self.licence.device})
        with self.session.get(url, headers=headers, stream=True, timeout=(8, 60)) as res:
            res.raise_for_status()
            total = size or int(res.headers.get("Content-Length") or 0)
            with partial.open("wb") as handle:
                for chunk in res.iter_content(256 * 1024):
                    if not chunk:
                        continue
                    done += len(chunk)
                    if done > MAX_DOWNLOAD:
                        raise ValueError("download too large")
                    digest.update(chunk)
                    handle.write(chunk)
                    if total:
                        with self.lock:
                            self.progress = min(99, int(done * 100 / total))
        if digest.hexdigest() != expected:
            partial.unlink(missing_ok=True)
            raise ValueError("downloaded file does not match the signed checksum")
        os.replace(partial, target)

    def _launch(self, platform, target, folder, manifest):
        if platform == "windows":
            self._launch_windows(target)
        elif platform == "pi":
            self._launch_pi(folder, target)
        else:
            raise RuntimeError("automatic install is not available on this system yet")

    def _launch_windows(self, installer):
        """Start the new Setup.exe so that it outlives DX Zaza, then close DX Zaza.

        The installer is created by Windows' own WMI service (Win32_Process.Create), so it is not a
        child of DX Zaza and is not closed with it. Inno Setup closes what is left of DX Zaza
        (/CLOSEAPPLICATIONS), installs in the same place and starts it again (/RELAUNCH=1).
        """
        if not getattr(sys, "frozen", False):
            raise RuntimeError("only the installed app can update itself")
        exe = Path(sys.executable)
        local = os.environ.get("LOCALAPPDATA", "")
        scope = "/CURRENTUSER" if local and str(exe).lower().startswith(local.lower()) else "/ALLUSERS"
        setup_log = Path(installer).with_name("install.log")
        command = ('"%s" /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /CLOSEAPPLICATIONS %s /RELAUNCH=1 /LOG="%s"'
                   % (installer, scope, setup_log))
        no_window = 0x08000000
        quoted = command.replace("'", "''")
        script = ("$r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create "
                  "-Arguments @{CommandLine='%s'}; exit [int]$r.ReturnValue" % quoted)
        started = False
        try:
            result = subprocess.run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
                                    capture_output=True, text=True, timeout=60, creationflags=no_window)
            started = result.returncode == 0
            if not started:
                log.warning("WMI start of the installer failed (%s): %s", result.returncode,
                            (result.stderr or result.stdout).strip()[-300:])
        except (OSError, subprocess.SubprocessError) as exc:
            log.warning("WMI start of the installer failed: %s", exc)
        if not started:
            # fallback: our own child, asked to leave DX Zaza's job so it survives the exit
            args = [str(installer), "/VERYSILENT", "/SUPPRESSMSGBOXES", "/NORESTART", "/CLOSEAPPLICATIONS", scope,
                    "/RELAUNCH=1", "/LOG=%s" % setup_log]
            base = 0x00000008 | 0x00000200                   # DETACHED_PROCESS | NEW_PROCESS_GROUP
            try:
                subprocess.Popen(args, creationflags=base | 0x01000000, close_fds=True)   # + BREAKAWAY_FROM_JOB
            except OSError:
                subprocess.Popen(args, creationflags=base, close_fds=True)
        log.info("installer started (%s), closing DX Zaza for the update", "wmi" if started else "direct")
        threading.Timer(1.5, self.exit_app).start()

    def _launch_pi(self, folder, bundle):
        if not os.path.exists(PI_HELPER):
            raise RuntimeError("update helper missing: install this version once with the normal update")
        result = subprocess.run(["sudo", "-n", PI_HELPER, str(folder), bundle.name],
                                capture_output=True, text=True, timeout=120)
        if result.returncode != 0:
            raise RuntimeError((result.stderr or result.stdout or "helper failed").strip()[-300:])
        log.info("Raspberry Pi update started: %s", result.stdout.strip()[-200:])


def voice_busy_reason(engine_status):
    """Reason not to update now (on air / linked), or None."""
    status = engine_status() if callable(engine_status) else None
    if not status:
        return None
    tx = status.get("tx") or {}
    if tx.get("active") or tx.get("on") or tx.get("state") in ("tx", "transmitting"):
        return "Transmitting: the update will be possible when you finish."
    if status.get("rx"):
        return "Receiving a station: try again in a moment."
    if (status.get("link") or {}).get("state") == "linked":
        return "Disconnect from the reflector / talkgroup first."
    return None
